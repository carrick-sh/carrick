//! Process-lifecycle syscall dispatch tests.
//!
//! Split out of the former tests/syscall_dispatch.rs monolith. Shared imports,
//! constants, and helpers live in the kernel suite's
//! `tests/integration/common/syscall_support.rs`, included below.

#[path = "../../carrick-kernel/tests/integration/common/syscall_support.rs"]
mod support;

use support::*;

#[test]
fn exit_syscall_requests_process_exit() {
    let mut memory = LinearMemory::new(0x4000, Vec::new());
    let reporter = CompatReporter::default();
    let mut dispatcher = SyscallDispatcher::new();

    let outcome = dispatcher
        .dispatch(
            &dispatcher.capture_one_task_context().unwrap(),
            SyscallRequest::new(93, SyscallArgs::from([42, 0, 0, 0, 0, 0])),
            &mut memory,
            &reporter,
        )
        .unwrap();

    assert_eq!(outcome, DispatchOutcome::Exit { code: 42 });
    assert!(reporter.finish().unhandled_syscalls.is_empty());
}

#[test]
fn exit_group_syscall_requests_process_exit() {
    let mut memory = LinearMemory::new(0x4000, Vec::new());
    let reporter = CompatReporter::default();
    let mut dispatcher = SyscallDispatcher::new();

    let outcome = dispatcher
        .dispatch(
            &dispatcher.capture_one_task_context().unwrap(),
            SyscallRequest::new(94, SyscallArgs::from([7, 0, 0, 0, 0, 0])),
            &mut memory,
            &reporter,
        )
        .unwrap();

    assert_eq!(outcome, DispatchOutcome::Exit { code: 7 });
    assert!(reporter.finish().unhandled_syscalls.is_empty());
}

#[test]
fn unknown_syscall_returns_enosys_and_records_report_entry() {
    let mut memory = LinearMemory::new(0x4000, Vec::new());
    let reporter = CompatReporter::default();
    let mut dispatcher = SyscallDispatcher::new();

    let outcome = dispatcher
        .dispatch(
            &dispatcher.capture_one_task_context().unwrap(),
            SyscallRequest::new(9999, SyscallArgs::from([1, 2, 3, 4, 5, 6])),
            &mut memory,
            &reporter,
        )
        .unwrap();

    assert_eq!(
        outcome,
        DispatchOutcome::Errno {
            errno: LinuxErrno::new(38)
        }
    );
    let report = reporter.finish();
    assert_eq!(report.unhandled_syscalls[0].number, 9999);
    assert_eq!(report.unhandled_syscalls[0].name, "unknown");
    assert_eq!(report.unhandled_syscalls[0].count, 1);
}

#[test]
fn syscall_request_can_be_built_from_a_raw_syscall() {
    // The per-ISA register decode lives behind `GuestArch::decode_syscall`
    // (covered by carrick-hal's aarch64 tests); the dispatcher consumes the
    // ISA-neutral `RawSyscall`.
    let raw = carrick_hal::RawSyscall {
        current_guest_sp: None,
        number: carrick_abi::CanonicalNr(64),
        args: [1, 0x4000, 17, 0, 0, 0],
        guest_abi: carrick_abi::LinuxGuestAbi::Aarch64,
        native_number: carrick_abi::NativeNr(64),
    };

    assert_eq!(
        SyscallRequest::from_raw(raw),
        SyscallRequest::new(64, SyscallArgs::from([1, 0x4000, 17, 0, 0, 0]))
    );
}

#[test]
fn getrandom_fills_guest_buffer() {
    let mut memory = LinearMemory::new(0x4000, vec![0; 32]);
    let reporter = CompatReporter::default();
    let mut dispatcher = SyscallDispatcher::new();

    assert_eq!(
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(278, SyscallArgs::from([0x4000, 16, 0, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .unwrap(),
        DispatchOutcome::Returned { value: 16 }
    );
    assert!(
        memory
            .read_bytes(0x4000, 16)
            .unwrap()
            .iter()
            .any(|byte| *byte != 0)
    );
    assert!(reporter.finish().unhandled_syscalls.is_empty());
}

#[test]
fn privileged_op_stubs_return_eperm() {
    let mut memory = LinearMemory::new(0x4000, vec![0; 0x100]);
    let reporter = CompatReporter::default();
    let mut dispatcher = SyscallDispatcher::new();

    // reboot / sethostname / setdomainname / settimeofday → EPERM.
    for number in [142_u64, 161, 162, 170] {
        assert_eq!(
            dispatcher
                .dispatch(
                    &dispatcher.capture_one_task_context().unwrap(),
                    SyscallRequest::new(number, SyscallArgs::from([0, 0, 0, 0, 0, 0])),
                    &mut memory,
                    &reporter,
                )
                .unwrap(),
            DispatchOutcome::Errno {
                errno: LinuxErrno::new(1)
            },
            "syscall {number} should return EPERM"
        );
    }

    assert!(reporter.finish().unhandled_syscalls.is_empty());
}

/// Job-control queries answer from carrick's own kernel, not from Darwin.
///
/// This test used to assert the opposite — that `getpgid(0)`/`getsid(0)` equal
/// `libc::getpgid(0)`/`libc::getsid(0)` — which was true only while a Linux
/// process WAS a host process. Under HVPatch every guest process is a thread of
/// one carrier, so the host answer is a single number shared by all of them, and
/// the guest saw its Mac shell's five-digit group. The per-process behaviour
/// needs more than one task to observe at all; that lives in
/// `dispatch::proc::process_identity_dispatch_tests`. What is left here is the
/// single-process half: the guest identity relation and the argument validation.
#[test]
fn job_control_queries_answer_from_the_kernel_graph() {
    let mut memory = LinearMemory::new(0x4000, vec![0; 0x80]);
    let reporter = CompatReporter::default();
    let mut dispatcher = SyscallDispatcher::new();

    assert_eq!(
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(154, SyscallArgs::from([99, 0, 0, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .unwrap(),
        DispatchOutcome::Errno {
            errno: LinuxErrno::new(3)
        }
    );
    assert_eq!(
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(154, SyscallArgs::from([0, (-1_i64) as u64, 0, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .unwrap(),
        DispatchOutcome::Errno {
            errno: LinuxErrno::new(22)
        }
    );
    // The bootstrap process leads its own group and session, so Linux's
    // `getpid() == getpgid(0) == getsid(0)` relation holds for it. Asserting the
    // relation rather than a number is the point: a host-backed answer breaks it
    // the instant carrick's pid space stops coinciding with Darwin's.
    let guest_pid = dispatcher
        .dispatch(
            &dispatcher.capture_one_task_context().unwrap(),
            SyscallRequest::new(172, SyscallArgs::from([0; 6])),
            &mut memory,
            &reporter,
        )
        .unwrap();
    assert_eq!(
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(155, SyscallArgs::from([0, 0, 0, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .unwrap(),
        guest_pid
    );
    assert_eq!(
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(155, SyscallArgs::from([99, 0, 0, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .unwrap(),
        DispatchOutcome::Errno {
            errno: LinuxErrno::new(3)
        }
    );
    assert_eq!(
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(156, SyscallArgs::from([0, 0, 0, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .unwrap(),
        guest_pid
    );
    assert_eq!(
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(156, SyscallArgs::from([99, 0, 0, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .unwrap(),
        DispatchOutcome::Errno {
            errno: LinuxErrno::new(3)
        }
    );

    assert!(reporter.finish().unhandled_syscalls.is_empty());
}

#[test]
fn unhandled_named_syscall_surfaces_by_name_in_compat_report() {
    // A syscall that IS known in the aarch64 name table but has no handler in
    // the normalized dispatch table returns ENOSYS and surfaces in the compat
    // report under its REAL name (not "unknown" — that path is covered by
    // `unknown_syscall_returns_enosys_and_records_report_entry`).
    //
    // lookup_dcookie(18) is such a syscall today: it's in the aarch64 name
    // table but Linux removed it, so carrick will never give it a handler (it
    // falls through to the unimplemented catch-all → ENOSYS). The original
    // version of this test listed clone(220)/execve(221)/clone3(435)/
    // execveat(281), but those all gained real handlers, so they no longer
    // report ENOSYS. If lookup_dcookie ever gains a handler (it won't), point
    // this at the next still-unimplemented named syscall.
    let mut memory = LinearMemory::new(0x4000, vec![0; 0x80]);
    let reporter = CompatReporter::default();
    let mut dispatcher = SyscallDispatcher::new();

    let outcome = dispatcher
        .dispatch(
            &dispatcher.capture_one_task_context().unwrap(),
            SyscallRequest::new(18, SyscallArgs::from([0, 0, 0, 0, 0, 0])),
            &mut memory,
            &reporter,
        )
        .unwrap();
    assert_eq!(
        outcome,
        DispatchOutcome::Errno {
            errno: LinuxErrno::new(38)
        }
    );

    let report = reporter.finish();
    // lookup_dcookie(18) is a number the aarch64 table recognises (Deferred),
    // so it surfaces in the `deferred_syscalls` bucket — "recognised, not yet
    // emulated" — under its real name, NOT in `unhandled_syscalls` (which is
    // reserved for genuinely unknown numbers like 9999).
    assert!(
        report.unhandled_syscalls.iter().all(|e| e.number != 18),
        "recognised syscalls must not land in the truly-unknown bucket",
    );
    let entry = report
        .deferred_syscalls
        .iter()
        .find(|entry| entry.number == 18)
        .expect("lookup_dcookie should surface as a deferred syscall in the compat report");
    assert_eq!(entry.name, "lookup_dcookie");
    assert_eq!(entry.count, 1);
}

#[test]
fn seccomp_filter_blocks_the_targeted_syscall_with_errno() {
    // Install (via the real seccomp(2) syscall) the canonical libseccomp-style
    // filter "deny getpid(172) with EPERM, allow everything else", then confirm
    // the dispatcher enforces it before the handler runs.
    const BPF_LD_W_ABS: u16 = 0x20;
    const BPF_JMP_JEQ: u16 = 0x15;
    const BPF_RET_K: u16 = 0x06;
    const SECCOMP_RET_ERRNO: u32 = 0x0005_0000;
    const SECCOMP_RET_ALLOW: u32 = 0x7fff_0000;

    let mut memory = LinearMemory::new(0x4000, vec![0; 0x400]);
    let reporter = CompatReporter::default();
    let mut dispatcher = SyscallDispatcher::new();

    let write_insn = |m: &mut LinearMemory, addr: u64, code: u16, jt: u8, jf: u8, k: u32| {
        let mut b = [0u8; 8];
        b[0..2].copy_from_slice(&code.to_ne_bytes());
        b[2] = jt;
        b[3] = jf;
        b[4..8].copy_from_slice(&k.to_ne_bytes());
        m.write_bytes(addr, &b).unwrap();
    };
    // Filter program @0x4020: LD nr; JEQ 172 -> RET ERRNO|EPERM else RET ALLOW.
    write_insn(&mut memory, 0x4020, BPF_LD_W_ABS, 0, 0, 0);
    write_insn(&mut memory, 0x4028, BPF_JMP_JEQ, 0, 1, 172);
    write_insn(&mut memory, 0x4030, BPF_RET_K, 0, 0, SECCOMP_RET_ERRNO | 1);
    write_insn(&mut memory, 0x4038, BPF_RET_K, 0, 0, SECCOMP_RET_ALLOW);
    // struct sock_fprog @0x4000: len=4 @0, filter ptr=0x4020 @8.
    memory.write_bytes(0x4000, &4u16.to_ne_bytes()).unwrap();
    memory
        .write_bytes(0x4008, &0x4020u64.to_ne_bytes())
        .unwrap();

    let run = |d: &mut SyscallDispatcher, m: &mut LinearMemory, nr: u64, args: [u64; 6]| {
        d.dispatch(
            &d.capture_one_task_context().unwrap(),
            SyscallRequest::new(nr, SyscallArgs::from(args)),
            m,
            &reporter,
        )
        .unwrap()
    };

    // getpid before the filter is installed -> a real pid.
    assert!(matches!(
        run(&mut dispatcher, &mut memory, 172, [0; 6]),
        DispatchOutcome::Returned { value } if value > 0
    ));

    // PR_SET_NO_NEW_PRIVS (38) is required before SECCOMP_SET_MODE_FILTER.
    assert_eq!(
        run(&mut dispatcher, &mut memory, 167, [38, 1, 0, 0, 0, 0]),
        DispatchOutcome::Returned { value: 0 }
    );

    // seccomp(SECCOMP_SET_MODE_FILTER=1, flags=0, &fprog) -> 0.
    assert_eq!(
        run(&mut dispatcher, &mut memory, 277, [1, 0, 0x4000, 0, 0, 0]),
        DispatchOutcome::Returned { value: 0 }
    );

    // getpid(172) is now denied with EPERM (1); getppid(173) still works.
    assert_eq!(
        run(&mut dispatcher, &mut memory, 172, [0; 6]),
        DispatchOutcome::Errno {
            errno: LinuxErrno::new(1)
        }
    );
    assert!(matches!(
        run(&mut dispatcher, &mut memory, 173, [0; 6]),
        DispatchOutcome::Returned { value } if value >= 0
    ));
}

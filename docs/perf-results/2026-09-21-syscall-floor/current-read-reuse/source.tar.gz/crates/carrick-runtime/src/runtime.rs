//! The run lifecycle: load an image, drive the trap→dispatch→complete loop, and
//! own the process/thread, signal-delivery, and fault-handling models.
//!
//! # The loop
//!
//! Every `run_*` entry point converges on [`finish_and_run_image`], which
//! finalises a loaded [`AddressSpace`] (EL0 trampoline → EL1 vectors → stage-1
//! page tables → vDSO) and enters the trap engine. The core of the runtime is a
//! tight loop:
//!
//! 1. `next_syscall` runs the vCPU (`hv_vcpu_run`) until the guest executes
//!    `svc #0`, faults synchronously at EL0, or is forced out by a cross-thread
//!    kick.
//! 2. The trapped frame (`x8` = syscall number, `x0..x5` = args) is handed to
//!    the [`SyscallDispatcher`], which emulates it against Darwin host
//!    primitives and returns a [`DispatchOutcome`].
//! 3. The loop acts on the outcome — write the return value into `x0` and resume
//!    (`Returned`/`Errno`), block on host fds and re-dispatch on readiness
//!    (`WaitOn*`), create or retire a logical process or thread
//!    (`Fork`/`CloneThread`/`Execve`/`Exit`), or pop a signal frame (`SigReturn`).
//! 4. Between syscalls it delivers any pending signal ([`deliver_pending_signal`]).
//!
//! There are **two** loop implementations:
//!
//! - **Single-threaded fixture loop** ([`run_combined_syscall_loop_with_dispatcher`],
//!   and its split-view sibling [`run_split_loop`]): one vCPU, no thread
//!   registry. Retained only as a deterministic syscall/memory fixture for the
//!   in-process test harnesses and `run-elf`. It runs exactly one logical
//!   process: a guest `fork(2)` here lowers to `EOPNOTSUPP`.
//! - **HVPatch unified kernel loop** ([`run_threaded_hvf_loop`] →
//!   `threaded_loop::run_threaded_loop` → `vcpu_loop::run_vcpu_until_exit`):
//!   every Linux process and thread of the container is a logical task in
//!   Carrick's kernel graph, multiplexed inside ONE host process (the carrier)
//!   and ONE HVF VM. Each logical guest thread has a host pthread, but HVF
//!   vCPUs are a bounded, reclaimable set of leases (`carrick_hal::vcpu_sched`).
//!   Shared kernel state lives behind [`KernelState`](crate::vcpu_loop::KernelState)
//!   (an `Arc`, each subsystem internally synchronised — there is no single big
//!   lock). This is the path every product run takes (Go, CPython, Node,
//!   apt/dpkg).
//!
//! Both loops produce a [`RunResult`] (exit code + captured stdio + the
//! [`CompatReport`](crate::compat::CompatReport)).
//!
//! # The process/thread model
//!
//! No guest operation creates a host process. macOS HVF allows one VM per host
//! process (a second `hv_vm_create` returns `HV_BUSY`), and the kernel graph
//! makes that irrelevant:
//!
//! - **`clone(2)` that creates a thread** (`CLONE_VM`):
//!   [`DispatchOutcome::CloneThread`] spawns a host thread that acquires a vCPU
//!   lease in the *same* VM and runs `run_vcpu_until_exit`.
//! - **`fork(2)` / `vfork(2)` / process-creating `clone(2)`**:
//!   [`DispatchOutcome::Fork`] is a logical kernel-graph fork
//!   (`prepare_in_process_fork` → `complete_persistent_process_fork` in
//!   `vcpu_loop`): the child gets its own mm, pid, credentials and wait edges
//!   inside the carrier, COW-armed private pages, and a fresh logical thread.
//!   Process-fork admission must win before the child waits for a vCPU lease,
//!   and fork participates in exec/exit cancellation.
//! - **`execve(2)`**: [`DispatchOutcome::Execve`] tears down the task's address
//!   space and reloads the new ELF in place; the host process is untouched.
//!
//! Orthogonal to fork, a stage-1 **page-table edit** (mmap/mprotect/munmap that
//! changes a mm's shared descriptors) is a lighter stop-the-world: `pt_pause`
//! (in `vcpu_loop`) kicks in-guest siblings of that mm out so none walks a
//! half-edited table, but *keeps* every vCPU alive. The handshake between an
//! editing coordinator and a vCPU about to enter the guest is a Dekker pattern
//! on `quiescing` ↔ `in_guest` (SeqCst), so neither side misses the other.
//!
//! # PID-namespace placement
//!
//! A container `carrick run` that requests PID-ns placement initializes the
//! kernel arena and namespace table directly in the one VM carrier. Guest
//! processes remain logical Carrick-kernel tasks; launch placement never forks
//! a host namespace-supervisor process. `run-elf` never requests placement, so
//! it stays in the identity namespace.
//!
//! # Faults are signals
//!
//! A synchronous guest EL0 fault (nil deref, bad access, `BRK`, single-step) is
//! not fatal to carrick: [`crate::vcpu_loop`]'s `deliver_fault_signal` maps the
//! `ESR_EL1`
//! to the Linux `(signum, si_code)` the kernel would deliver (SIGSEGV/SIGBUS/
//! SIGTRAP) and injects it into the guest, so Go's `sigpanic`/`recover`, glibc
//! backtraces, and any installed handler run exactly as on Linux.
//!
//! # Exit is an unwind, never `_exit`
//!
//! Because no guest exit is a host-process exit, every exit path of both loops
//! returns a [`RunResult`] and unwinds normally through `Drop`.
//!
//! [`AddressSpace`]: crate::memory::AddressSpace

use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use carrick_fatal::carrick_fatal;
use carrick_guest_mem::{Gpa, GuestVa, HostVa};

use crate::compat::CompatReporter;
use crate::linux_abi::LinuxErrno;
use crate::memory::{AddressSpace, AddressSpaceError};
use carrick_kernel::dispatch::rosetta::ROSETTA_INTERPRETER;
use carrick_kernel::dispatch::{
    CurrentMmMemory, DispatchOutcome, FdWaitCompletion, GuestMemory, MemoryError, PreparedDispatch,
    PreparedSyscall, SyscallCompletionToken, SyscallDispatcher, SyscallRequest,
};
use carrick_vfs::rootfs::RootFs;

// The EL0 synchronous-fault translation + the threaded vCPU loop were hoisted
// into the unconditional `crate::vcpu_loop` module (generic over
// `carrick_hal::ThreadedEngine`). The single-threaded loop below still uses the
// forked-child / execve helpers in `exec`, so that submodule stays here; it is
// `pub(crate)` so `vcpu_loop` can reach the same helpers.
pub(crate) mod exec;
use crate::vcpu_loop::{
    apply_exec_image_proc_state, apply_image_proc_state, deliver_pending_signal,
    dispatch_with_panic_backstop, partial_write_interrupt_outcome,
    raise_sigpipe_for_blocking_write, signal_wait_expired, signal_wait_slice,
};
use carrick_kernel::kernel::identity_page::stamp_identity_page;
use exec::{load_execve_image, stop_after_traced_exec, stop_by_signal};

use crate::trap::{HvfTrapEngine, TrapError};
// `SyscallTrap`/`TrapError` live in the carrick-hal leaf crate
// and are re-exported through `carrick_vmm_hvf::trap` (re-exported here as
// `crate::trap`). Re-export `SyscallTrap` from this module too so the original
// `carrick_runtime::runtime::SyscallTrap` path (used by the runtime_loop tests
// and the engine crate) is unchanged.
pub use crate::trap::SyscallTrap;

// vDSO attach policy (`VdsoDebugMode`, `with_optional_vdso[_at]`,
// `vdso_enabled_for_debug`) and the `--debug-state-path` snapshot moved to the
// platform-NEUTRAL `carrick_kernel::vdso_policy` / `crate::debug_state` modules so the
// native backend resolves them on every host OS. Re-exported here so the
// original `crate::runtime::…` paths are unchanged on this arm.
pub(crate) use carrick_kernel::vdso_policy::{
    debug_env_flag_enabled, vdso_enabled_for_debug, with_optional_vdso_for_clock_with_visibility,
};

pub use crate::debug_state::{DebugRegionSnapshot, DebugStateSnapshot, maybe_dump_debug_state};

pub(crate) fn hardware_tso_for_debug(requested: bool) -> bool {
    requested && !debug_env_flag_enabled(std::env::var("CARRICK_DISABLE_TSO").ok().as_deref())
}

#[cfg(test)]
fn hardware_tso_for_debug_from_env(requested: bool, disable: Option<&str>) -> bool {
    requested && !debug_env_flag_enabled(disable)
}

// `SyscallTrap` (the trap-engine contract the loops drive) moved into
// carrick-vmm-hvf alongside `TrapError`/`HvfTrapEngine`. Re-exported
// from `crate::trap`; imported here via the `use crate::trap::{…}` below so
// `SplitView`/`HvfTrapEngine` impls and the loop bounds are unchanged.

// `RunResult` / `RuntimeError` / `TerminalReason` are kernel types
// (`carrick_kernel::run_result`, unified with the Linux KVM loop). This is a
// PRIVATE import: the carrier does not re-export a moved type, so every
// consumer — carrick-engine, carrick-cli, carrick-embed, the tests — names
// `carrick_kernel::run_result::…` and there is exactly one path to each type.
use carrick_kernel::run_result::{RunResult, RuntimeError, TerminalReason};

pub fn run_static_elf_with_hvf(
    path: impl AsRef<Path>,
    max_traps: usize,
) -> Result<RunResult, RuntimeError> {
    run_static_elf_with_hvf_and_dispatcher(
        path,
        SyscallDispatcher::with_bridges(crate::platform_bridges()),
        max_traps,
    )
}

pub fn run_static_elf_with_hvf_and_dispatcher(
    path: impl AsRef<Path>,
    dispatcher: SyscallDispatcher,
    max_traps: usize,
) -> Result<RunResult, RuntimeError> {
    let path = path.as_ref();
    let argv0 = canonical_host_executable_path(path);
    run_static_elf_with_hvf_args_and_dispatcher(
        path,
        dispatcher,
        [argv0],
        std::iter::empty(),
        max_traps,
    )
}

pub fn run_static_elf_with_hvf_args_and_dispatcher<A, E>(
    path: impl AsRef<Path>,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    run_static_elf_with_hvf_args_and_dispatcher_debug(path, dispatcher, argv, env, max_traps, None)
}

pub fn run_static_elf_with_hvf_args_and_dispatcher_debug<A, E>(
    path: impl AsRef<Path>,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    max_traps: usize,
    debug_state_path: Option<&PathBuf>,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    let path = path.as_ref();
    let argv: Vec<String> = argv.into_iter().collect();
    let env: Vec<String> = env.into_iter().collect();
    let identity = argv
        .first()
        .cloned()
        .unwrap_or_else(|| canonical_host_executable_path(path));
    dispatcher.set_executable_identity(
        identity,
        argv.clone(),
        env.iter().map(|s| s.as_bytes().to_vec()).collect(),
    );
    let file = std::fs::read(path).map_err(AddressSpaceError::Io)?;
    let launch_context = dispatcher.capture_one_task_context().map_err(|error| {
        RuntimeError::Unsupported(format!("capture static launch Kernel context: {error}"))
    })?;
    let loaded = dispatcher.with_kernel_credentials(&launch_context, || {
        AddressSpace::load_elf_bytes_with_reader(&file, &|p| {
            dispatcher
                .read_exec_file(p)
                .or_else(|| std::fs::read(p).ok())
        })
    });
    drop(launch_context);
    let image = loaded?
        .with_vdso_auxv(vdso_enabled_for_debug())
        .with_linux_initial_stack_page_size(
            argv,
            env,
            carrick_kernel::page_profile::DEFAULT_LINUX_PAGE_SIZE,
        )?;
    let requires_syscall_traps = dispatcher.requires_syscall_traps();
    finish_and_run_image(
        image,
        dispatcher,
        requires_syscall_traps,
        max_traps,
        debug_state_path,
    )
}

pub struct RunStaticElfBackendOptions<'a> {
    pub max_traps: usize,
    pub debug_state_path: Option<&'a PathBuf>,
    pub exec_backend: carrick_spec::ExecBackendRequest,
}

pub fn run_static_elf_with_backend_args_and_dispatcher_debug<A, E>(
    path: impl AsRef<Path>,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    options: RunStaticElfBackendOptions<'_>,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    let plan = carrick_kernel::page_profile::resolve_execution_plan_for_request(
        carrick_spec::Platform::host_native(),
        options.exec_backend,
    )?;
    // Kept for its capability check: it refuses a non-macOS/AArch64 lane
    // before the guest is built. HVPatch is the only backend, so the plan
    // carries no selection any more.
    let _plan = plan;
    crate::hvpatch::run_static_hvpatch(
        path.as_ref(),
        dispatcher,
        argv,
        env,
        options.max_traps,
        options.debug_state_path,
    )
}

fn canonical_host_executable_path(path: &Path) -> String {
    path.canonicalize()
        .unwrap_or_else(|_| path.to_path_buf())
        .to_string_lossy()
        .into_owned()
}

pub fn run_static_elf_bytes_with_hvf_and_dispatcher(
    bytes: &[u8],
    dispatcher: SyscallDispatcher,
    max_traps: usize,
) -> Result<RunResult, RuntimeError> {
    let image = AddressSpace::load_elf_bytes(bytes)?;
    let requires_syscall_traps = dispatcher.requires_syscall_traps();
    finish_and_run_image(image, dispatcher, requires_syscall_traps, max_traps, None)
}

pub fn run_static_elf_bytes_with_hvf_args_and_dispatcher<A, E>(
    bytes: &[u8],
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    let argv: Vec<String> = argv.into_iter().collect();
    let env: Vec<String> = env.into_iter().collect();
    if let Some(first) = argv.first() {
        dispatcher.set_executable_identity(
            first.clone(),
            argv.clone(),
            env.iter().map(|s| s.as_bytes().to_vec()).collect(),
        );
    }
    let image = AddressSpace::load_elf_bytes(bytes)?
        .with_vdso_auxv(vdso_enabled_for_debug())
        .with_linux_initial_stack_page_size(
            argv,
            env,
            carrick_kernel::page_profile::DEFAULT_LINUX_PAGE_SIZE,
        )?;
    let requires_syscall_traps = dispatcher.requires_syscall_traps();
    finish_and_run_image(image, dispatcher, requires_syscall_traps, max_traps, None)
}

pub fn run_rootfs_elf_with_hvf_args_and_dispatcher<A, E>(
    path: impl AsRef<Path>,
    rootfs: &RootFs,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    run_rootfs_elf_with_hvf_args_and_dispatcher_debug(
        path, rootfs, dispatcher, argv, env, max_traps, None,
    )
}

pub fn run_rootfs_elf_with_hvf_args_and_dispatcher_debug<A, E>(
    path: impl AsRef<Path>,
    rootfs: &RootFs,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    max_traps: usize,
    debug_state_path: Option<&PathBuf>,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    run_rootfs_elf_with_hvf_args_and_dispatcher_debug_owned(
        path,
        rootfs,
        dispatcher,
        argv,
        env,
        RunRootfsElfExecutionOptions {
            max_traps,
            debug_state_path,
            ownership: None,
        },
    )
}

pub(crate) struct RunElfExecutionOptions<'a> {
    pub max_traps: usize,
    pub debug_state_path: Option<&'a PathBuf>,
    pub carrier: crate::carrier::CarrierRuntime,
    pub lease: crate::carrier::CarrierLease,
}

pub(crate) struct RunRootfsElfExecutionOptions<'a> {
    pub max_traps: usize,
    pub debug_state_path: Option<&'a PathBuf>,
    pub ownership: Option<(crate::carrier::CarrierRuntime, crate::carrier::CarrierLease)>,
}

#[cfg(feature = "fs-memory")]
pub(crate) fn run_rootfs_elf_with_hvf_args_and_dispatcher_debug_on<A, E>(
    path: impl AsRef<Path>,
    rootfs: &RootFs,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    options: RunElfExecutionOptions<'_>,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    run_rootfs_elf_with_hvf_args_and_dispatcher_debug_owned(
        path,
        rootfs,
        dispatcher,
        argv,
        env,
        RunRootfsElfExecutionOptions {
            max_traps: options.max_traps,
            debug_state_path: options.debug_state_path,
            ownership: Some((options.carrier, options.lease)),
        },
    )
}

fn run_rootfs_elf_with_hvf_args_and_dispatcher_debug_owned<A, E>(
    path: impl AsRef<Path>,
    rootfs: &RootFs,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    options: RunRootfsElfExecutionOptions<'_>,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    let RunRootfsElfExecutionOptions {
        max_traps,
        debug_state_path,
        ownership,
    } = options;
    let path = path.as_ref();
    let argv: Vec<String> = argv.into_iter().collect();
    let env: Vec<String> = env.into_iter().collect();
    dispatcher.set_executable_identity(
        path.to_string_lossy().into_owned(),
        argv.clone(),
        env.iter().map(|s| s.as_bytes().to_vec()).collect(),
    );
    // Read the main binary from the rootfs here (runtime layer); AddressSpace
    // resolves any PT_INTERP through the rootfs read-closure, staying
    // rootfs-agnostic so `memory` doesn't depend on `rootfs`.
    let file = rootfs.read(path)?;
    // Redirect x86_64 binaries through Rosetta 2 (binfmt_misc-style). Rosetta
    // is read from the host (not the rootfs); it is statically linked, so the
    // rootfs reader below is never asked for a Rosetta PT_INTERP.
    let path_str = path.to_string_lossy();
    // argv normalises to opaque bytes (Linux ABI) past this point so the rosetta
    // and non-rosetta arms share a type; with_linux_initial_stack accepts bytes.
    let mut needs_at_base = false;
    let (file, argv): (Vec<u8>, Vec<Vec<u8>>) =
        match maybe_redirect_to_rosetta(&path_str, &file, &argv) {
            None => (file, argv.into_iter().map(String::into_bytes).collect()),
            Some(Ok(redirect)) => {
                // Faithful binfmt: keep the target's identity (/proc/self/exe
                // stays the program); flag binfmt-interpreted (uname → x86_64) and
                // record the stack argv so /proc/self/cmdline survives Rosetta's
                // argv-skip. (redirect.argv is consumed for the stack below.)
                needs_at_base = redirect.target_is_dynamic;
                dispatcher.enter_binfmt(&redirect.argv);
                (redirect.interpreter_bytes, redirect.argv)
            }
            Some(Err(errno)) => return Err(rosetta_unavailable(errno, &path_str)),
        };
    let mut image = AddressSpace::load_elf_bytes_with_reader(&file, &|p| {
        rootfs.read(p).ok().or_else(|| std::fs::read(p).ok())
    })?
    .with_vdso_auxv(vdso_enabled_for_debug());
    if needs_at_base {
        image = image.with_auxv_base(ROSETTA_AT_BASE_PLACEHOLDER);
    }
    let image = image.with_linux_initial_stack_page_size(
        argv,
        env,
        carrick_kernel::page_profile::DEFAULT_LINUX_PAGE_SIZE,
    )?;
    let requires_syscall_traps = dispatcher.requires_syscall_traps();
    finish_and_run_image_owned(
        image,
        dispatcher,
        requires_syscall_traps,
        max_traps,
        debug_state_path,
        ownership,
    )
}

// `resolve_entrypoint_path` / `resolve_entrypoint_program` (Docker `execvp` PATH
// search + `#!` shebang resolution) were hoisted into the cross-platform
// `carrick_kernel::exec_helpers`, shared by the macOS HVF and Linux KVM `carrick run`
// paths — only the run-loop entry that consumes the assembled image differs.

/// Run an ELF whose filesystem is entirely in the dispatcher's overlay
/// (i.e. `--fs host` after `extract_layers`). The initial binary AND its
/// PT_INTERP are loaded via `dispatcher.read_exec_file` — the same
/// overlay-first reader used by the guest-runtime execve path — so no
/// in-memory `RootFs` is required.
pub(crate) fn run_elf_from_dispatcher_debug_on<A, E>(
    path: &str,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    options: RunElfExecutionOptions<'_>,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    run_elf_from_dispatcher_debug_owned(path, dispatcher, argv, env, options)
}

fn run_elf_from_dispatcher_debug_owned<A, E>(
    path: &str,
    dispatcher: SyscallDispatcher,
    argv: A,
    env: E,
    options: RunElfExecutionOptions<'_>,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    let RunElfExecutionOptions {
        max_traps,
        debug_state_path,
        carrier,
        lease,
    } = options;
    let argv: Vec<String> = argv.into_iter().collect();
    let env: Vec<String> = env.into_iter().collect();
    // Docker accepts a bare entrypoint command (`carrick run alpine ls`); resolve
    // it against $PATH like runc/execvp before loading. A name with '/' is left
    // as-is. Guest execve(2) is unaffected (it keeps full-path semantics).
    // PATH-resolve a bare command AND resolve `#!` shebang scripts to their
    // interpreter (Docker / execve(2) semantics) before loading, so a script
    // entrypoint runs instead of failing "not an ELF binary".
    let launch_context = dispatcher.capture_one_task_context().map_err(|error| {
        RuntimeError::Unsupported(format!("capture image launch Kernel context: {error}"))
    })?;
    let argv_for_cmdline = argv.clone();
    let argv_bytes: Vec<Vec<u8>> = argv.into_iter().map(String::into_bytes).collect();
    let resolved_entry = dispatcher.with_kernel_credentials(&launch_context, || {
        carrick_kernel::exec_helpers::resolve_entrypoint_program(
            path,
            &env,
            argv_bytes,
            &dispatcher,
        )
    });
    let (resolved, argv) = resolved_entry.map_err(|_| {
        RuntimeError::AddressSpace(AddressSpaceError::Io(std::io::Error::new(
            std::io::ErrorKind::NotFound,
            path.to_owned(),
        )))
    })?;
    // /proc/self/cmdline reflects the user's argv, but /proc/self/exe MUST be the
    // RESOLVED absolute binary path — real Linux always stores the resolved path.
    // A bare `uname` would otherwise absolutize to `/uname` (cwd-relative) and
    // break anything that opens /proc/self/exe: Apple Rosetta opens it to find its
    // x86 target ("rosetta error: Unable to open /proc/self/exe"), and uutils-
    // coreutils (Ubuntu 26.04) derives its locale dir from it. Identity is set
    // AFTER resolution so the recorded exe is the real binary, not the bare name.
    let path: &str = &resolved;
    let executable_source = dispatcher
        .with_kernel_credentials(&launch_context, || {
            dispatcher.acquire_exec_source(&launch_context, path)
        })
        .map_err(|error| {
            let error = match error {
                carrick_kernel::dispatch::executable_authority::ExecSourceError::Linux(errno) => {
                    std::io::Error::from_raw_os_error(errno.get())
                }
                carrick_kernel::dispatch::executable_authority::ExecSourceError::Host(error) => {
                    error
                }
            };
            RuntimeError::AddressSpace(AddressSpaceError::Io(error))
        })?;
    let bytes = executable_source
        .read_all()
        .map_err(AddressSpaceError::Io)?;
    dispatcher.set_executable_identity_with_source(
        resolved.clone(),
        argv_for_cmdline,
        env.iter().map(|s| s.as_bytes().to_vec()).collect(),
        executable_source,
    );
    // Redirect x86_64 binaries through Rosetta 2 (binfmt_misc-style). argv is
    // already opaque bytes (Linux ABI).
    let mut needs_at_base = false;
    let mut main_image_path = Some(path);
    let (bytes, argv): (Vec<u8>, Vec<Vec<u8>>) =
        match maybe_redirect_to_rosetta(path, &bytes, &argv) {
            None => (bytes, argv),
            Some(Ok(redirect)) => {
                // Faithful binfmt: /proc/self/exe stays the target (the redirect
                // is transparent on real Linux; Rosetta finds itself without it).
                // Flag the guest (uname → x86_64) and record the stack argv so
                // /proc/self/cmdline survives Rosetta's argv-skip.
                needs_at_base = redirect.target_is_dynamic;
                main_image_path = None;
                dispatcher.enter_binfmt(&redirect.argv);
                (redirect.interpreter_bytes, redirect.argv)
            }
            Some(Err(errno)) => return Err(rosetta_unavailable(errno, path)),
        };
    // The platform-neutral image assembly (load + auxv + initial stack) is shared
    // with the KVM run path via `exec_helpers::build_run_image`; only the run-loop
    // entry below (HVF `finish_and_run_image`) is macOS-specific.
    let built = dispatcher.with_kernel_credentials(&launch_context, || {
        carrick_kernel::exec_helpers::build_run_image(
            &bytes,
            argv,
            &env,
            &dispatcher,
            vdso_enabled_for_debug(),
            needs_at_base.then_some(ROSETTA_AT_BASE_PLACEHOLDER),
        )
    });
    drop(launch_context);
    let mut image = built?;
    if let Some(path) = main_image_path {
        // Byte-based boot loading leaves the main PT_LOAD paths empty. Bind
        // the resolved ELF identity before dispatcher VMA/backing publication.
        image = image.with_main_file_path(path);
    }
    crate::hvpatch::finish_hvpatch_image_on(
        image,
        dispatcher,
        max_traps,
        debug_state_path,
        carrier,
        lease,
    )
}

pub fn run_rootfs_elf_with_hvf_args<A, E>(
    path: impl AsRef<Path>,
    rootfs: &RootFs,
    argv: A,
    env: E,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    run_rootfs_elf_with_hvf_args_debug(path, rootfs, argv, env, max_traps, None)
}

pub fn run_rootfs_elf_with_hvf_args_debug<A, E>(
    path: impl AsRef<Path>,
    rootfs: &RootFs,
    argv: A,
    env: E,
    max_traps: usize,
    debug_state_path: Option<&PathBuf>,
) -> Result<RunResult, RuntimeError>
where
    A: IntoIterator<Item = String>,
    E: IntoIterator<Item = String>,
{
    let path = path.as_ref();
    run_rootfs_elf_with_hvf_args_and_dispatcher_debug(
        path,
        rootfs,
        SyscallDispatcher::with_rootfs_and_executable_on(
            crate::platform_bridges(),
            rootfs.clone(),
            path.to_string_lossy().into_owned(),
        ),
        argv,
        env,
        max_traps,
        debug_state_path,
    )
}

fn finalize_persistent_hvf_run<Retire, Record, Publish>(
    mut run: Result<RunResult, RuntimeError>,
    retire: Retire,
    record_terminal: Record,
    publish_artifact: Publish,
) -> Result<RunResult, RuntimeError>
where
    Retire: FnOnce() -> Result<(), RuntimeError>,
    Record: FnOnce(crate::vm_lifecycle::VmRunTerminalOutcome),
    Publish: FnOnce(&Result<RunResult, RuntimeError>) -> Result<(), RuntimeError>,
{
    if let Err(error) = retire()
        && run.is_ok()
    {
        run = Err(error);
    }
    let terminal = match &run {
        Ok(result) => crate::vm_lifecycle::VmRunTerminalOutcome::Completed {
            exit_code: result.exit_code,
            traps: u64::try_from(result.traps).unwrap_or(u64::MAX),
            trap_limit_hit: result.trap_limit_hit,
        },
        Err(_) => crate::vm_lifecycle::VmRunTerminalOutcome::RuntimeError,
    };
    record_terminal(terminal);
    publish_artifact(&run)?;
    run
}

fn run_address_space_with_hvf_and_dispatcher(
    image: AddressSpace,
    mut dispatcher: SyscallDispatcher,
    max_traps: usize,
    carrier: crate::carrier::CarrierRuntime,
    lease: crate::carrier::CarrierLease,
) -> Result<RunResult, RuntimeError> {
    let _ = crate::ulock::preinit_waiter_table();
    // The carrier owns the kernel arena; this container owns its pid region
    // inside it. Guest fork/clone creates logical Carrick-kernel tasks, never a
    // host namespace-supervisor process.
    let _ = carrick_kernel_arena::arena::KernelArena::global();
    let container = dispatcher.container();
    if lease.launch().container_id != container.id() || !lease.belongs_to(&carrier) {
        return Err(RuntimeError::CarrierFailed(
            "runtime received a carrier lease for a different container or generation".to_owned(),
        ));
    }
    lease.mark_running()?;
    // All image/spec/embed mounts are installed before this entry point. The
    // token seals that immutable routing table now and becomes its exclusive
    // terminal owner after the run loop and optional archive endpoint drain.
    let mount_retirement = dispatcher.prepare_mount_retirement();
    lease.register_mounts(mount_retirement.mount_count())?;
    // Taken by the run terminal (inside `finalize_persistent_hvf_run`), or by
    // the boot-failure path below when the loop never ran.
    let registry_id = container.launch().registry_id().map(str::to_owned);
    let mut retire = Some((container, lease, mount_retirement));
    let mut exact_control_installed = false;
    let mut run = (|| -> Result<RunResult, RuntimeError> {
        // Build the engine (create VM + vCPU, map the address space, park at the EL0
        // trampoline) — the shared `Aarch64EngineCore<HvfAarch64Vmm>` bring-up.
        let mut trap = crate::trap::new_hvf_trap_engine(&image)?;
        carrick_hal::ThreadedEngine::set_persistent_vm_lifecycle(&mut trap, true);
        // Hand the dispatcher the real region list + auxv so /proc/self/maps
        // (regions, bootstrap pages, stack) and /proc/self/auxv reflect the loaded
        // ELF instead of the legacy summary. Language runtimes, malloc
        // implementations, and debuggers parse these; refreshed again on each execve.
        apply_image_proc_state(&mut dispatcher, &image)?;
        // Boot-stamp the identity page before the guest runs a single syscall,
        // so the very first fast-path getpid/get*id reads the right value.
        let boot_context = dispatcher.capture_one_task_context().map_err(|error| {
            RuntimeError::Configuration(format!("capture boot identity Kernel context: {error}"))
        })?;
        let _ = stamp_identity_page(&mut trap, &dispatcher, &boot_context);
        drop(boot_context);
        let mut completion = run_threaded_hvf_loop(trap, dispatcher, max_traps, &carrier);
        // The control server owns an archive authority over this container's
        // mount table. Stop admission and join its synchronous worker before
        // retirement proves exclusive terminal ownership. Terminal state is
        // persisted only after teardown, so a cleanup failure still reports
        // the fail-closed status 125.
        if let Some(control) = completion.carrier_control.as_mut() {
            exact_control_installed = true;
            control.quiesce();
        }
        // Container teardown: reap, drop mounts, release the pid region. The
        // VM, the arena and every other carrier facility persist for the next
        // container; `carrier::shutdown` retires them at carrier exit.
        let mut run = finalize_persistent_hvf_run(
            completion.run,
            || {
                let (container, lease, mounts) = retire.as_mut().ok_or_else(|| {
                    RuntimeError::Configuration("container retired twice".to_owned())
                })?;
                crate::carrier::retire_leased_container(Arc::clone(container), lease, mounts)?;
                retire.take();
                Ok(())
            },
            |terminal| carrier.record_terminal(terminal),
            |_| Ok(()),
        );
        // Keep mutating control live through VM destruction, terminal receipt,
        // and optional lifecycle-artifact publication.  Only then publish the
        // exact externally visible status and release the endpoint.  Any error
        // after control installation is fail-closed as 125.
        if let Some(control) = completion.carrier_control.as_mut() {
            let exit_code = run.as_ref().map_or(125, |result| result.exit_code);
            if let Err(error) = control.complete(exit_code)
                && run.is_ok()
            {
                run = Err(RuntimeError::Configuration(format!(
                    "publish carrier terminal state: {error}"
                )));
            }
        }
        run
    })();
    // Boot failed before the loop (file authority, VM/root bring-up, boot
    // identity): `finalize_persistent_hvf_run` never ran, so the container is
    // still admitted. Retire it here; the admission's RAII drop alone would
    // un-count it but leave its tasks/mounts/pid region behind.
    if let Some((container, lease, mounts)) = retire.as_mut() {
        match crate::carrier::retire_leased_container(Arc::clone(container), lease, mounts) {
            Ok(_) => {
                retire.take();
            }
            Err(error) if run.is_ok() => run = Err(error),
            Err(_) => {}
        }
    }
    if !exact_control_installed && let Some(id) = registry_id.as_deref() {
        let exit_code = run.as_ref().map_or(125, |result| result.exit_code);
        carrick_kernel::container::mark_exited(id, exit_code);
    }
    run
}

/// Install the macOS/HVF AArch64 syscall transport in a freshly loaded image.
///
/// Every ordinary SVC publishes its complete frame through an EL1-only mailbox
/// before exiting to HVF. The optional identity shim remains an independent
/// optimization inside the vector: disabling it does not return HVF to the
/// register-scraping transport. Keeping this builder shared by boot and
/// `execve` also makes the transport immutable across a container lifecycle.
fn with_hvf_syscall_mailbox(
    image: AddressSpace,
    _requires_syscall_traps: bool,
) -> Result<AddressSpace, AddressSpaceError> {
    // EL1 vectors are carrier-wide immutable code. They cannot depend on one
    // container's observer/interceptor policy: two siblings may legitimately
    // require different visibility. Install the universal shim-capable page
    // whenever the feature is compiled, and let each container's private
    // identity-page gate decide whether matched calls return in EL1 or fall
    // through to the host dispatcher.
    let identity_fast_path = carrick_kernel::syscall_shim_enabled();
    let image = image.with_el1_vectors_mailbox_clock(identity_fast_path, true)?;
    // The page is part of the compile-enabled transport shape even when its
    // runtime gate is closed. Boot/fork/exec stampers still publish the task
    // identity there; interceptor/observer visibility keeps the gate at zero
    // so every identity call traps through ordinary dispatch.
    let image = if carrick_kernel::syscall_shim_enabled() {
        image.with_identity_page()?
    } else {
        image
    };
    let image = image.with_syscall_mailbox_arena()?;
    image
        .with_carrier_maintenance_root()?
        .with_fd_ceiling_control()
}

/// Construct the immutable HVPatch image boundary shared by initial boots and
/// its unit-level construction proof. The live dispatcher restriction is
/// sealed here so a stale caller snapshot can only make the image stricter.
fn finalize_hvf_initial_image(
    image: AddressSpace,
    dispatcher: &SyscallDispatcher,
    requires_syscall_traps: bool,
) -> Result<AddressSpace, AddressSpaceError> {
    use carrick_hal::GuestArch as _;

    type HvfArch = <HvfTrapEngine as carrick_hal::ThreadedEngine>::Arch;
    let requires_syscall_traps = requires_syscall_traps || dispatcher.requires_syscall_traps();
    let image = image.with_el0_trampoline_bytes(HvfArch::entry_trampoline_bytes())?;
    let image = with_hvf_syscall_mailbox(image, requires_syscall_traps)?;
    let image = image.with_hvpatch_stage1_page_tables()?;
    with_optional_vdso_for_clock_with_visibility::<HvfArch>(
        image,
        dispatcher.container().clock(),
        requires_syscall_traps,
    )
}

/// Finish a freshly-loaded image (its initial stack already set, if any) and
/// run it: install the EL0 trampoline, EL1 vectors, stage-1 page tables and
/// vDSO, optionally dump debug state, then enter the HVF run loop. This
/// trampoline→vectors→page-tables→vdso→dump→run tail was duplicated verbatim
/// across every `run_*` entry point; the entry points now differ only in how
/// they obtain the image bytes (host file / raw bytes / rootfs / overlay) and
/// set up identity + Rosetta redirection.
pub(crate) fn finish_and_run_image(
    image: AddressSpace,
    dispatcher: SyscallDispatcher,
    requires_syscall_traps: bool,
    max_traps: usize,
    debug_state_path: Option<&PathBuf>,
) -> Result<RunResult, RuntimeError> {
    finish_and_run_image_owned(
        image,
        dispatcher,
        requires_syscall_traps,
        max_traps,
        debug_state_path,
        None,
    )
}

pub(crate) fn finish_and_run_image_on(
    image: AddressSpace,
    dispatcher: SyscallDispatcher,
    requires_syscall_traps: bool,
    max_traps: usize,
    debug_state_path: Option<&PathBuf>,
    carrier: crate::carrier::CarrierRuntime,
    lease: crate::carrier::CarrierLease,
) -> Result<RunResult, RuntimeError> {
    finish_and_run_image_owned(
        image,
        dispatcher,
        requires_syscall_traps,
        max_traps,
        debug_state_path,
        Some((carrier, lease)),
    )
}

fn finish_and_run_image_owned(
    image: AddressSpace,
    dispatcher: SyscallDispatcher,
    requires_syscall_traps: bool,
    max_traps: usize,
    debug_state_path: Option<&PathBuf>,
    ownership: Option<(crate::carrier::CarrierRuntime, crate::carrier::CarrierLease)>,
) -> Result<RunResult, RuntimeError> {
    // The carrier's deadlock watchdog is NOT armed here. Its window is a typed
    // parameter now (`carrick_kernel::deadlock_watchdog::DeadlockWindow`),
    // stated by the caller that owns the run's budget — `carrick-embed`'s
    // carrier budget arms it for the signed test lane. This call site had no
    // window to state: it read a deleted environment variable and was a no-op
    // without it, which is how a spinning carrier ran for 29m45s with a
    // watchdog "present".
    // Back the guest's default fd table with real host descriptors. Every
    // guest-visible file is a host fd, so the carrier's own `RLIMIT_NOFILE`
    // (macOS starts at 256) must cover the guest default plus headroom, or
    // a guest well inside its own limit is refused by the host (libuv's
    // ~2500 UDP sockets, LTP creat05/fork09). Carrier-lifetime, idempotent,
    // only ever raises — see the `carrier.rs` ledger. Shared here so the
    // embedded runner gets it, not only the CLI.
    carrick_kernel::dispatch::raise_host_nofile_backing(
        carrick_kernel::kernel::objects::RlimitSet::carrick_defaults()
            .get(carrick_abi::LinuxResource::Nofile)
            .rlim_cur,
    );
    // macOS/HVF ordinary syscalls always publish through the EL1-only mailbox.
    // The feature-gated identity handlers remain a no-exit fast path within
    // that vector; native DSR and the non-macOS VMM lifecycle never enter this
    // builder.
    let image = finalize_hvf_initial_image(image, &dispatcher, requires_syscall_traps)?;
    if let Some(p) = maybe_dump_debug_state(&image, debug_state_path) {
        eprintln!("debug state written: {}", p.display());
    }
    let (carrier, lease) = match ownership {
        Some(ownership) => ownership,
        None => {
            let carrier = crate::carrier::process_carrier()?;
            let lease = carrier.reserve(dispatcher.container().launch().clone())?;
            (carrier, lease)
        }
    };
    run_address_space_with_hvf_and_dispatcher(image, dispatcher, max_traps, carrier, lease)
}

// `apply_image_proc_state`, `stamp_identity_page`, and
// `proc_maps_from_address_space` were hoisted into `crate::vcpu_loop` (shared
// with the threaded loop); imported above and called unchanged here.

pub fn run_syscall_loop<M, T>(
    memory: &mut M,
    trap: &mut T,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    M: CurrentMmMemory,
    T: SyscallTrap,
{
    run_syscall_loop_with_dispatcher(
        memory,
        trap,
        SyscallDispatcher::with_bridges(crate::platform_bridges()),
        max_traps,
    )
}

pub fn run_syscall_loop_with_dispatcher<M, T>(
    memory: &mut M,
    trap: &mut T,
    dispatcher: SyscallDispatcher,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    M: CurrentMmMemory,
    T: SyscallTrap,
{
    run_split_loop(memory, trap, dispatcher, max_traps)
}

pub fn run_combined_syscall_loop<R>(
    runtime: &mut R,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    R: CurrentMmMemory + SyscallTrap,
{
    run_combined_syscall_loop_with_dispatcher(
        runtime,
        SyscallDispatcher::with_bridges(crate::platform_bridges()),
        max_traps,
    )
}

pub fn run_combined_syscall_loop_with_dispatcher<R>(
    runtime: &mut R,
    mut dispatcher: SyscallDispatcher,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    R: CurrentMmMemory + SyscallTrap,
{
    let reporter = CompatReporter::default();
    carrick_vmm_hvf::host_signal::install_default_handlers();
    // Snapshot the host stdin termios so a guest crash mid-`stty raw`
    // doesn't leave the user's terminal wedged. The guard drops at the
    // end of this function and restores the saved state if we touched
    // it.
    let _termios_guard = carrick_kernel::host_tty::TermiosRestoreGuard::new();

    let this_tid = ThreadId::main_from_host_pid();
    // Per-thread blocking-I/O waiter (owns this thread's kqueue).
    let mut waiter = carrick_vmm_hvf::io_wait::ThreadWaiter::new(this_tid);
    for traps in 1..=max_traps {
        let frame = match runtime.next_syscall()? {
            Some(f) => f,
            None => {
                // Forced out of the guest by a kick (process-directed signal
                // pump). Deliver at the interrupted PC, then resume.
                let pc = runtime.current_pc()?;
                let signal_context = dispatcher.capture_one_task_context().map_err(|error| {
                    RuntimeError::Configuration(format!(
                        "capture forced-exit signal Kernel context: {error}"
                    ))
                })?;
                if let Some(action) = deliver_pending_signal(
                    runtime,
                    &dispatcher,
                    &signal_context,
                    None,
                    this_tid,
                    Some(pc),
                )? {
                    if let Some(signum) = action.stop_signal {
                        stop_by_signal(&*dispatcher.host_signal, signum);
                        continue;
                    }
                    if let Some(signum) = action.term_signal {
                        return Ok(RunResult {
                            exit_code: 128 + signum,
                            terminating_signal: Some(signum),
                            stdout: dispatcher.stdout().to_vec(),
                            stderr: dispatcher.stderr().to_vec(),
                            traps,
                            report: reporter.finish(),
                            trap_limit_hit: false,
                            terminal_reason: None,
                        });
                    }
                }
                continue;
            }
        };
        #[cfg(feature = "trace-traps")]
        {
            // Canonical (= aarch64) lookup: this single-threaded loop is generic
            // over `SyscallTrap` only (no `ThreadedEngine::Arch` to consult); a
            // per-ISA name needs the threaded loop's `Arch::Table` route.
            let name = crate::syscall::lookup_aarch64(frame.number.raw())
                .map(|s| s.name)
                .unwrap_or("<unknown>");
            let a = frame.args;
            eprintln!(
                "trap#{traps}: nr={} ({name}) a0={:#x} a1={:#x} a2={:#x} a3={:#x} a4={:#x} a5={:#x}",
                frame.number.raw(),
                a[0],
                a[1],
                a[2],
                a[3],
                a[4],
                a[5]
            );
        }
        let kernel_context = dispatcher.capture_one_task_context().map_err(|error| {
            RuntimeError::Configuration(format!("capture one-task syscall Kernel context: {error}"))
        })?;
        let prepared = dispatcher.prepare_syscall(
            &kernel_context,
            SyscallRequest::from_raw(frame),
            &reporter,
        )?;
        let (syscall, prepared_outcome) = match prepared {
            PreparedDispatch::Invoke(syscall) => (syscall, None),
            PreparedDispatch::Complete { syscall, outcome } => (syscall, Some(outcome)),
        };
        let mut completion = Some(SyscallCompletionToken::new(
            syscall,
            kernel_context.retain_exact(),
            dispatcher.observers().cloned(),
        ));
        let outcome = match prepared_outcome {
            Some(outcome) => outcome,
            None => dispatch_single_threaded_syscall(
                &mut dispatcher,
                &kernel_context,
                syscall,
                runtime,
                &reporter,
                &mut waiter,
            )?,
        };

        let mut last_syscall_retval: Option<i64> = None;
        let mut signal_interrupted_pc: Option<u64> = None;

        match outcome {
            DispatchOutcome::WaitOnFds { .. }
            | DispatchOutcome::BlockingOpen(_)
            | DispatchOutcome::BlockingWrite(_)
            | DispatchOutcome::BlockingTimerFdRead(_)
            | DispatchOutcome::BlockingSemop(_)
            | DispatchOutcome::BlockingMqueue(_)
            | DispatchOutcome::BlockingFdWait { .. }
            | DispatchOutcome::BlockingRecordLock(_)
            | DispatchOutcome::WaitOnHvpatchChild { .. }
            | DispatchOutcome::WaitOnSignals { .. }
            | DispatchOutcome::WaitOnSleep { .. } => {
                let value = crate::linux_abi::LINUX_EINTR.guest_retval();
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, value)?;
                last_syscall_retval = Some(value);
            }
            DispatchOutcome::Exit { code } => {
                retire_single_threaded_syscall(&mut completion)?;
                crate::probes::guest_exit(code);
                dispatcher.cleanup_sysv_ipc_on_process_exit();
                return Ok(RunResult {
                    exit_code: code,
                    terminating_signal: None,
                    stdout: dispatcher.stdout().to_vec(),
                    stderr: dispatcher.stderr().to_vec(),
                    traps,
                    report: reporter.finish(),
                    trap_limit_hit: false,
                    terminal_reason: None,
                });
            }
            DispatchOutcome::SignalDeath { signum } => {
                retire_single_threaded_syscall(&mut completion)?;
                dispatcher.cleanup_sysv_ipc_on_process_exit();
                return Ok(RunResult {
                    exit_code: 128 + signum,
                    terminating_signal: Some(signum),
                    stdout: dispatcher.stdout().to_vec(),
                    stderr: dispatcher.stderr().to_vec(),
                    traps,
                    report: reporter.finish(),
                    trap_limit_hit: false,
                    terminal_reason: None,
                });
            }
            DispatchOutcome::Returned { value } => {
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, value)?;
                last_syscall_retval = Some(value);
            }
            DispatchOutcome::SchedulerYield => {
                std::thread::yield_now();
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, 0)?;
                last_syscall_retval = Some(0);
            }
            DispatchOutcome::Errno { errno } => {
                let value = errno.guest_retval();
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, value)?;
                last_syscall_retval = Some(value);
            }
            DispatchOutcome::Fork { .. } => {
                // This loop is retained only as a deterministic syscall/memory
                // fixture. Product execution uses the unified kernel loop, where
                // fork/vfork clone logical tasks and never create a host process.
                let value = crate::linux_abi::LINUX_EOPNOTSUPP.guest_retval();
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, value)?;
                last_syscall_retval = Some(value);
            }
            DispatchOutcome::Execve { path, argv, env } => {
                crate::probes::execve_argv(&path, &argv);
                carrick_kernel::event_ring::rec(carrick_kernel::event_ring::EXEC, 1, 0, 0);
                // proctitle / cmdline identity is display text (lossy decode).
                let proc_argv: Vec<String> = argv
                    .iter()
                    .map(|a| String::from_utf8_lossy(a).into_owned())
                    .collect();
                // Reflect the new program into the host process name
                // (`carrick: <argv>`), so a hung exec'd guest is
                // identifiable in `ps -M` / Activity Monitor.
                let cmdline = proc_argv.join(" ");
                carrick_kernel::dispatch::set_host_process_name(cmdline.as_bytes());
                let proc_env = env.clone();
                let loaded = dispatcher.with_kernel_credentials(&kernel_context, || {
                    load_execve_image(
                        &dispatcher,
                        &kernel_context,
                        &path,
                        argv,
                        env,
                        dispatcher.requires_syscall_traps(),
                    )
                });
                match loaded {
                    Ok(crate::runtime::exec::LoadedExecImage {
                        image: new_image,
                        source: executable_source,
                    }) => {
                        crate::probes::execve_loaded(
                            &path,
                            new_image.entry(),
                            new_image.initial_stack_pointer().unwrap_or(0),
                            new_image.regions().len() as u64,
                        );
                        let prepared_kernel_exec =
                            dispatcher.prepare_one_task_kernel_exec(&kernel_context)?;
                        dispatcher.set_executable_identity_with_source(
                            path.clone(),
                            proc_argv,
                            proc_env,
                            executable_source,
                        );
                        dispatcher.reset_signal_handlers_on_execve(&kernel_context);
                        // Reset and refresh memory proc state as one VMA generation.
                        let prepared_dispatch_mm_exec = apply_exec_image_proc_state(
                            &dispatcher,
                            prepared_kernel_exec.replacement_mm_id(),
                            &new_image,
                        );
                        runtime.execve_into(&new_image)?;
                        let exec_context =
                            dispatcher.commit_one_task_kernel_exec(prepared_kernel_exec)?;
                        prepared_dispatch_mm_exec.commit();
                        carrick_kernel::namespace::pid::mark_self_execed_for(&exec_context);
                        // execve_into rebuilt a fresh (zeroed) identity page;
                        // exec retains the caller's captured credential values.
                        let _ = stamp_identity_page(runtime, &dispatcher, &exec_context);
                        retire_single_threaded_syscall(&mut completion)?;
                        stop_after_traced_exec(&dispatcher);
                    }
                    Err(errno) => {
                        let value = errno.guest_retval();
                        complete_single_threaded_syscall(
                            runtime,
                            &mut completion,
                            &reporter,
                            value,
                        )?;
                        last_syscall_retval = Some(value);
                    }
                }
            }
            DispatchOutcome::SigReturn => {
                // Pop the Carrick sigframe at SP_EL0 and restore the
                // pre-signal register state. No `complete_syscall` —
                // the restored x0 IS the syscall return value the
                // pre-empted caller observes.
                let restored_sigmask = runtime.restore_from_sigframe()?;
                dispatcher.restore_signal_mask(
                    &kernel_context,
                    this_tid,
                    carrick_abi::SigSet::from_raw(restored_sigmask),
                );
                retire_single_threaded_syscall(&mut completion)?;
                // Deliver the NEXT pending signal (if any) before resuming the
                // restored context — the kernel delivers all deliverable pending
                // signals back-to-back before returning to userspace. The just-
                // handled signal was already cleared from the pending set when
                // delivered, so this can't re-deliver it. `last_syscall_retval`
                // is None on this path, so the next inject preserves the
                // restored x0.
                signal_interrupted_pc = Some(runtime.current_pc()?);
            }
            DispatchOutcome::SetMemoryModel { tso } => {
                // Rosetta requested hardware x86_64 TSO on this vCPU. Toggle
                // ACTLR_EL1.EnTSO, then complete prctl with 0.
                runtime.set_memory_model(hardware_tso_for_debug(tso))?;
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, 0)?;
                last_syscall_retval = Some(0);
            }
            DispatchOutcome::MapHostAlias {
                success_retval,
                transaction,
                va,
                ipa,
                len,
                payload,
                backing,
                prot,
                prot_none,
            } => {
                let shared = backing.is_shared();
                let retval = dispatcher.with_mm_executor_mutation(|dispatcher, mutation| {
                    let permit = mutation.host_alias_permit();
                    match transaction.claim(&permit) {
                        None => {
                            // No backend mutation started; dropping `backing` closes
                            // the owned dup and this pre-install claim failure is
                            // recoverable.
                            drop(backing);
                            crate::linux_abi::LINUX_ENOMEM.guest_retval()
                        }
                        Some(install) => {
                            if runtime
                                .map_host_alias(va, ipa, len, &payload, backing)
                                .is_err()
                            {
                                // Backend `Err` does not prove that stage-2/page-table
                                // mutation never began. Process teardown is the only
                                // sound rollback until the backend Result is stronger.
                                carrick_fatal!(
                                    "runtime::host_alias_mapping",
                                    "backend map_host_alias failed in single-threaded loop"
                                );
                            }
                            let Ok(len) = usize::try_from(len) else {
                                carrick_fatal!(
                                    "runtime::host_alias_mapping",
                                    "host alias length exceeds usize"
                                );
                            };
                            if prot_none && runtime.protect_range(va.raw(), len, 0).is_err() {
                                carrick_fatal!(
                                    "runtime::host_alias_mapping",
                                    "protect_range PROT_NONE failed for host alias"
                                );
                            }
                            // Publish the dispatcher's authoritative Linux VMA
                            // protection + sharing only after the backend mapping and
                            // requested leaf protection are both live. This is the
                            // final infallible half of the alias transaction: a
                            // sibling can never observe MAP_SHARED provenance for a
                            // backing that failed to install, nor resume with a live
                            // shared mapping classified as process-private.
                            runtime.set_mapping_protection_and_sharing(
                                va.raw(),
                                len,
                                prot_none,
                                !carrick_abi::LinuxProtFlags::from_bits_truncate(prot)
                                    .contains(carrick_abi::LinuxProtFlags::WRITE),
                                if shared {
                                    carrick_guest_mem::MappingSharing::Shared
                                } else {
                                    carrick_guest_mem::MappingSharing::Private
                                },
                            );
                            if let Some((bus_start, bus_len)) = install.bus_fault_range() {
                                let Ok(bus_len) = usize::try_from(bus_len) else {
                                    carrick_fatal!(
                                        "runtime::host_alias_mapping",
                                        "bus fault length exceeds usize"
                                    );
                                };
                                if runtime.protect_range(bus_start, bus_len, 0).is_err() {
                                    carrick_fatal!(
                                        "runtime::host_alias_mapping",
                                        "protect_range failed for bus fault range"
                                    );
                                }
                                runtime.set_no_access(bus_start, bus_len, true);
                            }
                            if dispatcher.commit_host_alias_install(install).is_err() {
                                carrick_fatal!(
                                    "runtime::host_alias_mapping",
                                    "commit_host_alias_install failed"
                                );
                            }
                            success_retval
                        }
                    }
                })?;
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, retval)?;
                last_syscall_retval = Some(retval);
            }
            DispatchOutcome::SharedFutexWait {
                target,
                generation,
                value,
                timeout,
            } => {
                // A cross-process MAP_SHARED futex (e.g. /dev/shm-backed
                // LTP tst_checkpoint) goes through __ulock so a waker in
                // another carrick process is reached. Single-threaded
                // guests (like LTP test binaries) hit this path too; the
                // legacy `dispatch_threaded`-only short-circuit was the
                // root cause of LTP pause01 TBROKing on
                // `tst_checkpoint_wake ETIMEDOUT`.
                let prewoken = carrick_thread::platform_futex::carrier_shared_futex_table()
                    .take_woken(&generation);
                let retval = if prewoken {
                    0
                } else {
                    shared_futex_wait(
                        target.location.wait_addr(),
                        target.waiter_key,
                        value,
                        timeout,
                        this_tid,
                    )
                };
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, retval)?;
                last_syscall_retval = Some(retval);
            }
            DispatchOutcome::SharedFutexWaitv {
                target,
                generation,
                value,
                timeout,
                index,
            } => {
                let prewoken = carrick_thread::platform_futex::carrier_shared_futex_table()
                    .take_woken(&generation);
                let retval = if prewoken {
                    0
                } else {
                    shared_futex_wait(
                        target.location.wait_addr(),
                        target.waiter_key,
                        value,
                        timeout,
                        this_tid,
                    )
                };
                let retval = if retval == 0 { index } else { retval };
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, retval)?;
                last_syscall_retval = Some(retval);
            }
            DispatchOutcome::WaitOnSharedWord {
                mut location,
                mut waiter_key,
                mut generation,
                mut value,
                mut sysv,
            } => loop {
                let prewoken = carrick_thread::platform_futex::carrier_shared_futex_table()
                    .take_woken(&generation);
                let retval = if prewoken {
                    0
                } else {
                    shared_futex_wait(location.wait_addr(), waiter_key, value, None, this_tid)
                };
                if retval != 0 {
                    complete_single_threaded_syscall(runtime, &mut completion, &reporter, retval)?;
                    last_syscall_retval = Some(retval);
                    break;
                }
                if let Some(outcome) = sysv.as_ref().and_then(|wait| wait.completion_after_wake()) {
                    let retval = match outcome {
                        DispatchOutcome::Errno { errno } => errno.guest_retval(),
                        DispatchOutcome::Returned { value } => value,
                        _ => {
                            return Err(RuntimeError::Unsupported(
                                "SysV wait produced a non-terminal resume outcome".to_owned(),
                            ));
                        }
                    };
                    complete_single_threaded_syscall(runtime, &mut completion, &reporter, retval)?;
                    last_syscall_retval = Some(retval);
                    break;
                }
                match dispatch_single_threaded_syscall(
                    &mut dispatcher,
                    &kernel_context,
                    syscall,
                    runtime,
                    &reporter,
                    &mut waiter,
                )? {
                    DispatchOutcome::WaitOnSharedWord {
                        location: next_location,
                        waiter_key: next_waiter_key,
                        generation: next_generation,
                        value: next_value,
                        sysv: next_sysv,
                    } => {
                        location = next_location;
                        waiter_key = next_waiter_key;
                        generation = next_generation;
                        value = next_value;
                        sysv = next_sysv;
                    }
                    DispatchOutcome::Returned { value } => {
                        complete_single_threaded_syscall(
                            runtime,
                            &mut completion,
                            &reporter,
                            value,
                        )?;
                        last_syscall_retval = Some(value);
                        break;
                    }
                    DispatchOutcome::Errno { errno } => {
                        let value = errno.guest_retval();
                        complete_single_threaded_syscall(
                            runtime,
                            &mut completion,
                            &reporter,
                            value,
                        )?;
                        last_syscall_retval = Some(value);
                        break;
                    }
                    _ => {
                        return Err(RuntimeError::Unsupported(
                            "SysV wait redispatch changed syscall class".to_owned(),
                        ));
                    }
                }
            },
            DispatchOutcome::SharedFutexWake { target, count } => {
                // Cross-process MAP_SHARED futex wake from a single-threaded
                // guest (LTP tst_checkpoint_wake). Same __ulock one-at-a-time +
                // sched_yield as the threaded loop's PlatformFutex::shared_wake.
                let retval =
                    shared_futex_wake(target.location.wait_addr().raw(), target.waiter_key, count);
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, retval)?;
                last_syscall_retval = Some(retval);
            }
            DispatchOutcome::SharedFutexRequeue {
                from,
                to,
                wake,
                requeue,
            } => {
                trace_shared_futex_requeue(0, from.waiter_key, to.waiter_key, wake, requeue, 0, 0);
                let (woken, requeued) = crate::ulock::requeue_counted(
                    from.location.wait_addr().raw(),
                    from.waiter_key,
                    to.location.wait_addr().raw(),
                    to.waiter_key,
                    wake,
                    requeue,
                );
                trace_shared_futex_requeue(
                    1,
                    from.waiter_key,
                    to.waiter_key,
                    wake,
                    requeue,
                    woken,
                    requeued,
                );
                let retval = i64::from(woken + requeued);
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, retval)?;
                last_syscall_retval = Some(retval);
            }
            DispatchOutcome::CloneThread { .. }
            | DispatchOutcome::ThreadExit { .. }
            | DispatchOutcome::SignalThread { .. }
            | DispatchOutcome::FutexWait { .. }
            | DispatchOutcome::FutexWaitv { .. } => {
                // These are emitted only on the multi-threaded
                // `dispatch_threaded` path (run_vcpu_until_exit). The
                // single-threaded loops here always pass `thread: None`, so
                // the dispatcher never produces them.
                let value = crate::linux_abi::LINUX_ENOSYS.guest_retval();
                complete_single_threaded_syscall(runtime, &mut completion, &reporter, value)?;
                last_syscall_retval = Some(value);
            }
        }

        #[cfg(feature = "trace-traps")]
        if let Some(ret) = last_syscall_retval {
            // Return-side companion to the entry line above: shows what carrick
            // returned to the guest. A negative value in [-4095, -1] is -errno
            // (decode it), otherwise it's a plain return. This makes the trap
            // stream a request+result log — the reducer aligns it against the
            // Docker oracle to localise a divergence (wrong errno) or the last
            // syscall before a hang (no return line printed).
            if let Some(e) = LinuxErrno::from_guest_retval(ret) {
                let ename = crate::linux_abi::errno_name(e).unwrap_or("?");
                let e = e.get();
                eprintln!("trap#{traps}:   -> errno={e} ({ename})");
            } else {
                eprintln!("trap#{traps}:   -> ret={ret:#x} ({ret})");
            }
        }

        if let Some(action) = deliver_pending_signal(
            runtime,
            &dispatcher,
            &kernel_context,
            last_syscall_retval,
            this_tid,
            signal_interrupted_pc,
        )? {
            if let Some(signum) = action.stop_signal {
                stop_by_signal(&*dispatcher.host_signal, signum);
                continue;
            }
            if let Some(signum) = action.term_signal {
                dispatcher.cleanup_sysv_ipc_on_process_exit();
                return Ok(RunResult {
                    exit_code: 128 + signum,
                    terminating_signal: Some(signum),
                    stdout: dispatcher.stdout().to_vec(),
                    stderr: dispatcher.stderr().to_vec(),
                    traps,
                    report: reporter.finish(),
                    trap_limit_hit: false,
                    terminal_reason: None,
                });
            }
        }
    }

    Ok(RunResult {
        exit_code: -1,
        terminating_signal: None,
        stdout: dispatcher.stdout().to_vec(),
        stderr: dispatcher.stderr().to_vec(),
        traps: max_traps,
        report: reporter.finish(),
        trap_limit_hit: true,
        terminal_reason: Some(TerminalReason::TrapLimit),
    })
}

// `dispatch_with_panic_backstop`, `raise_sigpipe_for_blocking_write`, and
// `partial_write_interrupt_outcome` were hoisted into `crate::vcpu_loop` (shared
// with the threaded loop); imported above and called unchanged here.

fn complete_single_threaded_syscall<R: SyscallTrap>(
    runtime: &mut R,
    completion: &mut Option<SyscallCompletionToken>,
    reporter: &CompatReporter,
    value: i64,
) -> Result<(), RuntimeError> {
    runtime.complete_syscall(value)?;
    let token = completion.take().ok_or_else(|| {
        RuntimeError::Configuration("single-threaded syscall completed twice".to_owned())
    })?;
    token.publish_return(reporter, value);
    Ok(())
}

fn retire_single_threaded_syscall(
    completion: &mut Option<SyscallCompletionToken>,
) -> Result<(), RuntimeError> {
    completion.take().ok_or_else(|| {
        RuntimeError::Configuration("single-threaded syscall token retired twice".to_owned())
    })?;
    Ok(())
}

fn dispatch_single_threaded_syscall<M: CurrentMmMemory>(
    dispatcher: &mut SyscallDispatcher,
    kernel_context: &carrick_kernel::kernel::KernelContext,
    syscall: PreparedSyscall,
    memory: &mut M,
    reporter: &CompatReporter,
    waiter: &mut carrick_vmm_hvf::io_wait::ThreadWaiter,
) -> Result<DispatchOutcome, RuntimeError> {
    dispatch_single_threaded_syscall_with(
        dispatcher,
        kernel_context,
        syscall,
        memory,
        reporter,
        waiter,
        |dispatcher, kernel_context, syscall, memory, reporter| {
            dispatcher.dispatch_prepared(kernel_context, syscall, memory, reporter)
        },
    )
}

fn dispatch_single_threaded_syscall_with<M, F>(
    dispatcher: &mut SyscallDispatcher,
    kernel_context: &carrick_kernel::kernel::KernelContext,
    syscall: PreparedSyscall,
    memory: &mut M,
    reporter: &CompatReporter,
    waiter: &mut carrick_vmm_hvf::io_wait::ThreadWaiter,
    mut dispatch: F,
) -> Result<DispatchOutcome, RuntimeError>
where
    M: CurrentMmMemory,
    F: FnMut(
        &mut SyscallDispatcher,
        &carrick_kernel::kernel::KernelContext,
        PreparedSyscall,
        &mut M,
        &CompatReporter,
    ) -> Result<DispatchOutcome, carrick_kernel::dispatch::DispatchError>,
{
    use carrick_vmm_hvf::io_wait::WaitResult;

    // Service blocking I/O by waiting without re-entering the dispatcher's
    // blocking path: poll the host fds, then re-dispatch the same syscall on
    // readiness. This is the common single-threaded path for the combined and
    // split runtimes; the threaded runtime keeps its own fork-quiesce handling.
    let mut signal_wait_deadline = None;
    let mut sleep_deadline: Option<Instant> = None;
    let mut poll_deadline: Option<Instant> = None;
    loop {
        let outcome = dispatch_with_panic_backstop(
            syscall.request.number.raw(),
            ThreadId::main_from_host_pid(),
            || dispatch(dispatcher, kernel_context, syscall, memory, reporter),
        )?;
        match outcome {
            DispatchOutcome::BlockingWrite(mut write) => {
                waiter.ensure_full();
                loop {
                    match carrick_kernel::dispatch::drive_blocking_write(
                        &mut write,
                        &*dispatcher.host_signal,
                    ) {
                        carrick_kernel::dispatch::BlockingWriteStep::Done(outcome) => {
                            return Ok(raise_sigpipe_for_blocking_write(
                                dispatcher,
                                kernel_context,
                                &write,
                                outcome,
                            ));
                        }
                        carrick_kernel::dispatch::BlockingWriteStep::Wait => {
                            match waiter.wait(
                                &[carrick_hal::WaitFd::raw(
                                    write.poll_fd(),
                                    write.poll_events(),
                                )],
                                None,
                                carrick_abi::SigBlockMask::NONE,
                            ) {
                                WaitResult::Ready => continue,
                                WaitResult::Interrupted => {
                                    return Ok(partial_write_interrupt_outcome(&write));
                                }
                                WaitResult::TimedOut => {
                                    return Ok(DispatchOutcome::Returned {
                                        value: write.offset() as i64,
                                    });
                                }
                                WaitResult::Errno(errno) => {
                                    if write.offset() > 0 {
                                        return Ok(DispatchOutcome::Returned {
                                            value: write.offset() as i64,
                                        });
                                    }
                                    return Ok(DispatchOutcome::Errno { errno });
                                }
                            }
                        }
                    }
                }
            }
            DispatchOutcome::BlockingRecordLock(lock) => {
                return Ok(carrick_kernel::dispatch::drive_blocking_record_lock(
                    &lock,
                    &*dispatcher.host_signal,
                ));
            }
            DispatchOutcome::WaitOnFds {
                fds,
                timeout,
                sig_mask,
                completion,
            } => match completion {
                FdWaitCompletion::Fd { on_timeout } => {
                    waiter.ensure_full();
                    match waiter.wait(&fds, timeout, sig_mask.block_mask()) {
                        WaitResult::Ready => continue,
                        WaitResult::TimedOut => {
                            return Ok(DispatchOutcome::Returned { value: on_timeout });
                        }
                        WaitResult::Interrupted => {
                            return Ok(DispatchOutcome::Errno {
                                errno: crate::linux_abi::LINUX_EINTR,
                            });
                        }
                        WaitResult::Errno(errno) => return Ok(DispatchOutcome::Errno { errno }),
                    }
                }
                FdWaitCompletion::Select { clear_on_timeout } => {
                    waiter.ensure_full();
                    match waiter.wait(&fds, timeout, sig_mask.block_mask()) {
                        // A fd became ready -> re-dispatch; the handler re-reads the
                        // (untouched) input sets and reports the now-ready fds.
                        WaitResult::Ready => continue,
                        // Timeout -> select returns 0 with the fd-sets zeroed. The
                        // handler left them intact (so Ready/EINTR are correct), so
                        // zero them here before completing.
                        WaitResult::TimedOut => {
                            for (addr, len) in &clear_on_timeout {
                                let _ = memory.zero_guest_range(*addr, *len);
                            }
                            return Ok(DispatchOutcome::Returned { value: 0 });
                        }
                        // Signal interrupt -> EINTR; Linux leaves the fd-sets
                        // unmodified on EINTR, and the handler already did.
                        WaitResult::Interrupted => {
                            return Ok(DispatchOutcome::Errno {
                                errno: crate::linux_abi::LINUX_EINTR,
                            });
                        }
                        WaitResult::Errno(errno) => return Ok(DispatchOutcome::Errno { errno }),
                    }
                }
                FdWaitCompletion::Poll { on_timeout } => {
                    waiter.ensure_full();
                    let timeout = match timeout {
                        Some(duration) => {
                            let deadline =
                                *poll_deadline.get_or_insert_with(|| Instant::now() + duration);
                            let now = Instant::now();
                            if now >= deadline {
                                return Ok(DispatchOutcome::Returned { value: on_timeout });
                            }
                            Some(deadline - now)
                        }
                        None => {
                            poll_deadline = None;
                            None
                        }
                    };
                    match waiter.wait_poll(&fds, timeout, sig_mask.block_mask()) {
                        WaitResult::Ready => continue,
                        WaitResult::TimedOut => {
                            return Ok(DispatchOutcome::Returned { value: on_timeout });
                        }
                        WaitResult::Interrupted => {
                            return Ok(DispatchOutcome::Errno {
                                errno: crate::linux_abi::LINUX_EINTR,
                            });
                        }
                        WaitResult::Errno(errno) => return Ok(DispatchOutcome::Errno { errno }),
                    }
                }
            },
            DispatchOutcome::WaitOnHvpatchChild { sig_mask, .. } => {
                waiter.ensure_full();
                match waiter.wait_with_dispatch_pending(
                    &[],
                    Some(Duration::from_millis(10)),
                    sig_mask.block_mask(),
                    || false,
                ) {
                    WaitResult::Ready | WaitResult::TimedOut => continue,
                    WaitResult::Interrupted => {
                        return Ok(DispatchOutcome::Errno {
                            errno: crate::linux_abi::LINUX_EINTR,
                        });
                    }
                    WaitResult::Errno(errno) => {
                        return Ok(DispatchOutcome::Errno { errno });
                    }
                }
            }
            DispatchOutcome::WaitOnSignals {
                wait_set,
                block_mask,
                timeout,
            } => {
                let slice = match signal_wait_slice(&mut signal_wait_deadline, timeout) {
                    Some(slice) => slice,
                    None => {
                        return Ok(DispatchOutcome::Errno {
                            errno: crate::linux_abi::LINUX_EAGAIN,
                        });
                    }
                };
                waiter.ensure_full();
                match waiter.wait(&[], Some(slice), block_mask) {
                    WaitResult::Ready => continue,
                    WaitResult::Interrupted => {
                        // An unblocked pending signal OUTSIDE the wait set must
                        // EINTR the wait (its handler is delivered by the run
                        // loop's tail); a wait-set signal re-dispatches so the
                        // dispatcher dequeues it and returns the signum.
                        if dispatcher.signal_wait_should_eintr(
                            kernel_context,
                            waiter.tid(),
                            wait_set,
                            block_mask,
                        ) {
                            return Ok(DispatchOutcome::Errno {
                                errno: crate::linux_abi::LINUX_EINTR,
                            });
                        }
                        continue;
                    }
                    WaitResult::TimedOut => {
                        if signal_wait_expired(signal_wait_deadline) {
                            return Ok(DispatchOutcome::Errno {
                                errno: crate::linux_abi::LINUX_EAGAIN,
                            });
                        }
                        continue;
                    }
                    // WaitOnSignals waits over an EMPTY fd slice, so new() never
                    // dups and this is unreachable; present for exhaustiveness.
                    WaitResult::Errno(errno) => {
                        return Ok(DispatchOutcome::Errno { errno });
                    }
                }
            }
            DispatchOutcome::WaitOnSleep {
                duration,
                remaining,
            } => {
                // Single-vCPU path: no fork-quiesce, but still wait via the
                // waiter so a guest signal interrupts the sleep (EINTR). The
                // deadline is preserved across re-dispatch (signal re-wait).
                let deadline = *sleep_deadline.get_or_insert_with(|| Instant::now() + duration);
                let now = Instant::now();
                if now >= deadline {
                    return Ok(DispatchOutcome::Returned { value: 0 });
                }
                let waiter_tid = waiter.tid();
                let sleep_interrupt_pending = || {
                    dispatcher.drain_xsignals_process_directed(kernel_context);
                    dispatcher.has_deliverable_dispatch_pending_for_wait(
                        kernel_context,
                        waiter_tid,
                        carrick_abi::WaitSigMask::Additive(carrick_abi::SigSet::EMPTY),
                    )
                };
                if sleep_interrupt_pending() {
                    return Ok(carrick_kernel::dispatch::complete_interrupted_sleep(
                        memory,
                        remaining,
                        deadline.saturating_duration_since(Instant::now()),
                    ));
                }
                waiter.ensure_full();
                // Xsignals live in a fork-shared ring, not an fd. Bound the
                // sleep wait at the same internal slice as `io_wait` so each
                // slice services dispatcher-owned pending state.
                let wait_for = (deadline - now).min(Duration::from_millis(50));
                match waiter.wait_with_dispatch_pending(
                    &[],
                    Some(wait_for),
                    carrick_abi::SigBlockMask::NONE,
                    sleep_interrupt_pending,
                ) {
                    WaitResult::Ready => continue,
                    WaitResult::TimedOut => {
                        if Instant::now() >= deadline {
                            return Ok(DispatchOutcome::Returned { value: 0 });
                        }
                        continue;
                    }
                    WaitResult::Interrupted => {
                        return Ok(carrick_kernel::dispatch::complete_interrupted_sleep(
                            memory,
                            remaining,
                            deadline.saturating_duration_since(Instant::now()),
                        ));
                    }
                    WaitResult::Errno(errno) => return Ok(DispatchOutcome::Errno { errno }),
                }
            }
            DispatchOutcome::WaitOnSharedWord {
                location,
                waiter_key,
                generation,
                value,
                sysv,
            } => {
                let prewoken = carrick_thread::platform_futex::carrier_shared_futex_table()
                    .take_woken(&generation);
                let retval = if prewoken {
                    0
                } else {
                    shared_futex_wait(location.wait_addr(), waiter_key, value, None, waiter.tid())
                };
                if retval == 0 {
                    if let Some(outcome) =
                        sysv.as_ref().and_then(|wait| wait.completion_after_wake())
                    {
                        return Ok(outcome);
                    }
                    continue;
                }
                return Ok(DispatchOutcome::Returned { value: retval });
            }
            other => return Ok(other),
        }
    }
}

// ===================================================================
// Multi-threaded HVF runtime: one host thread + one HVF vCPU per guest
// thread, sharing ONE process VM. The loop ITSELF was hoisted into the
// unconditional `crate::vcpu_loop` (generic over `carrick_hal::ThreadedEngine`);
// `KernelState`/`Kernel`/`VcpuLoopOutcome`/`ThreadRuntimeState`/
// `run_vcpu_until_exit`/`service_signals_threaded`/`deliver_pending_signal`/
// `shared_futex_wait` (now `PlatformFutex::shared_wait`) all live there. Only the
// HVF SETUP WRAPPER (`run_threaded_hvf_loop`) stays here, building the concrete
// HVF kicker / futex table / signal-pump control and threading them in.
// ===================================================================

use crate::thread::{FutexTable, ThreadId};
use std::sync::Arc;

/// Top-level multi-threaded HVF entry. Builds the shared dispatcher lock + the
/// thread registry + futex table, then runs the MAIN guest thread's vCPU
/// through `run_vcpu_until_exit`. Thread-creating clones spawn sibling host
/// threads that run the same function on their own vCPU.
/// HVF's [`crate::threaded_loop::HostBackend`]: `hvf_futex`, the kqueue
/// signal-pump control, `VcpuKicker`, `HvfTimerDelivery`, the `HvfSignalArrival`
/// kqueue-pump wake, and HVF's pre-loop setup (default cross-process signal
/// handlers + a termios-restore guard) with a tty-gated LAZY pump.
struct HvfHostBackend;

impl crate::threaded_loop::HostBackend for HvfHostBackend {
    fn make_futex(&self, table: Arc<FutexTable>) -> Arc<dyn carrick_hal::PlatformFutex> {
        Arc::new(crate::threaded_impl::hvf_futex(table))
    }

    fn make_signal_pump(&self) -> Box<dyn carrick_hal::SignalPumpControl> {
        Box::new(crate::fork_coord::HvfSignalPumpControl::new())
    }

    fn make_kicker(&self) -> Arc<dyn carrick_hal::VcpuRegistry> {
        Arc::new(crate::vcpu_kick::VcpuKicker::new())
    }

    fn make_timer_delivery(
        &self,
        _kicker: Arc<dyn carrick_hal::VcpuRegistry>,
        _main_tid: ThreadId,
    ) -> Arc<dyn carrick_hal::TimerDelivery> {
        // HVF arms an EVFILT_TIMER on the pump kqueue and owns delivery; only a
        // pump-less fork child falls back to the shared wall-clock thread.
        Arc::new(carrick_vmm_hvf::timer_delivery::HvfTimerDelivery)
    }

    fn make_signal_arrival(
        &self,
        _kicker: &Arc<dyn carrick_hal::VcpuRegistry>,
        _platform_futex: &Arc<dyn carrick_hal::PlatformFutex>,
    ) -> Arc<dyn carrick_hal::SignalArrival> {
        // HVF's kqueue-pump wake (per-thread waiter wakes, xsig ring, child-exit
        // watches) — NOT the generic kick+futex arrival.
        Arc::new(crate::signal_arrival::HvfSignalArrival)
    }

    fn pre_loop_setup(&self) -> Box<dyn std::any::Any> {
        carrick_vmm_hvf::host_signal::install_default_handlers();
        Box::new(carrick_kernel::host_tty::TermiosRestoreGuard::new())
    }

    fn start_pump_eagerly(&self) -> bool {
        // Non-interactive runners start pump-free and request a pump lazily;
        // interactive terminals keep prompt Ctrl-C delivery for busy guests.
        carrick_kernel::host_tty::host_isatty(0) || carrick_kernel::host_tty::host_isatty(1)
    }
}

/// Thin wrapper over the shared [`crate::threaded_loop::run_threaded_loop`] with
/// [`HvfHostBackend`] — the macOS twin of `run_threaded_kvm_loop` (F3). The shared
/// loop owns the scaffold (thread registry, root-pid + child-CPU table, PID-ns
/// fallback, M:N scheduler, `KernelState`, `run_vcpu_until_exit`, result
/// assembly); only HVF's host trait-objects differ, and those are `HvfHostBackend`.
fn run_threaded_hvf_loop(
    trap: HvfTrapEngine,
    dispatcher: SyscallDispatcher,
    max_traps: usize,
    carrier: &crate::carrier::CarrierRuntime,
) -> crate::threaded_loop::ThreadedLoopCompletion {
    crate::threaded_loop::run_threaded_loop(trap, dispatcher, HvfHostBackend, max_traps, carrier)
}

// `run_vcpu_until_exit`, `assemble_run_result`, `PendingSignalAction`,
// `deliver_pending_signal`, `is_restartable_syscall`, the default-signal
// classifiers, and `service_signals_threaded` were hoisted into
// `crate::vcpu_loop` (generic over the engine). The THREADED loop's shared-futex
// wait now goes through `PlatformFutex::shared_wait`; the macOS-only
// SINGLE-threaded loop below keeps its own free-fn `shared_futex_wait` (it has no
// `PlatformFutex` handle and is HVF-local).

struct SharedFutexWaiterGuard(usize, std::cell::Cell<bool>);

impl SharedFutexWaiterGuard {
    /// Mark the wait as completing WOKEN (FUTEX_WAIT returns 0): the exit
    /// keeps a self-woken waiter claimable by the next wake's count (see
    /// `carrick_host::ulock::waiter_exit`). EINTR/ETIMEDOUT exits leave the
    /// default `false`.
    fn mark_woken(&self) {
        self.1.set(true);
    }
}

impl Drop for SharedFutexWaiterGuard {
    fn drop(&mut self) {
        crate::ulock::waiter_exit(self.0, self.1.get());
    }
}

/// Block on a cross-process (`MAP_SHARED`) futex via the host `__ulock`,
/// interruptibly. Returns 0 when woken (or the futex word already changed),
/// `-EINTR` when a signal deliverable to THIS thread is pending, `-ETIMEDOUT` at
/// the guest's deadline. errnos are translated host→Linux. Used by the
/// single-threaded macOS run loop; the threaded loop uses
/// `PlatformFutex::shared_wait` (which shares this logic in `HvfFutex`).
fn shared_futex_wait(
    host_addr: HostVa,
    waiter_key: usize,
    value: u32,
    timeout: Option<std::time::Duration>,
    this_tid: ThreadId,
) -> i64 {
    let host_addr = host_addr.raw();
    crate::ulock::waiter_enter(waiter_key);
    let waiter_guard = SharedFutexWaiterGuard(waiter_key, std::cell::Cell::new(false));
    let deadline = timeout.map(|d| std::time::Instant::now() + d);
    let host_value = unsafe { (host_addr as *const u32).read() };
    crate::probes::futex_route(host_addr as u64, 99, value as i32, host_value as u64);
    loop {
        if carrick_vmm_hvf::host_signal::has_pending_for(this_tid.raw())
            || crate::fork_quiesce::is_quiescing()
            || crate::fork_quiesce::exec_replacing_other_thread(this_tid)
        {
            return crate::linux_abi::LINUX_EINTR.guest_retval();
        }
        let slice_us: u32 = match deadline {
            Some(dl) => {
                let now = std::time::Instant::now();
                if now >= dl {
                    return crate::linux_abi::LINUX_ETIMEDOUT.guest_retval();
                }
                u32::try_from((dl - now).as_micros().min(20_000)).unwrap_or(20_000)
            }
            None => 20_000,
        };
        crate::probes::ulock_wait(host_addr as u64, value, slice_us, 0, 0);
        let r = crate::ulock::wait(host_addr, value, slice_us);
        crate::probes::ulock_wait(host_addr as u64, value, slice_us, 1, r);
        if r >= 0 {
            let current = unsafe { (host_addr as *const u32).read() };
            if current != value {
                waiter_guard.mark_woken();
                return 0;
            }
            continue;
        }
        let host_errno = (-r) as i32;
        if host_errno == libc::ETIMEDOUT || host_errno == libc::EINTR {
            continue;
        }
        return -i64::from(host_errno);
    }
}

/// Wake up to `count` waiters on a cross-process (`MAP_SHARED`) futex from a
/// SINGLE-THREADED guest (an LTP test binary that forks + `tst_checkpoint_wake`s
/// a child). Darwin's shared-futex wake primitive does not report a Linux-style
/// waiter count, so the host ulock wrapper pairs the wake with its fork-shared
/// parked-waiter table.
fn shared_futex_wake(host_addr: usize, waiter_key: usize, count: u32) -> i64 {
    let woke = crate::ulock::wake_counted(host_addr, waiter_key, count);
    crate::probes::ulock_wake(host_addr as u64, 0, woke);
    woke.max(0)
}

fn trace_shared_futex_requeue(
    phase: u32,
    from_key: usize,
    to_key: usize,
    wake_req: u32,
    requeue_req: u32,
    wake_ret: u32,
    requeue_ret: u32,
) {
    let from = crate::ulock::waiter_debug_counts(from_key);
    let to = crate::ulock::waiter_debug_counts(to_key);
    crate::probes::ulock_requeue(crate::probes::UlockRequeueProbe {
        phase,
        from_key: from_key as u64,
        to_key: to_key as u64,
        wake_req,
        requeue_req,
        wake_ret,
        requeue_ret,
        from_count: from.count,
        from_requeue_wake: from.requeue_wake,
        from_requeue_count: from.requeue_count,
        from_logical_requeued: from.logical_requeued,
        from_logical_wake: from.logical_wake,
        to_count: to.count,
        to_requeue_wake: to.requeue_wake,
        to_requeue_count: to.requeue_count,
        to_logical_requeued: to.logical_requeued,
        to_logical_wake: to.logical_wake,
    });
}

/// Placeholder `AT_BASE` value for a Rosetta-redirected *dynamic* x86_64 target.
/// carrick loads the static `rosetta` interpreter as the image, so the auxv it
/// builds has no AT_BASE. A *dynamic* x86 target needs one present so Apple's
/// Rosetta emits AT_BASE in the inner x86 auxv — filled with the real
/// ld-musl/ld-linux base Rosetta maps (carrick can't know that address; Rosetta
/// chooses it and overwrites this value). It only needs to be a present,
/// non-zero, page-aligned slot. Without it, musl's dynamic linker null-derefs at
/// startup (glibc's self-locates, so glibc-dynamic tolerated the gap).
pub(crate) const ROSETTA_AT_BASE_PLACEHOLDER: u64 = 0x10_0000_0000;

/// Inspect raw ELF bytes about to be loaded into the guest. If they describe an
/// x86_64 binary, rewrite the load to run Apple's Rosetta 2 interpreter instead
/// — exactly as Linux `binfmt_misc` redirects a foreign-arch binary to its
/// registered interpreter:
///
///   argv = [`<rosetta>`, `<target>`, `<original argv[1..]>`]
///
/// Returns:
///
/// - `None`         — the binary is AArch64 (or not an ELF we recognise); the
///   caller proceeds with the original bytes/argv.
/// - `Some(Ok(..))` — the binary is x86_64; `(rosetta_bytes, new_argv)`.
/// - `Some(Err(e))` — the binary is x86_64 but Rosetta isn't readable on this
///   host (`-errno` for the caller to surface).
///
/// Rosetta itself is statically linked, so the AddressSpace loader never needs
/// to resolve a PT_INTERP for it from the guest VFS.
/// Outcome of redirecting an x86_64 target through Apple's Rosetta interpreter.
pub(crate) struct RosettaRedirect {
    /// Bytes of the `rosetta` interpreter to load as the guest image.
    pub interpreter_bytes: Vec<u8>,
    /// argv to hand the interpreter: `[program argv0, target, args…]`.
    pub argv: Vec<Vec<u8>>,
    /// Whether the x86_64 target is dynamically linked (has a `PT_INTERP`). A
    /// dynamic target needs an `AT_BASE` auxv entry in the auxv carrick hands
    /// Rosetta, so Rosetta emits AT_BASE — filled with the real ld-musl/ld-linux
    /// base it maps — in the inner x86 auxv. Without it musl's dynamic linker
    /// null-derefs (glibc's self-locates, so it tolerated the gap). A static
    /// target must NOT get AT_BASE, matching Linux. See `with_auxv_base`.
    pub target_is_dynamic: bool,
}

pub(crate) fn maybe_redirect_to_rosetta<A: AsRef<[u8]>>(
    target_path: &str,
    target_bytes: &[u8],
    // argv items are opaque bytes (Linux ABI); accept String (initial entry)
    // or Vec<u8> (execve) and always return the byte form.
    argv: &[A],
) -> Option<Result<RosettaRedirect, LinuxErrno>> {
    use crate::linux_abi::LINUX_ENOENT;

    // Consult the binfmt_misc registry (magic/mask). A native (aarch64) or
    // non-ELF binary matches nothing and runs directly.
    let _registration = crate::binfmt::match_registration(target_bytes)?;

    crate::probes::execve_argv("rosetta-redirect", &[target_path.as_bytes().to_vec()]);

    let rosetta_bytes = match carrick_kernel::dispatch::rosetta::rosetta_binary_bytes() {
        Some(b) => b.to_vec(),
        None => return Some(Err(LINUX_ENOENT)),
    };

    // A PT_INTERP means the x86 target is dynamically linked and needs an AT_BASE
    // slot in the auxv carrick hands Rosetta (see ROSETTA_AT_BASE_PLACEHOLDER).
    let target_is_dynamic = crate::elf::inspect_elf_bytes(target_bytes)
        .ok()
        .is_some_and(|m| m.interpreter.is_some());

    let orig_argv: Vec<Vec<u8>> = argv.iter().map(|a| a.as_ref().to_vec()).collect();
    Some(Ok(RosettaRedirect {
        interpreter_bytes: rosetta_bytes,
        // The registration is `P` (preserve argv[0]); `rosetta_argv` builds the
        // form Apple's rosetta requires (argv[0] passed through, target at argv[1]).
        argv: rosetta_argv(target_path, &orig_argv),
        target_is_dynamic,
    }))
}

/// Build the argv carrick hands the loaded Apple Rosetta interpreter for an
/// x86_64 target. Apple's `rosetta` consumes `argv[1]` as the binary to
/// translate and presents the program with `argv = [argv[0], argv[2..]]` — i.e.
/// it passes OUR `argv[0]` straight through as the *program's* `argv[0]`. So
/// `argv[0]` MUST be the program's original `argv[0]`, not the interpreter path:
/// a multi-call binary (coreutils/busybox, which dispatch on `argv[0]`) otherwise
/// sees "rosetta" and fails ("coreutils: unknown program 'rosetta'"). Standalone
/// binaries ignore `argv[0]`, which is why glibc programs worked regardless.
///
/// Layout: `[<orig argv[0]>, <target>, <orig argv[1..]>]`. With no original argv
/// (should not happen for an execve), fall back to the target path as `argv[0]`.
fn rosetta_argv(target_path: &str, orig_argv: &[Vec<u8>]) -> Vec<Vec<u8>> {
    let mut new_argv: Vec<Vec<u8>> = Vec::with_capacity(orig_argv.len() + 1);
    new_argv.push(
        orig_argv
            .first()
            .cloned()
            .unwrap_or_else(|| target_path.as_bytes().to_vec()),
    );
    new_argv.push(target_path.as_bytes().to_vec());
    new_argv.extend(orig_argv.iter().skip(1).cloned());
    new_argv
}

/// Build the `RuntimeError` for "this is an x86_64 binary but Rosetta 2 is not
/// available on the host" — surfaced from the initial-load call sites (the
/// execve path returns the bare `-errno` instead).
fn rosetta_unavailable(errno: LinuxErrno, path: &str) -> RuntimeError {
    let errno = errno.get();
    RuntimeError::FsBackend(anyhow::anyhow!(
        "{path}: x86_64 binary requires Apple Rosetta 2 at {ROSETTA_INTERPRETER} \
         (errno {errno}); is Rosetta installed for Linux? \
         `softwareupdate --install-rosetta`"
    ))
}

/// Adapter presenting a separate (`memory`, `trap`) pair as one
/// `CurrentMmMemory + SyscallTrap` object, so `run_split_loop` reuses the combined
/// run loop instead of duplicating its ~200-line body. `GuestMemory` delegates
/// to `mem`, `SyscallTrap` to `trap`.
struct SplitView<'a, M: CurrentMmMemory, T: SyscallTrap> {
    mem: &'a mut M,
    trap: &'a mut T,
}

impl<M: CurrentMmMemory, T: SyscallTrap> GuestMemory for SplitView<'_, M, T> {
    // This adapter must be transparent. In particular, inheriting a modelless
    // default here silently bypasses the wrapped backend's physical repoint and
    // provenance publication while `run_syscall_loop` uses this split shape.
    fn protections(&self) -> Option<&carrick_guest_mem::protections::MemoryProtections> {
        self.mem.protections()
    }
    fn has_complete_mapping_metadata(&self) -> bool {
        self.mem.has_complete_mapping_metadata()
    }
    fn read_bytes(&self, address: u64, length: usize) -> Result<Vec<u8>, MemoryError> {
        self.mem.read_bytes(address, length)
    }
    fn write_bytes(&mut self, address: u64, bytes: &[u8]) -> Result<(), MemoryError> {
        self.mem.write_bytes(address, bytes)
    }
    fn read_bytes_raw(&self, address: u64, length: usize) -> Result<Vec<u8>, MemoryError> {
        self.mem.read_bytes_raw(address, length)
    }
    fn write_bytes_raw(&mut self, address: u64, bytes: &[u8]) -> Result<(), MemoryError> {
        self.mem.write_bytes_raw(address, bytes)
    }
    fn read_into(&self, address: u64, dst: &mut [u8]) -> Result<(), MemoryError> {
        self.mem.read_into(address, dst)
    }
    fn read_into_raw(&self, address: u64, dst: &mut [u8]) -> Result<(), MemoryError> {
        self.mem.read_into_raw(address, dst)
    }
    fn write_bytes_unchecked(&mut self, address: u64, bytes: &[u8]) -> Result<(), MemoryError> {
        self.mem.write_bytes_unchecked(address, bytes)
    }
    fn host_ptr_for_read(&self, address: u64, len: usize) -> Option<*const u8> {
        self.mem.host_ptr_for_read(address, len)
    }
    fn host_ptr_for_write(&mut self, address: u64, len: usize) -> Option<*mut u8> {
        self.mem.host_ptr_for_write(address, len)
    }
    fn begin_host_write(&mut self, ranges: &[(u64, usize)]) {
        self.mem.begin_host_write(ranges);
    }
    fn finish_host_write(&mut self, ranges: &[(u64, usize)]) {
        self.mem.finish_host_write(ranges);
    }
    fn zero_backing(&mut self, address: u64, len: usize) -> Result<(), MemoryError> {
        self.mem.zero_backing(address, len)
    }
    fn zero_anonymous_reuse(
        &mut self,
        address: u64,
        len: usize,
        sharing: carrick_guest_mem::MappingSharing,
    ) -> Result<(), MemoryError> {
        self.mem.zero_anonymous_reuse(address, len, sharing)
    }
    fn zero_guest_range(&mut self, address: u64, len: usize) -> Result<(), MemoryError> {
        self.mem.zero_guest_range(address, len)
    }
    fn guest_range_is_writable(&self, address: u64, length: usize) -> bool {
        self.mem.guest_range_is_writable(address, length)
    }
    fn set_no_access(&mut self, address: u64, len: usize, no_access: bool) {
        self.mem.set_no_access(address, len, no_access);
    }
    fn set_no_write(&mut self, address: u64, len: usize, no_write: bool) {
        self.mem.set_no_write(address, len, no_write);
    }
    fn set_unmapped(&mut self, address: u64, len: usize, unmapped: bool) {
        self.mem.set_unmapped(address, len, unmapped);
    }
    fn set_mapping_protection(
        &mut self,
        address: u64,
        len: usize,
        no_access: bool,
        no_write: bool,
    ) {
        self.mem
            .set_mapping_protection(address, len, no_access, no_write);
    }
    fn set_mapping_sharing(
        &mut self,
        address: u64,
        len: usize,
        sharing: carrick_guest_mem::MappingSharing,
    ) {
        self.mem.set_mapping_sharing(address, len, sharing);
    }
    fn set_mapping_protection_and_sharing(
        &mut self,
        address: u64,
        len: usize,
        no_access: bool,
        no_write: bool,
        sharing: carrick_guest_mem::MappingSharing,
    ) {
        self.mem
            .set_mapping_protection_and_sharing(address, len, no_access, no_write, sharing);
    }
    fn protect_range(&mut self, address: u64, len: usize, prot: u64) -> Result<(), MemoryError> {
        self.mem.protect_range(address, len, prot)
    }
    fn supports_concurrent_exec_protection(&self) -> bool {
        self.mem.supports_concurrent_exec_protection()
    }
    fn unmap_range(&mut self, address: u64, len: usize) -> Result<(), MemoryError> {
        self.mem.unmap_range(address, len)
    }
    fn unmap_alias_range(&mut self, address: u64, len: usize) -> Result<(), MemoryError> {
        self.mem.unmap_alias_range(address, len)
    }
    fn repoint_private(
        &mut self,
        va: u64,
        overlay_ipa: u64,
        len: usize,
        content: &[u8],
    ) -> Result<(), carrick_guest_mem::RepointPrivateError> {
        self.mem.repoint_private(va, overlay_ipa, len, content)
    }
    fn repoint_shared_leaf(
        &mut self,
        va: u64,
        target_ipa: u64,
        len: usize,
    ) -> Result<(), MemoryError> {
        self.mem.repoint_shared_leaf(va, target_ipa, len)
    }
    fn translate_va(&self, va: u64) -> Option<u64> {
        self.mem.translate_va(va)
    }
    fn resident_pages(
        &self,
        start: carrick_guest_mem::GuestVa,
        page_count: u64,
        page_size: u64,
    ) -> Option<Vec<u8>> {
        self.mem.resident_pages(start, page_count, page_size)
    }
    fn shared_futex_location(
        &self,
        guest_addr: u64,
    ) -> Option<carrick_guest_mem::SharedFutexLocation> {
        self.mem.shared_futex_location(guest_addr)
    }
}

impl<M: CurrentMmMemory, T: SyscallTrap> CurrentMmMemory for SplitView<'_, M, T> {}

impl<M: CurrentMmMemory, T: SyscallTrap> SyscallTrap for SplitView<'_, M, T> {
    fn next_syscall(&mut self) -> Result<Option<carrick_hal::RawSyscall>, TrapError> {
        self.trap.next_syscall()
    }
    fn current_pc(&self) -> Result<u64, TrapError> {
        self.trap.current_pc()
    }
    fn complete_syscall(&mut self, return_value: i64) -> Result<(), TrapError> {
        self.trap.complete_syscall(return_value)
    }
    fn execve_into(&mut self, new_image: &AddressSpace) -> Result<(), TrapError> {
        self.trap.execve_into(new_image)
    }
    fn is_forked_child(&self) -> bool {
        self.trap.is_forked_child()
    }
    fn process_exit_cleanup(&mut self) -> Result<(), TrapError> {
        self.trap.process_exit_cleanup()
    }
    fn inject_signal(&mut self, signal: carrick_hal::SignalInjection) -> Result<(), TrapError> {
        self.trap.inject_signal(signal)
    }
    fn last_syscall_nr(&self) -> Option<u64> {
        self.trap.last_syscall_nr()
    }
    fn restore_from_sigframe(&mut self) -> Result<u64, TrapError> {
        self.trap.restore_from_sigframe()
    }
    fn set_memory_model(&mut self, tso: bool) -> Result<(), TrapError> {
        self.trap.set_memory_model(tso)
    }
    fn map_host_alias(
        &mut self,
        va: GuestVa,
        ipa: Gpa,
        len: u64,
        payload: &[u8],
        backing: carrick_hal::HostAliasBacking,
    ) -> Result<(), TrapError> {
        self.trap.map_host_alias(va, ipa, len, payload, backing)
    }
}

/// Single-threaded run loop over a separate (`memory`, `trap`) pair. Wraps them
/// in a [`SplitView`] and delegates to `run_combined_syscall_loop_with_dispatcher`
/// — one loop body, two entry shapes (this was ~200 duplicated lines).
fn run_split_loop<M, T>(
    memory: &mut M,
    trap: &mut T,
    dispatcher: SyscallDispatcher,
    max_traps: usize,
) -> Result<RunResult, RuntimeError>
where
    M: CurrentMmMemory,
    T: SyscallTrap,
{
    let mut view = SplitView { mem: memory, trap };
    run_combined_syscall_loop_with_dispatcher(&mut view, dispatcher, max_traps)
}

// `impl SyscallTrap for HvfTrapEngine` moved into carrick-vmm-hvf (trap.rs):
// both the trait and the type now live there, so the impl must too (orphan
// rule). The blanket loop bounds (`T: SyscallTrap`) and `SplitView` impl below
// use the re-exported trait and are unchanged.

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Default)]
    struct RetryCompletionTrap {
        completed: Vec<i64>,
        syscalls: std::collections::VecDeque<carrick_hal::RawSyscall>,
        restored_sigframes: usize,
        execve_calls: usize,
        memory: std::collections::BTreeMap<u64, u8>,
    }

    impl carrick_guest_mem::GuestMemory for RetryCompletionTrap {
        fn read_bytes_raw(
            &self,
            address: u64,
            length: usize,
        ) -> Result<Vec<u8>, carrick_guest_mem::MemoryError> {
            Ok((0..length)
                .map(|offset| {
                    self.memory
                        .get(&(address + offset as u64))
                        .copied()
                        .unwrap_or(0)
                })
                .collect())
        }

        fn write_bytes_raw(
            &mut self,
            address: u64,
            bytes: &[u8],
        ) -> Result<(), carrick_guest_mem::MemoryError> {
            for (offset, byte) in bytes.iter().copied().enumerate() {
                self.memory.insert(address + offset as u64, byte);
            }
            Ok(())
        }
    }

    impl carrick_guest_mem::CurrentMmMemory for RetryCompletionTrap {}

    impl SyscallTrap for RetryCompletionTrap {
        fn next_syscall(&mut self) -> Result<Option<carrick_hal::RawSyscall>, TrapError> {
            Ok(self.syscalls.pop_front())
        }

        fn current_pc(&self) -> Result<u64, TrapError> {
            Ok(0)
        }

        fn complete_syscall(&mut self, return_value: i64) -> Result<(), TrapError> {
            self.completed.push(return_value);
            Ok(())
        }

        fn execve_into(&mut self, _new_image: &AddressSpace) -> Result<(), TrapError> {
            self.execve_calls += 1;
            Ok(())
        }

        fn inject_signal(
            &mut self,
            _signal: carrick_hal::SignalInjection,
        ) -> Result<(), TrapError> {
            Ok(())
        }

        fn restore_from_sigframe(&mut self) -> Result<u64, TrapError> {
            self.restored_sigframes += 1;
            Ok(0)
        }
    }

    fn scripted_syscall(number: u64, args: [u64; 6]) -> carrick_hal::RawSyscall {
        carrick_hal::RawSyscall {
            current_guest_sp: None,
            number: carrick_abi::CanonicalNr(number),
            args,
            guest_abi: carrick_abi::LinuxGuestAbi::Aarch64,
            native_number: carrick_abi::NativeNr(number),
        }
    }

    fn synthetic_exec_elf() -> Vec<u8> {
        const ET_EXEC: u16 = 2;
        const PT_LOAD: u32 = 1;
        let mut elf = vec![0_u8; 0x1000];
        elf[0..4].copy_from_slice(b"\x7fELF");
        elf[4] = 2;
        elf[5] = 1;
        elf[6] = 1;
        elf[16..18].copy_from_slice(&ET_EXEC.to_le_bytes());
        elf[18..20].copy_from_slice(&goblin::elf::header::EM_AARCH64.to_le_bytes());
        elf[20..24].copy_from_slice(&1_u32.to_le_bytes());
        elf[24..32].copy_from_slice(&0x400000_u64.to_le_bytes());
        elf[32..40].copy_from_slice(&64_u64.to_le_bytes());
        elf[52..54].copy_from_slice(&64_u16.to_le_bytes());
        elf[54..56].copy_from_slice(&56_u16.to_le_bytes());
        elf[56..58].copy_from_slice(&1_u16.to_le_bytes());
        let ph = 64;
        elf[ph..ph + 4].copy_from_slice(&PT_LOAD.to_le_bytes());
        elf[ph + 4..ph + 8].copy_from_slice(&5_u32.to_le_bytes());
        elf[ph + 16..ph + 24].copy_from_slice(&0x400000_u64.to_le_bytes());
        elf[ph + 24..ph + 32].copy_from_slice(&0x400000_u64.to_le_bytes());
        let len = elf.len() as u64;
        elf[ph + 32..ph + 40].copy_from_slice(&len.to_le_bytes());
        elf[ph + 40..ph + 48].copy_from_slice(&len.to_le_bytes());
        elf[ph + 48..ph + 56].copy_from_slice(&0x1000_u64.to_le_bytes());
        elf
    }

    struct KillOnEntryObserver;

    impl carrick_kernel::observe::SyscallObserver for KillOnEntryObserver {
        fn on_syscall(
            &self,
            _process: &carrick_kernel::observe::ProcessInfo<'_>,
            _call: &carrick_kernel::observe::SyscallInfo<'_>,
        ) -> carrick_kernel::observe::SyscallAction {
            carrick_kernel::observe::SyscallAction::Kill(carrick_kernel::dispatch::Signal(
                crate::linux_abi::LINUX_SIGKILL,
            ))
        }
    }

    struct RedispatchCountingInterceptor(std::sync::Arc<std::sync::atomic::AtomicUsize>);

    impl carrick_kernel::observe::SyscallInterceptor for RedispatchCountingInterceptor {
        fn intercept(
            &self,
            _process: &carrick_kernel::observe::ProcessInfo<'_>,
            _call: &carrick_kernel::observe::InterceptedSyscall<'_>,
        ) -> carrick_kernel::observe::InterceptAction {
            self.0.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            carrick_kernel::observe::InterceptAction::Continue
        }
    }

    #[test]
    fn interception_redispatch_reuses_one_prepared_envelope_once_and_twice() {
        for redispatches in [1, 2] {
            let calls = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
            let mut dispatcher = SyscallDispatcher::new();
            dispatcher.install_interceptor(std::sync::Arc::new(RedispatchCountingInterceptor(
                std::sync::Arc::clone(&calls),
            )));
            let context = dispatcher.capture_one_task_context().unwrap();
            let reporter = CompatReporter::default();
            let prepared = dispatcher
                .prepare_syscall(
                    &context,
                    SyscallRequest::new(92, crate::compat::SyscallArgs::from([0; 6])),
                    &reporter,
                )
                .unwrap();
            let PreparedDispatch::Invoke(syscall) = prepared else {
                panic!("personality must invoke its handler")
            };
            let mut token = Some(SyscallCompletionToken::new(
                syscall,
                context.retain_exact(),
                dispatcher.observers().cloned(),
            ));
            let mut memory =
                carrick_kernel::dispatch::LinearMemory::new(0x4000_0000, vec![0; 4096]);
            let mut waiter = carrick_vmm_hvf::io_wait::ThreadWaiter::new(
                crate::thread::ThreadId::synthetic_for_tests(72_410 + redispatches),
            );
            let mut handler_calls = 0;
            let outcome = dispatch_single_threaded_syscall_with(
                &mut dispatcher,
                &context,
                syscall,
                &mut memory,
                &reporter,
                &mut waiter,
                |_, _, received, _, _| {
                    handler_calls += 1;
                    assert_eq!(received.request.args, syscall.request.args);
                    if handler_calls <= redispatches {
                        Ok(DispatchOutcome::WaitOnHvpatchChild {
                            target: None,
                            sig_mask: carrick_abi::WaitSigMask::NONE,
                            precheck: carrick_kernel::kernel::ChildWaitPrecheck::unsampled(),
                        })
                    } else {
                        Ok(DispatchOutcome::Returned { value: 17 })
                    }
                },
            )
            .unwrap();
            assert_eq!(outcome, DispatchOutcome::Returned { value: 17 });
            let mut trap = RetryCompletionTrap::default();
            complete_single_threaded_syscall(&mut trap, &mut token, &reporter, 17).unwrap();

            assert_eq!(
                calls.load(std::sync::atomic::Ordering::Relaxed),
                1,
                "redispatch count {redispatches} reran interception"
            );
            assert_eq!(handler_calls, redispatches + 1);
            assert_eq!(trap.completed, vec![17]);
            assert!(token.is_none());
            let report = reporter.snapshot();
            assert_eq!(report.summary.syscall_invocations, 1);
            assert_eq!(report.summary.syscall_returns_ok, 1);
        }
    }

    #[test]
    fn interception_blocking_write_partial_completion_publishes_actual_value_once() {
        let dispatcher = &mut SyscallDispatcher::new();
        let context = dispatcher.capture_one_task_context().unwrap();
        let reporter = CompatReporter::default();
        let prepared = dispatcher
            .prepare_syscall(
                &context,
                SyscallRequest::new(92, crate::compat::SyscallArgs::from([0; 6])),
                &reporter,
            )
            .unwrap();
        let PreparedDispatch::Invoke(syscall) = prepared else {
            panic!("partial completion fixture must invoke")
        };
        let mut completion = Some(SyscallCompletionToken::new(
            syscall,
            context.retain_exact(),
            dispatcher.observers().cloned(),
        ));
        let mut fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(fds.as_mut_ptr()) }, 0);
        let write = carrick_kernel::dispatch::BlockingWrite::for_tests(
            fds[1],
            vec![1, 2, 3, 4],
            2,
            crate::thread::ThreadId::synthetic_for_tests(72_411),
            true,
        )
        .unwrap();
        assert_eq!(unsafe { libc::close(fds[0]) }, 0);
        assert_eq!(unsafe { libc::close(fds[1]) }, 0);
        let mut memory = carrick_kernel::dispatch::LinearMemory::new(0x4000_0000, vec![0; 4096]);
        let mut waiter = carrick_vmm_hvf::io_wait::ThreadWaiter::new(
            crate::thread::ThreadId::synthetic_for_tests(72_411),
        );
        let mut write = Some(write);

        let outcome = dispatch_single_threaded_syscall_with(
            dispatcher,
            &context,
            syscall,
            &mut memory,
            &reporter,
            &mut waiter,
            |_, _, _, _, _| {
                Ok(DispatchOutcome::BlockingWrite(
                    write.take().expect("handler runs once"),
                ))
            },
        )
        .unwrap();
        assert_eq!(outcome, DispatchOutcome::Returned { value: 2 });
        let mut trap = RetryCompletionTrap::default();
        complete_single_threaded_syscall(&mut trap, &mut completion, &reporter, 2).unwrap();

        assert_eq!(trap.completed, vec![2]);
        assert!(completion.is_none());
        assert_eq!(reporter.snapshot().summary.syscall_invocations, 1);
        assert_eq!(reporter.snapshot().summary.syscall_returns_ok, 1);
    }

    #[test]
    fn interception_nonreturning_rt_sigreturn_and_exit_retire_without_publication() {
        let mut runtime = RetryCompletionTrap {
            syscalls: std::collections::VecDeque::from([
                scripted_syscall(139, [0; 6]),
                scripted_syscall(94, [7, 0, 0, 0, 0, 0]),
            ]),
            ..Default::default()
        };

        let result =
            run_combined_syscall_loop_with_dispatcher(&mut runtime, SyscallDispatcher::new(), 3)
                .unwrap();

        assert_eq!(result.exit_code, 7);
        assert_eq!(runtime.restored_sigframes, 1);
        assert!(runtime.completed.is_empty());
        assert_eq!(result.report.summary.syscall_invocations, 2);
        assert_eq!(result.report.summary.syscall_returns_ok, 0);
        assert_eq!(result.report.summary.syscall_returns_errno, 0);
    }

    #[test]
    fn interception_nonreturning_signal_death_retires_without_publication() {
        let mut dispatcher = SyscallDispatcher::new();
        dispatcher.install_observer(std::sync::Arc::new(KillOnEntryObserver));
        let mut runtime = RetryCompletionTrap {
            syscalls: std::collections::VecDeque::from([scripted_syscall(92, [0; 6])]),
            ..Default::default()
        };

        let result =
            run_combined_syscall_loop_with_dispatcher(&mut runtime, dispatcher, 2).unwrap();

        assert_eq!(
            result.terminating_signal,
            Some(crate::linux_abi::LINUX_SIGKILL)
        );
        assert!(runtime.completed.is_empty());
        assert_eq!(result.report.summary.syscall_invocations, 1);
        assert_eq!(result.report.summary.syscall_returns_ok, 0);
        assert_eq!(result.report.summary.syscall_returns_errno, 0);
    }

    #[test]
    fn interception_nonreturning_successful_exec_retires_without_publication() {
        let path = std::env::temp_dir().join(format!(
            "carrick-task4-exec-{}-{}",
            std::process::id(),
            std::thread::current().name().unwrap_or("test")
        ));
        std::fs::write(&path, synthetic_exec_elf()).unwrap();
        use std::os::unix::fs::PermissionsExt as _;
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o755)).unwrap();
        let path = path.to_string_lossy().into_owned();
        let path_address = 0x1000;
        let argv_address = 0x2000;
        let env_address = 0x3000;
        let mut runtime = RetryCompletionTrap {
            syscalls: std::collections::VecDeque::from([
                scripted_syscall(221, [path_address, argv_address, env_address, 0, 0, 0]),
                scripted_syscall(94, [9, 0, 0, 0, 0, 0]),
            ]),
            ..Default::default()
        };
        for (offset, byte) in path
            .as_bytes()
            .iter()
            .copied()
            .chain(std::iter::once(0))
            .enumerate()
        {
            runtime.memory.insert(path_address + offset as u64, byte);
        }
        for (offset, byte) in path_address
            .to_le_bytes()
            .into_iter()
            .chain(0_u64.to_le_bytes())
            .enumerate()
        {
            runtime.memory.insert(argv_address + offset as u64, byte);
        }
        for (offset, byte) in 0_u64.to_le_bytes().into_iter().enumerate() {
            runtime.memory.insert(env_address + offset as u64, byte);
        }

        let result =
            run_combined_syscall_loop_with_dispatcher(&mut runtime, SyscallDispatcher::new(), 3);
        let _ = std::fs::remove_file(&path);
        let result = result.unwrap();

        assert_eq!(result.exit_code, 9);
        assert_eq!(runtime.execve_calls, 1);
        assert!(runtime.completed.is_empty());
        assert_eq!(result.report.summary.syscall_invocations, 2);
        assert_eq!(result.report.summary.syscall_returns_ok, 0);
        assert_eq!(result.report.summary.syscall_returns_errno, 0);
    }

    #[cfg(feature = "syscall-shim")]
    struct ContinueInterceptor;

    #[cfg(feature = "syscall-shim")]
    impl carrick_kernel::observe::SyscallInterceptor for ContinueInterceptor {
        fn intercept(
            &self,
            _process: &carrick_kernel::observe::ProcessInfo<'_>,
            _call: &carrick_kernel::observe::InterceptedSyscall<'_>,
        ) -> carrick_kernel::observe::InterceptAction {
            carrick_kernel::observe::InterceptAction::Continue
        }
    }

    #[cfg(feature = "syscall-shim")]
    struct RequiredObserver;

    #[cfg(feature = "syscall-shim")]
    impl carrick_kernel::observe::SyscallObserver for RequiredObserver {
        fn wants_fast_path_visibility(&self) -> carrick_kernel::observe::FastPathVisibility {
            carrick_kernel::observe::FastPathVisibility::Required
        }
    }

    #[cfg(feature = "syscall-shim")]
    fn image_region(image: &AddressSpace, start: u64) -> &[u8] {
        image
            .regions()
            .iter()
            .find(|region| region.start == start)
            .expect("required image region")
            .bytes()
    }

    #[cfg(feature = "syscall-shim")]
    #[test]
    fn interceptor_initial_image_preserves_closed_identity_page() {
        let mut dispatcher = SyscallDispatcher::new();
        dispatcher.install_interceptor(std::sync::Arc::new(ContinueInterceptor));
        let raw = AddressSpace::from_regions(0x4000, Vec::new()).expect("raw image");

        let mut image = finalize_hvf_initial_image(raw, &dispatcher, false)
            .expect("interceptor-bearing initial image");
        let context = dispatcher
            .capture_one_task_context()
            .expect("initial task context");
        stamp_identity_page(&mut image, &dispatcher, &context)
            .expect("closed identity page remains stampable");

        let identity = image_region(&image, carrick_mem::memory::LINUX_IDENTITY_PAGE_BASE);
        let gate = usize::try_from(carrick_mem::memory::IDENTITY_OFF_SHIM_ENABLED)
            .expect("identity gate offset");
        assert_eq!(&identity[gate..gate + 4], &0_u32.to_le_bytes());

        let vdso = image_region(&image, carrick_mem::vdso::LINUX_VDSO_BASE);
        let no_fastpaths = carrick_mem::vdso::vdso_image_bytes_without_fastpaths();
        assert_eq!(&vdso[..no_fastpaths.len()], no_fastpaths.as_slice());
    }

    #[cfg(feature = "syscall-shim")]
    #[test]
    fn observer_initial_image_preserves_closed_identity_page_without_interceptor() {
        let mut dispatcher = SyscallDispatcher::new();
        dispatcher.install_observer(std::sync::Arc::new(RequiredObserver));
        assert!(dispatcher.interceptors().is_none());
        let raw = AddressSpace::from_regions(0x4000, Vec::new()).expect("raw image");

        let mut image = finalize_hvf_initial_image(raw, &dispatcher, false)
            .expect("observer-visible initial image");
        let context = dispatcher
            .capture_one_task_context()
            .expect("initial task context");
        stamp_identity_page(&mut image, &dispatcher, &context)
            .expect("closed observer identity page remains stampable");

        let identity = image_region(&image, carrick_mem::memory::LINUX_IDENTITY_PAGE_BASE);
        let gate = usize::try_from(carrick_mem::memory::IDENTITY_OFF_SHIM_ENABLED)
            .expect("identity gate offset");
        assert_eq!(&identity[gate..gate + 4], &0_u32.to_le_bytes());
    }

    #[cfg(feature = "syscall-shim")]
    #[test]
    fn carrier_vector_page_is_identical_across_fast_path_visibility_policies() {
        let unrestricted = SyscallDispatcher::new();
        let mut observed = SyscallDispatcher::new();
        observed.install_observer(std::sync::Arc::new(RequiredObserver));
        let raw = || AddressSpace::from_regions(0x4000, Vec::new()).expect("raw image");
        let fast =
            finalize_hvf_initial_image(raw(), &unrestricted, false).expect("unrestricted image");
        let visible =
            finalize_hvf_initial_image(raw(), &observed, true).expect("observer-visible image");

        assert_eq!(
            image_region(&fast, carrick_mem::memory::LINUX_EL1_VECTORS_BASE),
            image_region(&visible, carrick_mem::memory::LINUX_EL1_VECTORS_BASE),
            "carrier-wide vector code must not encode per-container visibility"
        );
    }

    #[cfg(feature = "syscall-shim")]
    #[test]
    fn unrestricted_initial_image_preserves_fastpaths() {
        use carrick_hal::GuestArch as _;

        type HvfArch = <HvfTrapEngine as carrick_hal::ThreadedEngine>::Arch;
        let dispatcher = SyscallDispatcher::new();
        let raw = AddressSpace::from_regions(0x4000, Vec::new()).expect("raw image");
        let image = finalize_hvf_initial_image(raw, &dispatcher, false)
            .expect("unrestricted initial image");

        image_region(&image, carrick_mem::memory::LINUX_IDENTITY_PAGE_BASE);
        let clock_stub = image
            .regions()
            .iter()
            .find(|region| region.start == carrick_mem::memory::LINUX_EL0_CLOCK_STUB_BASE)
            .expect("production image must install the raw-clock EL0 transport");
        assert!(clock_stub.perms.read);
        assert!(!clock_stub.perms.write);
        assert!(clock_stub.perms.execute);
        let vdso = image_region(&image, carrick_mem::vdso::LINUX_VDSO_BASE);
        assert_eq!(&vdso[..HvfArch::vdso_bytes().len()], HvfArch::vdso_bytes());
    }

    #[test]
    fn runtime_host_process_creation_inventory_is_exact_and_shrinking() {
        use std::collections::BTreeMap;

        fn visit_rs_files(root: &Path, current: &Path, files: &mut Vec<PathBuf>) {
            for entry in std::fs::read_dir(current).expect("read runtime source directory") {
                let path = entry.expect("runtime source entry").path();
                if path.is_dir() {
                    visit_rs_files(root, &path, files);
                } else if path.extension().is_some_and(|extension| extension == "rs") {
                    files.push(
                        path.strip_prefix(root)
                            .expect("relative source path")
                            .to_owned(),
                    );
                }
            }
        }

        let expected: BTreeMap<&str, [usize; 3]> = BTreeMap::from([
            // NOT rows any more: `fs_backend/tests.rs` left this crate with the
            // filesystem model (carrick-vfs), and eight more rows
            // (`dispatch/ioring.rs`, `dispatch/mem/tests.rs`,
            // `dispatch/sysv.rs`, `dispatch/tests.rs`, `exec_stamps.rs`,
            // `kernel/continuation/tests.rs`, `network/socket_namespace.rs`,
            // `run_state.rs`) left it with the kernel (carrick-kernel). This
            // inventory scans `CARGO_MANIFEST_DIR/src`, so they are out of
            // SCOPE here, not retired: every one of them is still gated, by
            // `scripts/migrate/check-carrier-only-process-invariant.py` in
            // `just lint-domains`, whose scan roots follow the code.
            // This unit test self-spawns to isolate a process-global abort
            // boundary while proving pending exec error preservation. It is
            // not production host-process-per-guest architecture.
            ("vcpu_loop/exec.rs", [0, 0, 1]),
            // Task 7's budget-one proof self-spawns this exact unit test in an
            // isolated process so it can install the process-global vCPU
            // scheduler before any sibling test initializes the OnceLock. The
            // test moved with the carrier foreign-COW projection tests from
            // `kernel/mm_access.rs` (Task 2.2 of the crate extraction).
            ("vcpu_loop/memory.rs", [0, 0, 1]),
            // Both are unit tests that fork a child to BE the tracee, because
            // a ptrace stop needs a real host parent/child pair:
            // 1. `ptrace_signal_stop_queued_host_sigkill_remains_terminal`
            // 2. `synchronous_fault_stops_for_ptrace_before_default_termination`
            // (added by `ac13739db` without moving this row). Neither is a
            // production host-process creation, which is what this inventory
            // is shrinking toward zero.
            ("vcpu_loop/signal.rs", [2, 0, 0]),
            // `wedge_capture.rs` carries the one reviewed OPERATOR BOUNDARY
            // (`sudo -n lldb`) but is NOT a row here: it lives beside the
            // deadlock watchdog it serves, in `carrick-kernel`, so this
            // carrier-crate scan never sees it. Its limit is stated in
            // `scripts/migrate/check-carrier-only-process-invariant.py`, which
            // scans the whole workspace.
        ]);
        let patterns = [
            ["unsafe { libc::", "fork()"].concat(),
            ["libc::posix_", "spawn("].concat(),
            ["Command", "::new("].concat(),
        ];
        let source_root = Path::new(env!("CARGO_MANIFEST_DIR")).join("src");
        let mut files = Vec::new();
        visit_rs_files(&source_root, &source_root, &mut files);
        let mut observed = BTreeMap::new();
        for relative in files {
            let source = std::fs::read_to_string(source_root.join(&relative))
                .expect("read runtime source file");
            let counts = patterns
                .each_ref()
                .map(|pattern| source.matches(pattern).count());
            if counts != [0, 0, 0] {
                observed.insert(relative.to_string_lossy().into_owned(), counts);
            }
        }
        let expected: BTreeMap<String, [usize; 3]> = expected
            .into_iter()
            .map(|(path, counts)| (path.to_owned(), counts))
            .collect();
        assert_eq!(
            observed, expected,
            "runtime host-process creation changed; classify the exact call as a test, explicit operator boundary, or retirement regression before updating this shrinking inventory"
        );
    }

    #[test]
    fn namespace_supervisor_launch_surface_is_deleted() {
        let runtime_source = include_str!("runtime.rs");
        let execute_source = include_str!("execute.rs");
        let pid_source = include_str!("../../carrick-kernel/src/namespace/pid.rs");
        let namespace_source = include_str!("../../carrick-kernel/src/namespace/mod.rs");

        for forbidden in [
            ["Supervisor", "Role"].concat(),
            ["maybe_fork_ns_", "supervisor"].concat(),
        ] {
            assert!(
                !runtime_source.contains(&forbidden),
                "runtime launch must not retain namespace-supervisor surface `{forbidden}`"
            );
        }
        let launch_source = runtime_source
            .split("fn run_address_space_with_hvf_and_dispatcher")
            .nth(1)
            .and_then(|tail| {
                tail.split("/// Install the macOS/HVF AArch64 syscall transport")
                    .next()
            })
            .expect("HVPatch runtime launch source");
        assert!(
            !launch_source.contains(&["libc::", "fork"].concat()),
            "HVPatch runtime launch must not create a host process"
        );
        for forbidden in [
            "request_supervisor",
            "supervisor_requested",
            "REG_PIPE_WRITE",
            "set_reg_pipe_write",
            "notify_registration",
        ] {
            assert!(
                !execute_source.contains(forbidden) && !pid_source.contains(forbidden),
                "carrier-only PID placement must delete {forbidden}"
            );
        }
        assert!(
            !namespace_source.contains("pub mod supervisor"),
            "carrier-only namespace module must not compile the retired supervisor"
        );
        assert!(
            !std::path::Path::new(concat!(
                env!("CARGO_MANIFEST_DIR"),
                "/../carrick-kernel/src/namespace/supervisor.rs"
            ))
            .exists(),
            "retired namespace supervisor implementation must stay deleted"
        );
    }

    #[test]
    fn setup_failure_has_one_vm_teardown_and_runtime_error_artifact() {
        let ledger = std::sync::Arc::new(crate::vm_lifecycle::VmLifecycleLedger::default());
        ledger.record_raw(0, 0);
        ledger.record_raw(1, 0);
        let destroy_count = std::cell::Cell::new(0_u32);
        let terminal_count = std::cell::Cell::new(0_u32);
        let publication_count = std::cell::Cell::new(0_u32);

        let destroy_ledger = std::sync::Arc::clone(&ledger);
        let terminal_ledger = std::sync::Arc::clone(&ledger);
        let publication_ledger = std::sync::Arc::clone(&ledger);
        let result = finalize_persistent_hvf_run(
            Err(RuntimeError::Unsupported(
                "deterministic post-vCPU setup failure".to_owned(),
            )),
            || {
                destroy_count.set(destroy_count.get() + 1);
                destroy_ledger.record_raw(2, -1);
                destroy_ledger.record_raw(3, -1);
                Ok(())
            },
            |terminal| {
                terminal_count.set(terminal_count.get() + 1);
                terminal_ledger.record_terminal(terminal);
            },
            |run| {
                assert!(run.is_err());
                publication_count.set(publication_count.get() + 1);
                let digest = "00".repeat(32);
                let bytes = crate::vm_lifecycle::render_completed_artifact(
                    &publication_ledger.snapshot(),
                    digest.clone(),
                    digest.clone(),
                    digest.clone(),
                    digest,
                )
                .map_err(|error| RuntimeError::Unsupported(error.to_string()))?;
                let summary = crate::vm_lifecycle::validate_artifact(&bytes)
                    .map_err(|error| RuntimeError::Unsupported(error.to_string()))?;
                assert!(matches!(
                    summary.terminal,
                    crate::vm_lifecycle::VmRunTerminalOutcome::RuntimeError
                ));
                Ok(())
            },
        );

        assert!(result.is_err());
        assert_eq!(destroy_count.get(), 1);
        assert_eq!(terminal_count.get(), 1);
        assert_eq!(publication_count.get(), 1);
    }

    fn rootfs_with(files: &[(&str, &[u8])]) -> carrick_vfs::rootfs::RootFs {
        let mut b = tar::Builder::new(Vec::new());
        for (path, data) in files {
            let mut h = tar::Header::new_gnu();
            h.set_entry_type(tar::EntryType::Regular);
            h.set_mode(0o755);
            h.set_size(data.len() as u64);
            b.append_data(&mut h, path, *data).unwrap();
        }
        let bytes = b.into_inner().unwrap();
        carrick_vfs::rootfs::RootFs::from_layers(std::iter::once(
            carrick_vfs::rootfs::LayerSource::Tar(bytes),
        ))
        .unwrap()
    }

    #[test]
    fn entrypoint_path_search_resolves_bare_command_like_execvp() {
        // Docker accepts a bare entrypoint command and PATH-resolves it; `env`
        // lives ONLY in /usr/bin, so finding it proves a real $PATH walk.
        let rootfs = rootfs_with(&[("bin/ls", b"\x7fELFx"), ("usr/bin/env", b"\x7fELFx")]);
        let dispatcher = SyscallDispatcher::with_rootfs(rootfs);
        let env = vec!["PATH=/usr/local/bin:/usr/bin:/bin".to_string()];

        // Bare names resolve to the first PATH dir that has them.
        assert_eq!(
            carrick_kernel::exec_helpers::resolve_entrypoint_path("ls", &env, &dispatcher),
            "/bin/ls"
        );
        assert_eq!(
            carrick_kernel::exec_helpers::resolve_entrypoint_path("env", &env, &dispatcher),
            "/usr/bin/env"
        );
        // A path containing '/' is returned unchanged (execve, not execvp).
        assert_eq!(
            carrick_kernel::exec_helpers::resolve_entrypoint_path("/sbin/foo", &env, &dispatcher),
            "/sbin/foo"
        );
        assert_eq!(
            carrick_kernel::exec_helpers::resolve_entrypoint_path("./x", &env, &dispatcher),
            "./x"
        );
        // Not found anywhere on PATH → keep the bare name (so the load error names it).
        assert_eq!(
            carrick_kernel::exec_helpers::resolve_entrypoint_path("nope", &env, &dispatcher),
            "nope"
        );
        // No PATH in env → fall back to the standard default set (covers /usr/bin).
        assert_eq!(
            carrick_kernel::exec_helpers::resolve_entrypoint_path("env", &[], &dispatcher),
            "/usr/bin/env"
        );
    }

    #[test]
    fn entrypoint_program_resolves_shebang_to_interpreter() {
        // A script entrypoint (`#!/bin/sh`) must load its INTERPRETER with the
        // script spliced into argv — Docker / execve(2) semantics — instead of
        // being handed to the ELF loader as "not an ELF binary".
        // (`carrick run --entrypoint <script>`.)
        let rootfs = rootfs_with(&[
            ("entry.sh", b"#!/bin/sh\necho hi\n"),
            ("bin/sh", b"\x7fELFx"),
        ]);
        let dispatcher = SyscallDispatcher::with_rootfs(rootfs);

        let (path, argv) = carrick_kernel::exec_helpers::resolve_entrypoint_program(
            "/entry.sh",
            &[],
            vec![b"/entry.sh".to_vec(), b"arg1".to_vec()],
            &dispatcher,
        )
        .expect("entrypoint program resolves");

        assert_eq!(path, "/bin/sh");
        assert_eq!(
            argv,
            vec![b"/bin/sh".to_vec(), b"/entry.sh".to_vec(), b"arg1".to_vec(),]
        );
    }

    #[test]
    fn entrypoint_program_passes_through_plain_elf() {
        // A normal ELF entrypoint is unchanged (no shebang, no argv splice).
        let rootfs = rootfs_with(&[("bin/true", b"\x7fELFx")]);
        let dispatcher = SyscallDispatcher::with_rootfs(rootfs);
        let (path, argv) = carrick_kernel::exec_helpers::resolve_entrypoint_program(
            "/bin/true",
            &[],
            vec![b"/bin/true".to_vec()],
            &dispatcher,
        )
        .expect("resolve");
        assert_eq!(path, "/bin/true");
        assert_eq!(argv, vec![b"/bin/true".to_vec()]);
    }

    // `vdso_debug_control_is_opt_out` moved to `carrick_kernel::vdso_policy` with the
    // code it tests.

    #[test]
    fn hardware_tso_debug_control_only_suppresses_requested_tso() {
        assert!(hardware_tso_for_debug_from_env(true, None));
        assert!(hardware_tso_for_debug_from_env(true, Some("0")));
        assert!(hardware_tso_for_debug_from_env(true, Some("false")));
        assert!(!hardware_tso_for_debug_from_env(true, Some("1")));
        assert!(!hardware_tso_for_debug_from_env(true, Some("true")));
        assert!(!hardware_tso_for_debug_from_env(true, Some("yes")));
        assert!(!hardware_tso_for_debug_from_env(true, Some("on")));
        assert!(!hardware_tso_for_debug_from_env(false, None));
        assert!(!hardware_tso_for_debug_from_env(false, Some("1")));
    }
}

#[cfg(test)]
mod rosetta_tests {
    use super::*;

    /// Minimal goblin-parseable ELF64 header with the given `e_machine`. No
    /// program headers needed — `inspect_elf_bytes` only reads the header.
    fn synthetic_elf(e_machine: u16) -> Vec<u8> {
        let mut elf = vec![0u8; 64];
        elf[0..4].copy_from_slice(b"\x7fELF");
        elf[4] = 2; // ELFCLASS64
        elf[5] = 1; // ELFDATA2LSB
        elf[6] = 1; // EV_CURRENT
        elf[16..18].copy_from_slice(&2u16.to_le_bytes()); // ET_EXEC
        elf[18..20].copy_from_slice(&e_machine.to_le_bytes());
        elf[20..24].copy_from_slice(&1u32.to_le_bytes()); // version
        elf[52..54].copy_from_slice(&64u16.to_le_bytes()); // e_ehsize
        elf
    }

    /// Synthetic *dynamic* x86_64 ELF: a 64-byte header plus one `PT_INTERP`
    /// program header pointing at an interpreter string, so `inspect_elf_bytes`
    /// reports `interpreter.is_some()` (the signal a target needs `AT_BASE`).
    fn synthetic_dynamic_x86_elf() -> Vec<u8> {
        const PT_INTERP: u32 = 3;
        let interp = b"/lib/ld-musl-x86_64.so.1\0";
        let ph_off = 64u64; // program headers immediately follow the ELF header
        let interp_off = 64 + 56; // one 56-byte phdr, then the interp string
        let mut elf = vec![0u8; interp_off + interp.len()];
        elf[0..4].copy_from_slice(b"\x7fELF");
        elf[4] = 2; // ELFCLASS64
        elf[5] = 1; // ELFDATA2LSB
        elf[6] = 1; // EV_CURRENT
        elf[16..18].copy_from_slice(&3u16.to_le_bytes()); // ET_DYN (PIE)
        elf[18..20].copy_from_slice(&62u16.to_le_bytes()); // EM_X86_64
        elf[20..24].copy_from_slice(&1u32.to_le_bytes()); // version
        elf[32..40].copy_from_slice(&ph_off.to_le_bytes()); // e_phoff
        elf[52..54].copy_from_slice(&64u16.to_le_bytes()); // e_ehsize
        elf[54..56].copy_from_slice(&56u16.to_le_bytes()); // e_phentsize
        elf[56..58].copy_from_slice(&1u16.to_le_bytes()); // e_phnum
        let ph = ph_off as usize;
        elf[ph..ph + 4].copy_from_slice(&PT_INTERP.to_le_bytes()); // p_type
        elf[ph + 8..ph + 16].copy_from_slice(&(interp_off as u64).to_le_bytes()); // p_offset
        elf[ph + 32..ph + 40].copy_from_slice(&(interp.len() as u64).to_le_bytes()); // p_filesz
        elf[interp_off..].copy_from_slice(interp);
        elf
    }

    const EM_AARCH64: u16 = 183;
    const EM_X86_64: u16 = 62;

    #[test]
    fn aarch64_binary_is_not_redirected() {
        let elf = synthetic_elf(EM_AARCH64);
        let argv = vec!["/bin/sh".to_string(), "-c".to_string()];
        assert!(maybe_redirect_to_rosetta("/bin/sh", &elf, &argv).is_none());
    }

    #[test]
    fn non_elf_is_not_redirected() {
        let not_elf = b"#!/bin/sh\necho hi\n";
        let argv = vec!["/script".to_string()];
        assert!(maybe_redirect_to_rosetta("/script", not_elf, &argv).is_none());
    }

    #[test]
    fn rosetta_argv_passes_program_argv0_through_not_the_interpreter() {
        // Pure argv construction — no Rosetta install needed, so the assertion
        // always runs. bash exec'ing a coreutils multi-call symlink resolves the
        // target to the real binary (/usr/bin/coreutils) but passes argv[0]="ls".
        // Apple's `rosetta` consumes argv[1] as the binary and presents the
        // program with argv = [argv[0], argv[2..]], so argv[0] MUST be "ls" — not
        // the interpreter — or the multi-call binary dispatches on "rosetta" and
        // errors ("coreutils: unknown program 'rosetta'"). Regression for that.
        let got = rosetta_argv("/usr/bin/coreutils", &[b"ls".to_vec(), b"-l".to_vec()]);
        assert_eq!(
            got,
            vec![
                b"ls".to_vec(),                 // program argv[0], passed through
                b"/usr/bin/coreutils".to_vec(), // the x86 binary for Rosetta (argv[1])
                b"-l".to_vec(),                 // program argv[1..]
            ]
        );
        assert_ne!(
            got[0],
            ROSETTA_INTERPRETER.as_bytes(),
            "argv[0] must be the program's argv0, never the interpreter path"
        );
    }

    #[test]
    fn x86_64_binary_redirects_to_rosetta_preserving_program_argv0() {
        let elf = synthetic_elf(EM_X86_64);
        let argv = vec!["uname".to_string(), "-m".to_string()];
        match maybe_redirect_to_rosetta("/usr/bin/uname", &elf, &argv) {
            // Rosetta installed: load is rewritten to Rosetta; argv[0] preserved.
            Some(Ok(redirect)) => {
                assert!(redirect.interpreter_bytes.starts_with(b"\x7fELF"));
                assert_eq!(
                    redirect.argv,
                    vec![
                        b"uname".to_vec(),          // program argv[0] (NOT the interpreter)
                        b"/usr/bin/uname".to_vec(), // x86 binary for Rosetta
                        b"-m".to_vec(),
                    ]
                );
            }
            // No Rosetta on this host: detected as x86_64 but unavailable.
            Some(Err(errno)) => assert_eq!(errno, crate::linux_abi::LINUX_ENOENT),
            None => panic!("x86_64 ELF must be detected for redirect"),
        }
    }

    #[test]
    fn dynamic_x86_64_target_is_flagged_so_rosetta_gets_at_base() {
        // A dynamic x86_64 target (has PT_INTERP) must be reported as dynamic so
        // the loader adds AT_BASE to the auxv it hands Rosetta. Without AT_BASE,
        // Rosetta omits it from the inner x86 auxv and musl's dynamic linker
        // null-derefs at startup (alpine `/bin/uname` exited 139 / SIGSEGV).
        // glibc's ld self-locates, which is why glibc-dynamic targets worked.
        let dynamic = synthetic_dynamic_x86_elf();
        let argv = vec!["uname".to_string()];
        match maybe_redirect_to_rosetta("/bin/uname", &dynamic, &argv) {
            Some(Ok(redirect)) => assert!(
                redirect.target_is_dynamic,
                "a PT_INTERP x86_64 target must be flagged dynamic so AT_BASE is added"
            ),
            // No Rosetta installed: detection still ran (it precedes the rosetta
            // read), but the redirect short-circuits to ENOENT before the flag.
            Some(Err(errno)) => assert_eq!(errno, crate::linux_abi::LINUX_ENOENT),
            None => panic!("x86_64 ELF must be detected for redirect"),
        }
    }

    #[test]
    fn static_x86_64_target_is_not_flagged_dynamic() {
        // A static x86_64 target (no PT_INTERP) must NOT be flagged: Linux omits
        // AT_BASE for static binaries, and a bogus AT_BASE with no interpreter to
        // overwrite it would mislead the translated program.
        let static_elf = synthetic_elf(EM_X86_64);
        let argv = vec!["prog".to_string()];
        match maybe_redirect_to_rosetta("/bin/prog", &static_elf, &argv) {
            Some(Ok(redirect)) => assert!(
                !redirect.target_is_dynamic,
                "a static x86_64 target must NOT be flagged dynamic"
            ),
            Some(Err(errno)) => assert_eq!(errno, crate::linux_abi::LINUX_ENOENT),
            None => panic!("x86_64 ELF must be detected for redirect"),
        }
    }

    #[test]
    fn rosetta_license_blob_is_sourced_from_binary_if_present() {
        // When Rosetta is installed, the licence blob is the NUL-terminated
        // verification string read live from its binary (never embedded here).
        if let Some(blob) = carrick_kernel::dispatch::rosetta::rosetta_license_blob() {
            assert!(blob.starts_with(b"Our hard work"));
            assert_eq!(blob.last(), Some(&0u8), "blob must end at the NUL");
        }
    }
}

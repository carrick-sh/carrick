//! The thin per-VMM backend trait pair (`Aarch64Vmm` + `Aarch64Vcpu`) and the
//! small value types they trade in (`Aarch64Exit`, `Aarch64VcpuSnapshot`,
//! `ForkRamStrategy`).
//!
//! This is the Axis-1 (aarch64 host/VMM) seam, mirroring `carrick-x86`'s
//! [`crate`]-level `X86Vmm`/`X86Vcpu` pair. Everything that is *genuinely*
//! per-VMM on aarch64 (HVF's `applevisor` trap surface vs KVM's MMIO-sentinel
//! trap surface) is named here, and `carrick-aarch64`'s engine scaffold is
//! written ONCE over this pair (Stage 2+). The trait surface is reverse-
//! engineered from the HVF ∩ KVM intersection: the genuinely-irreducible body is
//! [`Aarch64Vcpu::run`] (each backend decodes its native trap surface into
//! [`Aarch64Exit`]); the genuinely-per-VMM divergence is on [`Aarch64Vmm`]
//! (fork VM rebuild, execve remap, sibling spawn, stage-2 mapping, the HVF-only
//! lazy-alias re-map as the [`Aarch64Vmm::handle_memory_exit`] hook).
//!
//! Stage 1 defines this surface only — NOTHING implements it yet (no backend is
//! migrated). It must compile standalone.

use std::sync::Arc;

use carrick_guest_mem::protections::MemoryProtections;
use carrick_guest_mem::{Aarch64SyscallFrame, Gpa, MemoryError, SharedFutexLocation};
use carrick_hal::threaded::Aarch64TaskCpuStateV1;
use carrick_hal::{
    GuestEntryRegs, GuestVmBackend, HostAliasBacking, MemPerms, ProcessForkRequest, Reg, SlotId,
    SysReg, TrapError, VcpuKick, VcpuRegistry,
};
use carrick_mem::memory::AddressSpace;
use carrick_mem::page_table::PageTableManager;

/// COW-inherit vs eager full-RAM copy at `fork(2)`. Re-exported from
/// [`carrick_hal`] (the single canonical definition, shared with the x86 lane) so
/// existing `crate::vmm::ForkRamStrategy` references keep resolving.
pub use carrick_hal::ForkRamStrategy;

/// The shared exit shape. Lifted from HVF's `applevisor` `ExitReason`+`ESR.EC`
/// decode ∪ KVM's `VcpuExit::MmioWrite{gpa}`/`Kicked`/`Halt`. Backends decode
/// their native exit into THIS.
///
/// `resume_pc` rides [`Aarch64Exit::Syscall`] so the ENGINE owns the
/// pending-syscall state (the §2.1 contract). On aarch64 it is the post-`svc`
/// `ELR_EL1` the EL1 vector's `eret` consumes — so `complete_syscall` sets X0
/// only and never re-advances PC.
#[derive(Debug, Clone)]
pub enum Aarch64Exit {
    /// A guest EL0 `svc #0`. `frame` carries x0..x5 + x8 (already read via the
    /// shared `read_aarch64_syscall_frame`); `resume_pc` is `ELR_EL1` (= svc+4).
    /// HVF: surfaced when the EL1-vector vehicle is an EXCEPTION with
    /// EC==SVC/HVC-syscall. KVM: `MmioWrite{gpa == SENTINEL_GPA}`.
    Syscall {
        frame: Aarch64SyscallFrame,
        resume_pc: u64,
        /// Exact SP captured with this syscall, if supplied by the transport.
        current_guest_sp: Option<u64>,
    },

    /// An EL0 SYNCHRONOUS fault (data/instruction abort, alignment, undef, debug)
    /// the engine lowers to `TrapError::EL0Fault` then to `GuestFault`. Carries
    /// the raw architectural state both backends already build `el0_fault()`
    /// from. `from_el0_direct` is the ONE trap-surface bit: HVF gets a DIRECT
    /// EXCEPTION exit (authoritative PC=ELR, VA=FAR) => `true`; KVM steers the
    /// abort to the guest VBAR and catches it at the fault sentinel, latching
    /// `ELR_EL1`/`FAR_EL1` => `false`. (Matches
    /// `carrick_hal::TrapError::EL0Fault::from_el0_direct`.)
    EL0Fault {
        /// `ESR_EL1`.
        syndrome: u64,
        /// `ELR_EL1` (or authoritative exit PC).
        elr: u64,
        /// `FAR_EL1` (or authoritative exit VA).
        far: u64,
        x16: u64,
        x17: u64,
        x29: u64,
        x30: u64,
        sp: u64,
        from_el0_direct: bool,
    },

    /// A write-permission abort taken while Carrick's EL1 vector was copying
    /// state to a fork-COW user frame. The backend has restored the interrupted
    /// EL1 PC/PSTATE so resolving the frame and re-entering retries exactly the
    /// faulting vector instruction.
    Stage1CowFault { syndrome: u64, far: u64 },

    /// An EL0 `MRS` of an emulated ID/timer/cache register that trapped (Rosetta
    /// x86-on-arm + HVF). The engine's shared `emulate_el0_sys64_read` services
    /// it and re-enters; backends whose config never traps `MRS` never surface
    /// this (cf. x86's `FpDoorbell` / `Memory` defaults).
    Sys64Read {
        /// `ESR_EL1` (op0/op1/CRn/CRm/op2 decode).
        esr: u64,
    },

    /// The EL1 stage-1 TLBI maintenance trampoline finished
    /// (`run_el1_maintenance`). HVF: `hvc #1`. KVM:
    /// `MmioWrite{gpa == MAINT_SENTINEL_GPA}`. The shared maintenance loop
    /// matches on THIS instead of each backend matching its native vehicle.
    MaintenanceDone,

    /// WFI/halt with no syscall pending: the engine returns `Ok(None)`, the loop
    /// runs signal delivery and resumes.
    Halt,

    /// Cross-thread kick (HVF `hv_vcpus_exit` -> `ExitReason::CANCELED`; KVM
    /// signal -> `KVM_RUN` EINTR). The shared loop checks: if PC is in the
    /// carrick EL1 vector, swallow + re-enter; else report `Ok(None)`.
    Kicked,

    /// A backend memory exit a sparse/alias backend can resolve and retry. HVF
    /// uses this for the lazy high-VA alias re-map on a forked child's missing
    /// stage-2 entry; KVM never surfaces it (siblings share one VM). Mirrors
    /// `X86Exit::Memory{gpa}` + [`Aarch64Vmm::handle_memory_exit`] (default
    /// `Ok(false)`).
    Memory { gpa: u64, va: u64 },
}

/// Snapshot of a vCPU's full architectural register file (GPRs + stage-1 MMU
/// sysregs + V-regs + FP control), taken on the parent before `fork(2)`/`clone`/
/// `execve` and restored onto the child's rebuilt vCPU.
///
/// Promoted from `carrick-vmm-kvm/src/fork.rs::VcpuSnapshot` so HVF and KVM share
/// ONE snapshot format; the only per-VMM marshalling is
/// [`Aarch64Vcpu::snapshot`]/[`Aarch64Vcpu::restore`]. This is the FP-carrying
/// shape — `vregs`/`fpsr`/`fpcr` are real fields (a zero-stubbed FP form silently
/// corrupts a guest's NEON/FP state across fork/clone/execve and signal
/// save/restore). `.fpsr` holds FPSR and `.fpcr` holds FPCR (do NOT swap).
#[derive(Debug, Clone)]
pub struct Aarch64VcpuSnapshot {
    /// X0..X30 (the general-purpose register file).
    pub gprs: [u64; 31],
    pub pc: u64,
    pub pstate: u64,
    /// `user_pt_regs.sp` == SP_EL0 (the EL0/user stack pointer).
    pub sp_el0: u64,
    pub sp_el1: u64,
    pub elr_el1: u64,
    pub spsr_el1: u64,
    pub ttbr0: u64,
    pub ttbr1: u64,
    pub tcr: u64,
    pub sctlr: u64,
    pub mair: u64,
    pub vbar: u64,
    pub cpacr: u64,
    pub cntkctl_el1: u64,
    /// TPIDR_EL0 — the EL0 thread pointer (libc TLS base).
    pub tpidr_el0: u64,
    /// TPIDRRO_EL0 — the read-only EL0 thread pointer. `hv_vcpu_create` zeroes it
    /// and the guest can only READ it (EL1 writes it), so a fork/clone/reclaim must
    /// restore it — vDSO cpu-id / rseq read it. KVM does not use it (left 0).
    pub tpidrro_el0: u64,
    /// TPIDR_EL1 — carrick's per-vCPU scratch. HVF's syscall shim uses it only
    /// transiently to preserve x16 while checking ESR_EL1; the fast `gettid`
    /// path stores the guest tid in CONTEXTIDR_EL1 instead. (On KVM TPIDR_EL1
    /// backs the syscall-frame `saved_x9` stash; the snapshot carries it so a
    /// reclaim/fork round-trips that too.)
    pub tpidr_el1: u64,
    /// CONTEXTIDR_EL1 — the guest-visible tid that HVF's EL1 `gettid` fast path
    /// returns without a VM exit. `hv_vcpu_create` zeroes it, and an HVF reclaim
    /// DESTROYS and recreates the vCPU, so a rebuilt vCPU that does not restore
    /// this reads 0 and sends every later `gettid` down the handler's degrade
    /// branch to the host — silently, since the host still returns the correct
    /// tid, so only the cost changes. KVM does not use it (left 0).
    pub contextidr_el1: u64,
    /// ACTLR_EL1 — incl. EnTSO (Rosetta `prctl(PR_SET_MEM_MODEL, TSO)`). Restored
    /// across fork/clone/reclaim so a rebuilt vCPU keeps hardware x86 TSO. KVM has
    /// no such bit (left 0).
    pub actlr_el1: u64,
    /// V0..V31 (the full 128-bit NEON/FP register file).
    pub vregs: [u128; 32],
    /// FPSR.
    pub fpsr: u32,
    /// FPCR.
    pub fpcr: u32,
}

/// Per-vCPU register/run surface. The ONLY thing genuinely per-VMM on the vCPU
/// side. HVF wraps `applevisor::Vcpu`; KVM wraps its `KvmVcpu` (which already
/// provides every method body). Supersedes the bare
/// [`carrick_hal::HvVcpu`] — it adds snapshot/restore, V-regs, FP control, and
/// fault-register reads. The genuinely-per-VMM marshalling lives here and
/// NOWHERE in the shared engine.
pub trait Aarch64Vcpu {
    /// Latch a mandatory host boundary while stopped inside Carrick transport
    /// code. Returns whether an owned clock transaction was normalized; a
    /// guest jumping into the EL0 stub without ownership remains ordinary EL0.
    fn force_clock_host_boundary(&mut self) -> Result<bool, TrapError> {
        Ok(false)
    }

    // ── GPR / sysreg access ──
    fn get_reg(&self, r: Reg) -> Result<u64, TrapError>;
    fn set_reg(&mut self, r: Reg, v: u64) -> Result<(), TrapError>;
    fn get_sys_reg(&self, r: SysReg) -> Result<u64, TrapError>;
    fn set_sys_reg(&mut self, r: SysReg, v: u64) -> Result<(), TrapError>;

    // ── V-regs + FP control (aarch64 V0..V31 are full 128b) ──
    fn get_vreg(&self, n: u32) -> Result<u128, TrapError>;
    fn set_vreg(&mut self, n: u32, v: u128) -> Result<(), TrapError>;
    fn get_fpcr(&self) -> Result<u64, TrapError>;
    fn set_fpcr(&mut self, v: u64) -> Result<(), TrapError>;
    fn get_fpsr(&self) -> Result<u64, TrapError>;
    fn set_fpsr(&mut self, v: u64) -> Result<(), TrapError>;
    // NOTE: the applevisor `set_simd_fp_reg_v` C-shim (the u128-by-value ABI-bug
    // workaround) lives in the HVF impl of `set_vreg` ONLY; KVM calls its native
    // setter. This is exactly x86's "the backend provides the fix (if any)".

    // ── fault-register reads (for Aarch64Exit::EL0Fault capture) ──
    fn get_esr_el1(&self) -> Result<u64, TrapError>;
    fn get_far_el1(&self) -> Result<u64, TrapError>;

    // ── snapshot / restore (the VALUE is ISA-neutral; the I/O is per-VMM) ──
    fn snapshot(&self) -> Result<Aarch64VcpuSnapshot, TrapError>;
    fn restore(&mut self, snap: &Aarch64VcpuSnapshot) -> Result<(), TrapError>;

    /// Restore `snap` onto a FRESHLY-CREATED sibling vCPU (a `clone(CLONE_THREAD)`
    /// thread). DEFAULT: a plain [`Self::restore`] (KVM — its restore sets PC/PSTATE
    /// directly and a fresh KVM vCPU enters EL0 via its own MMIO vehicle). HVF
    /// OVERRIDES: a brand-new HVF vCPU has never transitioned to EL0, so it must
    /// start at the EL0 trampoline (in EL1h) with `SPSR_EL1=EL0t` and
    /// `ELR_EL1=snap.pc`, so the trampoline's single `eret` drops it into EL0 at the
    /// post-clone instruction — distinct from a `restore` that just resumes.
    fn restore_thread_start(&mut self, snap: &Aarch64VcpuSnapshot) -> Result<(), TrapError> {
        self.restore(snap)
    }

    /// The guest's real x9 at the trapped `svc`, IFF this backend's trap vehicle
    /// clobbered it. The EL1 sentinel vector clobbers x9 (the sentinel-store
    /// scratch) after stashing the guest's live x9 in a scratch sysreg (KVM:
    /// `TPIDR_EL1`, free at EL0). The shared `complete_syscall` restores it on every
    /// syscall return. The Linux aarch64 syscall ABI preserves x1..x30, and musl
    /// holds a live x9 across `brk(2)` (`__expand_heap` → `str x10,[x9,#920]`), so
    /// without this the guest faults on the sentinel GPA.
    ///
    /// `Some(x9)` ⟹ the vehicle clobbered x9; `complete_syscall` writes it back.
    /// DEFAULT `Ok(None)` ⟹ the vehicle leaves x9 live in the register file
    /// (HVF's `hvc #2` clobbers NO GPR), so `complete_syscall` must NOT touch it —
    /// a blanket `set_reg(X9, 0)` here would DESTROY the guest's live x9 (musl's
    /// malloc-context pointer) and fault it on the next `str x10,[x9,#920]`.
    fn get_saved_x9(&self) -> Result<Option<u64>, TrapError> {
        Ok(None)
    }

    /// Complete one ordinary syscall through this backend's return transport.
    ///
    /// The default is the established register path used by KVM: write x0 and
    /// restore x9 only when the trap vehicle reports that it clobbered it. HVF
    /// overrides this in mailbox mode so ordinary completion performs no
    /// Hypervisor.framework register calls; its diagnostic legacy mode retains
    /// the same register behavior.
    fn complete_syscall_return(&mut self, return_value: i64) -> Result<(), TrapError> {
        self.set_reg(Reg::X(0), return_value as u64)?;
        if let Some(saved_x9) = self.get_saved_x9()? {
            self.set_reg(Reg::X(9), saved_x9)?;
        }
        Ok(())
    }

    /// Return an ordinary syscall result still owned by a backend response
    /// mailbox. Register-return backends keep the default: x0 is already live.
    fn pending_syscall_return(&self) -> Result<Option<i64>, TrapError> {
        Ok(None)
    }

    /// Publish that the host has replaced the live register resume context.
    ///
    /// Most backends return directly through their register file and need no
    /// extra work. HVF mailbox mode overrides this so signal injection and
    /// sigreturn bypass a pending ordinary-return payload without treating
    /// unrelated internal EL1 maintenance as a syscall response.
    fn prepare_register_resume(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    /// Stamp the guest-visible thread id into the per-thread scratch sysreg the
    /// EL1-vector `gettid` fast path reads, so `gettid(2)` is serviced at EL1
    /// without a host trap. DEFAULT `Ok(())` (no-op) ⟹ this backend has no
    /// in-guest `gettid` fast path and the dispatcher services `gettid` on the
    /// host trap. Genuinely per-VMM: HVF stamps `TPIDR_EL1` (its `hvc` vehicle
    /// leaves that sysreg free); KVM CANNOT — its sentinel vehicle already uses
    /// `TPIDR_EL1` as the live-x9 stash (see [`Self::get_saved_x9`]), so it keeps
    /// the no-op and traps `gettid` to the host.
    fn stamp_guest_thread_id(&self, tid: u64) -> Result<(), TrapError> {
        let _ = tid;
        Ok(())
    }

    /// Run until the next exit, decoding the backend's native trap surface into
    /// [`Aarch64Exit`]. HVF: `hv_vcpu_run` + `get_exit_info()` => EXCEPTION+ESR.EC
    /// decode (svc / abort / sys64 MRS / maint-hvc) + CANCELED => `Kicked`. KVM:
    /// `KVM_RUN` => `MmioWrite{SENTINEL => Syscall, FAULT_SENTINEL => EL0Fault,
    /// MAINT_SENTINEL => MaintenanceDone}` + EINTR => `Kicked`. `resume_pc` filled
    /// at decode time; the ENGINE owns the pending-syscall state (§2.1).
    fn run(&mut self) -> Result<Aarch64Exit, TrapError>;

    /// Force this vCPU out of `run()` from another thread (HVF `hv_vcpus_exit`;
    /// KVM `pthread_kill(SIGRTMIN)`).
    fn kick(&self) -> Result<(), TrapError>;

    /// Set the hardware TSO (total-store-order) memory model. HVF sets
    /// `ACTLR_EL1.EnTSO` for Rosetta; KVM keeps the no-op default. Carried
    /// separately from [`Self::set_memory_model`] so a backend that needs both a
    /// guest-prctl entrypoint and a direct bring-up entrypoint has each.
    fn set_hardware_tso(&mut self, _tso: bool) -> Result<(), TrapError> {
        Ok(())
    }

    /// `prctl(PR_SET_MEM_MODEL, TSO)`: HVF sets `ACTLR_EL1.EnTSO` for Rosetta; KVM
    /// keeps the no-op default (matches `SyscallTrap::set_memory_model`).
    fn set_memory_model(&mut self, _tso: bool) -> Result<(), TrapError> {
        Ok(())
    }
}

/// One live guest-private writable range that fork must share read-only until
/// a stage-1 permission fault gives the writer a new frame.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ForkCowRange {
    pub va: u64,
    pub len: usize,
    pub executable: bool,
    /// The leaf is Carrick-owned EL1 state (AP=00), not an EL0 mapping. Fork
    /// arming must use AP=10 and COW publication must restore AP=00; using the
    /// ordinary user AP bits makes PSTATE.PAN reject the EL1 syscall vector's
    /// mailbox stores.
    pub kernel_only: bool,
    /// How much of the armed range one write fault privatizes.
    pub granule: CowGranule,
}

/// How much of a host compound one stage-1 permission fault privatizes.
///
/// Fork arms a whole private anonymous frame: every 4 KiB page of a 16 KiB
/// host compound is the same private backing, so privatizing the compound at
/// once is exact. A `MAP_PRIVATE` file view is different: Linux tracks later
/// `write(2)`s per clean 4 KiB page, so dirtying one page must leave its
/// clean siblings on the page-cache view.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CowGranule {
    /// One 16 KiB host compound.
    Compound,
    /// One 4 KiB Linux page.
    Page,
}

/// Why Carrick is about to modify a fork-COW-backed byte.
///
/// Guest-visible writes must respect the process's current VMA permission.
/// Backing maintenance (for example zeroing a freshly reallocated anonymous
/// page) runs before the new VMA permission is published, so it must split the
/// physical frame without granting the guest write access to the old mapping.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FrameCowWriteIntent {
    GuestVisible,
    BackingMaintenance,
    PrivilegedInternal,
}

/// VM-level memory + lifecycle. One per guest process. This is where the
/// GENUINELY-backend-specific divergence lives: fork VM rebuild, execve remap,
/// sibling spawn, host memory windows + stage-2 mapping, and the HVF-only
/// lazy-alias re-map (as the optional [`Self::handle_memory_exit`] hook). Mirrors
/// `carrick-x86`'s `X86Vmm`.
pub trait Aarch64Vmm: Sized + GuestVmBackend {
    type Vcpu: Aarch64Vcpu;

    /// Prepared exact-MM backing retirement; dropping it makes no changes.
    type AnonymousDiscard;

    /// The per-backend vCPU-kick handle (`KvmKickHandle` / `HvfKickHandle`).
    type KickHandle: VcpuKick + 'static;

    /// The `Send` payload `build_sibling_builder` hands a freshly spawned host
    /// thread; `materialize_sibling` turns it into a fresh `(Self, Self::Vcpu)`
    /// pair on the SAME VM (`clone(CLONE_THREAD)`) without re-registering memory.
    type SiblingBuilder: Send;
    type ProcessBuilder: Send;

    fn fd_ceiling_publisher(&self) -> Option<std::sync::Arc<dyn carrick_hal::FdCeilingPublisher>> {
        None
    }

    fn foreign_mm_endpoint(&self) -> Option<carrick_hal::ForeignMmEndpoint> {
        None
    }

    fn frame_cow_owner_inventory(
        &self,
    ) -> Option<std::sync::Arc<dyn carrick_hal::FrameCowOwnerInventory>> {
        None
    }

    fn audit_executor_boundary(&mut self, _vcpu: &mut Self::Vcpu) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "AArch64 VMM does not expose executor boundary audit authority".to_owned(),
        ))
    }

    fn restore_persistent_executor_invariants(
        &mut self,
        _vcpu: &mut Self::Vcpu,
    ) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "AArch64 VMM does not expose persistent executor invariant authority".to_owned(),
        ))
    }

    fn carrier_maintenance_root(
        &self,
    ) -> Result<carrick_mem::memory::CarrierMaintenanceRoot, TrapError> {
        Err(TrapError::Hypervisor(
            "AArch64 VMM does not expose a carrier maintenance root".to_owned(),
        ))
    }

    /// Retain the host VM across guest process lifecycle operations. HVF's
    /// hvpatch lane overrides this; ordinary VMM and non-HVF backends preserve
    /// their established rebuild behavior.
    fn set_persistent_vm_lifecycle(&mut self, _enabled: bool) {}

    fn prepare_exec_address_space(
        &mut self,
        _root_slot_base: u64,
        _root_slot_size: u64,
        _asid: u16,
    ) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "AArch64 VMM does not support exact exec MM replacement".to_owned(),
        ))
    }

    fn bind_exec_predecessor_identity(
        &mut self,
        _identity: carrick_hal::ExecPredecessorIdentity,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// See `carrick_hal::ThreadedEngine::mark_exec_predecessor_shared`.
    fn mark_exec_predecessor_shared(&mut self, _shared: bool) {}

    /// Whether this backend keeps the hidden mmap arena as invalid stage-1
    /// coverage and materializes only committed VMA backing. HVPatch overrides;
    /// mature HVF VMM and KVM preserve their eager mappings.
    fn bind_deferred_anonymous_state(
        &mut self,
        _state: std::sync::Arc<carrick_guest_mem::DeferredAnonymousState>,
    ) {
    }

    fn deferred_anonymous_state(
        &self,
    ) -> Option<std::sync::Arc<carrick_guest_mem::DeferredAnonymousState>> {
        None
    }

    fn sparse_mmap_arena_enabled(&self) -> bool {
        false
    }

    /// Host mapping granule whose low address bits must match the file offset
    /// for a deferred private file view. Backends without a direct immutable
    /// file-view mapping return `None` and never advertise this lazy lane.
    fn private_file_view_granule(&self) -> Option<u64> {
        None
    }

    /// Retire the generic loader's eager mmap-arena mapping after the HVPatch
    /// backend is selected and stage-1 has been made inaccessible.
    fn retire_initial_mmap_arena(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    /// Ensure a committed sparse mmap range has private per-mm physical
    /// backing before stage-1 makes it accessible. Default is a no-op for
    /// backends whose boot mapping already owns the full arena.
    fn ensure_sparse_mmap_backing(
        &mut self,
        _va: u64,
        _len: usize,
        _flush_stage1: &mut dyn FnMut() -> Result<(), TrapError>,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// Materialize a committed sparse mmap range as a `MAP_PRIVATE` file
    /// mapping whose clean pages read the file's live page cache (Linux:
    /// a later `write(2)` is visible through a never-written private page)
    /// and whose first guest store privatizes exactly one 4 KiB page.
    /// `Ok(false)` means the backend cannot take the lowering for this range
    /// and the caller MUST fall back to the eager snapshot; the default is
    /// every backend without page-granular frame COW.
    fn materialize_private_file_backing(
        &mut self,
        _va: u64,
        _len: usize,
        _fd: std::os::fd::BorrowedFd<'_>,
        _offset: u64,
        _source: carrick_guest_mem::PrivateFileSource,
        _flush_stage1: &mut dyn FnMut() -> Result<(), TrapError>,
    ) -> Result<bool, TrapError> {
        Ok(false)
    }

    /// Bind the one stage-1 editor shared by the neutral engine and backend
    /// translation/physical-COW paths.  A backend retaining a second optional
    /// manager can otherwise publish through stale/absent authority immediately
    /// after fork.
    fn bind_stage1_page_tables(&mut self, _page_tables: crate::stage1_authority::Stage1Authority) {}

    /// Ensure any stage-1 extension table arenas in `manager` have real stage-2 backing
    /// before `sync_to_host` publishes descriptor stores to them.
    fn publish_stage1_extension_arenas(
        &mut self,
        _manager: &PageTableManager,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// Retire and unmap stage-1 extension table arenas belonging to `manager`.
    fn retire_stage1_extension_arenas(
        &mut self,
        _manager: &mut PageTableManager,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// Record the populated prefix (high-water mark in bytes) for a stage-1 table arena at `base`.
    fn record_stage1_populated_prefix(&mut self, _base: u64, _prefix: usize) {}

    // HVPatch-only K1 frame-inventory transaction seam. Defaults preserve the
    // mature HVF VMM and KVM lanes exactly: they report no inventory authority
    // and are never called by their runtime paths.
    fn frame_inventory_extent_count(&self) -> usize {
        0
    }

    fn inventory_initial_mappings(
        &mut self,
        reservation: carrick_hal::FrameInventoryReservation,
    ) -> Result<carrick_hal::FrameInventoryCommit<()>, TrapError> {
        drop(reservation);
        Err(TrapError::Hypervisor(
            "aarch64 backend has no initial frame inventory".to_owned(),
        ))
    }

    fn begin_alias_inventory(
        &mut self,
        reservation: carrick_hal::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        drop(reservation);
        Err(TrapError::Hypervisor(
            "aarch64 backend has no alias frame inventory".to_owned(),
        ))
    }

    fn take_alias_inventory(&mut self) -> Option<carrick_hal::FrameInventoryCommit<()>> {
        None
    }

    fn abandon_alias_inventory(&mut self) -> bool {
        false
    }

    fn frame_inventory_exec_extent_counts(&self, _new_image: &AddressSpace) -> (usize, usize) {
        (0, 0)
    }

    fn inject_next_begin_exec_inventory_failure(&mut self) {}

    fn begin_exec_inventory(
        &mut self,
        retired: Option<carrick_hal::FrameInventoryReservation>,
        replacement: carrick_hal::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        drop((retired, replacement));
        Err(TrapError::Hypervisor(
            "aarch64 backend has no exec frame inventory".to_owned(),
        ))
    }

    fn take_exec_inventory(&mut self) -> Option<carrick_hal::ExecInventoryCommits> {
        None
    }

    fn apply_exec_inventory(
        &mut self,
        _replacement_mm: u64,
        _apply: &mut dyn FnMut(
            carrick_hal::FrameInventoryCommit<()>,
        )
            -> Result<carrick_hal::FrameInventoryApplyReceipt, TrapError>,
    ) -> Result<bool, TrapError> {
        Ok(false)
    }

    fn activate_exec_inventory(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    fn begin_process_inventory(
        &mut self,
        reservation: carrick_hal::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        drop(reservation);
        Err(TrapError::Hypervisor(
            "aarch64 backend has no process frame inventory".to_owned(),
        ))
    }

    /// Cancel a child-inventory reservation that never reached the backend
    /// process builder. The kernel-side transaction remains owned by the
    /// runtime's abandon guard; this releases only the backend's operation slot.
    fn cancel_process_inventory(&mut self) -> bool {
        false
    }

    fn take_process_inventory(&mut self) -> Option<carrick_hal::FrameInventoryCommit<()>> {
        None
    }

    fn begin_retirement_inventory(
        &mut self,
        reservation: carrick_hal::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        drop(reservation);
        Err(TrapError::Hypervisor(
            "aarch64 backend has no retirement frame inventory".to_owned(),
        ))
    }

    fn take_retirement_inventory(&mut self) -> Option<carrick_hal::FrameInventoryCommit<()>> {
        None
    }

    // ── memory windows + stage-2 (the hv_vm_map / KVM-slot seam) ──
    //
    // NOTE: `host_ptr` / `host_ptr_mut` / `write_gpa` are inherited from the shared
    // [`GuestVmBackend`] supertrait (ISA-neutral, signature-identical with x86).

    /// Map host memory at a stage-2 IPA. The STAGE-1 path (page-table edit) is
    /// the shared engine's job; this is only the backend stage-2 op: HVF
    /// `hv_vm_map`; KVM `KVM_SET_USER_MEMORY_REGION`. Used by the shared
    /// `map_host_alias`.
    fn map_stage2(
        &mut self,
        ipa: u64,
        host: *mut u8,
        len: u64,
        perms: MemPerms,
    ) -> Result<(), TrapError>;

    /// Resolve a backend memory exit. HVF overrides for the lazy high-VA alias
    /// re-map (lookup_shared_alias + `hv_vm_map` on a forked child's missing
    /// stage-2 entry — the one HVF-only cluster). KVM keeps the default
    /// `Ok(false)`: siblings share one VM, fork relies on Linux COW, no analogue.
    /// Mirrors `X86Vmm::handle_memory_exit`.
    fn handle_memory_exit(&mut self, _gpa: u64, _va: u64) -> Result<bool, TrapError> {
        Ok(false)
    }

    /// Attach backend memory-route evidence to a vCPU run failure. The default
    /// preserves the original error; pointer-backed transports may override to
    /// distinguish a protocol failure from a stale stage-1/stage-2 route.
    fn enrich_vcpu_run_error(&self, _vcpu: &Self::Vcpu, error: TrapError) -> TrapError {
        error
    }

    // ── guest-memory access (the GuestMemory backing seam) ──
    //
    // The PROT_NONE EFAULT gate is keyed on the guest VA and lives in the engine's
    // default `read_bytes`/`write_bytes` (via [`Self::protections`]); the backend
    // hooks below do the BACKING access only, on the stage-1-TRANSLATED IPA, so a
    // `repoint_private` overlay / high-VA alias resolves to the page the guest's
    // OWN EL0 accesses hit rather than the stale shared aperture the VA still
    // covers. For an identity VA `ipa == va`. (HVF: discrete per-region windows;
    // KVM: `GuestRam::safe_access_translated_raw`.)

    /// Read live guest memory at guest-PHYSICAL `gpa` (no VA translation, no
    /// PROT_NONE gate). The shared run-elf / page-table seed paths read raw GPAs
    /// (e.g. the live stage-1 page-table region, an `execve` path string).
    fn read_gpa(&self, gpa: u64, len: usize) -> Result<Vec<u8>, TrapError>;

    /// The PROT_NONE set the engine's default `read_bytes`/`write_bytes` gate on
    /// (keyed on the guest VA). `Some(..)` so the gate fires; the backend owns the
    /// set (KVM in `GuestRam`, shared across siblings) so a sibling thread's
    /// `mprotect(PROT_NONE)` is observed here.
    fn protections(&self) -> Option<&MemoryProtections>;

    /// Exact private writable ranges owned by this mm. HVPatch consumes this
    /// before cloning the stage-1 graph; reference backends retain the empty
    /// default because their host VM mechanism supplies fork COW.
    fn fork_cow_ranges(&mut self) -> Vec<ForkCowRange> {
        Vec::new()
    }

    fn arm_frame_cow_ranges(&mut self, _ranges: &[ForkCowRange]) {}

    /// Fresh host anonymous mappings the most recent `build_process_builder`
    /// created for the child's per-mm backing (`0` when every backing came
    /// from a carrier pool). Backends without in-process fork report `0`.
    fn last_fork_host_mapping_allocations(&self) -> u64 {
        0
    }

    /// Mapping and alias rows visited by the most recent `fork_cow_ranges`
    /// (`0` when its cached projection was reused).
    fn last_fork_projection_rows_visited(&self) -> u64 {
        0
    }

    /// Exact pre-fork arm metadata. A failed fork must restore this vector,
    /// rather than subtracting the newly requested ranges (which destroys
    /// overlapping pre-existing arms).
    fn frame_cow_arm_snapshot(&self) -> Vec<ForkCowRange> {
        Vec::new()
    }

    fn restore_frame_cow_arm_snapshot(&mut self, _snapshot: Vec<ForkCowRange>) {}

    fn armed_frame_cow_ranges(&self, _va: u64, _len: usize) -> Vec<ForkCowRange> {
        Vec::new()
    }

    fn bind_frame_cow(
        &mut self,
        _authority: std::sync::Arc<dyn carrick_hal::FrameCowAuthority>,
        _identity: carrick_hal::FrameCowIdentity,
    ) {
    }

    /// Refresh fork-private process state after the child frame inventory and
    /// exact MM/COW authority are live, but before the child enters guest code.
    fn refresh_fork_process_state(
        &mut self,
        _flush_stage1: &mut dyn FnMut() -> Result<(), TrapError>,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    fn resolve_frame_cow_fault(
        &mut self,
        _syndrome: u64,
        _far: u64,
        _ttbr0: u64,
        _flush_stage1: &mut dyn FnMut() -> Result<(), TrapError>,
    ) -> Result<carrick_hal::CowFaultResolution, TrapError> {
        Ok(carrick_hal::CowFaultResolution::NotCow)
    }

    /// Refresh per-vCPU host pointers whose guest VA may have moved to a new
    /// physical backing during the just-completed stage-1 COW. Backends without
    /// host pointers into guest-owned mappings keep the no-op default.
    fn refresh_vcpu_after_frame_cow(&self, _vcpu: &mut Self::Vcpu) -> Result<(), TrapError> {
        Ok(())
    }

    fn ensure_frame_cow_write(
        &mut self,
        _va: u64,
        _len: usize,
        _intent: FrameCowWriteIntent,
        _flush_stage1: &mut dyn FnMut() -> Result<(), TrapError>,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// Authenticate the final stage-1 protection published after a backing-
    /// maintenance COW. HVPatch uses this to close the signed structural
    /// transaction; reference backends have no deferred COW receipt.
    fn observe_frame_cow_protection(
        &mut self,
        _va: u64,
        _len: usize,
        _prot: u64,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// Publish semantic VA ownership after `MAP_FIXED|MAP_PRIVATE` repoints a
    /// live stage-1 leaf into an existing private-overlay frame. The stage-2
    /// extent already exists; HVPatch records only the VA→global-frame edge so
    /// later fork arming and inventory use the translated owner.
    fn publish_private_repoint(
        &mut self,
        _va: u64,
        _overlay_ipa: u64,
        _len: usize,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// Publish semantic VA ownership after `MREMAP_FIXED` repoints a live
    /// stage-1 leaf into an existing shared extent. The stage-2 extent
    /// already exists; HVPatch records the alias and mapped region edge.
    fn publish_shared_repoint(
        &mut self,
        _va: u64,
        _target_ipa: u64,
        _len: usize,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// Backing READ of `[va, va+len)` whose stage-1 translation is `ipa`. The
    /// engine already ran the PROT_NONE gate (on `va`); this does the IPA-translated
    /// single-region backing copy. NULL-guard + single-window bounds live in the
    /// backend.
    fn translated_read(&self, va: u64, ipa: u64, len: usize) -> Result<Vec<u8>, MemoryError>;

    /// Backing WRITE of `bytes` to `[va, va+len)` whose stage-1 translation is
    /// `ipa`. Symmetric to [`Self::translated_read`].
    fn translated_write(&mut self, va: u64, ipa: u64, bytes: &[u8]) -> Result<(), MemoryError>;

    /// Record/clear a PROT_NONE range (the HOST-SIDE EFAULT bookkeeping). The
    /// COMPLEMENTARY guest-side enforcement (so the guest's OWN EL0 access faults)
    /// is the engine's stage-1 `protect_range`/`unmap_range` (page-table edit +
    /// TLBI). Keyed on the guest VA.
    fn set_no_access(&mut self, address: u64, len: usize, no_access: bool);

    /// Scrub the physical backing of `[address, address+len)`, BYPASSING the
    /// PROT_NONE check — clears a reused/`munmap`'d region whose stale bytes must
    /// never resurface after a later `mprotect` makes it readable.
    fn zero_backing(&mut self, address: u64, len: usize) -> Result<(), MemoryError>;

    /// Host wait address plus Linux-visible waiter-count key for a guest futex
    /// word IFF it lives in a `MAP_SHARED` region. `None` for private/COW words,
    /// which stay in-process via the parking-lot `FutexTable`.
    fn shared_futex_location(&self, _backing_gpa: Gpa) -> Option<SharedFutexLocation> {
        None
    }

    /// Back a dynamic mmap (`DispatchOutcome::MapHostAlias`): mmap the host
    /// file/anon backing described by `backing` and register a fresh stage-2
    /// alias slot, returning the `(gpa, writable)` the engine then threads into
    /// the SHARED stage-1 `map_aliased` edit. KVM derives the alias GPA from the
    /// VA inside its <1 TiB arena; HVF maps at a low alias IPA. The STAGE-1 path
    /// stays in the engine. A file backing transfers ownership of a dup: every
    /// backend closes it (by dropping it) on every return/unwind path. Until a
    /// returned error certifies zero mutation, the generic runtime fail-stops
    /// rather than resuming the guest after cleanup.
    fn add_alias(
        &mut self,
        va: u64,
        ipa: u64,
        len: u64,
        payload: &[u8],
        backing: HostAliasBacking,
    ) -> Result<(u64, bool), TrapError>;

    /// Minimum aligned unit accepted by anonymous retirement. This also opts
    /// into retiring an aligned interior before authenticating partial edges.
    fn anonymous_discard_granule(&self) -> Option<u64> {
        None
    }

    /// Prepare private-anonymous backing retirement before any stage-1 edit.
    /// `None` refuses without mutation. The caller owns MM mutation exclusion.
    fn prepare_anonymous_discard(
        &self,
        _va: u64,
        _len: usize,
    ) -> Result<Option<Self::AnonymousDiscard>, TrapError> {
        Ok(None)
    }

    /// Commit after stage-1 removal and TLBI. Failures are indeterminate to the
    /// caller; a backend must preserve exact owner generations and fork peers.
    fn commit_anonymous_discard(
        &mut self,
        _prepared: Self::AnonymousDiscard,
    ) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "anonymous discard unsupported".into(),
        ))
    }

    /// Called by the engine's `unmap_range`/`unmap_alias_range` only AFTER the
    /// checked stage-1 edit and TLBI complete, so an edit failure leaves a
    /// backend's process-shared alias index (HVF's `alias_registry`) intact and
    /// consistent with its still-owned backing. KVM has no such index; default
    /// no-op.
    fn on_unmap(&mut self, _va: u64, _len: usize) -> Result<(), TrapError> {
        Ok(())
    }

    /// Whether the engine saves/restores guest FP/SIMD across signal delivery (the
    /// `InjectParams::fpsimd_enabled` flag for inject + restore). HVF gates this on
    /// `CARRICK_NO_FPSIMD` (differential measurement); KVM keeps the default `true`.
    fn fpsimd_enabled(&self) -> bool {
        true
    }

    /// Export task-owned syscall continuation independently of executor-local
    /// mailbox storage. Non-mailbox backends have no continuation payload.
    fn task_continuation(
        &self,
        _vcpu: &Self::Vcpu,
    ) -> Result<Option<carrick_hal::threaded::Aarch64SyscallContinuationV1>, TrapError> {
        Ok(None)
    }

    /// Remove task-owned mailbox continuation state at an executor switch
    /// without releasing or replacing the executor's live mailbox slot/vCPU.
    fn take_task_continuation_for_executor_switch(
        &mut self,
        _vcpu: &mut Self::Vcpu,
    ) -> Result<Option<carrick_hal::threaded::Aarch64SyscallContinuationV1>, TrapError> {
        Err(TrapError::Hypervisor(
            "aarch64 backend does not support persistent executor mailbox detach".to_owned(),
        ))
    }

    /// Install task-owned continuation state into the already-live executor
    /// mailbox. This must not allocate a slot or recreate the vCPU.
    fn install_task_continuation_for_executor_switch(
        &mut self,
        _vcpu: &mut Self::Vcpu,
        _continuation: Option<carrick_hal::threaded::Aarch64SyscallContinuationV1>,
    ) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "aarch64 backend does not support persistent executor mailbox attach".to_owned(),
        ))
    }

    /// Backing-only fixed-size READ into `dst` whose stage-1 translation is `ipa`,
    /// the no-alloc hot path (`read_u32`/`read_u64`/struct headers). Default:
    /// allocate via [`Self::translated_read`] + copy. HVF overrides to
    /// `volatile`-copy straight into `dst`.
    fn translated_read_into(&self, va: u64, ipa: u64, dst: &mut [u8]) -> Result<(), MemoryError> {
        let bytes = self.translated_read(va, ipa, dst.len())?;
        dst.copy_from_slice(&bytes);
        Ok(())
    }

    /// Backing WRITE that bypasses the guest-visible WRITE permission (a
    /// carrick-INTERNAL frame the guest must receive even into a guest-read-only
    /// mapping: vdso vvar, the signal frame, bootstrap). The host page is writable;
    /// only the guest-visible permission is bypassed. Default: the permission-checked
    /// [`Self::translated_write`] (KVM models no per-mapping write-permission split).
    /// HVF overrides to its unchecked writer.
    fn translated_write_unchecked(
        &mut self,
        va: u64,
        ipa: u64,
        bytes: &[u8],
    ) -> Result<(), MemoryError> {
        self.translated_write(va, ipa, bytes)
    }

    /// Whether every byte of `[va, va+len)` is currently guest-WRITABLE (signal
    /// delivery uses this to detect an unwritable SA_ONSTACK alt-stack → Linux
    /// `force_sigsegv`). Default `true` (KVM models no per-mapping write-permission
    /// flag); HVF checks its per-region `guest_writable` + PROT_NONE set.
    fn guest_range_is_writable(&self, _va: u64, _len: usize) -> bool {
        true
    }

    /// Host pointer for a CONTIGUOUS guest range usable for zero-copy host I/O,
    /// valid IFF the whole `[va, va+len)` is one mapped region (and, for writes,
    /// guest-writable). `None` ⇒ the caller falls back to `read_bytes`/`write_bytes`.
    /// Default `None` (KVM uses the identity copy path); HVF resolves its region.
    fn host_ptr_for_read(&self, _va: u64, _len: usize) -> Option<*const u8> {
        None
    }
    fn host_ptr_for_write(&mut self, _va: u64, _len: usize) -> Option<*mut u8> {
        None
    }

    // ── vCPU lifecycle ──

    /// Create a fresh vCPU bound to this VM.
    fn add_vcpu(&mut self) -> Result<Self::Vcpu, TrapError>;

    /// `execve(2)` image replacement. KVM remaps slots in place on the live VM;
    /// HVF rebuilds the VM. The shared `execve_into` calls this then reprograms
    /// sysregs (shared `program_sysregs`) + clears pending state.
    fn execve_rebuild(
        &mut self,
        vcpu: &mut Self::Vcpu,
        new_image: &AddressSpace,
    ) -> Result<(), TrapError>;

    fn exec_page_tables(&self) -> Option<carrick_mem::page_table::PageTableManager> {
        None
    }

    /// Replacement PROT_NONE authority installed by the just-completed exec.
    /// Backends whose protection gate lives entirely behind `GuestVmBackend`
    /// keep the default; HVPatch returns the exact Arc owned by its new task
    /// projection so a persistent detach/reload cannot resurrect the
    /// predecessor's ranges.
    fn exec_protections(&self) -> Option<Arc<MemoryProtections>> {
        None
    }

    // NOTE: `process_exit_cleanup` is inherited from the shared [`GuestVmBackend`]
    // supertrait (ISA-neutral hook, signature-identical with x86).

    // ── threaded sibling lifecycle (the generic ThreadedEngine drives these) ──

    /// A kick handle for the current vCPU thread (the engine's `kick_handle`).
    fn kick_handle(&self) -> Self::KickHandle;

    // NOTE: `wait_for_vcpu_slot` / `vcpu_budget` / `reclaims` are inherited from the
    // shared [`GuestVmBackend`] supertrait (ISA-neutral, signature-identical with
    // x86).

    /// Save THIS thread's full guest CPU state before releasing its vCPU slot at a
    /// block point (M:N reclaim), passing the engine-owned `vcpu`. KVM aarch64 does
    /// not reclaim (default no-op error). HVF DESTROYS the vCPU here (snapshot then
    /// raw `hv_vcpu_destroy`) and stashes the snapshot internally; the returned
    /// snapshot is unused for HVF (it round-trips through its own field). The engine
    /// passes `&mut self.vcpu` so a destroy-in-place backend can recycle it.
    fn save_guest_state(
        &mut self,
        _vcpu: &mut Self::Vcpu,
    ) -> Result<Aarch64VcpuSnapshot, TrapError> {
        Err(TrapError::Hypervisor(
            "aarch64 backend does not reclaim (save_guest_state)".into(),
        ))
    }

    /// Destroy/release a newly materialized, still-idle vCPU before its first
    /// guest instruction. Backends must not route this through syscall-block
    /// reclaim, whose mailbox contract requires an outstanding continuation.
    fn save_initial_runner_state(
        &mut self,
        _vcpu: &mut Self::Vcpu,
    ) -> Result<Aarch64VcpuSnapshot, TrapError> {
        Err(TrapError::Hypervisor(
            "aarch64 backend does not support idle initial-runner transfer".into(),
        ))
    }

    fn rebind_initial_runner_state(
        &mut self,
        _state: &Aarch64TaskCpuStateV1,
        _vcpu: &mut Self::Vcpu,
    ) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "aarch64 backend does not support idle initial-runner restore".into(),
        ))
    }

    /// Save state for a process-shared futex wait. Defaults to the generic
    /// vCPU-only reclaim; HVF overrides this for single-threaded process waits
    /// so it can tear down the whole VM while the process is parked.
    fn save_shared_wait_state(
        &mut self,
        vcpu: &mut Self::Vcpu,
    ) -> Result<Aarch64VcpuSnapshot, TrapError> {
        self.save_guest_state(vcpu)
    }

    /// Re-bind to `slot`'s vCPU after a block (M:N reclaim wake), passing the
    /// engine-owned `vcpu`. HVF RECREATES the vCPU in its existing VM and restores
    /// the parked state, writing the new vCPU back through `vcpu`. KVM no-op.
    fn rebind_to_slot(
        &mut self,
        slot: SlotId,
        state: &Aarch64TaskCpuStateV1,
        vcpu: &mut Self::Vcpu,
    ) -> Result<(), TrapError> {
        let _ = (slot, state, vcpu);
        Err(TrapError::Hypervisor(
            "aarch64 backend does not support complete typed guest-state restore".to_owned(),
        ))
    }

    /// Restore state saved by [`Self::save_shared_wait_state`].
    fn rebind_shared_wait_state(
        &mut self,
        slot: SlotId,
        state: &Aarch64TaskCpuStateV1,
        vcpu: &mut Self::Vcpu,
    ) -> Result<(), TrapError> {
        self.rebind_to_slot(slot, state, vcpu)
    }

    /// MT whole-VM lease — VM-only release by the LAST parker, whose own vCPU
    /// was already destroyed by [`Self::save_guest_state`] (snapshot stashed;
    /// compatible with the shared-wait resume). `Ok(true)` iff whole-VM state
    /// was released. Default `Ok(false)`: the backend has no whole-VM state
    /// to release (KVM), and the caller keeps the park vCPU-only.
    fn release_vm_after_reclaim_park(&mut self) -> Result<bool, TrapError> {
        Ok(false)
    }

    /// [`Self::rebind_shared_wait_state`] for a MULTI-THREADED parked process
    /// (the whole-VM residency lease): the first waker rebuilds the process VM
    /// for every still-parked sibling, so the mapping replay must carry the
    /// UNION of every thread's dynamic mappings. HVF overrides this; the
    /// default (KVM: no whole-VM teardown on park) is the single-threaded
    /// restore.
    fn rebind_shared_wait_state_mt(
        &mut self,
        slot: SlotId,
        state: &Aarch64TaskCpuStateV1,
        vcpu: &mut Self::Vcpu,
    ) -> Result<(), TrapError> {
        self.rebind_shared_wait_state(slot, state, vcpu)
    }

    /// Build the `Send` payload a `clone(CLONE_THREAD)` sibling needs to add its
    /// own vCPU on the SAME VM (shared VM handle + window descriptors + a
    /// live-vcpu ticket). KVM `build_sibling_spec` (ignores `vcpu`); HVF publishes
    /// its VM + clones the mapping list and needs `vcpu` to snapshot the parent.
    /// `entry` carries the new thread's `clone` deltas (return value / child stack /
    /// TLS).
    fn build_sibling_builder(
        &self,
        vcpu: &Self::Vcpu,
        entry: GuestEntryRegs,
    ) -> Result<Self::SiblingBuilder, TrapError>;

    /// On the sibling thread, turn the builder into a fresh `(VM, vCPU)` on the
    /// SAME VM. KVM `materialize_sibling`; the engine restores the seeded snapshot
    /// and SHARES the protections/page_tables Arc.
    fn materialize_sibling(builder: Self::SiblingBuilder) -> Result<(Self, Self::Vcpu), TrapError>;

    fn build_process_builder(
        &self,
        _request: ProcessForkRequest,
        _page_tables: &mut carrick_mem::page_table::PageTableManager,
        _cow_ranges: &[ForkCowRange],
    ) -> Result<Self::ProcessBuilder, TrapError> {
        Err(TrapError::Hypervisor(
            "aarch64 backend does not support in-process fork".to_owned(),
        ))
    }

    fn materialize_process(
        _builder: Self::ProcessBuilder,
    ) -> Result<(Self, Self::Vcpu), TrapError> {
        Err(TrapError::Hypervisor(
            "aarch64 backend does not support in-process fork".to_owned(),
        ))
    }

    /// Publish backend metadata that must not become globally visible until
    /// the fresh vCPU register file has been restored successfully.
    fn commit_process_materialization(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    /// Undo a backend process materialization whose fresh-vCPU restore failed.
    /// The default backend has no persistent stage-2/alias publication.
    fn abort_process_materialization(&mut self, vcpu: &mut Self::Vcpu) -> Result<(), TrapError> {
        self.destroy_vcpu_on_thread_exit(vcpu);
        Ok(())
    }

    /// Set SP_EL0 on a vfork child given an explicit `child_stack`, through
    /// `&self` (the shared loop holds only `&engine`).
    fn set_guest_sp(&self, vcpu: &Self::Vcpu, sp: u64) -> Result<(), TrapError>;

    /// A FRESH kick registry for the CHILD of a guest `fork(2)` (only the calling
    /// thread survived `libc::fork`). KVM `fresh_fork_kicker`.
    fn fresh_fork_kicker(&self) -> Arc<dyn VcpuRegistry>;

    // ── multithreaded-fork sibling lifecycle (HVF-only; KVM defaults no-op) ──
    //
    // A MULTITHREADED guest fork on HVF must quiesce sibling vCPUs, destroy them
    // so the forker can `hv_vm_destroy` before `libc::fork`, then republish the
    // rebuilt VM for them to recreate vCPUs in. KVM siblings share ONE VM and rely
    // on Linux COW, so none of this is needed (defaults).

    /// Whether this backend's M:N reclaim DESTROYS the vCPU (so its kick handle goes
    /// dead and the runtime must unregister it from the registry before the block
    /// and re-register on wake). `true` for HVF (raw `hv_vcpu_destroy` does not drop
    /// applevisor's liveness Weak); `false` (default) for pool-swap backends.
    fn reclaim_refreshes_kicker(&self) -> bool {
        false
    }

    /// A guest thread is exiting: destroy its vCPU (freeing an HVF concurrent-vCPU
    /// slot). KVM no-op (vCPU drops with the engine).
    fn destroy_vcpu_on_thread_exit(&mut self, _vcpu: &mut Self::Vcpu) {}
}

#[cfg(test)]
mod completion_tests {
    use super::*;

    struct RegisterCompletionVcpu {
        writes: Vec<(Reg, u64)>,
        saved_x9: Option<u64>,
    }

    impl Aarch64Vcpu for RegisterCompletionVcpu {
        fn get_reg(&self, _r: Reg) -> Result<u64, TrapError> {
            Ok(0)
        }

        fn set_reg(&mut self, r: Reg, v: u64) -> Result<(), TrapError> {
            self.writes.push((r, v));
            Ok(())
        }

        fn get_sys_reg(&self, _r: SysReg) -> Result<u64, TrapError> {
            Ok(0)
        }

        fn set_sys_reg(&mut self, _r: SysReg, _v: u64) -> Result<(), TrapError> {
            Ok(())
        }

        fn get_vreg(&self, _n: u32) -> Result<u128, TrapError> {
            Ok(0)
        }

        fn set_vreg(&mut self, _n: u32, _v: u128) -> Result<(), TrapError> {
            Ok(())
        }

        fn get_fpcr(&self) -> Result<u64, TrapError> {
            Ok(0)
        }

        fn set_fpcr(&mut self, _v: u64) -> Result<(), TrapError> {
            Ok(())
        }

        fn get_fpsr(&self) -> Result<u64, TrapError> {
            Ok(0)
        }

        fn set_fpsr(&mut self, _v: u64) -> Result<(), TrapError> {
            Ok(())
        }

        fn get_esr_el1(&self) -> Result<u64, TrapError> {
            Ok(0)
        }

        fn get_far_el1(&self) -> Result<u64, TrapError> {
            Ok(0)
        }

        fn snapshot(&self) -> Result<Aarch64VcpuSnapshot, TrapError> {
            Err(TrapError::Hypervisor("unused test snapshot".into()))
        }

        fn restore(&mut self, _snap: &Aarch64VcpuSnapshot) -> Result<(), TrapError> {
            Ok(())
        }

        fn get_saved_x9(&self) -> Result<Option<u64>, TrapError> {
            Ok(self.saved_x9)
        }

        fn run(&mut self) -> Result<Aarch64Exit, TrapError> {
            Ok(Aarch64Exit::Halt)
        }

        fn kick(&self) -> Result<(), TrapError> {
            Ok(())
        }
    }

    #[test]
    fn default_complete_syscall_return_preserves_register_transport() {
        let mut vcpu = RegisterCompletionVcpu {
            writes: Vec::new(),
            saved_x9: Some(0x9999),
        };
        vcpu.complete_syscall_return(-9).expect("completion");
        assert_eq!(
            vcpu.writes,
            vec![(Reg::X(0), (-9_i64) as u64), (Reg::X(9), 0x9999)]
        );
    }
}

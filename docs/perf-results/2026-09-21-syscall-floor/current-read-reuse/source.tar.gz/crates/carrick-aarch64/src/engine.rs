//! `Aarch64EngineCore<V>` — the generic aarch64 trap engine scaffold.
//!
//! Mirrors `carrick-x86`'s `X86EngineCore<V>`: implements the `carrick-hal` engine
//! traits ONCE over the thin [`Aarch64Vmm`] / [`Aarch64Vcpu`] trait pair,
//! replacing the two per-VMM copies of the aarch64 trap loop (HVF's
//! `HvfTrapEngine` and KVM's aarch64 `trap_engine`).
//!
//! ## Status — Stage 1 (compile-only scaffold)
//!
//! This struct only DEFINES the engine's owned state today; nothing implements
//! the `carrick-hal` engine traits over it yet, and no backend is wired. The
//! field set is taken from the union of the two existing engines (see the
//! per-field docs for the HVF vs KVM origin).
//!
//! ## The pending-syscall state lives HERE (§2.1)
//!
//! Collapsing each backend's pending-doorbell bookkeeping into the single
//! [`Aarch64Exit::Syscall { resume_pc }`](crate::vmm::Aarch64Exit::Syscall) moves
//! the "which doorbell is pending" state into the engine. On aarch64 there is no
//! SYSRET trampoline — `ELR_EL1` is always live and the EL1 vector's `eret`
//! consumes it — so the engine carries no `sysret_resume` analogue, which makes
//! this core SMALLER than `X86EngineCore`.

use std::sync::Arc;

use carrick_fatal::carrick_fatal;
use carrick_guest_mem::protections::MemoryProtections;
use carrick_guest_mem::{
    Aarch64SyscallFrame, CurrentMmMemory, Gpa, GuestMemory, GuestVa, MappingSharing, MemoryError,
    RepointPrivateError, SharedFutexLocation,
};
use carrick_hal::guest_arch::GuestArch as _;
use carrick_hal::threaded::{Aarch64TaskCpuStateV1, GuestCpuState};
use carrick_hal::{
    GuestEntryRegs, HostAliasBacking, OsError, ProcessForkRequest, RawSyscall, Reg, SlotId, SysReg,
    SyscallTrap, ThreadedEngine, TrapError,
};
use carrick_mem::memory::AddressSpace;
use carrick_mem::page_table::{PageTableApplyOutcome, PageTableError, PageTableManager};

pub use crate::stage1_authority::{ShareState, Stage1Authority, Stage1Editor};

use crate::vmm::{Aarch64Exit, Aarch64Vcpu, Aarch64VcpuSnapshot, Aarch64Vmm, FrameCowWriteIntent};

/// HVPatch installs this scoped-ASID routine into the existing EL1 maintenance
/// page's NOP tail. Other AArch64 backends do not invoke it until they install
/// the same backend completion sequence at this address.
pub const HVPATCH_EL1_ASID_MAINT_BASE: u64 = carrick_mem::memory::LINUX_EL1_ASID_MAINT_BASE;

pub fn asid_maintenance_bytes() -> Vec<u8> {
    carrick_mem::memory::el1_asid_maintenance_bytes()
}

/// Remove Carrick's HVPatch root/global-frame aperture from an AArch64
/// stage-1 image before it is published for an HvPatch process.
///
/// The operation is deterministic for an exec layout, so the HVF backend can
/// bake it into its stage-1 layout. Initial root bring-up still applies it
/// through the live editor before the first ASID is installed.
pub fn reserve_hvpatch_process_apertures(
    manager: &mut PageTableManager,
) -> Result<PageTableApplyOutcome, PageTableError> {
    manager.set_prot_none(
        carrick_mem::memory::LINUX_HVPATCH_ROOT_SLOT_BASE,
        (carrick_mem::memory::LINUX_HVPATCH_ROOT_SLOT_ARENA_SIZE
            + carrick_mem::memory::LINUX_HVPATCH_GLOBAL_FRAME_SIZE) as usize,
        None,
    )
}

/// The generic aarch64 trap engine. Owns the VM, the (one) vCPU, the
/// pending-syscall resume PC, and the SA_RESTART syscall-number stash.
/// Per-backend behaviour is reached only through the [`Aarch64Vmm`] /
/// [`Aarch64Vcpu`] trait pair.
pub struct Aarch64EngineCore<V: Aarch64Vmm> {
    // ── backend bindings (the only per-VMM members) ──
    /// Owns stage-2 mapping, fork/execve rebuild, sibling spawn.
    vm: V,
    /// The (one) vCPU for this process thread.
    vcpu: V::Vcpu,

    // ── syscall-doorbell state (OWNED BY ENGINE, §2.1; backend run() stateless) ──
    /// Resume PC (= `ELR_EL1`, post-`svc`) for the pending syscall; `Some` between
    /// `next_syscall` and `complete_syscall`. On aarch64 the EL1 vector's `eret`
    /// consumes `ELR_EL1`, so `complete_syscall` sets X0 only and never
    /// re-advances — but we still carry `resume_pc` to detect the trampoline-vs-
    /// direct case and to expose `current_pc` on a non-syscall kick. (x86 calls
    /// this `pending_resume_pc`.)
    pending_resume_pc: Option<u64>,

    /// Linux syscall number (x8) of the most recent trapped `svc`. Feeds the
    /// loop's SA_RESTART decision (`last_syscall_nr()`). `None` before the first
    /// syscall. (Both backends already have this.)
    last_syscall_nr: Option<u64>,

    /// Original x0 of the most recent trapped `svc` (the pre-syscall x0 the
    /// SA_RESTART rewind needs; supplies `InjectParams::orig_x0`). x86 calls this
    /// `last_orig_rax`.
    last_syscall_orig_x0: u64,

    /// `ESR_EL1` of the most recent EL0 synchronous fault (supplies
    /// `InjectParams::fault_esr`; the arm64 sigframe's `esr_context`, required by
    /// Rosetta's handler). Reset to 0 across fork/clone/execve and right after
    /// delivery.
    last_fault_esr: u64,

    // ── trap-surface discriminator (the one aarch64-specific scalar) ──
    /// EC of the most recent exit: did we leave EL0 via `svc` (EC=0x15) or the
    /// EL1 vector's `hvc` (EC=0x16)? `complete_syscall` consults it to know
    /// whether to advance PC past the HVC. HVF-meaningful; on KVM the vector's own
    /// `eret` handles PC, so KVM leaves it at a fixed value. Kept as a plain field
    /// because it is engine policy, not backend state.
    last_exit_class: u64,

    // ── fork marker ──
    /// `true` on the child side of a guest `fork(2)`. Drives the
    /// `_exit`-without-report shutdown path + the `forked=` diagnostic.
    is_forked_child: bool,

    /// Hvpatch-only in-process guest ASID. `None` preserves the mature VMM/KVM
    /// bootstrap exactly; `Some` is re-applied after every exec replacement.
    process_asid: Option<u16>,

    /// Exact Kernel MM identity generation authorizing task snapshots.
    mm_generation: u64,
    /// Exact ASID allocation generation authorizing the task's TTBR values.
    asid_generation: u64,

    /// Non-aliasing guest-run time awaiting the exact logical-thread charge.
    pending_guest_run_receipt_ns: u64,

    /// `(far, retries)` of the stale stage-1 fault this task keeps retrying.
    /// A genuine sibling race resolves within one or two retries; a fault the
    /// live walk keeps permitting while the vCPU keeps refusing it names a
    /// stage-1 leaf whose frame stage-2 no longer maps, which no TLBI can
    /// repair. Bounding the retry turns that silent 100% CPU livelock into a
    /// named failure carrying the walk.
    stale_stage1_retry: (u64, u32),

    /// Fresh stage-1 image allocations of the most recent `build_process_spec`
    /// (`0` when the child image came from the recycle pool). Read by the
    /// runtime and charged as `page_table_image_allocations`.
    last_fork_image_allocations: u64,

    // ── shared memory state (the X86EngineCore parallels) ──
    /// Live stage-1 page-table authority over the guest's own translation tables at
    /// `LINUX_PAGE_TABLES_BASE` and extension arena source.
    page_tables: Stage1Authority,

    /// Process-wide PROT_NONE ranges; the EFAULT gate on every syscall-buffer
    /// access. SHARED by `CLONE_THREAD` siblings (`Arc` clone), COW'd on fork.
    protections: Arc<MemoryProtections>,

    /// Exact parent state retained across the host-thread spawn/materialization
    /// window of an in-process fork. Runtime commits it only after the child is
    /// materialized; a recoverable failure restores both authorities.
    pending_process_fork: Option<ParentForkCowRollback>,

    /// When set, records the runtime's exec predecessor-sharing expectation
    /// (`mark_exec_predecessor_shared`) to cross-check against the stage-1
    /// authority's own share decision.
    exec_predecessor_shared: Option<bool>,
}

pub struct Aarch64TaskEngineState<V: Aarch64Vmm> {
    vm: V,
    pending_resume_pc: Option<u64>,
    last_syscall_nr: Option<u64>,
    last_syscall_orig_x0: u64,
    last_fault_esr: u64,
    last_exit_class: u64,
    is_forked_child: bool,
    process_asid: Option<u16>,
    mm_generation: u64,
    asid_generation: u64,
    pending_guest_run_receipt_ns: u64,
    page_tables: Stage1Authority,
    protections: Arc<MemoryProtections>,
    pending_process_fork: Option<ParentForkCowRollback>,
}

/// Task-owned runtime authorities that must follow a logical HVPatch task
/// across persistent-worker attach/detach boundaries.  Exec may replace all
/// three while the task is loaded, so a task-only binding must republish the
/// projection returned by the live engine rather than retaining immutable
/// construction-time clones.
pub struct Aarch64TaskRuntimeProjection {
    pub page_tables: Stage1Authority,
    pub protections: Arc<MemoryProtections>,
    pub process_asid: Option<u16>,
}

impl Aarch64TaskRuntimeProjection {
    /// Require both runtime handles to name one exact shared MM authority.
    /// Pointer identity is intentional: independently cloned contents cannot
    /// substitute for the carrier-owned state shared by CLONE_VM tasks.
    pub fn shares_exact_mm_authority(
        &self,
        page_tables: &Stage1Authority,
        protections: &Arc<MemoryProtections>,
    ) -> bool {
        self.page_tables.shares_exact_authority(page_tables)
            && Arc::ptr_eq(&self.protections, protections)
    }
}
unsafe impl<V: Aarch64Vmm> Send for Aarch64TaskEngineState<V> {}

impl<V: Aarch64Vmm> Aarch64TaskEngineState<V> {
    pub fn backend_mut(&mut self) -> &mut V {
        &mut self.vm
    }
}

impl<V: Aarch64Vmm> Aarch64EngineCore<V> {
    /// Borrow the VM-bearing backend while preparing a persistent executor
    /// factory. Task state extraction below remains the only consuming split.
    pub fn backend(&self) -> &V {
        &self.vm
    }

    /// Mutably borrow the VM-bearing backend exactly once while transferring
    /// carrier-only mapping ownership into the persistent executor factory.
    pub fn backend_mut_for_persistent_factory(&mut self) -> &mut V {
        &mut self.vm
    }

    /// Attach one task-only HVPatch binding to a worker-injected backend/vCPU.
    /// The binding contributes only shared logical task state; VM/vCPU owner
    /// identity comes from the worker for this resident interval.
    pub fn from_injected_task_only_backend(
        mut vm: V,
        vcpu: V::Vcpu,
        page_tables: Stage1Authority,
        protections: Arc<MemoryProtections>,
        process_asid: Option<u16>,
        mm_generation: u64,
        asid_generation: u64,
    ) -> Self {
        vm.bind_stage1_page_tables(page_tables.clone());
        Self {
            vm,
            vcpu,
            pending_resume_pc: None,
            last_syscall_nr: None,
            last_syscall_orig_x0: 0,
            stale_stage1_retry: (0, 0),
            last_fork_image_allocations: 0,
            last_fault_esr: 0,
            last_exit_class: 0,
            is_forked_child: false,
            process_asid,
            mm_generation,
            asid_generation,
            pending_guest_run_receipt_ns: 0,
            page_tables,
            protections,
            pending_process_fork: None,
            exec_predecessor_shared: None,
        }
    }

    pub fn into_injected_task_only_backend(self) -> (V, V::Vcpu, Aarch64TaskRuntimeProjection) {
        let Self {
            vm,
            vcpu,
            page_tables,
            protections,
            process_asid,
            ..
        } = self;
        (
            vm,
            vcpu,
            Aarch64TaskRuntimeProjection {
                page_tables,
                protections,
                process_asid,
            },
        )
    }

    pub fn overlay_task_state_on_live_executor(
        &mut self,
        state: &GuestCpuState,
    ) -> Result<(), TrapError> {
        let GuestCpuState::Aarch64V1(state) = state else {
            return Err(TrapError::Hypervisor(
                "AArch64 persistent executor rejected non-AArch64 V1 state".to_owned(),
            ));
        };
        self.validate_task_metadata(state)?;
        let destination = self.vcpu.snapshot()?;
        let restored = restore_aarch64_task_state(&destination, state)?;
        self.vcpu.restore(&restored)?;
        self.vm.install_task_continuation_for_executor_switch(
            &mut self.vcpu,
            state.syscall_continuation,
        )?;
        self.apply_task_metadata(state);
        self.validate_loaded_task_runtime_projection()?;
        Ok(())
    }

    pub fn reaffirm_resident_task_state_on_live_executor(
        &mut self,
        state: &GuestCpuState,
        metadata: &Aarch64ResidentTaskMetadata,
    ) -> Result<(), TrapError> {
        let GuestCpuState::Aarch64V1(state) = state else {
            return Err(TrapError::Hypervisor(
                "AArch64 persistent executor rejected non-AArch64 V1 state".to_owned(),
            ));
        };
        self.validate_task_metadata(state)?;
        self.vm
            .install_task_continuation_for_executor_switch(&mut self.vcpu, metadata.continuation)?;
        self.pending_resume_pc = metadata.pending_resume_pc;
        self.last_syscall_nr = metadata.last_syscall_nr;
        self.last_syscall_orig_x0 = metadata.last_syscall_orig_x0;
        self.last_fault_esr = metadata.last_fault_esr;
        self.last_exit_class = metadata.last_exit_class;
        self.is_forked_child = metadata.is_forked_child;
        self.validate_loaded_task_runtime_projection()?;
        Ok(())
    }

    fn validate_loaded_task_runtime_projection(&self) -> Result<(), TrapError> {
        let Some(process_asid) = self.process_asid else {
            return Ok(());
        };
        const TTBR_ROOT_MASK: u64 = (1_u64 << 48) - 1;
        let ttbr = self.vcpu.get_sys_reg(SysReg::Ttbr0)?;
        let hardware_asid = (ttbr >> 48) as u16;
        if hardware_asid != process_asid {
            return Err(TrapError::Hypervisor(format!(
                "loaded HVPatch projection ASID {process_asid} does not match TTBR ASID {hardware_asid}"
            )));
        }
        let root = ttbr & TTBR_ROOT_MASK;
        if let Some(base) = self.page_tables.root_base()
            && base != root
        {
            return Err(TrapError::Hypervisor(format!(
                "loaded HVPatch page-table manager root 0x{base:x} does not match TTBR root 0x{root:x}"
            )));
        }
        Ok(())
    }

    pub fn snapshot_task_state_from_live_executor(&mut self) -> Result<GuestCpuState, TrapError> {
        require_migratable_fpsimd_authority(self.vm.fpsimd_enabled())?;
        let continuation = self
            .vm
            .take_task_continuation_for_executor_switch(&mut self.vcpu)?;
        let snapshot = self.vcpu.snapshot()?;
        Ok(GuestCpuState::from_aarch64_v1(
            aarch64_task_state_from_snapshot(
                &snapshot,
                self.pending_resume_pc,
                self.last_syscall_nr,
                self.last_syscall_orig_x0,
                self.last_fault_esr,
                self.last_exit_class,
                self.is_forked_child,
                continuation,
                self.mm_generation,
                self.asid_generation,
            )?,
        ))
    }

    pub fn extract_resident_task_metadata_for_lazy_save(
        &mut self,
    ) -> Result<Aarch64ResidentTaskMetadata, TrapError> {
        let continuation = self
            .vm
            .take_task_continuation_for_executor_switch(&mut self.vcpu)?;
        Ok(Aarch64ResidentTaskMetadata {
            pending_resume_pc: self.pending_resume_pc,
            last_syscall_nr: self.last_syscall_nr,
            last_syscall_orig_x0: self.last_syscall_orig_x0,
            last_fault_esr: self.last_fault_esr,
            last_exit_class: self.last_exit_class,
            is_forked_child: self.is_forked_child,
            continuation,
            mm_generation: self.mm_generation,
            asid_generation: self.asid_generation,
        })
    }

    pub fn restore_persistent_executor_invariants(&mut self) -> Result<(), TrapError> {
        self.vm
            .restore_persistent_executor_invariants(&mut self.vcpu)
    }

    pub fn into_task_state_and_vcpu(self) -> (Aarch64TaskEngineState<V>, V::Vcpu) {
        let Self {
            vm,
            vcpu,
            pending_resume_pc,
            last_syscall_nr,
            last_syscall_orig_x0,
            last_fault_esr,
            last_exit_class,
            is_forked_child,
            process_asid,
            mm_generation,
            asid_generation,
            pending_guest_run_receipt_ns,
            page_tables,
            protections,
            pending_process_fork,
            ..
        } = self;
        (
            Aarch64TaskEngineState {
                vm,
                pending_resume_pc,
                last_syscall_nr,
                last_syscall_orig_x0,
                last_fault_esr,
                last_exit_class,
                is_forked_child,
                process_asid,
                mm_generation,
                asid_generation,
                pending_guest_run_receipt_ns,
                page_tables,
                protections,
                pending_process_fork,
            },
            vcpu,
        )
    }

    pub fn from_task_state_and_vcpu(state: Aarch64TaskEngineState<V>, vcpu: V::Vcpu) -> Self {
        let Aarch64TaskEngineState {
            vm,
            pending_resume_pc,
            last_syscall_nr,
            last_syscall_orig_x0,
            last_fault_esr,
            last_exit_class,
            is_forked_child,
            process_asid,
            mm_generation,
            asid_generation,
            pending_guest_run_receipt_ns,
            page_tables,
            protections,
            pending_process_fork,
        } = state;
        Self {
            vm,
            vcpu,
            pending_resume_pc,
            last_syscall_nr,
            last_syscall_orig_x0,
            last_fault_esr,
            last_exit_class,
            is_forked_child,
            process_asid,
            mm_generation,
            asid_generation,
            pending_guest_run_receipt_ns,
            // A task adopted from a snapshot starts with no stale fault.
            stale_stage1_retry: (0, 0),
            last_fork_image_allocations: 0,
            page_tables,
            protections,
            pending_process_fork,
            exec_predecessor_shared: None,
        }
    }
}

pub fn sibling_task_cpu_state(
    snapshot: &Aarch64VcpuSnapshot,
    mm_generation: u64,
    asid_generation: u64,
) -> Result<GuestCpuState, TrapError> {
    Ok(GuestCpuState::from_aarch64_v1(
        aarch64_task_state_from_snapshot(
            snapshot,
            None,
            None,
            0,
            0,
            0,
            false,
            None,
            mm_generation,
            asid_generation,
        )?,
    ))
}

/// Bootstrap the live stage-1 editor only when persistent exec left it absent.
///
/// Clone publication deliberately writes the parent TID while its vCPU can be
/// reclaimed. An already-present editor means the sparse backend can resolve an
/// existing mapping without reading TTBR0 or running maintenance on that parked
/// vCPU. A genuinely absent editor still takes the historical live-vCPU
/// bootstrap before any new sparse stage-1 publication.
fn ensure_sparse_page_table_editor(
    editor_present: bool,
    bootstrap: impl FnOnce() -> Result<(), MemoryError>,
) -> Result<(), MemoryError> {
    if editor_present { Ok(()) } else { bootstrap() }
}

struct ParentForkCowRollback {
    armed_ranges: Vec<crate::vmm::ForkCowRange>,
}

fn aarch64_task_state_from_snapshot(
    snapshot: &Aarch64VcpuSnapshot,
    pending_resume_pc: Option<u64>,
    last_syscall_nr: Option<u64>,
    last_syscall_orig_x0: u64,
    last_fault_esr: u64,
    last_exit_class: u64,
    is_forked_child: bool,
    syscall_continuation: Option<carrick_hal::threaded::Aarch64SyscallContinuationV1>,
    mm_generation: u64,
    asid_generation: u64,
) -> Result<Aarch64TaskCpuStateV1, TrapError> {
    if mm_generation == 0 || asid_generation == 0 {
        return Err(TrapError::Hypervisor(
            "aarch64 snapshot has no exact MM/ASID generation binding".to_owned(),
        ));
    }
    let (pc, pstate) = core_resume_pair(pending_resume_pc, snapshot);
    Ok(Aarch64TaskCpuStateV1 {
        gprs: snapshot.gprs,
        pc,
        pstate,
        trap_pc: snapshot.pc,
        trap_pstate: snapshot.pstate,
        sp_el0: snapshot.sp_el0,
        elr_el1: snapshot.elr_el1,
        spsr_el1: snapshot.spsr_el1,
        ttbr0: snapshot.ttbr0,
        ttbr1: snapshot.ttbr1,
        tcr: snapshot.tcr,
        sctlr_el1: snapshot.sctlr,
        mair_el1: snapshot.mair,
        vbar_el1: snapshot.vbar,
        cpacr_el1: snapshot.cpacr,
        cntkctl_el1: snapshot.cntkctl_el1,
        tpidr_el1: snapshot.tpidr_el1,
        actlr_el1: snapshot.actlr_el1,
        tpidr_el0: snapshot.tpidr_el0,
        tpidrro_el0: snapshot.tpidrro_el0,
        contextidr_el1: snapshot.contextidr_el1,
        vregs: snapshot.vregs,
        fpsr: snapshot.fpsr,
        fpcr: snapshot.fpcr,
        pending_resume_pc,
        last_syscall_nr,
        last_syscall_orig_x0,
        last_fault_esr,
        last_exit_class,
        is_forked_child,
        syscall_continuation,
        mm_generation,
        asid_generation,
    })
}

#[derive(Clone, Debug)]
pub struct Aarch64ResidentTaskMetadata {
    pub pending_resume_pc: Option<u64>,
    pub last_syscall_nr: Option<u64>,
    pub last_syscall_orig_x0: u64,
    pub last_fault_esr: u64,
    pub last_exit_class: u64,
    pub is_forked_child: bool,
    pub continuation: Option<carrick_hal::threaded::Aarch64SyscallContinuationV1>,
    pub mm_generation: u64,
    pub asid_generation: u64,
}

impl Aarch64ResidentTaskMetadata {
    pub fn snapshot_guest_cpu<V: Aarch64Vcpu>(&self, vcpu: &V) -> Result<GuestCpuState, TrapError> {
        let snapshot = vcpu.snapshot()?;
        Ok(GuestCpuState::from_aarch64_v1(
            aarch64_task_state_from_snapshot(
                &snapshot,
                self.pending_resume_pc,
                self.last_syscall_nr,
                self.last_syscall_orig_x0,
                self.last_fault_esr,
                self.last_exit_class,
                self.is_forked_child,
                self.continuation,
                self.mm_generation,
                self.asid_generation,
            )?,
        ))
    }
}

/// Overlay one migratable task image onto a destination executor snapshot.
/// Executor-local `SP_EL1`/mailbox state is retained from `destination`.
/// Before the overlay, the destination's neutral EL1 controls are validated;
/// the task's exact saved controls are then restored for guest execution.
pub fn restore_aarch64_task_state(
    destination: &Aarch64VcpuSnapshot,
    state: &Aarch64TaskCpuStateV1,
) -> Result<Aarch64VcpuSnapshot, TrapError> {
    let boot = carrick_hal::Aarch64GuestArch::bootstrap_sysregs();
    let expected_vbar = carrick_mem::memory::LINUX_EL1_VECTORS_BASE;
    // SCTLR_EL1 is compared through `is_bootstrap_sctlr_el1` rather than for
    // equality: `boot.sctlr_el1` lists the bits carrick PROGRAMS, while
    // `destination.sctlr` is what a vCPU reads BACK, which also carries the
    // architecture's RES1 bits. Those are different domains and raw equality
    // between them can never hold.
    if destination.vbar != expected_vbar
        || !carrick_mem::arch_sysregs::is_bootstrap_sctlr_el1(destination.sctlr)
        || destination.mair != boot.mair_el1
        || destination.cpacr != boot.cpacr_el1
    {
        return Err(TrapError::Hypervisor(format!(
            "aarch64 destination executor invariant mismatch: vbar={:#x}/{expected_vbar:#x} \
             sctlr={:#x}/{:#x} mair={:#x}/{:#x} cpacr={:#x}/{:#x}",
            destination.vbar,
            destination.sctlr,
            boot.sctlr_el1,
            destination.mair,
            boot.mair_el1,
            destination.cpacr,
            boot.cpacr_el1,
        )));
    }
    if state.mm_generation == 0 || state.asid_generation == 0 {
        return Err(TrapError::Hypervisor(
            "aarch64 restore rejected stale zero MM/ASID generation".to_owned(),
        ));
    }
    let mut restored = destination.clone();
    restored.gprs = state.gprs;
    restored.pc = state.trap_pc;
    restored.pstate = state.trap_pstate;
    restored.sp_el0 = state.sp_el0;
    restored.elr_el1 = state.elr_el1;
    restored.spsr_el1 = state.spsr_el1;
    restored.ttbr0 = state.ttbr0;
    restored.ttbr1 = state.ttbr1;
    restored.tcr = state.tcr;
    restored.sctlr = state.sctlr_el1;
    restored.mair = state.mair_el1;
    restored.vbar = state.vbar_el1;
    restored.cpacr = state.cpacr_el1;
    restored.cntkctl_el1 = state.cntkctl_el1;
    restored.tpidr_el1 = state.tpidr_el1;
    restored.actlr_el1 = state.actlr_el1;
    restored.tpidr_el0 = state.tpidr_el0;
    restored.tpidrro_el0 = state.tpidrro_el0;
    restored.contextidr_el1 = state.contextidr_el1;
    restored.vregs = state.vregs;
    restored.fpsr = state.fpsr;
    restored.fpcr = state.fpcr;
    Ok(restored)
}

fn seed_heap_unmapped(protections: &MemoryProtections) {
    if let Ok(heap_size) = usize::try_from(carrick_mem::memory::LINUX_HEAP_SIZE) {
        protections.set_unmapped(carrick_mem::memory::LINUX_HEAP_BASE, heap_size, true);
    }
}

/// Pure transition for replacing an engine's stage-1 page-table authority.
/// When `page_tables` is shared (`Arc::strong_count > 1`, e.g. after a
/// `CLONE_VM` / `vfork` before child's `execve`), the existing authority
/// belongs to the other threads/processes. Taking its manager or retiring
/// its extension arenas would strip the parent's live address space and
/// arena source.
#[cfg(test)]
pub(crate) fn replace_page_tables_authority(
    page_tables: &mut Stage1Authority,
    manager: Option<PageTableManager>,
    mut retire_old: impl FnMut(&mut PageTableManager) -> Result<(), TrapError>,
    mut bind_new: impl FnMut(Stage1Authority),
) -> Result<(), TrapError> {
    let new_authority = page_tables.replace_for_exec(|| Ok(manager), |old| retire_old(old))?;
    bind_new(new_authority.clone());
    *page_tables = new_authority;
    Ok(())
}

impl<V: Aarch64Vmm> Aarch64EngineCore<V> {
    fn validate_task_metadata(&self, state: &Aarch64TaskCpuStateV1) -> Result<(), TrapError> {
        if state.mm_generation != self.mm_generation
            || state.asid_generation != self.asid_generation
        {
            return Err(TrapError::Hypervisor(format!(
                "AArch64 restore generation mismatch: snapshot mm/asid={}/{} destination={}/{}",
                state.mm_generation,
                state.asid_generation,
                self.mm_generation,
                self.asid_generation
            )));
        }
        Ok(())
    }

    fn apply_task_metadata(&mut self, state: &Aarch64TaskCpuStateV1) {
        self.pending_resume_pc = state.pending_resume_pc;
        self.last_syscall_nr = state.last_syscall_nr;
        self.last_syscall_orig_x0 = state.last_syscall_orig_x0;
        self.last_fault_esr = state.last_fault_esr;
        self.last_exit_class = state.last_exit_class;
        self.is_forked_child = state.is_forked_child;
    }

    fn try_fast_write(&mut self, frame: &Aarch64SyscallFrame) -> Option<usize> {
        let base = carrick_mem::memory::LINUX_IDENTITY_PAGE_BASE;
        // The seek authority and write lease fields form a contiguous 44-byte span:
        // 0x14: SEEK_GATE (4 bytes)
        // 0x18: SEEK_FD (4 bytes)
        // 0x1C: padding (4 bytes)
        // 0x20: SEEK_OFFSET (8 bytes)
        // 0x28: WRITE_LEASE_GATE (4 bytes)
        // 0x2C: WRITE_LEASE_HOST_FD (4 bytes)
        // 0x30: WRITE_LEASE_OFFSET (8 bytes)
        // 0x38: WRITE_LEASE_GUEST_FD (4 bytes)
        // 0x3C: WRITE_LEASE_DIRTY (4 bytes)
        let mut chunk = [0u8; 44];
        if self
            .read_into_raw(
                base + carrick_mem::memory::IDENTITY_OFF_SEEK_GATE,
                &mut chunk,
            )
            .is_err()
        {
            return None;
        }

        let seek_gate = u32::from_le_bytes(chunk[0..4].try_into().ok()?);
        let seek_fd = i32::from_le_bytes(chunk[4..8].try_into().ok()?);
        let cur_seek_off = i64::from_le_bytes(chunk[12..20].try_into().ok()?);
        let write_gate = u32::from_le_bytes(chunk[20..24].try_into().ok()?);
        let host_fd = i32::from_le_bytes(chunk[24..28].try_into().ok()?);
        let write_guest_fd = i32::from_le_bytes(chunk[36..40].try_into().ok()?);

        let guest_fd = frame.x0 as i32;
        if seek_gate != 1
            || write_gate != 1
            || seek_fd != guest_fd
            || write_guest_fd != guest_fd
            || host_fd < 0
            || cur_seek_off < 0
        {
            return None;
        }

        let offset = cur_seek_off as u64;
        let buf_gva = frame.x1;
        let count = frame.x2 as usize;
        let written = if count <= 4096 {
            let mut stack_buf = [0u8; 4096];
            if self
                .read_into_raw(buf_gva, &mut stack_buf[..count])
                .is_err()
            {
                return None;
            }
            unsafe {
                libc::pwrite(
                    host_fd,
                    stack_buf.as_ptr() as *const libc::c_void,
                    count,
                    offset as libc::off_t,
                )
            }
        } else if let Some(host_ptr) = self.vm.host_ptr_for_read(buf_gva, count) {
            unsafe {
                libc::pwrite(
                    host_fd,
                    host_ptr as *const libc::c_void,
                    count,
                    offset as libc::off_t,
                )
            }
        } else {
            return None;
        };
        if written < 0 {
            return None;
        }

        let new_offset = offset.saturating_add(written as u64);
        let _ = self.write_bytes(
            base + carrick_mem::memory::IDENTITY_OFF_SEEK_OFFSET,
            &(new_offset as i64).to_le_bytes(),
        );
        let mut lease_update = [0u8; 16];
        lease_update[0..8].copy_from_slice(&new_offset.to_le_bytes());
        lease_update[8..12].copy_from_slice(&chunk[36..40]); // preserve guest_fd
        lease_update[12..16].copy_from_slice(&1_u32.to_le_bytes()); // dirty = 1
        let _ = self.write_bytes(
            base + carrick_mem::memory::IDENTITY_OFF_WRITE_LEASE_OFFSET,
            &lease_update,
        );
        Some(written as usize)
    }

    fn try_fast_read(&mut self, frame: &Aarch64SyscallFrame) -> Option<usize> {
        let base = carrick_mem::memory::LINUX_IDENTITY_PAGE_BASE;
        let mut chunk = [0u8; 44];
        if self
            .read_into_raw(
                base + carrick_mem::memory::IDENTITY_OFF_SEEK_GATE,
                &mut chunk,
            )
            .is_err()
        {
            return None;
        }

        let seek_gate = u32::from_le_bytes(chunk[0..4].try_into().ok()?);
        let seek_fd = i32::from_le_bytes(chunk[4..8].try_into().ok()?);
        let cur_seek_off = i64::from_le_bytes(chunk[12..20].try_into().ok()?);
        let write_gate = u32::from_le_bytes(chunk[20..24].try_into().ok()?);
        let host_fd = i32::from_le_bytes(chunk[24..28].try_into().ok()?);
        let write_guest_fd = i32::from_le_bytes(chunk[36..40].try_into().ok()?);

        let guest_fd = frame.x0 as i32;
        if seek_gate != 1
            || write_gate != 1
            || seek_fd != guest_fd
            || write_guest_fd != guest_fd
            || host_fd < 0
            || cur_seek_off < 0
        {
            return None;
        }

        let offset = cur_seek_off as u64;
        let buf_gva = frame.x1;
        let count = frame.x2 as usize;
        if count == 0 {
            return Some(0);
        }

        let nread = if count <= 4096 {
            let mut stack_buf = [0u8; 4096];
            let read = unsafe {
                libc::pread(
                    host_fd,
                    stack_buf.as_mut_ptr() as *mut libc::c_void,
                    count,
                    offset as libc::off_t,
                )
            };
            if read < 0 {
                return None;
            }
            let read_bytes = read as usize;
            if self.write_bytes(buf_gva, &stack_buf[..read_bytes]).is_err() {
                return None;
            }
            read_bytes
        } else if let Some(host_ptr) = self.vm.host_ptr_for_write(buf_gva, count) {
            let read = unsafe {
                libc::pread(
                    host_fd,
                    host_ptr as *mut libc::c_void,
                    count,
                    offset as libc::off_t,
                )
            };
            if read < 0 {
                return None;
            }
            read as usize
        } else {
            return None;
        };

        let new_offset = offset.saturating_add(nread as u64);
        let _ = self.write_bytes(
            base + carrick_mem::memory::IDENTITY_OFF_SEEK_OFFSET,
            &(new_offset as i64).to_le_bytes(),
        );
        let mut lease_update = [0u8; 12];
        lease_update[0..8].copy_from_slice(&new_offset.to_le_bytes());
        lease_update[8..12].copy_from_slice(&chunk[36..40]); // preserve guest_fd
        let _ = self.write_bytes(
            base + carrick_mem::memory::IDENTITY_OFF_WRITE_LEASE_OFFSET,
            &lease_update,
        );
        Some(nread)
    }

    /// Build an engine around an already-constructed VM + vCPU (the backend's
    /// bring-up produces these). Mirrors `X86EngineCore::from_parts`: the
    /// tracking fields start cleared, and a freshly brought-up engine gets a
    /// fresh page-table editor and an empty PROT_NONE set. Siblings instead SHARE
    /// the spawning thread's `page_tables`/`protections` via the (later) sibling
    /// constructor.
    pub fn from_parts(mut vm: V, vcpu: V::Vcpu) -> Self {
        let page_tables = Stage1Authority::new();
        vm.bind_stage1_page_tables(page_tables.clone());
        // Adopt the backend's protections authority when it exposes one
        // (`exec_protections` is the backend's live task authority, not an
        // exec-only value). Creating a separate engine-side Arc here split the
        // per-mm protections into TWO instances: every marking write goes
        // through `self.vm.protections()` (the backend's), while the fork
        // process-spec and sibling specs snapshot/share the engine's. The
        // root process's engine mirror therefore stayed EMPTY forever, so a
        // forked child inherited no `mutable_shared_backing` ranges and every
        // anon-`MAP_SHARED` futex in a child fell to the process-private
        // table (sharedanonfutexfork / futexforkrequeue: all waiters
        // ETIMEDOUT while the parent's wake found zero). One mm, one
        // authority.
        let protections = vm
            .exec_protections()
            .unwrap_or_else(|| Arc::new(MemoryProtections::default()));
        seed_heap_unmapped(&protections);
        Self {
            vm,
            vcpu,
            pending_resume_pc: None,
            last_syscall_nr: None,
            last_syscall_orig_x0: 0,
            stale_stage1_retry: (0, 0),
            last_fork_image_allocations: 0,
            last_fault_esr: 0,
            last_exit_class: 0,
            is_forked_child: false,
            process_asid: None,
            mm_generation: 1,
            asid_generation: 1,
            pending_guest_run_receipt_ns: 0,
            page_tables,
            protections,
            pending_process_fork: None,
            exec_predecessor_shared: None,
        }
    }

    /// The backend VM half (stage-2 mapping, fork/execve rebuild, sibling spawn).
    pub fn vm(&self) -> &V {
        &self.vm
    }

    /// Mutable access to the backend VM half.
    pub fn vm_mut(&mut self) -> &mut V {
        &mut self.vm
    }

    /// The (one) vCPU for this process thread.
    pub fn vcpu(&self) -> &V::Vcpu {
        &self.vcpu
    }

    /// Mutable access to the vCPU (the trap-surfacing primitive runs through it).
    pub fn vcpu_mut(&mut self) -> &mut V::Vcpu {
        &mut self.vcpu
    }

    /// The pending syscall resume PC (`Some` between `next_syscall` and
    /// `complete_syscall`).
    pub fn pending_resume_pc(&self) -> Option<u64> {
        self.pending_resume_pc
    }

    /// The Linux syscall number (x8) of the most recent trapped `svc` (the
    /// SA_RESTART input).
    pub fn last_syscall_nr(&self) -> Option<u64> {
        self.last_syscall_nr
    }

    /// The pre-syscall x0 of the most recent trapped `svc` (the SA_RESTART rewind
    /// input).
    pub fn last_syscall_orig_x0(&self) -> u64 {
        self.last_syscall_orig_x0
    }

    /// The `ESR_EL1` of the most recent EL0 synchronous fault.
    pub fn last_fault_esr(&self) -> u64 {
        self.last_fault_esr
    }

    /// The EC of the most recent exit (the `svc`-vs-`hvc` trap-surface
    /// discriminator).
    pub fn last_exit_class(&self) -> u64 {
        self.last_exit_class
    }

    /// Whether this engine is the child side of a guest `fork(2)`.
    pub fn is_forked_child(&self) -> bool {
        self.is_forked_child
    }

    /// The shared stage-1 page-table authority handle.
    pub fn page_tables(&self) -> &Stage1Authority {
        &self.page_tables
    }

    /// Replace this mm's stage-1 manager without splitting the engine/backend
    /// authority. The HVPatch backend resolves permission faults itself, so
    /// every fresh authority must be rebound before the stopped vCPU can resume.
    ///
    /// The sharing decision is governed strictly by the authority's own
    /// `vfork_shares` count. Returns `true` if the predecessor authority was
    /// shared (and therefore preserved for other siblings/parent).
    fn replace_page_tables(
        &mut self,
        manager: Option<PageTableManager>,
    ) -> Result<bool, TrapError> {
        let (new_authority, was_shared) = self.page_tables.replace_for_exec_internal(
            || Ok(manager),
            |old| self.vm.retire_stage1_extension_arenas(old),
        )?;
        self.vm.bind_stage1_page_tables(new_authority.clone());
        self.page_tables = new_authority;
        Ok(was_shared)
    }

    /// The shared PROT_NONE EFAULT gate (cloned across `CLONE_THREAD` siblings,
    /// COW'd on fork).
    pub fn protections(&self) -> &Arc<MemoryProtections> {
        &self.protections
    }

    /// Like [`from_parts`](Self::from_parts) but ADOPTS the spawning thread's
    /// page-table authority + PROT_NONE bookkeeping — used to make a
    /// `clone(CLONE_THREAD)` sibling SHARE its parent's stage-1 authority (same VM,
    /// same backing) and PROT_NONE set. On KVM the PROT_NONE set itself lives in
    /// the backend `GuestRam` (shared via `from_shared_windows`), so this `Arc`
    /// is the engine-side mirror; the page-table authority is the load-bearing share.
    pub fn from_parts_with_shared(
        mut vm: V,
        vcpu: V::Vcpu,
        page_tables: Stage1Authority,
        protections: Arc<MemoryProtections>,
    ) -> Self {
        vm.bind_stage1_page_tables(page_tables.clone());
        Self {
            vm,
            vcpu,
            pending_resume_pc: None,
            last_syscall_nr: None,
            last_syscall_orig_x0: 0,
            stale_stage1_retry: (0, 0),
            last_fork_image_allocations: 0,
            last_fault_esr: 0,
            last_exit_class: 0,
            is_forked_child: false,
            process_asid: None,
            mm_generation: 1,
            asid_generation: 1,
            pending_guest_run_receipt_ns: 0,
            page_tables,
            protections,
            pending_process_fork: None,
            exec_predecessor_shared: None,
        }
    }

    /// Read `len` bytes of live guest memory at guest-physical `gpa` (e.g. a
    /// `write(2)` buffer the guest passed). Backed by the same host RAM the vCPU
    /// sees, so guest writes are visible. (The standalone run-elf loop uses this.)
    pub fn read_guest(&self, gpa: Gpa, len: usize) -> Result<Vec<u8>, TrapError> {
        self.vm.read_gpa(gpa.raw(), len)
    }

    // ── test / bring-up setters (used by the backend crates' unit tests) ──
    // These poke the same engine-owned tracking fields the trap loop maintains, so
    // a per-VMM `#[cfg(test)]` (which lives in another crate and cannot reach the
    // private fields) can assert the fork/execve/inject behaviour. They are plain
    // `pub` (not `#[cfg(test)]`) because the consumers are cross-crate tests, so
    // they are not dead code.

    /// Set the forked-child marker (mirrors what the shared `fork()` does on the
    /// child side). For cross-crate tests of `execve` is_forked_child preservation.
    #[doc(hidden)]
    pub fn set_is_forked_child_for_test(&mut self, v: bool) {
        self.is_forked_child = v;
    }

    /// Set the most-recent-fault ESR stash (the `inject_signal` sigframe input).
    #[doc(hidden)]
    pub fn set_last_fault_esr_for_test(&mut self, v: u64) {
        self.last_fault_esr = v;
    }

    /// Set the SA_RESTART syscall-number / orig-x0 stash.
    #[doc(hidden)]
    pub fn set_last_syscall_for_test(&mut self, nr: Option<u64>, orig_x0: u64) {
        self.last_syscall_nr = nr;
        self.last_syscall_orig_x0 = orig_x0;
    }

    // ── stage-1 page-table edit core (the locked EDIT primitive) ──

    /// Edit the live stage-1 page tables (the guest's own translation tables at
    /// `LINUX_PAGE_TABLES_BASE`) under the shared manager lock and replay the
    /// changed descriptors into the guest page-table backing — the locked EDIT
    /// CORE, WITHOUT a TLB flush. Builds the `PageTableManager` lazily from the
    /// live backing on first use (the boot image already wrote
    /// `stage1_identity_page_tables` there). Returns whether the edit CHANGED any
    /// descriptor (so the caller can skip a pointless flush on a no-op edit).
    /// Callers that publish a guest-visible translation route through
    /// [`Self::pt_edit_and_flush`], which runs [`Self::run_el1_maintenance`]
    /// afterwards so a cached invalid walk or stale leaf cannot survive the
    /// publication.
    /// Build a stage-1 manager from the live guest tables at the current
    /// TTBR0 root — the same construction `pt_edit_locked` performs lazily on
    /// the first edit. Fails (rather than guessing) when the root or its
    /// backing is not readable yet.
    fn build_page_tables_manager_from_live(&self) -> Result<PageTableManager, MemoryError> {
        const TTBR_ROOT_MASK: u64 = (1_u64 << 48) - 1;
        let pt_base = self
            .vcpu
            .get_sys_reg(SysReg::Ttbr0)
            .map_err(|error| MemoryError::HostMap(format!("read TTBR0_EL1: {error}")))?
            & TTBR_ROOT_MASK;
        if pt_base == 0 {
            return Err(MemoryError::HostMap(
                "stage-1 root not programmed".to_string(),
            ));
        }
        let size = carrick_mem::memory::LINUX_PAGE_TABLES_SIZE as usize;
        let bytes = self
            .vm
            .read_gpa(pt_base, size)
            .map_err(|_| MemoryError::HostMap("read live page tables".to_string()))?;
        use carrick_hal::PageTableCodec as _;
        Ok(
            <<Self as ThreadedEngine>::Arch as carrick_hal::GuestArch>::Mmu::new_manager(
                bytes, pt_base,
            ),
        )
    }

    fn pt_edit_locked(
        &mut self,
        edit: impl FnOnce(&mut Stage1Editor<'_>) -> Result<PageTableApplyOutcome, PageTableError>,
    ) -> Result<PageTableApplyOutcome, MemoryError> {
        const TTBR_ROOT_MASK: u64 = (1_u64 << 48) - 1;
        let pt_base = self
            .vcpu
            .get_sys_reg(SysReg::Ttbr0)
            .map_err(|error| MemoryError::HostMap(format!("read TTBR0_EL1: {error}")))?
            & TTBR_ROOT_MASK;
        let size = carrick_mem::memory::LINUX_PAGE_TABLES_SIZE as usize;
        let host = self
            .vm
            .host_ptr(pt_base, size)
            .ok_or_else(|| MemoryError::HostMap("page-table region not mapped".to_string()))?;
        let page_tables = self.page_tables.clone();
        let engines = page_tables.engines();
        let unsafe_to_coalesce = page_tables.is_shared_with_vfork_child() || engines > 1;
        let stage1_exclusive = carrick_hal::stage1_exclusive::current_thread_edits_exclusively();

        let live_mgr = if page_tables.is_none() {
            Some(self.build_page_tables_manager_from_live()?)
        } else {
            None
        };
        let mut outcome = PageTableApplyOutcome::default();
        let edit_res: Result<(), MemoryError> = page_tables.edit(
            || live_mgr.ok_or_else(|| MemoryError::HostMap("stage-1 manager absent".to_string())),
            |editor| {
                if editor.base() != pt_base {
                    return Err(MemoryError::HostMap(format!(
                        "page-table manager root 0x{:x} does not match TTBR0 root 0x{pt_base:x}",
                        editor.base()
                    )));
                }
                editor.set_multi_vcpu(unsafe_to_coalesce);
                editor.set_stage1_exclusive(stage1_exclusive);
                match edit(editor) {
                    Ok(res) => {
                        outcome = res;
                        if outcome.changed {
                            self.vm
                                .publish_stage1_extension_arenas(editor.manager)
                                .map_err(|error| {
                                    MemoryError::HostMap(format!(
                                        "publish stage-1 extension arenas failed: {error:?}"
                                    ))
                                })?;
                            // SAFETY: `host` backs the live page-table region for the whole process
                            // lifetime; the manager writes only 8-byte-aligned descriptor slots
                            // within `[host, host + size)`.
                            unsafe {
                                editor.sync_to_host(|base| {
                                    self.vm
                                        .host_ptr(base, size)
                                        .or_else(|| (base == pt_base).then_some(host))
                                })
                            }
                            .map_err(|error| {
                                MemoryError::HostMap(format!(
                                    "sync stage-1 page tables to host failed: {error:?}"
                                ))
                            })?;
                            editor.manager.record_populated_prefixes(|base, prefix| {
                                self.vm.record_stage1_populated_prefix(base, prefix);
                            });
                        }
                        Ok(())
                    }
                    Err(PageTableError::OutOfTables) => {
                        let (in_use, free, capacity, arenas) = editor.pool_stats();
                        let source = editor.has_arena_source();
                        let pmr = stage1_exclusive;
                        Err(MemoryError::HostMap(format!(
                            "stage-1 page-table pool exhausted \
                             (in_use={in_use} free={free} capacity={capacity} arenas={arenas} source={source} \
                             reclaim_disabled={unsafe_to_coalesce} engines={engines} pmr={pmr})"
                        )))
                    }
                    Err(PageTableError::BadAddress) => {
                        Err(MemoryError::OutOfBounds {
                            address: 0,
                            length: 0,
                        })
                    }
                    Err(PageTableError::MissingArenaSource) => {
                        Err(MemoryError::HostMap(
                            "stage-1 page-table manager has no arena source".to_owned(),
                        ))
                    }
                    Err(PageTableError::ConflictingArenaSource) => {
                        Err(MemoryError::HostMap(
                            "stage-1 page-table manager conflicting arena source".to_owned(),
                        ))
                    }
                    Err(PageTableError::UnresolvedArena(base)) => {
                        Err(MemoryError::HostMap(format!(
                            "stage-1 page-table manager unresolved arena 0x{base:x}",
                        )))
                    }
                }
            },
        );
        edit_res?;
        Ok(outcome)
    }

    /// Edit the stage-1 tables WITHOUT a TLB flush. Reserved for changes that do
    /// not publish a new guest-visible translation.
    fn pt_edit(
        &mut self,
        edit: impl FnOnce(&mut Stage1Editor<'_>) -> Result<PageTableApplyOutcome, PageTableError>,
    ) -> Result<(), MemoryError> {
        self.pt_edit_locked(edit).map(|_outcome| ())
    }

    /// Edit the stage-1 tables AND, if any descriptor changed in a way that
    /// requires a TLB flush, flush the stale stage-1 TLB by running the
    /// EL1-maintenance trampoline on this vCPU ([`Self::run_el1_maintenance`]).
    ///
    /// Transitions that only validate previously-invalid leaves require NO TLB
    /// maintenance on AArch64 (invalid translations are never cached in TLBs by
    /// hardware MMUs). Coalescing, splitting, or changing already-valid leaf
    /// permissions/output addresses set `flush_required` and invoke TLBI.
    ///
    /// Cross-vCPU: the generic threaded loop's Pause-Modify-Resume
    /// (`vcpu_loop.rs` `pt_pause`) has already PAUSED every sibling vCPU out of
    /// guest before this edit runs, and the maintenance trampoline's
    /// `tlbi vmalle1is` is INNER-SHAREABLE, so it broadcasts the invalidation to
    /// the paused siblings' stage-1 TLBs too — multi-threaded correctness comes
    /// from PMR (pause) + the inner-shareable flush, both reused here, not
    /// re-invented.
    fn pt_edit_and_flush(
        &mut self,
        edit: impl FnOnce(&mut Stage1Editor<'_>) -> Result<PageTableApplyOutcome, PageTableError>,
    ) -> Result<(), MemoryError> {
        let outcome = self.pt_edit_locked(edit)?;
        if !outcome.flush_required {
            // Nothing changed that requires a TLB flush: no previously-valid leaf
            // was modified, split, or coalesced, so there is no stale TLB entry
            // to invalidate.
            return Ok(());
        }
        self.run_stage1_maintenance()
            .map_err(|e| MemoryError::HostMap(format!("stage-1 TLBI failed: {e}")))
    }

    /// Revert uncommitted page table edits from the undo journal to shadow and host memory,
    /// and flush stale translations from the stage-1 TLB.
    fn pt_rollback_undo_and_flush(&mut self) -> Result<(), MemoryError> {
        const TTBR_ROOT_MASK: u64 = (1_u64 << 48) - 1;
        let pt_base = self
            .vcpu
            .get_sys_reg(SysReg::Ttbr0)
            .map_err(|error| MemoryError::HostMap(format!("read TTBR0_EL1: {error}")))?
            & TTBR_ROOT_MASK;
        let size = carrick_mem::memory::LINUX_PAGE_TABLES_SIZE as usize;
        let host = self
            .vm
            .host_ptr(pt_base, size)
            .ok_or_else(|| MemoryError::HostMap("page-table region not mapped".to_string()))?;
        unsafe {
            self.page_tables.rollback_undo(|base| {
                self.vm
                    .host_ptr(base, size)
                    .or_else(|| (base == pt_base).then_some(host))
            });
        }
        self.run_stage1_maintenance()
            .map_err(|e| MemoryError::HostMap(format!("stage-1 TLBI failed: {e}")))
    }

    /// Diagnostic walk of the authoritative host backing after publication.
    /// Unlike [`PageTableManager::debug_walk`], this reads the descriptors the
    /// hardware MMU sees. Kept off the syscall hot path; high-VA alias installs
    /// use it to fire the existing `pt-alias-walk` USDT receipt.
    fn live_pt_debug_walk(&self, va: u64) -> Result<[u64; 4], MemoryError> {
        const TTBR_ROOT_MASK: u64 = (1_u64 << 48) - 1;
        let pt_base = self
            .vcpu
            .get_sys_reg(SysReg::Ttbr0)
            .map_err(|error| MemoryError::HostMap(format!("read TTBR0_EL1: {error}")))?
            & TTBR_ROOT_MASK;
        let size = carrick_mem::memory::LINUX_PAGE_TABLES_SIZE as usize;
        let host = self
            .vm
            .host_ptr(pt_base, size)
            .ok_or_else(|| MemoryError::HostMap("page-table region not mapped".to_owned()))?;
        self.live_pt_debug_walk_with_host(va, pt_base, host)
    }

    fn live_pt_debug_walk_with_host(
        &self,
        va: u64,
        pt_base: u64,
        host: *mut u8,
    ) -> Result<[u64; 4], MemoryError> {
        let size = carrick_mem::memory::LINUX_PAGE_TABLES_SIZE as usize;
        self.page_tables
            .with_manager(|manager| {
                if manager.base() != pt_base {
                    return Err(MemoryError::HostMap(format!(
                        "page-table manager root 0x{:x} does not match TTBR0 root 0x{pt_base:x}",
                        manager.base()
                    )));
                }
                // SAFETY: `host_ptr` resolved the complete live page-table mapping at
                // `pt_base`, and the manager's base/length were checked above.
                unsafe {
                    manager.debug_walk_host(
                        |base| {
                            self.vm
                                .host_ptr(base, size)
                                .or_else(|| (base == pt_base).then_some(host))
                        },
                        va,
                    )
                }
                .map_err(|error| {
                    MemoryError::HostMap(format!(
                        "debug walk stage-1 page tables failed: {error:?}"
                    ))
                })
            })
            .ok_or_else(|| {
                MemoryError::HostMap("page-table manager unexpectedly absent".to_owned())
            })?
    }

    /// Flush the stale stage-1 TLB after a host page-descriptor edit by running the
    /// EL1 stage-1 maintenance trampoline on THIS vCPU. The trampoline
    /// (`dsb sy; tlbi vmalle1is; dsb sy; isb`) lives at
    /// [`carrick_mem::memory::LINUX_EL1_MAINT_BASE`] and ends in a backend
    /// completion vehicle — KVM's MMIO store to `MAINT_SENTINEL_GPA` (surfaced as
    /// `Aarch64Exit::MaintenanceDone`), in place of HVF's `hvc #1`.
    ///
    /// The vCPU is parked at a syscall (or fault) trap when this runs, so it saves
    /// and restores the interrupted EL1-vector state — PC, PSTATE (CPSR), ELR_EL1,
    /// SPSR_EL1 — AND the two GPRs the trampoline clobbers (x8 the store value, x9
    /// the sentinel-address scratch). With those restored, the in-flight syscall
    /// resumes exactly as before. Mirrors HVF's `run_el1_maintenance`.
    fn run_el1_maintenance_on(vcpu: &mut V::Vcpu) -> Result<(), TrapError> {
        // M[3:0]=0b0101 EL1h (SP_EL1) + DAIF masked, PAN(bit22)=0 — the SAME PSTATE
        // boot uses to run the EL0-entry trampoline at EL1 (program_sysregs sets
        // `PSTATE_M_EL1H | DAIF_MASKED`). The maintenance trampoline issues no
        // EL0-accessible store under PAN, so PAN=0 is not strictly required, but
        // matching boot keeps the EL1 entry conditions identical.
        const AARCH64_PSTATE_EL1H_DAIF_MASKED: u64 = 0x3c5;

        let g = |vcpu: &V::Vcpu, r: Reg| vcpu.get_reg(r);
        // Save the interrupted EL1-vector state + the two scratch GPRs the
        // trampoline clobbers.
        let saved_pc = g(vcpu, Reg::Pc)?;
        let saved_pstate = g(vcpu, Reg::Pstate)?;
        let saved_elr = g(vcpu, Reg::ElrEl1)?;
        let saved_spsr = g(vcpu, Reg::SpsrEl1)?;
        let saved_x8 = g(vcpu, Reg::X(8))?;
        let saved_x9 = g(vcpu, Reg::X(9))?;

        let s = |vcpu: &mut V::Vcpu, r: Reg, v: u64| vcpu.set_reg(r, v);
        s(vcpu, Reg::Pc, carrick_mem::memory::LINUX_EL1_MAINT_BASE)?;
        s(vcpu, Reg::Pstate, AARCH64_PSTATE_EL1H_DAIF_MASKED)?;

        // Run the trampoline to its completion vehicle. A cross-thread kick
        // (`Aarch64Exit::Kicked`) can land mid-flush; the trampoline is tiny and
        // idempotent, so just re-enter it. Any OTHER exit is ambiguous (we cannot
        // trust guest memory visibility) — surface it. (No guest_cpu accounting:
        // this is a host-driven flush, not guest execution time.)
        let result = loop {
            match vcpu.run() {
                Ok(Aarch64Exit::MaintenanceDone) => {
                    if std::env::var_os("CARRICK_MAINT_DEBUG").is_some() {
                        eprintln!("[MAINTDBG tid={}] stage-1 TLBI completed", debug_tid());
                    }
                    break Ok(());
                }
                Ok(Aarch64Exit::Kicked) => continue,
                Ok(other) => {
                    break Err(TrapError::UnexpectedExit {
                        reason: format!(
                            "{} during EL1 stage-1 maintenance",
                            maintenance_exit_detail(&other)
                        ),
                    });
                }
                Err(e) => break Err(e),
            }
        };

        // Restore the interrupted EL1-vector state + scratch GPRs on EVERY path so
        // the parked syscall resumes unperturbed even if the flush errored.
        s(vcpu, Reg::Pc, saved_pc)?;
        s(vcpu, Reg::Pstate, saved_pstate)?;
        s(vcpu, Reg::ElrEl1, saved_elr)?;
        s(vcpu, Reg::SpsrEl1, saved_spsr)?;
        s(vcpu, Reg::X(8), saved_x8)?;
        s(vcpu, Reg::X(9), saved_x9)?;
        result
    }

    /// Invalidate one numeric ASID on this exact owner-thread vCPU. The strong
    /// software generation is authenticated by the runtime command; hardware
    /// consumes only the architectural 16-bit ASID operand in `x0[63:48]`.
    pub fn invalidate_asid_on_vcpu(
        vcpu: &mut V::Vcpu,
        asid: u16,
        carrier_maintenance_root: carrick_mem::memory::CarrierMaintenanceRoot,
    ) -> Result<(), TrapError> {
        if asid == 0 {
            return Err(TrapError::Hypervisor(
                "refusing to invalidate reserved ASID zero".to_owned(),
            ));
        }
        const AARCH64_PSTATE_EL1H_DAIF_MASKED: u64 = 0x3c5;
        let saved_pc = vcpu.get_reg(Reg::Pc).map_err(|e| {
            TrapError::Hypervisor(format!("save PC for scoped EL1 ASID maintenance: {e}"))
        })?;
        let saved_pstate = vcpu.get_reg(Reg::Pstate).map_err(|e| {
            TrapError::Hypervisor(format!("save PSTATE for scoped EL1 ASID maintenance: {e}"))
        })?;
        let saved_elr = vcpu.get_reg(Reg::ElrEl1).map_err(|e| {
            TrapError::Hypervisor(format!("save ELR_EL1 for scoped EL1 ASID maintenance: {e}"))
        })?;
        let saved_spsr = vcpu.get_reg(Reg::SpsrEl1).map_err(|e| {
            TrapError::Hypervisor(format!(
                "save SPSR_EL1 for scoped EL1 ASID maintenance: {e}"
            ))
        })?;
        let saved_x0 = vcpu.get_reg(Reg::X(0)).map_err(|e| {
            TrapError::Hypervisor(format!("save X0 for scoped EL1 ASID maintenance: {e}"))
        })?;
        let saved_ttbr0 = vcpu.get_sys_reg(carrick_hal::SysReg::Ttbr0).map_err(|e| {
            TrapError::Hypervisor(format!("save TTBR0 for scoped EL1 ASID maintenance: {e}"))
        })?;

        let maint_ttbr0 = carrier_maintenance_root.raw();
        vcpu.set_sys_reg(carrick_hal::SysReg::Ttbr0, maint_ttbr0)
            .map_err(|e| {
                TrapError::Hypervisor(format!(
                    "install carrier root into TTBR0 for scoped EL1 ASID maintenance: {e}"
                ))
            })?;
        vcpu.set_reg(Reg::X(0), u64::from(asid) << 48)
            .map_err(|e| {
                TrapError::Hypervisor(format!("set X0 for scoped EL1 ASID maintenance: {e}"))
            })?;
        vcpu.set_reg(Reg::Pc, HVPATCH_EL1_ASID_MAINT_BASE)
            .map_err(|e| {
                TrapError::Hypervisor(format!("set PC for scoped EL1 ASID maintenance: {e}"))
            })?;
        vcpu.set_reg(Reg::Pstate, AARCH64_PSTATE_EL1H_DAIF_MASKED)
            .map_err(|e| {
                TrapError::Hypervisor(format!("set PSTATE for scoped EL1 ASID maintenance: {e}"))
            })?;

        // Fail closed if the entry state did not take. A live failure reported
        // `EL0Fault(esr=0x82000086 elr=far=LINUX_EL1_ASID_MAINT_BASE)` — EC 0x20
        // is "instruction abort from a LOWER EL", i.e. the trampoline was
        // fetched at EL0, where the EL1-only kernel hole is not mapped. Reading
        // the entry state back says whether the writes above landed, which
        // separates "PSTATE never took" from "something reset it mid-run".
        let entry_pc = vcpu.get_reg(Reg::Pc).map_err(|e| {
            TrapError::Hypervisor(format!(
                "verify entry PC for scoped EL1 ASID maintenance: {e}"
            ))
        })?;
        let entry_pstate = vcpu.get_reg(Reg::Pstate).map_err(|e| {
            TrapError::Hypervisor(format!(
                "verify entry PSTATE for scoped EL1 ASID maintenance: {e}"
            ))
        })?;
        let entry_ttbr0 = vcpu.get_sys_reg(carrick_hal::SysReg::Ttbr0).map_err(|e| {
            TrapError::Hypervisor(format!(
                "verify entry TTBR0 for scoped EL1 ASID maintenance: {e}"
            ))
        })?;
        if entry_pc != HVPATCH_EL1_ASID_MAINT_BASE
            || entry_pstate != AARCH64_PSTATE_EL1H_DAIF_MASKED
            || entry_ttbr0 != maint_ttbr0
        {
            return Err(TrapError::Hypervisor(format!(
                "scoped EL1 ASID maintenance entry state did not take: \
                 pc={entry_pc:#x}/{HVPATCH_EL1_ASID_MAINT_BASE:#x} \
                 pstate={entry_pstate:#x}/{AARCH64_PSTATE_EL1H_DAIF_MASKED:#x} \
                 ttbr0={entry_ttbr0:#x}/{maint_ttbr0:#x}"
            )));
        }
        carrick_observability::probes::hvpatch_tlb_invalidation(u32::from(asid), 0, 0);
        let result = loop {
            match vcpu.run() {
                Ok(Aarch64Exit::MaintenanceDone) => break Ok(()),
                Ok(Aarch64Exit::Kicked) => continue,
                Ok(other) => {
                    // The entry state is verified above, so a fetch fault at the
                    // trampoline base is about the TRANSLATION REGIME, not the
                    // entry sequence. Name it: which roots was this vCPU using,
                    // and was stage-1 even enabled.
                    let sysreg = |reg| vcpu.get_sys_reg(reg).unwrap_or(u64::MAX);
                    let ttbr0 = sysreg(carrick_hal::SysReg::Ttbr0);
                    let ttbr1 = sysreg(carrick_hal::SysReg::Ttbr1);
                    let sctlr = sysreg(carrick_hal::SysReg::Sctlr);
                    break Err(TrapError::UnexpectedExit {
                        reason: format!(
                            "{} during scoped EL1 ASID maintenance: EL1 maintenance faulted on the carrier maintenance root \
                             (asid={asid:#x} carrier_root={:#x} ttbr0={ttbr0:#x} ttbr1={ttbr1:#x} sctlr={sctlr:#x})",
                            maintenance_exit_detail(&other),
                            carrier_maintenance_root.raw(),
                        ),
                    });
                }
                Err(error) => break Err(error),
            }
        };

        let restore_ttbr0 = vcpu
            .set_sys_reg(carrick_hal::SysReg::Ttbr0, saved_ttbr0)
            .map_err(|e| {
                TrapError::Hypervisor(format!(
                    "restore TTBR0 after scoped EL1 ASID maintenance: {e}"
                ))
            });
        let restore_pc = vcpu.set_reg(Reg::Pc, saved_pc).map_err(|e| {
            TrapError::Hypervisor(format!("restore PC after scoped EL1 ASID maintenance: {e}"))
        });
        let restore_pstate = vcpu.set_reg(Reg::Pstate, saved_pstate).map_err(|e| {
            TrapError::Hypervisor(format!(
                "restore PSTATE after scoped EL1 ASID maintenance: {e}"
            ))
        });
        let restore_elr = vcpu.set_reg(Reg::ElrEl1, saved_elr).map_err(|e| {
            TrapError::Hypervisor(format!(
                "restore ELR_EL1 after scoped EL1 ASID maintenance: {e}"
            ))
        });
        let restore_spsr = vcpu.set_reg(Reg::SpsrEl1, saved_spsr).map_err(|e| {
            TrapError::Hypervisor(format!(
                "restore SPSR_EL1 after scoped EL1 ASID maintenance: {e}"
            ))
        });
        let restore_x0 = vcpu.set_reg(Reg::X(0), saved_x0).map_err(|e| {
            TrapError::Hypervisor(format!("restore X0 after scoped EL1 ASID maintenance: {e}"))
        });

        restore_ttbr0?;
        restore_pc?;
        restore_pstate?;
        restore_elr?;
        restore_spsr?;
        restore_x0?;

        result
    }

    pub fn complete_task_load_on_vcpu(vcpu: &mut V::Vcpu) -> Result<(), TrapError> {
        const AARCH64_PSTATE_EL1H_DAIF_MASKED: u64 = 0x3c5;
        let saved_pc = vcpu.get_reg(Reg::Pc)?;
        let saved_pstate = vcpu.get_reg(Reg::Pstate)?;
        let saved_elr = vcpu.get_reg(Reg::ElrEl1)?;
        let saved_spsr = vcpu.get_reg(Reg::SpsrEl1)?;
        vcpu.set_reg(Reg::Pc, carrick_mem::memory::LINUX_EL1_LOAD_BARRIER_BASE)?;
        vcpu.set_reg(Reg::Pstate, AARCH64_PSTATE_EL1H_DAIF_MASKED)?;
        let result = loop {
            match vcpu.run() {
                Ok(Aarch64Exit::MaintenanceDone) => break Ok(()),
                Ok(Aarch64Exit::Kicked) => continue,
                Ok(other) => {
                    // The full exit payload (FAR/ESR/ELR for a fault) is the
                    // whole diagnosis when the barrier dies — the bare
                    // variant name cost the vforkexecthread hunt a round.
                    break Err(TrapError::UnexpectedExit {
                        reason: format!("{other:?} during EL1 task-load barrier"),
                    });
                }
                Err(error) => break Err(error),
            }
        };
        vcpu.set_reg(Reg::Pc, saved_pc)?;
        vcpu.set_reg(Reg::Pstate, saved_pstate)?;
        vcpu.set_reg(Reg::ElrEl1, saved_elr)?;
        vcpu.set_reg(Reg::SpsrEl1, saved_spsr)?;
        result
    }

    fn run_el1_maintenance(&mut self) -> Result<(), TrapError> {
        Self::run_el1_maintenance_on(&mut self.vcpu)
    }

    fn run_stage1_maintenance_on(
        vcpu: &mut V::Vcpu,
        process_asid: Option<u16>,
        carrier_maintenance_root: Option<carrick_mem::memory::CarrierMaintenanceRoot>,
    ) -> Result<(), TrapError> {
        match process_asid {
            Some(asid) => {
                let root = carrier_maintenance_root.ok_or_else(|| {
                    TrapError::Hypervisor(
                        "AArch64 VMM does not expose a carrier maintenance root".to_owned(),
                    )
                })?;
                Self::invalidate_asid_on_vcpu(vcpu, asid, root)
            }
            None => Self::run_el1_maintenance_on(vcpu),
        }
    }

    fn run_stage1_maintenance(&mut self) -> Result<(), TrapError> {
        Self::run_stage1_maintenance_on(
            &mut self.vcpu,
            self.process_asid,
            self.vm.carrier_maintenance_root().ok(),
        )
    }

    fn ensure_frame_cow_write(
        &mut self,
        va: u64,
        len: usize,
        intent: FrameCowWriteIntent,
    ) -> Result<(), MemoryError> {
        self.ensure_sparse_mmap_backing(va, len)?;
        let vm = &mut self.vm;
        let vcpu = &mut self.vcpu;
        let process_asid = self.process_asid;
        let carrier_root = vm.carrier_maintenance_root().ok();
        let mut flush = || Self::run_stage1_maintenance_on(vcpu, process_asid, carrier_root);
        vm.ensure_frame_cow_write(va, len, intent, &mut flush)
            .map_err(|error| MemoryError::HostMap(format!("HVPatch frame COW: {error}")))
    }

    fn ensure_sparse_mmap_backing(&mut self, va: u64, len: usize) -> Result<(), MemoryError> {
        let in_sparse_arena = self.process_asid.is_some()
            && self.vm.sparse_mmap_arena_enabled()
            && ((va >= carrick_mem::memory::LINUX_MMAP_BASE
                && va.checked_add(len as u64).is_some_and(|end| {
                    end <= carrick_mem::memory::LINUX_MMAP_BASE
                        .saturating_add(carrick_mem::memory::mmap_arena_size())
                }))
                || (carrick_mem::memory::is_high_va(va)
                    && va
                        .checked_add(len as u64)
                        .is_some_and(|end| end <= (1u64 << 48))));
        if !in_sparse_arena || len == 0 {
            return Ok(());
        }
        // Persistent exec intentionally drops its software editor. A NEW sparse
        // materialization needs that editor, so instantiate it before the
        // backend transaction only when absent. When the editor already exists,
        // the backend first resolves the process-shared live mapping and does
        // not invoke the flush closure. This matters at clone publication: the
        // parent vCPU is deliberately reclaimed while its TID output is written,
        // so a redundant TTBR0 read from that parked vCPU would fail even though
        // the target stack is already materialized.
        let editor_present = self.page_tables.is_present();
        ensure_sparse_page_table_editor(editor_present, || {
            self.pt_edit(|_| Ok(PageTableApplyOutcome::default()))
        })?;
        let vm = &mut self.vm;
        let vcpu = &mut self.vcpu;
        let process_asid = self.process_asid;
        let carrier_root = vm.carrier_maintenance_root().ok();
        let mut flush = || Self::run_stage1_maintenance_on(vcpu, process_asid, carrier_root);
        vm.ensure_sparse_mmap_backing(va, len, &mut flush)
            .map_err(|error| MemoryError::HostMap(format!("HVPatch sparse mmap backing: {error}")))
    }

    /// The IPA a syscall buffer at guest VA `va` resolves to. Identity (`va`) for
    /// the common heap/stack/private-mmap pointer — NO page-table walk on the hot
    /// path. Only a `repoint_private` overlay over a shared-aperture VA
    /// ([`carrick_mem::memory::needs_stage1_translation`]) walks the live stage-1
    /// tables to find the overlay IPA whose backing the guest's OWN EL0 accesses
    /// hit (the VA-keyed window still resolves to the STALE shared aperture).
    /// High-VA aliases are EXCLUDED: their backend `WindowDesc::base == va`, so
    /// identity is correct and re-basing on the IPA would miss the window. A walk
    /// miss falls back to `va` (identity), preserving prior behaviour for an
    /// unmapped VA.
    fn syscall_buffer_ipa(&self, va: GuestVa, len: usize) -> Option<Gpa> {
        let raw = va.raw();
        if !carrick_mem::memory::needs_stage1_translation(raw, len as u64) {
            return Some(Gpa(raw));
        }
        self.page_tables
            .with_manager(|mgr| mgr.translate(raw))
            .flatten()
            .map(Gpa)
    }

    /// One page-bounded VA→IPA segment of a syscall buffer. Page bounding is
    /// mandatory: a private prefix/middle/suffix overlay can make numerically
    /// adjacent guest VAs resolve to unrelated physical pages.
    fn syscall_buffer_chunk(
        &self,
        address: u64,
        offset: usize,
        total_len: usize,
    ) -> Result<(u64, Gpa, usize), MemoryError> {
        let offset_u64 = u64::try_from(offset).map_err(|_| MemoryError::OutOfBounds {
            address,
            length: total_len,
        })?;
        let va = address
            .checked_add(offset_u64)
            .ok_or(MemoryError::OutOfBounds {
                address,
                length: total_len,
            })?;
        let page_left = (0x1000 - (va & 0xfff)) as usize;
        let len = (total_len - offset).min(page_left);
        let ipa = self
            .syscall_buffer_ipa(GuestVa(va), len)
            .ok_or(MemoryError::OutOfBounds {
                address,
                length: total_len,
            })?;
        Ok((va, ipa, len))
    }
}

/// Name a non-MaintenanceDone exit for the EL1-maintenance error path (the
/// `Aarch64Exit::Syscall` payload is not `Display`).
/// Name an unexpected maintenance exit WITH the state that explains it.
///
/// `exit_variant_name` alone says only "EL0Fault", which for a host-driven EL1
/// trampoline is the least useful half of the story: the question is always
/// which address faulted and why. An unrecoverable maintenance failure must
/// carry the syndrome, not just the variant.
fn maintenance_exit_detail(exit: &Aarch64Exit) -> String {
    match exit {
        Aarch64Exit::EL0Fault {
            syndrome,
            elr,
            far,
            from_el0_direct,
            ..
        } => format!(
            "EL0Fault(esr={syndrome:#x} elr={elr:#x} far={far:#x} \
             from_el0_direct={from_el0_direct})"
        ),
        Aarch64Exit::Stage1CowFault { .. } | Aarch64Exit::Memory { .. } => {
            format!(
                "{} (guest memory exit inside an EL1 trampoline)",
                exit_variant_name(exit)
            )
        }
        other => exit_variant_name(other).to_owned(),
    }
}

fn exit_variant_name(exit: &Aarch64Exit) -> &'static str {
    match exit {
        Aarch64Exit::Syscall { .. } => "Syscall",
        Aarch64Exit::EL0Fault { .. } => "EL0Fault",
        Aarch64Exit::Stage1CowFault { .. } => "Stage1CowFault",
        Aarch64Exit::Sys64Read { .. } => "Sys64Read",
        Aarch64Exit::MaintenanceDone => "MaintenanceDone",
        Aarch64Exit::Halt => "Halt",
        Aarch64Exit::Kicked => "Kicked",
        Aarch64Exit::Memory { .. } => "Memory",
    }
}

/// Map an engine-side `TrapError` from a `Vcpu` register read back to an
/// `OsError`, for the `read_aarch64_syscall_frame` closure (which wants `OsError`).
fn trap_to_os(e: TrapError) -> OsError {
    OsError::new(e.to_string())
}

/// The OS thread id for a diagnostic line, portably: `gettid(2)` on Linux (where
/// the KVM lane runs), `0` elsewhere (this crate also compiles on macOS for the
/// later HVF migration, where `SYS_gettid` is absent).
fn debug_tid() -> i64 {
    #[cfg(target_os = "linux")]
    {
        unsafe { libc::syscall(libc::SYS_gettid) }
    }
    #[cfg(not(target_os = "linux"))]
    {
        0
    }
}

// ─── GuestMemory ─────────────────────────────────────────────────────────────
//
// The guest is identity-mapped (stage-1 maps VA == IPA, and the single backend
// memory slot maps IPA == GPA), so a syscall's guest *virtual* pointer is
// numerically the same as its guest-physical address and indexes straight into
// the host backing. `read_bytes`/`write_bytes` move syscall buffers; the PROT_NONE
// gate is the backend's set (shared across siblings); `protect_range`/
// `unmap_range`/`repoint_private` edit the live stage-1 tables so the GUEST's own
// EL0 access honours mmap/mprotect/munmap permissions.

impl<V: Aarch64Vmm> GuestMemory for Aarch64EngineCore<V> {
    fn bind_deferred_anonymous_state(
        &mut self,
        state: std::sync::Arc<carrick_guest_mem::DeferredAnonymousState>,
    ) {
        self.vm.bind_deferred_anonymous_state(state);
    }

    fn supports_lazy_anonymous_mmap(&self) -> bool {
        self.process_asid.is_some()
            && self.vm.sparse_mmap_arena_enabled()
            && self.vm.deferred_anonymous_state().is_some()
    }

    fn supports_lazy_private_file_mmap(&self) -> bool {
        self.supports_lazy_anonymous_mmap()
    }

    /// The PROT_NONE set the shared default `read_bytes`/`write_bytes` gate on
    /// (keyed on the guest VA). The backend owns it (KVM in `GuestRam`, shared
    /// across siblings); `*_raw` does the IPA-translated backing lookup only.
    fn protections(&self) -> Option<&MemoryProtections> {
        self.vm.protections()
    }

    fn read_bytes_raw(&self, address: u64, length: usize) -> Result<Vec<u8>, MemoryError> {
        // PROT_NONE was gated on the guest VA in the default `read_bytes`. Walk
        // every page independently so a buffer spanning shared identity and a
        // private overlay never assumes one physically-contiguous base IPA.
        let mut out = vec![0u8; length];
        let mut copied = 0usize;
        while copied < length {
            let (va, ipa, chunk_len) = self.syscall_buffer_chunk(address, copied, length)?;
            let bytes = match self.vm.translated_read(va, ipa.raw(), chunk_len) {
                Ok(bytes) => bytes,
                Err(error) => {
                    let deferred = match self.vm.deferred_anonymous_state() {
                        Some(state) => state
                            .copy_pristine_file(GuestVa(va), &mut out[copied..copied + chunk_len])
                            .map_err(|error| {
                                MemoryError::HostMap(format!(
                                    "read deferred private file backing: {error}"
                                ))
                            })?,
                        None => false,
                    };
                    if deferred {
                        copied += chunk_len;
                        continue;
                    }
                    return Err(error);
                }
            };
            if bytes.len() != chunk_len {
                return Err(MemoryError::OutOfBounds { address, length });
            }
            out[copied..copied + chunk_len].copy_from_slice(&bytes);
            copied += chunk_len;
        }
        Ok(out)
    }

    fn read_into_raw(&self, address: u64, dst: &mut [u8]) -> Result<(), MemoryError> {
        // No-alloc fixed-size read (`read_u32`/`read_u64`/struct headers), still
        // page-segmented for fragmented overlays.
        let length = dst.len();
        let mut copied = 0usize;
        while copied < length {
            let (va, ipa, chunk_len) = self.syscall_buffer_chunk(address, copied, length)?;
            if let Err(error) =
                self.vm
                    .translated_read_into(va, ipa.raw(), &mut dst[copied..copied + chunk_len])
            {
                let deferred = match self.vm.deferred_anonymous_state() {
                    Some(state) => state
                        .copy_pristine_file(GuestVa(va), &mut dst[copied..copied + chunk_len])
                        .map_err(|error| {
                            MemoryError::HostMap(format!(
                                "read deferred private file backing: {error}"
                            ))
                        })?,
                    None => false,
                };
                if !deferred {
                    return Err(error);
                }
            }
            copied += chunk_len;
        }
        Ok(())
    }

    fn write_bytes_raw(&mut self, address: u64, bytes: &[u8]) -> Result<(), MemoryError> {
        // PROT_NONE gated on the guest VA in the default `write_bytes`; backing
        // lookup on the translated IPA (see `read_bytes_raw`). For a
        // `repoint_private` overlay the syscall write lands in the PRIVATE overlay
        // backing the guest reads, not the shared aperture.
        //
        // Dynamic read-only ranges (`mprotect(PROT_READ)` / read-only mmap) are
        // keyed on the guest VA in the shared protection table so a sibling vCPU's
        // syscall write observes the change. The backend's `translated_write` may
        // additionally enforce per-mapping write intent (HVF's boot/file mappings).
        if !bytes.is_empty()
            && self
                .vm
                .protections()
                .is_some_and(|p| p.range_write_denied(address, bytes.len()))
        {
            return Err(MemoryError::OutOfBounds {
                address,
                length: bytes.len(),
            });
        }
        let length = bytes.len();
        let mut copied = 0usize;
        while copied < length {
            let (va, ipa, chunk_len) = self.syscall_buffer_chunk(address, copied, length)?;
            self.ensure_frame_cow_write(va, chunk_len, FrameCowWriteIntent::GuestVisible)?;
            self.vm
                .translated_write(va, ipa.raw(), &bytes[copied..copied + chunk_len])?;
            copied += chunk_len;
        }
        Ok(())
    }

    fn write_bytes_unchecked(&mut self, address: u64, bytes: &[u8]) -> Result<(), MemoryError> {
        // carrick-INTERNAL frame the guest must receive even into a guest-read-only
        // mapping (vdso vvar, sigframe, bootstrap): bypass the per-mapping WRITE
        // permission (the host page is writable). PROT_NONE is NOT re-gated (the
        // default `write_bytes_unchecked` doesn't gate either). The translated IPA
        // resolves a `repoint_private` overlay to the private backing.
        let length = bytes.len();
        let mut copied = 0usize;
        while copied < length {
            let report_fault = |phase, error: MemoryError| {
                carrick_observability::probes::guest_internal_write_fault(
                    address,
                    length as u64,
                    phase,
                    &error.to_string(),
                );
                error
            };
            let (va, ipa, chunk_len) = self
                .syscall_buffer_chunk(address, copied, length)
                .map_err(|error| report_fault(0, error))?;
            self.ensure_frame_cow_write(va, chunk_len, FrameCowWriteIntent::PrivilegedInternal)
                .map_err(|error| report_fault(1, error))?;
            self.vm
                .translated_write_unchecked(va, ipa.raw(), &bytes[copied..copied + chunk_len])
                .map_err(|error| report_fault(2, error))?;
            copied += chunk_len;
        }
        Ok(())
    }

    fn guest_range_is_writable(&self, address: u64, length: usize) -> bool {
        if !self.vm.guest_range_is_writable(address, length) {
            return false;
        }
        if self
            .vm
            .protections()
            .is_some_and(|p| p.range_write_denied(address, length))
        {
            carrick_observability::probes::guest_internal_write_fault(
                address,
                length as u64,
                5,
                "guest write protection denies range",
            );
            return false;
        }
        true
    }

    fn host_ptr_for_read(&self, address: u64, len: usize) -> Option<*const u8> {
        self.vm.host_ptr_for_read(address, len)
    }

    fn host_ptr_for_write(&mut self, address: u64, len: usize) -> Option<*mut u8> {
        self.ensure_frame_cow_write(address, len, FrameCowWriteIntent::GuestVisible)
            .ok()?;
        self.vm.host_ptr_for_write(address, len)
    }

    /// Record/clear a PROT_NONE range so syscall buffers there fault (EFAULT). This
    /// is the HOST-SIDE check only; the COMPLEMENTARY guest-side enforcement (so
    /// the guest's own EL0 access faults) is done by `protect_range`/`unmap_range`/
    /// `unmap_alias_range`, which edit the live stage-1 tables AND flush the stale
    /// TLB via `pt_edit_and_flush` + the EL0-fault→SIGSEGV path.
    fn set_no_access(&mut self, address: u64, len: usize, no_access: bool) {
        self.vm.set_no_access(address, len, no_access);
    }

    fn set_no_write(&mut self, address: u64, len: usize, no_write: bool) {
        if let Some(protections) = self.vm.protections() {
            protections.set_no_write(address, len, no_write);
        }
    }

    fn set_unmapped(&mut self, address: u64, len: usize, unmapped: bool) {
        if let Some(protections) = self.vm.protections() {
            protections.set_unmapped(address, len, unmapped);
        }
    }

    fn set_mapping_protection(
        &mut self,
        address: u64,
        len: usize,
        no_access: bool,
        no_write: bool,
    ) {
        if let Some(protections) = self.vm.protections() {
            protections.set_mapping_protection(address, len, no_access, no_write);
        }
    }

    fn set_mapping_sharing(&mut self, address: u64, len: usize, sharing: MappingSharing) {
        if let Some(protections) = self.vm.protections() {
            protections.set_mapping_sharing(address, len, sharing);
        }
    }

    fn set_mapping_protection_and_sharing(
        &mut self,
        address: u64,
        len: usize,
        no_access: bool,
        no_write: bool,
        sharing: MappingSharing,
    ) {
        if let Some(protections) = self.vm.protections() {
            protections
                .set_mapping_protection_and_sharing(address, len, no_access, no_write, sharing);
        }
    }

    /// Scrub the physical backing of `[address, address+len)`, BYPASSING the
    /// PROT_NONE check — used to clear a reused/`munmap`'d region whose stale bytes
    /// must never resurface after a later `mprotect` makes it readable.
    fn zero_backing(&mut self, address: u64, len: usize) -> Result<(), MemoryError> {
        self.ensure_frame_cow_write(address, len, FrameCowWriteIntent::BackingMaintenance)?;
        self.vm.zero_backing(address, len)
    }

    fn discard_private_anonymous(
        &mut self,
        address: u64,
        len: usize,
    ) -> Result<bool, carrick_guest_mem::RepointPrivateError> {
        use carrick_guest_mem::RepointPrivateError;
        let Some(end) = address.checked_add(len as u64) else {
            return Err(RepointPrivateError::clean(MemoryError::OutOfBounds {
                address,
                length: len,
            }));
        };
        let in_sparse_range = (address >= carrick_mem::memory::LINUX_MMAP_BASE
            && end
                <= carrick_mem::memory::LINUX_MMAP_BASE
                    .saturating_add(carrick_mem::memory::mmap_arena_size()))
            || (carrick_mem::memory::is_high_va(address) && end <= (1u64 << 48));
        if len == 0
            || address % 4096 != 0
            || len % 4096 != 0
            || !in_sparse_range
            || !self.supports_lazy_anonymous_mmap()
            || !carrick_hal::stage1_exclusive::current_thread_edits_exclusively()
        {
            return Ok(false);
        }
        let Some(deferred) = self.vm.deferred_anonymous_state() else {
            return Ok(false);
        };
        if let Some(granule) = self.vm.anonymous_discard_granule()
            && granule.is_power_of_two()
            && granule >= 4096
            && (address % granule != 0 || (len as u64) % granule != 0)
        {
            return crate::anonymous_discard::with_edges(self, address, len, granule);
        }
        let Some(prepared) = self
            .vm
            .prepare_anonymous_discard(address, len)
            .map_err(|error| RepointPrivateError::clean(MemoryError::HostMap(error.to_string())))?
        else {
            return Ok(false);
        };
        // Keep semantic mapping/protection metadata intact. After editing starts,
        // uncertain publication must fail stopped with old owners still retained.
        self.pt_edit_and_flush(|mgr| mgr.unmap_aliased(address, len))
            .map_err(RepointPrivateError::indeterminate)?;
        self.vm
            .commit_anonymous_discard(prepared)
            .map_err(|error| {
                RepointPrivateError::indeterminate(MemoryError::HostMap(error.to_string()))
            })?;
        // Publish fresh-zero provenance only after the old translation and this
        // MM's authoritative aliases have been retired. Fork peers are untouched.
        deferred
            .reserve_fresh(carrick_guest_mem::GuestVa(address), len)
            .map_err(|error| {
                RepointPrivateError::indeterminate(MemoryError::HostMap(error.to_string()))
            })?;
        Ok(true)
    }

    fn zero_anonymous_reuse(
        &mut self,
        address: u64,
        len: usize,
        sharing: MappingSharing,
    ) -> Result<(), MemoryError> {
        if sharing == MappingSharing::Private
            && self.vm.sparse_mmap_arena_enabled()
            && ((address >= carrick_mem::memory::LINUX_MMAP_BASE
                && address.checked_add(len as u64).is_some_and(|end| {
                    end <= carrick_mem::memory::LINUX_MMAP_BASE
                        + carrick_mem::memory::mmap_arena_size()
                }))
                || (carrick_mem::memory::is_high_va(address)
                    && address
                        .checked_add(len as u64)
                        .is_some_and(|end| end <= (1u64 << 48))))
        {
            // HVPatch sparse arena retires private frames at munmap and allocates
            // pristine zeroed compounds on demand on first touch/fault.
            // Skipping the eager physical scrub keeps mmap service latency O(1).
            return Ok(());
        }
        self.zero_backing(address, len)
    }

    /// Host VA of a guest futex word IFF it lives in the `MAP_SHARED` aperture —
    /// routes a guest cross-process (`MAP_SHARED`) futex through the shared
    /// host-`SYS_futex` path on the same physical page. `None` for a private/COW
    /// word (those stay in-process via the parking-lot `FutexTable`).
    fn shared_futex_location(&self, guest_addr: u64) -> Option<SharedFutexLocation> {
        // Fork-lineage debug (CARRICK_FORK_DEBUG_VA=<hex guest VA>): name WHICH
        // gate refuses shared classification for that word. Every `None` below
        // silently lowers the op into the process-private FutexTable, where a
        // parent/child classification split is invisible until every waiter
        // times out (the sharedanonfutexfork / futexforkrequeue shape).
        let debug = fork_debug_va().is_some_and(|va| va == guest_addr);
        if !self.vm.protections().is_some_and(|protections| {
            protections.range_mutable_shared_backing(guest_addr, std::mem::size_of::<u32>())
        }) {
            if debug {
                match self.vm.protections() {
                    None => eprintln!(
                        "[FUTEXDBG] va={guest_addr:#x} REFUSED: backend exposes NO \
                         protections view"
                    ),
                    Some(protections) => eprintln!(
                        "[FUTEXDBG] va={guest_addr:#x} REFUSED: protections view live but \
                         mutable_shared_backing misses the word (ranges: {:?})",
                        protections.snapshot_all().mutable_shared_backing
                    ),
                }
            }
            return None;
        }
        // Futex identity is PHYSICAL, so always walk the live stage-1 tables.
        // Ordinary syscall buffers deliberately keep high aliases VA-keyed for
        // backend window lookup, but that policy is wrong here: HVPatch maps a
        // high guest VA (for example 0x100_0000_0000) to a stable global-frame
        // IPA. Passing the VA made both parent and child fall through to their
        // separate process-private FutexTables even though the frame receipt was
        // shared. A 4-byte-aligned futex word cannot cross a 4 KiB page.
        let backing_gpa = self
            .page_tables
            .with_manager(|page_tables| shared_futex_backing_gpa(page_tables, guest_addr));
        let Some(backing_gpa) = backing_gpa.flatten() else {
            if debug {
                eprintln!("[FUTEXDBG] va={guest_addr:#x} REFUSED: no leaf or no live tables");
            }
            return None;
        };
        let location = self.vm.shared_futex_location(backing_gpa);
        if debug {
            eprintln!(
                "[FUTEXDBG] va={guest_addr:#x} gpa={:#x} backend location: {}",
                backing_gpa.raw(),
                if location.is_some() {
                    "SHARED"
                } else {
                    "REFUSED (no shared mapping/alias covers the GPA)"
                }
            );
        }
        location
    }

    /// `mmap(MAP_PRIVATE, fd)` inside the sparse arena: hand an eligible file to
    /// the backend so it can materialize a direct view with page-granular COW
    /// instead of an eager snapshot. Unsupported ranges and mutable read-only
    /// host descriptors answer `Ok(false)` and the dispatcher snapshots.
    fn map_private_file_backed(
        &mut self,
        va: u64,
        len: usize,
        host_fd: std::os::fd::BorrowedFd<'_>,
        offset: u64,
        source: carrick_guest_mem::PrivateFileSource,
    ) -> Result<bool, MemoryError> {
        let eligible_range = self.process_asid.is_some()
            && self.vm.sparse_mmap_arena_enabled()
            && ((va >= carrick_mem::memory::LINUX_MMAP_BASE
                && va.checked_add(len as u64).is_some_and(|end| {
                    end <= carrick_mem::memory::LINUX_MMAP_BASE
                        .saturating_add(carrick_mem::memory::mmap_arena_size())
                }))
                || carrick_mem::memory::va_in_shared_aperture(va, len as u64));
        if !eligible_range || len == 0 {
            return Ok(false);
        }
        // Same editor precondition as `ensure_sparse_mmap_backing`: a fresh
        // materialization needs the software stage-1 editor.
        let editor_present = self.page_tables.is_present();
        ensure_sparse_page_table_editor(editor_present, || {
            self.pt_edit(|_| Ok(PageTableApplyOutcome::default()))
        })?;
        let vm = &mut self.vm;
        let vcpu = &mut self.vcpu;
        let process_asid = self.process_asid;
        let carrier_root = vm.carrier_maintenance_root().ok();
        let mut flush = || Self::run_stage1_maintenance_on(vcpu, process_asid, carrier_root);
        vm.materialize_private_file_backing(va, len, host_fd, offset, source, &mut flush)
            .map_err(|error| MemoryError::HostMap(format!("HVPatch private file backing: {error}")))
    }

    fn defer_private_file_backed(
        &mut self,
        va: u64,
        len: usize,
        host_fd: std::os::fd::BorrowedFd<'_>,
        offset: u64,
        source: carrick_guest_mem::PrivateFileSource,
    ) -> Result<bool, MemoryError> {
        if !self.supports_lazy_private_file_mmap()
            || len == 0
            || source != carrick_guest_mem::PrivateFileSource::ImmutableLower
        {
            return Ok(false);
        }
        let Some(granule) = self.vm.private_file_view_granule() else {
            return Ok(false);
        };
        if !granule.is_power_of_two() || va & (granule - 1) != offset & (granule - 1) {
            return Ok(false);
        }
        let state = self
            .vm
            .deferred_anonymous_state()
            .ok_or_else(|| MemoryError::HostMap("missing deferred mmap state".to_owned()))?;
        state
            .reserve_private_file(GuestVa(va), len, host_fd, offset, source)
            .map_err(|error| {
                MemoryError::HostMap(format!("defer private file backing: {error}"))
            })?;
        Ok(true)
    }

    /// Make a guest `mprotect`/`mmap`'s protection GUEST-visible by editing the
    /// live stage-1 tables. PROT_EXEC clears UXN (executable); its absence sets UXN
    /// (NX / W^X), matching Linux — so the dynamic loader's freshly-mapped library
    /// text (PROT_READ|PROT_EXEC) actually executes instead of permission-faulting
    /// on the NX-by-default arena. (Boot regions — image text, trampolines, vDSO —
    /// are mapped executable at boot and never edited here.)
    fn protect_range(&mut self, address: u64, len: usize, prot: u64) -> Result<(), MemoryError> {
        use carrick_abi::{LINUX_PROT_EXEC, LINUX_PROT_READ, LINUX_PROT_WRITE};
        if prot & (LINUX_PROT_READ | LINUX_PROT_WRITE | LINUX_PROT_EXEC) != 0 {
            self.ensure_sparse_mmap_backing(address, len)?;
        }
        let armed_cow = if prot & LINUX_PROT_WRITE != 0 {
            self.vm.armed_frame_cow_ranges(address, len)
        } else {
            Vec::new()
        };
        // pt_edit_AND_FLUSH: a guest can `mprotect` an ALREADY-TOUCHED page (e.g.
        // RELRO RW→RO), so the stale stage-1 TLB entry must be invalidated for the
        // new protection to take effect.
        self.pt_edit_and_flush(|editor| {
            editor.apply_protection_edit(address, len, prot, &armed_cow)
        })?;
        self.vm
            .observe_frame_cow_protection(address, len, prot)
            .map_err(|error| {
                MemoryError::HostMap(format!(
                    "authenticate deferred HVPatch COW protection: {error}"
                ))
            })
    }

    /// `munmap`: invalidate the stage-1 descriptors for `[address, address+len)` so
    /// the guest's own access faults (vs the host-side `no_access` check). The
    /// unmapped range is typically ALREADY-TOUCHED, so flush the stale TLB entry.
    fn restore_shared_identity(&mut self, va: u64, len: usize) -> Result<(), MemoryError> {
        let len = u64::try_from(len).map_err(|_| MemoryError::OutOfBounds {
            address: va,
            length: len,
        })?;
        self.pt_edit_and_flush(|mgr| {
            mgr.map_aliased(va, va, len, true)
                .map(|changed| PageTableApplyOutcome::new(changed, changed))
        })
    }

    fn unmap_range(&mut self, address: u64, len: usize) -> Result<(), MemoryError> {
        // Teardown the checked stage-1 path and flush stale translations first.
        // Only then retire process-shared backend lookup metadata. If the page-
        // table/TLBI operation fails, the alias registry remains an exact owner
        // of the still-published backing instead of becoming a dangling absence.
        if self.vm.sparse_mmap_arena_enabled()
            && ((address >= carrick_mem::memory::LINUX_MMAP_BASE
                && address.checked_add(len as u64).is_some_and(|end| {
                    end <= carrick_mem::memory::LINUX_MMAP_BASE
                        .saturating_add(carrick_mem::memory::mmap_arena_size())
                }))
                || carrick_mem::memory::is_high_va(address))
        {
            self.pt_edit_and_flush(|mgr| mgr.unmap_aliased(address, len))?;
        } else {
            self.pt_edit_and_flush(|mgr| mgr.invalidate(address, len))?;
        }
        self.vm.on_unmap(address, len).map_err(|error| {
            MemoryError::HostMap(format!("retire backend mapping after munmap: {error}"))
        })?;
        self.set_unmapped(address, len, true);
        Ok(())
    }

    /// `munmap` of a high-VA alias: invalidate AND reclaim the now-empty alias
    /// sub-table(s) (vs `unmap_range`, which keeps the table for the low-VA arena's
    /// in-place reuse). Flush the stale TLB entry. Mirrors HVF.
    fn unmap_alias_range(&mut self, address: u64, len: usize) -> Result<(), MemoryError> {
        // Reclaim the alias leaves/table and complete TLBI before unregistering
        // backend lookup metadata. An Err therefore leaves the alias registry
        // intact and consistent with the still-owned host/stage-2 backing.
        self.pt_edit_and_flush(|mgr| mgr.unmap_aliased(address, len))?;
        self.vm.on_unmap(address, len).map_err(|error| {
            MemoryError::HostMap(format!("retire backend alias after munmap: {error}"))
        })?;
        self.set_unmapped(address, len, true);
        Ok(())
    }

    /// Repoint guest VA `[va, va+len)` to a slot in the boot-mapped PRIVATE overlay
    /// aperture (`overlay_ipa`, identity IPA==VA), seeding the slot with the exact
    /// file or zero `content` snapshot first. Backs a guest
    /// `mmap(MAP_FIXED|MAP_PRIVATE)` over a SHARED-aperture VA: carrick's shared
    /// aperture is host-`MAP_SHARED`, so it is
    /// inherited across `fork(2)` AND visible to sibling carrick processes —
    /// leaving the VA pointed there would make a guest's "private" stores leak.
    ///
    /// (1) seed the overlay backing FIRST, while `va` still translates to the OLD
    /// (shared) IPA, so no concurrent reader sees a torn page through `va` during
    /// the flip; (2) `pt_edit_and_flush(map_aliased)` repoints the stage-1 leaf
    /// (splitting any covering boot block down to a page leaf) and — because the
    /// dispatcher may have ALREADY touched the overlay VA — runs the EL1-maintenance
    /// TLBI so any stale stage-1 entry is invalidated.
    fn repoint_private(
        &mut self,
        va: u64,
        overlay_slot_va: u64,
        len: usize,
        content: &[u8],
    ) -> Result<(), RepointPrivateError> {
        if content.len() != len {
            return Err(RepointPrivateError::clean(MemoryError::OutOfBounds {
                address: va,
                length: content.len(),
            }));
        }
        // 1. Resolve the overlay slot's host backing pointer (the same resolver the
        //    live page-table editor's `sync_to_host` uses). `len.max(1)` so a
        //    zero-length repoint still resolves the start page.
        // The overlay allocator returns its semantic slot VA. Initial boot is
        // identity-mapped, but an HVPatch exec replacement assigns that same
        // physical frame a stable global IPA. Resolve through the current mm's
        // stage-1 graph before touching backing or publishing the replacement
        // leaf; treating the slot VA as an IPA made post-exec MAP_FIXED fail
        // with ENOMEM despite the frame being live.
        let overlay_ipa = self
            .page_tables
            .with_manager(|manager| manager.translate(overlay_slot_va))
            .flatten()
            .ok_or_else(|| {
                RepointPrivateError::clean(MemoryError::OutOfBounds {
                    address: overlay_slot_va,
                    length: len,
                })
            })?;
        let dst = self.vm.host_ptr(overlay_ipa, len.max(1)).ok_or_else(|| {
            RepointPrivateError::clean(MemoryError::OutOfBounds {
                address: overlay_ipa,
                length: len,
            })
        })?;
        // 2. Seed `content` into the overlay backing FIRST, while `va` still
        //    translates to the OLD (shared) IPA — no torn read through `va` during
        //    the flip.
        if !content.is_empty() {
            // SAFETY: `host_ptr` proved `[overlay_ipa, overlay_ipa+len)` lies wholly
            // within the overlay slot's backing, and `content` is exactly `len`
            // distinct, valid source bytes.
            unsafe {
                std::ptr::copy_nonoverlapping(content.as_ptr(), dst, len);
            }
        }
        // 3. Stage-1 repoint + TLB flush. `map_aliased` splits the covering boot
        //    block to a page leaf so a single page within the shared aperture is
        //    repointed without disturbing its neighbours; the flush invalidates any
        //    stale stage-1 entry for an already-touched overlay VA.
        // The cached manager is process-persistent. Even when an edit error
        // prevents `sync_to_host`, a multi-leaf operation may have changed its
        // scratch image; fail stopped so a later successful edit cannot publish
        // partial leaves after this candidate was recycled.
        let outcome = self
            .pt_edit_locked(|mgr| {
                mgr.map_aliased(va, overlay_ipa, len as u64, true)
                    .map(|changed| PageTableApplyOutcome::new(changed, changed))
            })
            .map_err(RepointPrivateError::indeterminate)?;
        if !outcome.changed {
            return Ok(());
        }
        classify_private_repoint_tlbi(self.run_stage1_maintenance())?;
        self.vm
            .publish_private_repoint(va, overlay_ipa, len)
            .map_err(|error| {
                RepointPrivateError::indeterminate(MemoryError::HostMap(format!(
                    "publish private repoint frame ownership: {error}"
                )))
            })
    }

    fn repoint_shared_leaf(
        &mut self,
        va: u64,
        target_ipa: u64,
        len: usize,
    ) -> Result<(), MemoryError> {
        let outcome = self
            .pt_edit_locked(|mgr| {
                mgr.map_aliased(va, target_ipa, len as u64, true)
                    .map(|changed| PageTableApplyOutcome::new(changed, changed))
            })
            .map_err(|e| MemoryError::HostMap(format!("repoint shared leaf pt edit: {e}")))?;
        if !outcome.changed {
            return Ok(());
        }
        self.run_stage1_maintenance()
            .map_err(|e| MemoryError::HostMap(format!("repoint shared leaf tlbi: {e}")))?;
        self.vm
            .publish_shared_repoint(va, target_ipa, len)
            .map_err(|e| MemoryError::HostMap(format!("publish shared repoint: {e}")))?;
        Ok(())
    }

    fn translate_va(&self, va: u64) -> Option<u64> {
        self.page_tables
            .with_manager(|mgr| mgr.translate(va))
            .flatten()
    }
}

#[cfg(test)]
fn apply_stage1_protection_edit(
    mgr: &mut PageTableManager,
    address: u64,
    len: usize,
    prot: u64,
    armed_cow: &[crate::vmm::ForkCowRange],
) -> Result<PageTableApplyOutcome, PageTableError> {
    let mut source: Option<Box<dyn carrick_mem::page_table::TableArenaSource>> = None;
    let mut editor = crate::stage1_authority::Stage1Editor {
        manager: mgr,
        arena_source: &mut source,
    };
    editor.apply_protection_edit(address, len, prot, armed_cow)
}

impl<V: Aarch64Vmm> CurrentMmMemory for Aarch64EngineCore<V> {}

fn classify_private_repoint_tlbi(result: Result<(), TrapError>) -> Result<(), RepointPrivateError> {
    result.map_err(|error| {
        RepointPrivateError::indeterminate(MemoryError::HostMap(format!(
            "stage-1 TLBI after private repoint failed: {error}"
        )))
    })
}

// ─── RegAccess ───────────────────────────────────────────────────────────────

impl<V: Aarch64Vmm> carrick_hal::RegAccess for Aarch64EngineCore<V> {
    fn get_reg(&self, r: Reg) -> Result<u64, OsError> {
        self.vcpu.get_reg(r).map_err(trap_to_os)
    }
    fn set_reg(&mut self, r: Reg, v: u64) -> Result<(), OsError> {
        self.vcpu.set_reg(r, v).map_err(trap_to_os)
    }
    fn get_sys_reg(&self, r: SysReg) -> Result<u64, OsError> {
        self.vcpu.get_sys_reg(r).map_err(trap_to_os)
    }
    fn set_sys_reg(&mut self, r: SysReg, v: u64) -> Result<(), OsError> {
        self.vcpu.set_sys_reg(r, v).map_err(trap_to_os)
    }
    fn get_vreg(&self, n: u32) -> Result<u128, OsError> {
        self.vcpu.get_vreg(n).map_err(trap_to_os)
    }
    fn set_vreg(&mut self, n: u32, v: u128) -> Result<(), OsError> {
        self.vcpu.set_vreg(n, v).map_err(trap_to_os)
    }
    fn get_fpcr(&self) -> Result<u64, OsError> {
        self.vcpu.get_fpcr().map_err(trap_to_os)
    }
    fn set_fpcr(&mut self, v: u64) -> Result<(), OsError> {
        self.vcpu.set_fpcr(v).map_err(trap_to_os)
    }
    fn get_fpsr(&self) -> Result<u64, OsError> {
        self.vcpu.get_fpsr().map_err(trap_to_os)
    }
    fn set_fpsr(&mut self, v: u64) -> Result<(), OsError> {
        self.vcpu.set_fpsr(v).map_err(trap_to_os)
    }
}

// ─── SyscallTrap ─────────────────────────────────────────────────────────────

impl<V: Aarch64Vmm> SyscallTrap for Aarch64EngineCore<V> {
    fn frame_inventory_extent_count(&self) -> usize {
        self.vm.frame_inventory_extent_count()
    }

    fn inventory_initial_mappings(
        &mut self,
        reservation: carrick_hal::FrameInventoryReservation,
    ) -> Result<carrick_hal::FrameInventoryCommit<()>, TrapError> {
        self.vm.inventory_initial_mappings(reservation)
    }

    fn begin_alias_inventory(
        &mut self,
        reservation: carrick_hal::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        self.vm.begin_alias_inventory(reservation)
    }

    fn take_alias_inventory(&mut self) -> Option<carrick_hal::FrameInventoryCommit<()>> {
        self.vm.take_alias_inventory()
    }

    fn abandon_alias_inventory(&mut self) -> bool {
        self.vm.abandon_alias_inventory()
    }

    fn frame_inventory_exec_extent_counts(&self, new_image: &AddressSpace) -> (usize, usize) {
        self.vm.frame_inventory_exec_extent_counts(new_image)
    }

    fn inject_next_begin_exec_inventory_failure(&mut self) {
        self.vm.inject_next_begin_exec_inventory_failure();
    }

    fn begin_exec_inventory(
        &mut self,
        retired: Option<carrick_hal::FrameInventoryReservation>,
        replacement: carrick_hal::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        self.vm.begin_exec_inventory(retired, replacement)
    }

    fn take_exec_inventory(&mut self) -> Option<carrick_hal::ExecInventoryCommits> {
        self.vm.take_exec_inventory()
    }

    fn next_syscall(&mut self) -> Result<Option<RawSyscall>, TrapError> {
        // One guest run per call. The loop exists ONLY to re-enter the guest when a
        // kick lands mid-syscall-trap (the `Kicked` arm); every other exit returns.
        loop {
            // Account the guest's CPU time (wall time inside the backend's guest
            // run) into this thread's guest_cpu slot so getrusage(RUSAGE_SELF) /
            // times / `/proc` see it. Done ONCE here, so every aarch64 backend on
            // this shared engine gets it for free (mirrors carrick-x86).
            let run = carrick_host::guest_cpu::timed_run(|| self.vcpu.run());
            self.pending_guest_run_receipt_ns = self
                .pending_guest_run_receipt_ns
                .saturating_add(run.elapsed_ns);
            match run
                .value
                .map_err(|error| self.vm.enrich_vcpu_run_error(&self.vcpu, error))?
            {
                Aarch64Exit::Syscall {
                    frame,
                    resume_pc,
                    current_guest_sp,
                } => {
                    if frame.x8 == 64
                        && let Some(written) = self.try_fast_write(&frame)
                    {
                        self.complete_syscall(written as i64)?;
                        continue;
                    }
                    if frame.x8 == 63
                        && let Some(read) = self.try_fast_read(&frame)
                    {
                        self.complete_syscall(read as i64)?;
                        continue;
                    }
                    // The EL0 `svc` re-entered EL1 and hit the sentinel store. The
                    // hardware already set ELR_EL1 = (svc addr + 4); the EL1
                    // vector's own `eret` (after the sentinel store) consumes it —
                    // so we do NOT touch the PC here; we just read the frame. The
                    // ENGINE owns the pending state (§2.1).
                    self.pending_resume_pc = Some(resume_pc);
                    self.last_syscall_nr = Some(frame.x8);
                    self.last_syscall_orig_x0 = frame.x0;
                    // Decode through this engine's `GuestArch` so the runtime loop is
                    // ISA-neutral: x8 → number, x0..x5 → args. `last_syscall_nr`/
                    // `orig_x0` stay set from the raw frame above (their x8/x0
                    // meaning is aarch64-fixed).
                    let (number, args) = <Self as ThreadedEngine>::Arch::decode_syscall(&frame);
                    let guest_abi = <Self as ThreadedEngine>::Arch::linux_guest_abi();
                    return Ok(Some(RawSyscall {
                        current_guest_sp,
                        number: carrick_abi::CanonicalNr(number),
                        args,
                        guest_abi,
                        // aarch64 guests already issue canonical numbers, so the
                        // ISA-native number equals the dispatch number.
                        native_number: carrick_abi::NativeNr(number),
                    }));
                }
                Aarch64Exit::EL0Fault {
                    syndrome,
                    elr,
                    far,
                    x16,
                    x17,
                    x29,
                    x30,
                    sp,
                    from_el0_direct,
                } => {
                    // The fault ESR is only valid between fault and delivery; latch
                    // it so `inject_signal` can put it in the arm64 sigframe's
                    // `esr_context` (required by Rosetta's handler).
                    self.last_fault_esr = syndrome;
                    return Err(TrapError::el0_fault(
                        syndrome,
                        elr,
                        far,
                        x16,
                        x17,
                        x29,
                        x30,
                        sp,
                        from_el0_direct,
                    ));
                }
                Aarch64Exit::Stage1CowFault { syndrome, far } => {
                    self.last_fault_esr = syndrome;
                    return Err(TrapError::Stage1CowFault {
                        syndrome,
                        far,
                        elr: self.vcpu.get_reg(Reg::Pc).unwrap_or(0),
                        spsr: self.vcpu.get_reg(Reg::Pstate).unwrap_or(0),
                    });
                }
                Aarch64Exit::Sys64Read { esr: _ } => {
                    // An EL0 `MRS` of an emulated ID/timer/cache register (Rosetta
                    // x86-on-arm + HVF). KVM's config never traps `MRS`, so this
                    // never surfaces on the KVM path; a future HVF migration
                    // services it via the shared `emulate_el0_sys64_read` and
                    // re-enters. Re-run the guest for now (no-op on KVM).
                    continue;
                }
                Aarch64Exit::MaintenanceDone => {
                    // The maintenance trampoline's completion vehicle is consumed by
                    // `run_el1_maintenance`'s own loop; reaching it here is a
                    // spurious re-entry — re-run the guest.
                    continue;
                }
                // A WFI/halt with no pending syscall: report `None` so the run loop
                // can run signal delivery and resume.
                Aarch64Exit::Halt => return Ok(None),
                Aarch64Exit::Kicked => {
                    // A cross-thread kick (host signal → KVM_RUN EINTR, e.g. a timer
                    // or `tgkill`) can land while the guest is MID-SYSCALL-TRAP: the
                    // EL0 `svc` has already re-entered EL1 and the vCPU PC is inside
                    // carrick's EL1 vector, with the sentinel-store MMIO not yet
                    // surfaced. Reporting that as a deliverable kick (→ the loop
                    // injects a signal at the EL1-vector PC) corrupts the in-flight
                    // syscall and wedges the guest in an EL0 spin. If the PC is in
                    // the EL1 vector, swallow the kick and re-enter the guest so the
                    // syscall completes; the pending signal is delivered cleanly on
                    // the syscall return. Only a kick taken in genuine guest EL0 code
                    // is reported (`Ok(None)`).
                    let pc = self.vcpu.get_reg(Reg::Pc)?;
                    let in_vector = carrick_mem::memory::is_carrick_el1_vector_va(pc);
                    if in_vector || carrick_mem::memory::is_carrick_el0_clock_stub_va(pc) {
                        // Clock completion may have already passed its flag
                        // check. Normalize to the original SVC so replay must
                        // cross host dispatch before delivering the kick.
                        let normalized = self.vcpu.force_clock_host_boundary()?;
                        if in_vector || normalized {
                            continue;
                        }
                    }
                    return Ok(None);
                }
                Aarch64Exit::Memory { gpa, va } => {
                    // A sparse/alias backend (HVF lazy high-VA alias re-map) can
                    // resolve + retry; KVM keeps the default `Ok(false)`. Unhandled
                    // → surface.
                    if self.vm.handle_memory_exit(gpa, va)? {
                        continue;
                    }
                    return Err(TrapError::Hypervisor(format!(
                        "aarch64 backend did not handle memory exit for gpa=0x{gpa:x} va=0x{va:x}"
                    )));
                }
            }
        }
    }

    fn last_syscall_nr(&self) -> Option<u64> {
        self.last_syscall_nr
    }

    fn current_pc(&self) -> Result<u64, TrapError> {
        self.vcpu.get_reg(Reg::Pc)
    }

    fn process_exit_cleanup(&mut self) -> Result<(), TrapError> {
        self.vm.process_exit_cleanup()
    }

    fn complete_syscall(&mut self, return_value: i64) -> Result<(), TrapError> {
        // The pending state is engine-owned; clear it. On aarch64 the EL1 vector's
        // `eret` already consumed ELR_EL1 (= svc+4), so we do NOT re-advance the
        // PC — we just write x0 (and restore x9, below).
        self.pending_resume_pc = None;
        // The backend owns the completion vehicle. KVM's default writes x0 and
        // restores its sentinel-clobbered x9; HVF mailbox mode release-publishes
        // the return payload without register calls. ELR_EL1 already points past
        // the SVC, so neither path advances PC here.
        self.vcpu.complete_syscall_return(return_value)
    }

    fn is_forked_child(&self) -> bool {
        self.is_forked_child
    }

    fn execve_into(&mut self, new_image: &AddressSpace) -> Result<(), TrapError> {
        let expected_shared = self.exec_predecessor_shared.take();
        let authority_id = self.page_tables.authority_id();
        // Delegate the image replacement to the backend (remap slots / rebuild VM +
        // reprogram the live vCPU's sysregs). PRESERVE is_forked_child across execve:
        // a descendant of a forked child keeps the `_exit`-without-report shutdown
        // path even after it execve's into a different image. The flag is a plain
        // field on `self`, untouched by the remap.
        self.vm.execve_rebuild(&mut self.vcpu, new_image)?;
        // `execve_rebuild` installed a fresh table image. Drop the manager for
        // the old image before the hvpatch ASID configuration reserves its
        // per-mm root-slot aperture in the NEW tables.
        let was_shared = self.replace_page_tables(self.vm.exec_page_tables())?;
        if let Some(expected) = expected_shared
            && expected != was_shared
        {
            tracing::warn!(
                authority_id,
                expected_shared = expected,
                actual_shared = was_shared,
                "execve stage-1 authority sharing expectation mismatch"
            );
        }
        if let Some(protections) = self.vm.exec_protections() {
            self.protections = protections;
        }
        seed_heap_unmapped(&self.protections);
        if let Some(asid) = self.process_asid {
            <Self as ThreadedEngine>::configure_process_asid(self, asid)?;
        }
        // A fresh image has no in-flight syscall or fault.
        self.pending_resume_pc = None;
        self.last_syscall_nr = None;
        self.last_syscall_orig_x0 = 0;
        self.last_fault_esr = 0;
        Ok(())
    }

    fn map_host_alias(
        &mut self,
        va: GuestVa,
        ipa: Gpa,
        len: u64,
        payload: &[u8],
        backing: HostAliasBacking,
    ) -> Result<(), TrapError> {
        // Back a dynamic alias mapping and return the authoritative GPA, then
        // install the guest VA -> GPA stage-1 PTE. `backing` carries the
        // dispatcher's sharing classification: HVPatch uses it to distinguish
        // anonymous fork sharing from its VM-global shared-file namespace and
        // to choose MAP_PRIVATE vs MAP_SHARED host file backing.
        //
        // Alias VAs are not necessarily fresh: deferred commitment replaces a
        // PROT_NONE reservation, and MAP_FIXED can replace an older alias. The
        // vCPU may therefore retain an invalid walk-cache entry or a stale leaf.
        // Publish through the same edit + TLBI path as mprotect/munmap before the
        // guest resumes; a successful stage-2 hv_vm_map alone is not sufficient.
        let (gpa, writable) = self
            .vm
            .add_alias(va.raw(), ipa.raw(), len, payload, backing)?;
        let mut descriptors = [0_u64; 4];
        let page_table_result = self.pt_edit_and_flush(|mgr| {
            let changed = mgr.map_aliased(va.raw(), gpa, len, writable)?;
            descriptors = mgr.debug_walk(va.raw());
            Ok(PageTableApplyOutcome::new(changed, changed))
        });
        let walk_flags =
            i32::from(self.is_forked_child) | (i32::from(page_table_result.is_err()) << 1);
        carrick_observability::probes::pt_alias_walk(va.raw(), descriptors, walk_flags);
        if page_table_result.is_ok() {
            let live_descriptors = self.live_pt_debug_walk(va.raw());
            let live_flags = walk_flags | (1 << 2) | (i32::from(live_descriptors.is_err()) << 1);
            carrick_observability::probes::pt_alias_walk(
                va.raw(),
                live_descriptors.unwrap_or([0_u64; 4]),
                live_flags,
            );
        }
        if let Err(error) = page_table_result {
            // Roll the alias inventory staging back BEFORE tearing the mapping
            // down. `add_alias` has already staged an extent that
            // names a freshly claimed MappingId, and the authority does not
            // learn about that mapping until the commit is applied — which has
            // not happened yet, and now never will.
            //
            // `unmap_alias_range` is the RETIREMENT path: it walks the extents
            // covering this VA's stage-2 lease and stages an `UnmapMapping` for
            // each. Run in this order it would pick up the extent staged
            // moments ago and ask the authority to retire a mapping it has
            // never seen, aborting the whole carrier with
            // `mapping MappingId(N) is not live` — every Linux process
            // multiplexed into it, for one process's failed mmap. Discarding
            // the staging first leaves the retirement with nothing to retire,
            // which it handles by simply unregistering the alias.
            //
            // Reproduced by `reducers/alias-churn-fatal.py`: a few hundred
            // MAP_SHARED map/unmap cycles reach a stage-1 failure and abort
            // deterministically. It is also the crash that killed
            // `cpython-multiprocessing_spawn`.
            self.vm.abandon_alias_inventory();
            let cleanup_len = usize::try_from(len).unwrap_or_else(|_| {
                carrick_fatal!(
                    "aarch64::alias_cleanup",
                    "host alias mapping length {len:#x} exceeded host pointer width during failure cleanup unwinding"
                );
            });
            if let Err(unmap_error) = self.unmap_alias_range(va.raw(), cleanup_len) {
                carrick_fatal!(
                    "aarch64::alias_cleanup",
                    "failed to unmap staged alias range at {:#x} (len {:#x}) after hypervisor alias mapping failure: {unmap_error}",
                    va.raw(),
                    cleanup_len
                );
            }
            return Err(TrapError::Hypervisor(error.to_string()));
        }
        Ok(())
    }

    fn inject_signal(&mut self, signal: carrick_hal::SignalInjection) -> Result<(), TrapError> {
        let carrick_hal::SignalInjection {
            signum,
            handler,
            sa_restorer,
            pending_syscall_retval,
            interrupted_pc,
            altstack,
            saved_sigmask,
            fault_siginfo,
            queued_siginfo,
            restart_syscall,
        } = signal;
        use carrick_hal::RegAccess as _;
        // Choose the resume mechanism by the LIVE exception level, NOT by whether the
        // caller supplied an interrupted_pc. When the vCPU is at EL1 (inside the EL1
        // trampoline — a syscall boundary OR a just-serviced rt_sigreturn), the
        // interrupted USER context is latched in ELR_EL1/SPSR_EL1 and the handler
        // must enter via the pending `eret` (which drops to EL0t). A caller-supplied
        // interrupted_pc is the x86 rt_sigreturn resume-RIP workaround (vcpu_loop
        // sets signal_interrupted_pc after SigReturn); on aarch64 it is an EL1
        // trampoline PC, and taking the "kick" path for it (overwrite the live PC,
        // keep the EL1 PSTATE) would run the handler AT EL1 → its first PXN
        // instruction fetch aborts. Normalising interrupted_pc to None when at EL1
        // routes saved_pc/PSTATE/handler-entry through the eret path so the handler
        // runs at EL0t. Genuine EL0 kicks (the run loop's CANCELED handler guarantees
        // is_guest) keep the live-CPSR kick path. A durable wake can race the
        // caller's post-exit signal drain and reach this function with NO caller
        // hint while the vCPU is still live at EL0. In that case the exception
        // level remains authoritative: upgrade to the live PC rather than saving
        // stale ELR_EL1 and redirecting the handler into an eret that does not
        // exist. (KVM never sets interrupted_pc on aarch64, so this also makes its
        // live-EL0 authority explicit rather than caller-dependent.)
        let live_pstate = self.get_reg(Reg::Pstate)?;
        let interrupted_pc =
            signal_interrupted_pc_for_live_level(live_pstate, interrupted_pc, || {
                self.get_reg(Reg::Pc)
                    .map_err(|error| TrapError::Hypervisor(error.to_string()))
            })?;
        let pending_syscall_retval =
            pending_syscall_retval_for_boundary(pending_syscall_retval, interrupted_pc, || {
                self.vcpu.pending_syscall_return()
            })?;
        // The interrupted PSTATE to save into the sigframe: KICK path (interrupted_pc
        // set, EL0) → the live CPSR we just read; SYSCALL/eret path → SPSR_EL1 where
        // the `svc`/sigreturn-svc latched the EL0 PSTATE. Single-sourced (F7); reuse
        // the already-read `live_pstate` for the kick path.
        let pstate_source =
            carrick_hal::aarch64_signal_pstate_source(interrupted_pc, Some(live_pstate), |r| {
                self.get_reg(r)
            })
            .map_err(|e| TrapError::Hypervisor(e.to_string()))?;
        let params = carrick_hal::sigframe::InjectParams {
            signum,
            handler,
            sa_restorer,
            pending_syscall_retval,
            interrupted_pc,
            altstack,
            saved_sigmask,
            fault_siginfo,
            queued_siginfo,
            restart_syscall,
            pstate_source,
            orig_x0: self.last_syscall_orig_x0,
            fault_esr: self.last_fault_esr,
            // HVF gates FP/SIMD save on `CARRICK_NO_FPSIMD` (differential measurement);
            // KVM keeps the default `true`.
            fpsimd_enabled: self.vm.fpsimd_enabled(),
            sigreturn_trampoline_base: carrick_mem::memory::LINUX_SIGRETURN_TRAMPOLINE_BASE,
        };
        let info = <Self as ThreadedEngine>::Arch::build_sigframe(self, params)?;
        carrick_observability::probes::signal_inject(signum, info.saved_pc, info.new_sp, handler);
        // The fault ESR is only valid between fault and delivery; clear it so a
        // later async signal doesn't reuse a stale synchronous-fault syndrome.
        self.last_fault_esr = 0;
        self.vcpu.prepare_register_resume()
    }

    fn restore_from_sigframe(&mut self) -> Result<u64, TrapError> {
        // fpsimd_enabled MUST match inject_signal. Returns the SAVED SIGMASK — not
        // saved_pc — mirroring the per-backend impls.
        let fpsimd = self.vm.fpsimd_enabled();
        let r = <Self as ThreadedEngine>::Arch::restore_sigframe(self, fpsimd)?;
        carrick_observability::probes::signal_restore(r.saved_pc, r.frame_sp, r.magic);
        self.vcpu.prepare_register_resume()?;
        Ok(r.sigmask)
    }
}

fn signal_interrupted_pc_for_live_level(
    live_pstate: u64,
    interrupted_pc: Option<u64>,
    live_pc: impl FnOnce() -> Result<u64, TrapError>,
) -> Result<Option<u64>, TrapError> {
    if carrick_hal::aarch64::ExecLevel::from_pstate(live_pstate).is_guest() {
        interrupted_pc.map_or_else(|| live_pc().map(Some), |pc| Ok(Some(pc)))
    } else {
        Ok(None)
    }
}

fn pending_syscall_retval_for_boundary(
    caller: Option<i64>,
    interrupted_pc: Option<u64>,
    backend: impl FnOnce() -> Result<Option<i64>, TrapError>,
) -> Result<Option<i64>, TrapError> {
    if caller.is_none() && interrupted_pc.is_none() {
        backend()
    } else {
        Ok(caller)
    }
}

// ─── ThreadedEngine ──────────────────────────────────────────────────────────

/// The `Send` payload `build_sibling_spec` hands to a freshly spawned host thread,
/// which `materialize_sibling` turns into a sibling engine. Backend-parameterized:
/// the backend supplies how to build a sibling VM/vCPU from `builder`; the SEEDED
/// register snapshot + the SHARED page-table editor / PROT_NONE set ride along so
/// the new vCPU runs in the SAME guest address space on the SAME VM.
pub struct Aarch64SiblingSpec<V: Aarch64Vmm> {
    builder: V::SiblingBuilder,
    snapshot: Aarch64VcpuSnapshot,
    /// The parent's live stage-1 page-table authority, SHARED (Arc clone): a
    /// `clone(CLONE_THREAD)` sibling runs on the SAME VM with the SAME page-table
    /// backing, so its `mmap`/`mprotect` edits must go through the SAME authority.
    page_tables: Stage1Authority,
    /// The parent's PROT_NONE bookkeeping, SHARED (Arc clone). On KVM the
    /// load-bearing share is inside the backend `GuestRam` (via
    /// `from_shared_windows`); this is the engine-side mirror.
    protections: Arc<MemoryProtections>,
    process_asid: Option<u16>,
}

pub struct Aarch64ProcessSpec<V: Aarch64Vmm> {
    builder: V::ProcessBuilder,
    snapshot: Aarch64VcpuSnapshot,
    page_tables: Stage1Authority,
    protections: Arc<MemoryProtections>,
    process_asid: u16,
}

pub struct Aarch64SiblingTaskOnlyParts<V: Aarch64Vmm> {
    pub builder: V::SiblingBuilder,
    pub snapshot: Aarch64VcpuSnapshot,
    pub page_tables: Stage1Authority,
    pub protections: Arc<MemoryProtections>,
    pub process_asid: Option<u16>,
}

pub struct Aarch64ProcessTaskOnlyParts<V: Aarch64Vmm> {
    pub builder: V::ProcessBuilder,
    pub snapshot: Aarch64VcpuSnapshot,
    pub page_tables: Stage1Authority,
    pub protections: Arc<MemoryProtections>,
    pub process_asid: u16,
}

impl<V: Aarch64Vmm> Aarch64SiblingSpec<V> {
    pub fn into_task_only_parts(self) -> Aarch64SiblingTaskOnlyParts<V> {
        Aarch64SiblingTaskOnlyParts {
            builder: self.builder,
            snapshot: self.snapshot,
            page_tables: self.page_tables,
            protections: self.protections,
            process_asid: self.process_asid,
        }
    }
}

impl<V: Aarch64Vmm> Aarch64ProcessSpec<V> {
    pub fn into_task_only_parts(self) -> Aarch64ProcessTaskOnlyParts<V> {
        Aarch64ProcessTaskOnlyParts {
            builder: self.builder,
            snapshot: self.snapshot,
            page_tables: self.page_tables,
            protections: self.protections,
            process_asid: self.process_asid,
        }
    }
}

unsafe impl<V: Aarch64Vmm> Send for Aarch64ProcessSpec<V> where V::ProcessBuilder: Send {}

// SAFETY: the snapshot is POD; the page-table / protections `Arc`s are Send+Sync;
// the builder is the backend's own bounded-`Send` payload.
unsafe impl<V: Aarch64Vmm> Send for Aarch64SiblingSpec<V> where V::SiblingBuilder: Send {}

/// Seed a fresh sibling vCPU's register file for a `clone(CLONE_THREAD)` thread.
/// Starts from the parent snapshot (inheriting the SAME stage-1 MMU sysregs +
/// guest address space) then applies the aarch64 thread-entry deltas: x0 = the
/// clone return value, SP_EL0 = the child stack, TPIDR_EL0 = the TLS base,
/// PC = parent.elr_el1 (the post-svc address), and PSTATE = parent.spsr_el1 (the
/// EL0t resume PSTATE the `svc` latched — NOT the EL1h trap-time PSTATE, or the
/// sibling would re-enter at the wrong exception level). FP/SIMD is carried
/// verbatim. This is aarch64-shared logic (lifted from KVM's `seed_sibling_snapshot`).
fn seed_sibling_snapshot(
    parent: &Aarch64VcpuSnapshot,
    entry: GuestEntryRegs,
) -> Aarch64VcpuSnapshot {
    let mut snap = parent.clone();
    snap.gprs[0] = entry.return_value;
    if let Some(stack) = entry.stack {
        snap.sp_el0 = stack;
    }
    if let Some(tls) = entry.tls {
        snap.tpidr_el0 = tls;
    }
    snap.pc = parent.elr_el1;
    // EL0-resume PSTATE: the SPSR latched on the parent's `svc` trap IS the EL0t
    // PSTATE the new thread must run with. Without this the sibling restores the
    // EL1h trap-time PSTATE and re-enters at the wrong exception level.
    snap.pstate = parent.spsr_el1;
    // The gettid fast-path stamp (CONTEXTIDR_EL1) is PER-THREAD identity and
    // must not be inherited: a sibling carrying the parent's stamp answered
    // gettid(2) at EL1 with the LEADER's tid, so a container guest's
    // tgkill(gettid_of_sibling) targeted the wrong thread and the suspended
    // sibling never woke (sigsuspendxthread). Zero means "unstamped" — the
    // EL1 handler then traps to the host, whose dispatch answers from the
    // kernel graph's ThreadKey. A process-fork child leader is re-stamped by
    // its bootstrap (`stamp_guest_tid_checked`); a clone sibling stays
    // trap-served, matching the raw lane's proven behavior.
    snap.contextidr_el1 = 0;
    snap
}

impl<V: Aarch64Vmm> ThreadedEngine for Aarch64EngineCore<V> {
    fn fd_ceiling_publisher(&self) -> Option<std::sync::Arc<dyn carrick_hal::FdCeilingPublisher>> {
        self.vm.fd_ceiling_publisher()
    }

    fn foreign_mm_endpoint(&self) -> Option<carrick_hal::ForeignMmEndpoint> {
        self.vm.foreign_mm_endpoint()
    }

    fn frame_cow_owner_inventory(
        &self,
    ) -> Option<std::sync::Arc<dyn carrick_hal::FrameCowOwnerInventory>> {
        self.vm.frame_cow_owner_inventory()
    }

    fn last_fork_stage1_image_allocations(&self) -> u64 {
        self.last_fork_image_allocations
    }

    fn last_fork_host_mapping_allocations(&self) -> u64 {
        self.vm.last_fork_host_mapping_allocations()
    }

    fn last_fork_projection_rows_visited(&self) -> u64 {
        self.vm.last_fork_projection_rows_visited()
    }

    fn audit_executor_boundary(&mut self) -> Result<(), TrapError> {
        self.vm.audit_executor_boundary(&mut self.vcpu)
    }

    fn bind_task_snapshot_identity(&mut self, mm_generation: u64, asid_generation: u64) {
        self.mm_generation = mm_generation;
        self.asid_generation = asid_generation;
    }

    fn bind_exec_predecessor_identity(
        &mut self,
        identity: carrick_hal::ExecPredecessorIdentity,
    ) -> Result<(), TrapError> {
        self.vm.bind_exec_predecessor_identity(identity)
    }

    fn take_guest_run_receipt_ns(&mut self) -> u64 {
        std::mem::take(&mut self.pending_guest_run_receipt_ns)
    }

    fn snapshot_guest_state_for_publication(&mut self) -> Result<GuestCpuState, TrapError> {
        require_migratable_fpsimd_authority(self.vm.fpsimd_enabled())?;
        let snapshot = self.vcpu.snapshot()?;
        let continuation = self.vm.task_continuation(&self.vcpu)?;
        Ok(GuestCpuState::from_aarch64_v1(
            aarch64_task_state_from_snapshot(
                &snapshot,
                self.pending_resume_pc,
                self.last_syscall_nr,
                self.last_syscall_orig_x0,
                self.last_fault_esr,
                self.last_exit_class,
                self.is_forked_child,
                continuation,
                self.mm_generation,
                self.asid_generation,
            )?,
        ))
    }

    fn discard_terminal_syscall_continuation(&mut self) -> Result<(), TrapError> {
        let _ = self
            .vm
            .take_task_continuation_for_executor_switch(&mut self.vcpu)?;
        self.pending_resume_pc = None;
        self.last_syscall_nr = None;
        self.last_syscall_orig_x0 = 0;
        self.last_fault_esr = 0;
        Ok(())
    }

    fn bind_frame_cow(
        &mut self,
        authority: std::sync::Arc<dyn carrick_hal::FrameCowAuthority>,
        identity: carrick_hal::FrameCowIdentity,
    ) {
        if self.mm_generation != identity.mm {
            carrick_fatal!(
                "aarch64::cow_identity",
                "bound memory management generation mismatch against frame COW identity: expected mm={} vs actual mm={}",
                self.mm_generation,
                identity.mm
            );
        }
        // FrameCowIdentity carries the numeric hardware ASID, not the strong
        // allocation generation. `bind_task_snapshot_identity` installed that
        // generation immediately before this call; preserve it verbatim.
        self.vm.bind_frame_cow(authority, identity);
    }

    fn refresh_fork_process_state(&mut self) -> Result<(), TrapError> {
        let vm = &mut self.vm;
        let vcpu = &mut self.vcpu;
        let process_asid = self.process_asid;
        let carrier_root = vm.carrier_maintenance_root().ok();
        let mut flush = || Self::run_stage1_maintenance_on(vcpu, process_asid, carrier_root);
        vm.refresh_fork_process_state(&mut flush)?;
        vm.refresh_vcpu_after_frame_cow(vcpu)
    }

    fn install_stage1_table_arena_source(
        &mut self,
        source: Box<dyn carrick_mem::page_table::TableArenaSource>,
    ) -> Result<(), TrapError> {
        let page_tables = self.page_tables.clone();
        page_tables.install_source_with_eager_builder(source, || {
            self.build_page_tables_manager_from_live()
        })
    }

    fn resolve_frame_cow_fault(
        &mut self,
        syndrome: u64,
        far: u64,
    ) -> Result<carrick_hal::CowFaultResolution, TrapError> {
        // Serialize the actual hardware root/ASID and live descriptors for every
        // attempted COW, including the fast EL0-abort route that never reaches
        // the runtime's generic fault diagnostic arm. This is structural proof
        // that an identity-bearing COW event edited the graph the vCPU walked.
        let fault_page_tables = self.diagnostic_fault_page_tables(far);
        if let Some((ttbr, descriptors)) = fault_page_tables {
            carrick_observability::probes::pt_fault_walk(
                far,
                descriptors[0],
                descriptors[1],
                descriptors[2],
                descriptors[3],
            );
            carrick_observability::probes::pt_fault_ttbr(far, ttbr);
        }
        let vm = &mut self.vm;
        let vcpu = &mut self.vcpu;
        let process_asid = self.process_asid;
        let carrier_root = vm.carrier_maintenance_root().ok();
        let mut flush = || Self::run_stage1_maintenance_on(vcpu, process_asid, carrier_root);
        let ttbr0 = fault_page_tables.map_or(0, |(ttbr, _)| ttbr);
        let resolution = vm.resolve_frame_cow_fault(syndrome, far, ttbr0, &mut flush)?;
        if matches!(resolution, carrick_hal::CowFaultResolution::Resolved { .. }) {
            vm.refresh_vcpu_after_frame_cow(vcpu)?;
            self.last_fault_esr = 0;
        }
        Ok(resolution)
    }

    fn begin_process_inventory(
        &mut self,
        reservation: carrick_hal::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        self.vm.begin_process_inventory(reservation)
    }

    fn cancel_process_inventory(&mut self) -> bool {
        self.vm.cancel_process_inventory()
    }

    fn take_process_inventory(&mut self) -> Option<carrick_hal::FrameInventoryCommit<()>> {
        self.vm.take_process_inventory()
    }

    fn begin_retirement_inventory(
        &mut self,
        reservation: carrick_hal::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        self.vm.begin_retirement_inventory(reservation)
    }

    fn take_retirement_inventory(&mut self) -> Option<carrick_hal::FrameInventoryCommit<()>> {
        self.vm.take_retirement_inventory()
    }

    fn apply_exec_inventory(
        &mut self,
        replacement_mm: u64,
        apply: &mut dyn FnMut(
            carrick_hal::FrameInventoryCommit<()>,
        )
            -> Result<carrick_hal::FrameInventoryApplyReceipt, TrapError>,
    ) -> Result<bool, TrapError> {
        self.vm.apply_exec_inventory(replacement_mm, apply)
    }

    fn activate_exec_inventory(&mut self) -> Result<(), TrapError> {
        self.vm.activate_exec_inventory()
    }

    type Arch = carrick_hal::Aarch64GuestArch;
    type KickHandle = V::KickHandle;
    type SiblingSpec = Aarch64SiblingSpec<V>;
    type ProcessSpec = Aarch64ProcessSpec<V>;

    fn diagnostic_wait_registers(&self) -> Option<carrick_hal::GuestWaitRegisters> {
        let live_pc = self.vcpu.get_reg(Reg::Pc).ok()?;
        let resume_pc = diagnostic_resume_pc(self.pending_resume_pc, live_pc);
        let pc = if self.process_asid.is_some() && self.pending_resume_pc.is_some() {
            let start = resume_pc.checked_sub(4)?;
            let mut island_words = [0_u8; 8];
            self.read_into(start, &mut island_words).ok()?;
            let svc = u32::from_le_bytes(island_words[..4].try_into().ok()?);
            let return_branch = u32::from_le_bytes(island_words[4..].try_into().ok()?);
            decode_hvpatch_island_origin(resume_pc, svc, return_branch).unwrap_or(resume_pc)
        } else {
            resume_pc
        };
        Some(carrick_hal::GuestWaitRegisters {
            pc,
            sp: self.vcpu.get_reg(Reg::Sp).ok()?,
            lr: self.vcpu.get_reg(Reg::X(30)).ok()?,
        })
    }

    fn aarch64_core_registers(
        &self,
    ) -> Result<Option<carrick_hal::Aarch64CoreRegisters>, TrapError> {
        require_core_fpsimd_authority(self.vm.fpsimd_enabled())?;
        let snapshot = self.vcpu.snapshot()?;
        let (resume_pc, resume_pstate) = core_resume_pair(self.pending_resume_pc, &snapshot);
        Ok(Some(carrick_hal::Aarch64CoreRegisters {
            gprs: snapshot.gprs,
            sp_el0: snapshot.sp_el0,
            resume_pc,
            resume_pstate,
            pc: snapshot.pc,
            pstate: snapshot.pstate,
            elr_el1: snapshot.elr_el1,
            spsr_el1: snapshot.spsr_el1,
            tpidr_el0: snapshot.tpidr_el0,
            vregs: snapshot.vregs,
            fpsr: snapshot.fpsr,
            fpcr: snapshot.fpcr,
        }))
    }

    fn prepare_core_snapshot(&mut self) -> Result<(), TrapError> {
        if self.page_tables.is_none() {
            // Persistent exec intentionally defers the software observer until
            // the first edit. Core capture needs a read-only live walk even if
            // this process never called mmap/mprotect after exec. The no-op
            // edit initializes from TTBR backing, writes nothing, and performs
            // no TLBI.
            self.pt_edit(|_| Ok(PageTableApplyOutcome::default()))
                .map_err(|error| {
                    TrapError::Hypervisor(format!(
                        "load live page tables for core snapshot: {error}"
                    ))
                })?;
        }
        Ok(())
    }

    fn read_core_bytes(
        &self,
        address: u64,
        length: usize,
    ) -> Result<Vec<u8>, carrick_guest_mem::MemoryError> {
        // `capture_and_publish_core` has already joined this range to a
        // quiesced, readable Linux VMA. Use the backing-only path so the
        // syscall EFAULT metadata for the larger hidden heap reservation does
        // not reject its live `[heap_base, brk)` prefix.
        <Self as GuestMemory>::read_bytes_raw(self, address, length)
    }

    fn diagnostic_fault_page_tables(&self, far: u64) -> Option<(u64, [u64; 4])> {
        const TTBR_ROOT_MASK: u64 = (1_u64 << 48) - 1;
        let ttbr = self.vcpu.get_sys_reg(SysReg::Ttbr0).ok()?;
        let root = ttbr & TTBR_ROOT_MASK;
        let size = carrick_mem::memory::LINUX_PAGE_TABLES_SIZE as usize;
        // Walk the live backing in place. This runs on EVERY frame-COW fault
        // (`resolve_frame_cow_fault`), and reading the region through
        // `read_gpa` allocated and memcpy'd all 1.75 MiB of it to extract four
        // descriptors — measured at ~6 COW faults per guest fork+wait round
        // trip, so ~10 MiB of copying plus an mmap/munmap/madvise triple per
        // cycle for a diagnostic probe. It still reads the HARDWARE-visible
        // bytes rather than the software model, which is the whole point of
        // this walk.
        let host = self.vm.host_ptr(root, size)?;
        // SAFETY: `host_ptr` resolved a complete live mapping of `size` bytes
        // whose byte offset 0 is the PA `root`, and this frame holds the engine
        // borrow for the duration of the walk.
        Some((ttbr, unsafe {
            carrick_mem::page_table::walk_descriptors_host(host.cast_const(), size, root, far)
        }))
    }

    fn resolve_stale_stage1_fault(
        &mut self,
        far: u64,
        access: carrick_mem::page_table::LeafAccess,
    ) -> Result<bool, TrapError> {
        // Read the HARDWARE-visible leaf, never the software model: the model
        // is exactly what stopped naming this page when the sibling committed
        // it, and only the live descriptor says whether a retry can succeed.
        let Some((_ttbr, walk)) = self.diagnostic_fault_page_tables(far) else {
            return Ok(false);
        };
        let leaf = carrick_mem::page_table::terminal_descriptor(walk);
        if !carrick_mem::page_table::terminal_descriptor_permits_el0(leaf, access) {
            return Ok(false);
        }
        const STALE_STAGE1_RETRY_BOUND: u32 = 4096;
        self.stale_stage1_retry = match self.stale_stage1_retry {
            (va, retries) if va == far => (va, retries.saturating_add(1)),
            _ => (far, 1),
        };
        if self.stale_stage1_retry.1 > STALE_STAGE1_RETRY_BOUND {
            return Err(TrapError::Hypervisor(format!(
                "stale stage-1 fault at {far:#x} retried {STALE_STAGE1_RETRY_BOUND} times: the live walk {walk:x?} permits {access:?} but the vCPU keeps faulting (a stage-1 leaf naming a frame stage-2 no longer maps)"
            )));
        }
        self.run_stage1_maintenance()?;
        Ok(true)
    }

    fn set_persistent_vm_lifecycle(&mut self, enabled: bool) {
        self.vm.set_persistent_vm_lifecycle(enabled);
    }

    fn configure_process_asid(&mut self, asid: u16) -> Result<(), TrapError> {
        if asid == 0 {
            return Err(TrapError::Hypervisor(
                "hvpatch process ASID zero is reserved".to_owned(),
            ));
        }
        const TCR_AS: u64 = 1 << 36;
        const TTBR_ROOT_MASK: u64 = (1_u64 << 48) - 1;
        let reserved_len = usize::try_from(
            carrick_mem::memory::LINUX_HVPATCH_ROOT_SLOT_ARENA_SIZE
                + carrick_mem::memory::LINUX_HVPATCH_GLOBAL_FRAME_SIZE,
        )
        .map_err(|_| TrapError::Hypervisor("hvpatch reserved IPA size overflow".to_owned()))?;
        // Root bring-up starts from the generic identity tables and must carve
        // these apertures live. Exec replacement receives a global-frame image with
        // the same deterministic invalidations already baked into the cached
        // table bytes, so repeating the edit would rebuild/copy the complete
        // software manager solely to rediscover two no-ops.
        if self.process_asid.is_none() {
            if self.vm.sparse_mmap_arena_enabled() {
                self.pt_edit_and_flush(|manager| {
                    manager.set_prot_none(
                        carrick_mem::memory::LINUX_MMAP_BASE,
                        carrick_mem::memory::mmap_arena_size() as usize,
                    )
                })
                .map_err(|error| {
                    TrapError::Hypervisor(format!(
                        "reserve sparse HVPatch root mmap arena: {error}"
                    ))
                })?;
                self.vm.retire_initial_mmap_arena()?;
            }
            self.pt_edit_and_flush(|editor| editor.reserve_hvpatch_process_apertures())
                .map_err(|error| {
                    TrapError::Hypervisor(format!(
                        "reserve hvpatch root-slot/global-frame apertures: {error}"
                    ))
                })?;
        }
        self.set_unmapped(
            carrick_mem::memory::LINUX_HVPATCH_ROOT_SLOT_BASE,
            reserved_len,
            true,
        );
        let tcr = self.vcpu.get_sys_reg(SysReg::Tcr)?;
        let root = self.vcpu.get_sys_reg(SysReg::Ttbr0)? & TTBR_ROOT_MASK;
        let ttbr = (u64::from(asid) << 48) | root;
        self.vcpu.set_sys_reg(SysReg::Tcr, tcr | TCR_AS)?;
        self.vcpu.set_sys_reg(SysReg::Ttbr0, ttbr)?;
        self.vcpu.set_sys_reg(SysReg::Ttbr1, ttbr)?;
        self.process_asid = Some(asid);
        Ok(())
    }

    fn prepare_exec_address_space(
        &mut self,
        root_slot_base: u64,
        root_slot_size: u64,
        asid: u16,
    ) -> Result<(), TrapError> {
        if asid == 0 {
            return Err(TrapError::Hypervisor(
                "HVPatch exec ASID zero is reserved".to_owned(),
            ));
        }
        self.vm
            .prepare_exec_address_space(root_slot_base, root_slot_size, asid)?;
        self.process_asid = Some(asid);
        Ok(())
    }

    fn mark_exec_predecessor_shared(&mut self, shared: bool) {
        self.exec_predecessor_shared = Some(shared);
        self.vm.mark_exec_predecessor_shared(shared);
    }

    fn complete_task_load_barrier(&mut self) -> Result<(), TrapError> {
        Self::complete_task_load_on_vcpu(&mut self.vcpu).map_err(|error| {
            // A barrier failure is a stage-1 story: append the live TTBR and
            // the four walked descriptors for the barrier base so the death
            // carries its own page-table forensics (the vforkexecthread hunt
            // needed exactly this to see WHICH level of the shared old root
            // went invalid under a sibling exec).
            match self
                .diagnostic_fault_page_tables(carrick_mem::memory::LINUX_EL1_LOAD_BARRIER_BASE)
            {
                Some((ttbr, descriptors)) => TrapError::Hypervisor(format!(
                    "{error} [barrier walk: ttbr0={ttbr:#x} l0={:#x} l1={:#x} l2={:#x} l3={:#x}]",
                    descriptors[0], descriptors[1], descriptors[2], descriptors[3]
                )),
                None => error,
            }
        })
    }

    fn supports_in_process_fork(&self) -> bool {
        self.process_asid.is_some()
    }

    fn retire_in_process_address_space(&mut self) -> Result<(), TrapError> {
        self.run_el1_maintenance().map_err(|error| {
            TrapError::Hypervisor(format!(
                "hvpatch process-exit ASID maintenance failed: {error}"
            ))
        })?;
        self.vm.process_exit_cleanup().map_err(|error| {
            TrapError::Hypervisor(format!(
                "hvpatch process-exit stage-2 retirement failed: {error}"
            ))
        })?;
        self.vm.destroy_vcpu_on_thread_exit(&mut self.vcpu);
        Ok(())
    }

    fn retire_task_address_space(&mut self) -> Result<(), TrapError> {
        self.vm.process_exit_cleanup()
    }

    fn build_process_spec(
        &mut self,
        mut request: ProcessForkRequest,
    ) -> Result<Self::ProcessSpec, TrapError> {
        use carrick_observability::probes::{
            HvpatchForkProcessSpecStage, HvpatchForkProcessSpecStagePhase,
        };

        if self.pending_process_fork.is_some() {
            return Err(TrapError::Hypervisor(
                "overlapping in-process parent fork transaction".to_owned(),
            ));
        }
        let total_started = std::time::Instant::now();
        let child_tid_raw = request.child_tid.raw();
        let forking_tid_raw = request.forking_tid.raw();
        let emit_stage = move |phase: HvpatchForkProcessSpecStagePhase,
                               started: std::time::Instant,
                               units: u64| {
            let elapsed_ns = started.elapsed().as_nanos().min(u128::from(u64::MAX)) as u64;
            carrick_observability::probes::hvpatch_fork_process_spec_stage(
                HvpatchForkProcessSpecStage::new(
                    phase,
                    child_tid_raw,
                    forking_tid_raw,
                    elapsed_ns,
                    units,
                ),
            );
        };

        // Persistent-VM exec leaves the software editor absent until it is
        // needed. A process fork needs a complete manager immediately so it can
        // rebase a private child copy; initialize from the live backing here if
        // no mmap/mprotect edit has already done so. The no-op edit publishes
        // nothing and performs no TLBI.
        let stage_started = std::time::Instant::now();
        let page_tables_absent = self.page_tables.is_none();
        if page_tables_absent {
            self.pt_edit(|_| Ok(PageTableApplyOutcome::default()))
                .map_err(|error| {
                    TrapError::Hypervisor(format!(
                        "load hvpatch parent page tables for process fork: {error}"
                    ))
                })?;
        }
        emit_stage(
            HvpatchForkProcessSpecStagePhase::ParentPageTablesLoad,
            stage_started,
            u64::from(page_tables_absent),
        );

        // Describe the private writable graph now, but do not mutate the live
        // parent yet. Every fallible child-preparation step below operates on an
        // offline clone. The parent arm is the final publication transaction.
        // CLONE_VM keeps one Linux mm. The HVPatch execution adapter still
        // gives the child a private stage-1 root and per-process EL1 state, but
        // its user mappings must retain the same writable frames rather than
        // entering the ordinary fork-COW protocol.
        let cow_ranges = if request.shares_mm() {
            Vec::new()
        } else {
            self.vm.fork_cow_ranges()
        };

        let stage_started = std::time::Instant::now();
        let parent = self.vcpu.snapshot()?;
        // A process child, like a thread sibling, starts at the instruction
        // after the trapped clone in EL0. The raw parent snapshot is currently
        // parked in the EL1 syscall vector; using its live PC/PSTATE would send
        // a brand-new vCPU back into that vector as EL0 code and spin forever.
        let mut snapshot = seed_sibling_snapshot(&parent, request.entry);
        snapshot.ttbr0 = request.child_ttbr0;
        snapshot.ttbr1 = request.child_ttbr0;
        let child_asid = (request.child_ttbr0 >> 48) as u16;
        if child_asid == 0 {
            return Err(TrapError::Hypervisor(
                "in-process child ASID zero is reserved".to_owned(),
            ));
        }
        emit_stage(
            HvpatchForkProcessSpecStagePhase::VcpuSnapshot,
            stage_started,
            0,
        );

        let stage_started = std::time::Instant::now();
        // The child's own editable graph, cloned from the parent into a
        // recycled image buffer whenever the process tree's pool holds one
        // (`kernel.fork.stage1-image`): a fork storm must not allocate and
        // free a 1.75 MiB arena set per child. The parent's rollback
        // protection is the bounded undo journal, not a cloned pre-image.
        let (mut page_tables, fresh_image) =
            self.page_tables.snapshot_image_recycled().ok_or_else(|| {
                TrapError::Hypervisor("hvpatch parent page tables are absent".to_owned())
            })?;
        self.last_fork_image_allocations = u64::from(fresh_image);
        page_tables.declare_offline_private_image();
        let parent_armed_snapshot = self.vm.frame_cow_arm_snapshot();
        let unarmed_ranges: Vec<crate::vmm::ForkCowRange> = if parent_armed_snapshot.is_empty() {
            cow_ranges.clone()
        } else {
            cow_ranges
                .iter()
                .copied()
                .filter(|range| {
                    !parent_armed_snapshot
                        .binary_search_by_key(&(range.va, range.len), |r| (r.va, r.len))
                        .is_ok_and(|idx| {
                            let existing = &parent_armed_snapshot[idx];
                            existing.kernel_only == range.kernel_only
                                && existing.executable == range.executable
                        })
                })
                .collect()
        };
        emit_stage(
            HvpatchForkProcessSpecStagePhase::ParentPageTablesClone,
            stage_started,
            page_tables.copied_bytes(),
        );

        let mut child_source = request.table_arena_source.take();
        let stage_started = std::time::Instant::now();
        // Prepare the child's independent stage-1 graph read-only while it is
        // still offline. A failure here cannot affect the parent. This closes
        // the interval in which the old implementation had already armed the
        // surviving parent before snapshot/clone/rebase/builder could fail.
        // Ranges already armed in parent are already read-only in the cloned graph.
        for range in &unarmed_ranges {
            if range.kernel_only {
                page_tables
                    .set_kernel_readonly(
                        range.va,
                        range.len,
                        range.executable,
                        child_source.as_deref_mut(),
                    )
                    .map_err(|error| {
                        TrapError::Hypervisor(format!(
                            "prepare hvpatch child kernel fork leaves read-only: {error:?}"
                        ))
                    })?;
            } else {
                page_tables
                    .set_fork_readonly(range.va, range.len, child_source.as_deref_mut())
                    .map_err(|error| {
                        TrapError::Hypervisor(format!(
                            "prepare hvpatch child private fork leaves read-only: {error:?}"
                        ))
                    })?;
            }
        }

        emit_stage(
            HvpatchForkProcessSpecStagePhase::CowRangeProjection,
            stage_started,
            unarmed_ranges.len() as u64,
        );

        let stage_started = std::time::Instant::now();
        let child_root = request.child_ttbr0 & ((1_u64 << 48) - 1);
        page_tables
            .rebase(child_root, child_source.as_deref_mut())
            .map_err(|error| {
                TrapError::Hypervisor(format!("rebase child page tables: {error:?}"))
            })?;
        emit_stage(
            HvpatchForkProcessSpecStagePhase::PageTablesRebase,
            stage_started,
            carrick_mem::memory::LINUX_PAGE_TABLES_SIZE,
        );
        let builder = self
            .vm
            .build_process_builder(request, &mut page_tables, &cow_ranges)?;
        let child_authority = self.page_tables.child_with_manager(page_tables);
        if let Some(source) = child_source {
            child_authority.install_source(source).map_err(|error| {
                TrapError::Hypervisor(format!("set child arena source: {error:?}"))
            })?;
        }
        let stage_started = std::time::Instant::now();
        let protections = Arc::new(MemoryProtections::from_snapshot(
            self.protections.snapshot_all(),
        ));
        if fork_debug_va().is_some() {
            let wrapper = self.protections.snapshot_all();
            let backend = self.vm.protections().map(|p| p.snapshot_all());
            eprintln!(
                "[FUTEXDBG] fork spec: wrapper protections Arc={:p} shared={:?}; backend \
                 protections shared={:?}; same instance={}",
                Arc::as_ptr(&self.protections),
                wrapper.mutable_shared_backing,
                backend.as_ref().map(|s| &s.mutable_shared_backing),
                self.vm.protections().is_some_and(|p| {
                    std::ptr::eq(
                        p as *const MemoryProtections,
                        Arc::as_ptr(&self.protections),
                    )
                }),
            );
        }
        emit_stage(
            HvpatchForkProcessSpecStagePhase::WrapperProtections,
            stage_started,
            0,
        );
        let spec = Aarch64ProcessSpec {
            builder,
            snapshot,
            page_tables: child_authority,
            protections,
            process_asid: child_asid,
        };

        if !cow_ranges.is_empty() {
            let stage_started = std::time::Instant::now();
            // Final publication transaction. All child allocation, mapping-plan,
            // ASID, snapshot, and wrapper work is complete. Open an undo journal
            // covering the parent's fork-COW arming and restore it (including a
            // scoped TLBI) if either the edit or its fail-closed descriptor
            // authentication fails. Armed-range metadata is installed only after
            // publication succeeds, so every pre-commit error leaves both
            // authorities at their prior state.
            let publish_parent = (|| -> Result<(), TrapError> {
                if !unarmed_ranges.is_empty() {
                    const TTBR_ROOT_MASK: u64 = (1_u64 << 48) - 1;
                    let pt_base = self.vcpu.get_sys_reg(SysReg::Ttbr0).map_err(|error| {
                        TrapError::Hypervisor(format!("read TTBR0_EL1: {error}"))
                    })? & TTBR_ROOT_MASK;
                    let size = carrick_mem::memory::LINUX_PAGE_TABLES_SIZE as usize;
                    let host = self.vm.host_ptr(pt_base, size).ok_or_else(|| {
                        TrapError::Hypervisor("page-table region not mapped".to_owned())
                    })?;

                    self.pt_edit_and_flush(|manager| {
                        manager.begin_undo();
                        let mut outcome = PageTableApplyOutcome::default();
                        for range in &unarmed_ranges {
                            outcome |= if range.kernel_only {
                                manager.set_kernel_readonly(
                                    range.va,
                                    range.len,
                                    range.executable,
                                )?
                            } else {
                                manager.set_fork_readonly(range.va, range.len)?
                            };
                        }
                        Ok(outcome)
                    })
                    .map_err(|error| {
                        TrapError::Hypervisor(format!(
                            "arm hvpatch parent private fork leaves read-only: {error}"
                        ))
                    })?;

                    // Durable pre-write structural receipt: one live-backing walk
                    // per newly armed semantic range. bit4 distinguishes fork-COW arming
                    // from alias publication and post-COW authentication.
                    for range in &unarmed_ranges {
                        let walk = self.live_pt_debug_walk_with_host(range.va, pt_base, host).map_err(|error| {
                            TrapError::Hypervisor(format!(
                                "authenticate hvpatch parent fork-COW arm at VA 0x{:x}: {error}",
                                range.va
                            ))
                        })?;
                        carrick_observability::probes::pt_alias_walk(range.va, walk, 1 << 4);
                        let leaf = carrick_mem::page_table::terminal_descriptor(walk);
                        const VALID: u64 = 1;
                        const NON_GLOBAL: u64 = 1 << 11;
                        const AP_MASK: u64 = 0b11 << 6;
                        const PA_MASK_4KIB: u64 = 0x0000_FFFF_FFFF_F000;
                        const AP_USER_RO: u64 = 0b11 << 6;
                        const AP_PRIV_RO: u64 = 0b10 << 6;
                        let expected_ipa = self
                            .page_tables
                            .with_manager(|manager| manager.translate(range.va))
                            .flatten();
                        if let Some(expected_ipa) = expected_ipa {
                            if leaf & VALID == 0 {
                                return Err(TrapError::Hypervisor(format!(
                                    "HVPatch parent fork-COW arm live model has an invalid hardware leaf at VA 0x{:x}",
                                    range.va
                                )));
                            }
                            let expected_ap = if range.kernel_only {
                                AP_PRIV_RO
                            } else {
                                AP_USER_RO
                            };
                            if leaf & PA_MASK_4KIB != expected_ipa & PA_MASK_4KIB
                                || leaf & AP_MASK != expected_ap
                                || (!range.kernel_only && leaf & NON_GLOBAL == 0)
                            {
                                return Err(TrapError::Hypervisor(format!(
                                    "HVPatch parent fork-COW arm authentication failed at VA 0x{:x}: leaf=0x{:x} expected_ipa=0x{expected_ipa:x} expected_ap=0x{expected_ap:x}",
                                    range.va, leaf
                                )));
                            }
                            carrick_observability::probes::pt_alias_receipt(
                                range.va,
                                leaf,
                                expected_ipa,
                                expected_ap,
                                0,
                            );
                        } else if leaf & VALID != 0 {
                            return Err(TrapError::Hypervisor(format!(
                                "HVPatch parent fork-COW arm hardware leaf is live without a software translation at VA 0x{:x}",
                                range.va
                            )));
                        }
                    }
                }
                Ok(())
            })();

            if let Err(error) = publish_parent {
                if let Err(rollback_error) = self.pt_rollback_undo_and_flush() {
                    carrick_fatal!(
                        "aarch64::fork_cow",
                        "failed page table rollback and TLBI invalidation during parent fork COW setup after error {error}: {rollback_error}"
                    );
                }
                self.vm
                    .restore_frame_cow_arm_snapshot(parent_armed_snapshot);
                return Err(error);
            }
            self.vm.arm_frame_cow_ranges(&unarmed_ranges);
            self.pending_process_fork = Some(ParentForkCowRollback {
                armed_ranges: parent_armed_snapshot,
            });
            emit_stage(
                HvpatchForkProcessSpecStagePhase::ParentCowPublication,
                stage_started,
                unarmed_ranges.len() as u64,
            );
        }
        emit_stage(HvpatchForkProcessSpecStagePhase::Total, total_started, 0);
        Ok(spec)
    }

    fn materialize_process(spec: Self::ProcessSpec) -> Result<Self, TrapError> {
        let (mut vm, mut vcpu) = V::materialize_process(spec.builder)?;
        if let Err(error) = vcpu.restore_thread_start(&spec.snapshot) {
            vm.abort_process_materialization(&mut vcpu)
                .unwrap_or_else(|rollback_error| {
                    carrick_fatal!(
                        "aarch64::process_materialize",
                        "failed to abort and roll back process materialization after thread register restore failure {error}: {rollback_error}"
                    );
                });
            return Err(error);
        }
        if let Err(error) = vm.commit_process_materialization() {
            vm.abort_process_materialization(&mut vcpu)
                .unwrap_or_else(|rollback_error| {
                    carrick_fatal!(
                        "aarch64::process_materialize",
                        "failed to abort and roll back process materialization after commit failure {error}: {rollback_error}"
                    );
                });
            return Err(error);
        }
        // A fresh process: its source was installed on the child tables by
        // `build_process_spec`, so no deferral is inherited from the parent.
        let mut engine = Self::from_parts_with_shared(vm, vcpu, spec.page_tables, spec.protections);
        engine.process_asid = Some(spec.process_asid);
        Ok(engine)
    }

    fn commit_process_fork(&mut self) -> Result<(), TrapError> {
        let _ = self.pending_process_fork.take();
        self.page_tables.commit_undo();
        Ok(())
    }

    fn rollback_process_fork(&mut self) -> Result<(), TrapError> {
        let Some(rollback) = self.pending_process_fork.take() else {
            return Ok(());
        };
        self.pt_rollback_undo_and_flush().map_err(|error| {
            TrapError::Hypervisor(format!(
                "restore parent after failed in-process fork: {error}"
            ))
        })?;
        self.vm
            .restore_frame_cow_arm_snapshot(rollback.armed_ranges);
        Ok(())
    }

    fn kick_handle(&self) -> Self::KickHandle {
        self.vm.kick_handle()
    }

    fn wait_for_vcpu_slot() {
        V::wait_for_vcpu_slot();
    }

    fn vcpu_budget() -> usize {
        V::vcpu_budget()
    }

    fn reclaims(&self) -> bool {
        self.vm.reclaims()
    }

    fn reclaim_refreshes_kicker(&self) -> bool {
        self.vm.reclaim_refreshes_kicker()
    }

    fn save_guest_state(&mut self) -> Result<GuestCpuState, TrapError> {
        require_migratable_fpsimd_authority(self.vm.fpsimd_enabled())?;
        let continuation = self.vm.task_continuation(&self.vcpu)?;
        let snapshot = self
            .vm
            .save_guest_state(&mut self.vcpu)
            .map_err(|error| TrapError::Hypervisor(format!("save AArch64 guest state: {error}")))?;
        Ok(GuestCpuState::from_aarch64_v1(
            aarch64_task_state_from_snapshot(
                &snapshot,
                self.pending_resume_pc,
                self.last_syscall_nr,
                self.last_syscall_orig_x0,
                self.last_fault_esr,
                self.last_exit_class,
                self.is_forked_child,
                continuation,
                self.mm_generation,
                self.asid_generation,
            )?,
        ))
    }

    fn save_initial_runner_state(&mut self) -> Result<GuestCpuState, TrapError> {
        require_migratable_fpsimd_authority(self.vm.fpsimd_enabled())?;
        if self.vm.task_continuation(&self.vcpu)?.is_some() {
            return Err(TrapError::Hypervisor(
                "initial AArch64 runner unexpectedly owns a syscall continuation".to_owned(),
            ));
        }
        let snapshot = self
            .vm
            .save_initial_runner_state(&mut self.vcpu)
            .map_err(|error| {
                TrapError::Hypervisor(format!("save initial AArch64 runner state: {error}"))
            })?;
        Ok(GuestCpuState::from_aarch64_v1(
            aarch64_task_state_from_snapshot(
                &snapshot,
                self.pending_resume_pc,
                self.last_syscall_nr,
                self.last_syscall_orig_x0,
                self.last_fault_esr,
                self.last_exit_class,
                self.is_forked_child,
                None,
                self.mm_generation,
                self.asid_generation,
            )?,
        ))
    }

    fn rebind_initial_runner_state(
        &mut self,
        _slot: SlotId,
        state: &GuestCpuState,
    ) -> Result<(), TrapError> {
        let GuestCpuState::Aarch64V1(state) = state else {
            return Err(TrapError::Hypervisor(
                "AArch64 initial restore rejected non-AArch64 V1 state".to_owned(),
            ));
        };
        self.validate_task_metadata(state)?;
        self.vm.rebind_initial_runner_state(state, &mut self.vcpu)?;
        self.apply_task_metadata(state);
        Ok(())
    }

    fn save_shared_wait_state(&mut self) -> Result<GuestCpuState, TrapError> {
        require_migratable_fpsimd_authority(self.vm.fpsimd_enabled())?;
        let continuation = self.vm.task_continuation(&self.vcpu)?;
        let snapshot = self
            .vm
            .save_shared_wait_state(&mut self.vcpu)
            .map_err(|error| {
                TrapError::Hypervisor(format!("save shared-wait AArch64 guest state: {error}"))
            })?;
        Ok(GuestCpuState::from_aarch64_v1(
            aarch64_task_state_from_snapshot(
                &snapshot,
                self.pending_resume_pc,
                self.last_syscall_nr,
                self.last_syscall_orig_x0,
                self.last_fault_esr,
                self.last_exit_class,
                self.is_forked_child,
                continuation,
                self.mm_generation,
                self.asid_generation,
            )?,
        ))
    }

    fn rebind_to_slot(&mut self, slot: SlotId, state: &GuestCpuState) -> Result<(), TrapError> {
        let GuestCpuState::Aarch64V1(state) = state else {
            return Err(TrapError::Hypervisor(format!(
                "AArch64 restore rejected {:?} snapshot version {}",
                state.guest_abi(),
                state.version()
            )));
        };
        self.validate_task_metadata(state)?;
        self.vm.rebind_to_slot(slot, state, &mut self.vcpu)?;
        self.apply_task_metadata(state);
        Ok(())
    }

    fn rebind_shared_wait_state(
        &mut self,
        slot: SlotId,
        state: &GuestCpuState,
    ) -> Result<(), TrapError> {
        let GuestCpuState::Aarch64V1(state) = state else {
            return Err(TrapError::Hypervisor(
                "AArch64 shared-wait restore rejected non-AArch64 V1 state".to_owned(),
            ));
        };
        self.validate_task_metadata(state)?;
        self.vm
            .rebind_shared_wait_state(slot, state, &mut self.vcpu)?;
        self.apply_task_metadata(state);
        Ok(())
    }

    fn rebind_shared_wait_state_mt(
        &mut self,
        slot: SlotId,
        state: &GuestCpuState,
    ) -> Result<(), TrapError> {
        let GuestCpuState::Aarch64V1(state) = state else {
            return Err(TrapError::Hypervisor(
                "AArch64 MT shared-wait restore rejected non-AArch64 V1 state".to_owned(),
            ));
        };
        self.validate_task_metadata(state)?;
        self.vm
            .rebind_shared_wait_state_mt(slot, state, &mut self.vcpu)?;
        self.apply_task_metadata(state);
        Ok(())
    }

    fn release_vm_after_reclaim_park(&mut self) -> Result<bool, TrapError> {
        self.vm.release_vm_after_reclaim_park()
    }

    fn build_sibling_spec(&self, entry: GuestEntryRegs) -> Result<Self::SiblingSpec, TrapError> {
        // Snapshot the parent vCPU (taken while it is suspended at the trapped
        // `clone` syscall — atomic, race-free), then seed it for the new thread
        // (x0=0, sp_el0=stack, tpidr_el0=tls, pc=parent.elr_el1 = post-svc).
        let parent = self.vcpu.snapshot()?;
        let snapshot = seed_sibling_snapshot(&parent, entry);
        // HVF needs the parent vCPU to clone its VM handle + capture its mapping
        // descriptors into the builder; KVM ignores it. The seeded SNAPSHOT (above)
        // is what the new vCPU is restored from — both backends share that.
        let builder = self.vm.build_sibling_builder(&self.vcpu, entry)?;
        Ok(Aarch64SiblingSpec {
            builder,
            snapshot,
            // Share the SAME page-table authority: the sibling edits the
            // SAME backing through the SAME manager.
            page_tables: self.page_tables.clone(),
            // Share the SAME PROT_NONE bookkeeping (engine-side mirror; the backing
            // share lives in the backend `GuestRam`).
            protections: Arc::clone(&self.protections),
            process_asid: self.process_asid,
        })
    }

    fn materialize_sibling(spec: Self::SiblingSpec) -> Result<Self, TrapError> {
        let (vm, mut vcpu) = V::materialize_sibling(spec.builder)?;
        // Restore the seeded register file onto the FRESHLY-CREATED sibling vCPU via
        // `restore_thread_start`: KVM does a plain restore (the PC is already the
        // post-svc address — no sentinel-store replay to skip); HVF routes through
        // its EL0-trampoline thread-start so a brand-new vCPU eret's into EL0 at the
        // post-clone instruction.
        vcpu.restore_thread_start(&spec.snapshot)?;
        spec.page_tables.increment_engine_count();
        // SHARE the spawning thread's page-table authority + PROT_NONE set.
        let mut engine = Self::from_parts_with_shared(vm, vcpu, spec.page_tables, spec.protections);
        engine.process_asid = spec.process_asid;
        Ok(engine)
    }

    fn program_counter(&self) -> Result<u64, TrapError> {
        self.vcpu.get_reg(Reg::Pc)
    }

    fn set_guest_sp_el0(&self, sp: u64) -> Result<(), TrapError> {
        self.vm.set_guest_sp(&self.vcpu, sp)
    }

    fn set_guest_thread_id(&self, tid: u64) -> Result<(), TrapError> {
        // Stamp the per-thread scratch sysreg the EL1-vector `gettid` fast path
        // reads, so `gettid(2)` is serviced at EL1 without a host trap. Genuinely
        // per-VMM (see `Aarch64Vcpu::stamp_guest_thread_id`): HVF stamps TPIDR_EL1;
        // KVM no-ops (TPIDR_EL1 is its live-x9 stash) and traps `gettid` to the host.
        self.vcpu.stamp_guest_thread_id(tid)
    }

    fn fresh_fork_kicker(&self) -> Arc<dyn carrick_hal::VcpuRegistry> {
        self.vm.fresh_fork_kicker()
    }

    fn destroy_vcpu_on_thread_exit(&mut self) {
        // A guest thread exiting frees an HVF concurrent-vCPU slot (HVF). KVM no-op.
        self.vm.destroy_vcpu_on_thread_exit(&mut self.vcpu);
    }
}

#[inline]
fn diagnostic_resume_pc(pending_resume_pc: Option<u64>, live_pc: u64) -> u64 {
    pending_resume_pc.unwrap_or(live_pc)
}

/// Select the Linux-visible EL0 resume pair for a core note.
///
/// A running vCPU force-exited by a cross-thread kick is stopped directly in
/// EL0: its live PC/PSTATE are current and ELR/SPSR still describe the last
/// exception (often the pthread entry trampoline). A thread blocked while its
/// syscall is dispatched is parked in EL1, so the saved ELR/SPSR pair is the
/// current Linux user state instead. The pending-syscall marker normally names
/// that state, but a fatal signal can claim the task after dispatch clears the
/// marker and before the EL1 vector returns to EL0. PSTATE.M is architectural
/// authority for that window: any non-EL0 current exception level must publish
/// the saved ELR/SPSR pair, never Carrick's internal vector PC in a Linux core.
/// The runtime separately binds a synchronous fatal owner's raw ELR/SPSR to its
/// exact `FatalSignalRecord`.
fn core_resume_pair(pending_resume_pc: Option<u64>, snapshot: &Aarch64VcpuSnapshot) -> (u64, u64) {
    if pending_resume_pc.is_some()
        || !carrick_hal::aarch64::ExecLevel::from_pstate(snapshot.pstate).is_guest()
    {
        (
            pending_resume_pc.unwrap_or(snapshot.elr_el1),
            snapshot.spsr_el1,
        )
    } else {
        (snapshot.pc, snapshot.pstate)
    }
}

/// Cached `CARRICK_FORK_DEBUG_VA` (parsed once). `std::env::var` serializes on
/// std's process-wide environment lock; the shared-futex classification gate
/// runs on EVERY non-private futex op, so a per-call env read measurably
/// contended hot paths under a 1000-process storm.
fn fork_debug_va() -> Option<u64> {
    static CELL: std::sync::OnceLock<Option<u64>> = std::sync::OnceLock::new();
    *CELL.get_or_init(|| {
        std::env::var("CARRICK_FORK_DEBUG_VA")
            .ok()
            .and_then(|raw| u64::from_str_radix(raw.trim_start_matches("0x"), 16).ok())
    })
}

fn shared_futex_backing_gpa(page_tables: &PageTableManager, guest_addr: u64) -> Option<Gpa> {
    page_tables.translate(guest_addr).map(Gpa)
}

fn require_core_fpsimd_authority(enabled: bool) -> Result<(), TrapError> {
    if enabled {
        Ok(())
    } else {
        Err(TrapError::Hypervisor(
            "complete AArch64 core registers require live FP/SIMD capture; CARRICK_NO_FPSIMD disables that authority"
                .to_owned(),
        ))
    }
}

fn require_migratable_fpsimd_authority(enabled: bool) -> Result<(), TrapError> {
    if enabled {
        Ok(())
    } else {
        Err(TrapError::Hypervisor(
            "complete AArch64 migratable state requires live FP/SIMD capture; CARRICK_NO_FPSIMD disables that authority"
                .to_owned(),
        ))
    }
}

/// Recover the original patched `svc #0` address from an HvPatch island. At a
/// host-dispatched syscall the pending resume PC addresses the island's return
/// branch (`svc` is the preceding word); the branch target is original-svc+4.
/// This keeps crash/wait symbols tied to guest code instead of generated stubs.
fn decode_hvpatch_island_origin(resume_pc: u64, svc: u32, return_branch: u32) -> Option<u64> {
    const SVC_ZERO: u32 = 0xd400_0001;
    const B_OPCODE: u32 = 0x1400_0000;
    const B_OPCODE_MASK: u32 = 0xfc00_0000;
    if svc != SVC_ZERO || return_branch & B_OPCODE_MASK != B_OPCODE {
        return None;
    }
    let imm26 = i64::from(return_branch & 0x03ff_ffff);
    let signed_imm26 = (imm26 << 38) >> 38;
    let target = i128::from(resume_pc).checked_add(i128::from(signed_imm26) * 4)?;
    let origin = target.checked_sub(4)?;
    u64::try_from(origin).ok()
}

/// `Aarch64EngineCore` is `Send` when the backend pair is: the VM/vCPU hold the
/// host VMM fds (Send) and raw window pointers valid in every thread.
//
// SAFETY: `V`/`V::Vcpu` carry only host VMM fds + raw window pointers that are
// valid in every thread of the process (threads share the address space). The
// engine is moved to its owning sibling/vCPU thread before use.
unsafe impl<V: Aarch64Vmm> Send for Aarch64EngineCore<V> {}

#[cfg(test)]
mod tests {
    use super::*;

    fn continuation() -> carrick_hal::threaded::Aarch64SyscallContinuationV1 {
        carrick_hal::threaded::Aarch64SyscallContinuationV1 {
            sequence: 0x101,
            state: 1,
            trap_kind: 2,
            response_action: 3,
            flags: 4,
            native_nr: 5,
            args: [6, 7, 8, 9, 10, 11],
            x8: 12,
            resume_pc: 13,
            spsr: 14,
            fp: 15,
            lr: 16,
            sp: 17,
            esr: 18,
            return_value: 19,
            resume_x16: 20,
            resume_x17: 21,
        }
    }

    fn sample() -> Aarch64VcpuSnapshot {
        let boot = carrick_hal::Aarch64GuestArch::bootstrap_sysregs();
        Aarch64VcpuSnapshot {
            gprs: std::array::from_fn(|index| 0x1000 + index as u64),
            pc: 0x2000,
            pstate: 0x3000,
            sp_el0: 0x4000,
            sp_el1: 0x5000,
            elr_el1: 0x6000,
            spsr_el1: 0x7000,
            ttbr0: 0x8000,
            ttbr1: 0x9000,
            tcr: 0xa000,
            sctlr: boot.sctlr_el1,
            mair: boot.mair_el1,
            vbar: carrick_mem::memory::LINUX_EL1_VECTORS_BASE,
            cpacr: boot.cpacr_el1,
            cntkctl_el1: 0x3,
            tpidr_el0: 0xb000,
            tpidrro_el0: 0xc000,
            tpidr_el1: 0xd000,
            contextidr_el1: 0xe000,
            actlr_el1: 0xf000,
            vregs: std::array::from_fn(|index| 0x1_0000_0000 + index as u128),
            fpsr: 0x11,
            fpcr: 0x22,
        }
    }

    /// A vCPU reads SCTLR_EL1 back with the architecture's RES1 bits set, and
    /// `SCTLR_EL1_BOOTSTRAP` deliberately lists only the bits carrick PROGRAMS.
    /// Demanding raw equality between the two rejects a perfectly neutral
    /// executor. Measured live at fork teardown on Apple HVF: the destination
    /// reported `0x3400d185`, which is exactly `SCTLR_EL1_BOOTSTRAP`
    /// (`0x0400d005`) OR the four RES1 bits ITD(7) and SED(8) — AArch32 at EL0
    /// not implemented — and nTLSMD(28) and LSMAOE(29) — FEAT_LSMAOC not
    /// implemented. That mismatch failed `cloneexithandled`,
    /// `clone3exithandled` and `sigchld` in the persistent executor pool's
    /// shutdown, after the guest itself had run correctly.
    #[test]
    fn a_hardware_readback_of_the_bootstrap_sctlr_is_still_neutral() {
        let source = sample();
        let readback = carrick_mem::arch_sysregs::SCTLR_EL1_BOOTSTRAP
            | carrick_mem::arch_sysregs::SCTLR_EL1_RES1;
        assert_eq!(
            readback, 0x3400_d185,
            "the value measured on a live executor"
        );
        let destination = Aarch64VcpuSnapshot {
            sctlr: readback,
            ..sample()
        };
        let task = aarch64_task_state_from_snapshot(
            &source,
            Some(source.elr_el1),
            Some(172),
            source.gprs[0],
            0xdead_0001,
            0x15,
            false,
            Some(continuation()),
            23,
            29,
        )
        .expect("complete snapshot");
        restore_aarch64_task_state(&destination, &task)
            .expect("a readback carrying only RES1 bits is the neutral bootstrap value");

        // A FUNCTIONAL difference must still be rejected: SCTLR_EL1.WXN(19)
        // is not RES1 and is not something carrick programs.
        let reprogrammed = Aarch64VcpuSnapshot {
            sctlr: readback | (1 << 19),
            ..sample()
        };
        assert!(restore_aarch64_task_state(&reprogrammed, &task).is_err());
    }

    /// The thread-entry deltas are applied and nothing else drifts: the stage-1
    /// MMU sysregs are inherited verbatim (same address space) and the FPSR/FPCR
    /// fields are carried WITHOUT being swapped. (Lifted from the old KVM
    /// `fork::seed_tests`, with the corrected `GuestEntryRegs` signature.)
    #[test]
    fn seed_applies_thread_entry_deltas() {
        let parent = sample();
        let entry = GuestEntryRegs {
            return_value: 0,
            stack: Some(0x7FFF_0000),
            tls: Some(0xCAFE_0000),
        };
        let child = seed_sibling_snapshot(&parent, entry);

        assert_eq!(child.gprs[0], 0, "x0 (clone return value) must be 0");
        assert_eq!(child.sp_el0, 0x7FFF_0000, "sp_el0 must be the child stack");
        assert_eq!(
            child.tpidr_el0, 0xCAFE_0000,
            "tpidr_el0 must be the tls arg"
        );
        assert_eq!(
            child.pc, parent.elr_el1,
            "pc must be the post-svc address (parent.elr_el1)"
        );
        // EL0-resume PSTATE: seeded from the parent's SPSR_EL1 (the EL0t PSTATE),
        // NOT the parent's EL1h trap-time pstate.
        assert_eq!(
            child.pstate, parent.spsr_el1,
            "sibling pstate must be the EL0t SPSR_EL1, not the EL1h trap pstate"
        );
        // Inherited verbatim (same guest address space).
        assert_eq!(child.ttbr0, parent.ttbr0);
        assert_eq!(child.sctlr, parent.sctlr);
        assert_eq!(child.vbar, parent.vbar);
        for n in 1..31 {
            assert_eq!(child.gprs[n], parent.gprs[n], "x{n} must be inherited");
        }
        // FPSR/FPCR carried, NOT swapped.
        assert_eq!(
            child.fpsr, parent.fpsr,
            "fpsr must NOT be swapped with fpcr"
        );
        assert_eq!(
            child.fpcr, parent.fpcr,
            "fpcr must NOT be swapped with fpsr"
        );
    }

    #[test]
    fn private_repoint_tlbi_failure_is_indeterminate() {
        let result = classify_private_repoint_tlbi(Err(TrapError::Hypervisor(
            "injected post-publication TLBI failure".into(),
        )));
        assert!(matches!(
            result,
            Err(RepointPrivateError::Indeterminate(MemoryError::HostMap(_)))
        ));
    }

    #[test]
    fn asid_retirement_maintenance_is_exactly_scoped_and_ordered() {
        let bytes = super::asid_maintenance_bytes();
        let opcode = |index: usize| {
            let mut word = [0_u8; 4];
            word.copy_from_slice(&bytes[index * 4..index * 4 + 4]);
            u32::from_le_bytes(word)
        };
        assert_eq!(opcode(0), 0xd503_3f9f, "dsb sy");
        assert_eq!(opcode(1), 0xd508_8340, "tlbi aside1is, x0");
        assert_eq!(opcode(2), 0xd503_3f9f, "dsb sy");
        assert_eq!(opcode(3), 0xd503_3fdf, "isb");
        assert_eq!(opcode(4), 0xd400_0022, "hvc #1");
        assert!(
            !bytes
                .windows(4)
                .any(|word| word == 0xd508_831f_u32.to_le_bytes())
        );
    }

    #[test]
    fn live_hvpatch_stage1_edits_are_asid_scoped() {
        let source = include_str!("engine.rs");
        let production = source
            .split("\n#[cfg(test)]\nmod tests")
            .next()
            .expect("production AArch64 engine source");
        assert_eq!(
            production.matches("self.run_el1_maintenance()").count(),
            1,
            "only the isolated compatibility retirement may issue VMALLE1IS"
        );
        let compatibility_retirement = production
            .split("fn retire_in_process_address_space")
            .nth(1)
            .and_then(|tail| tail.split("fn retire_task_address_space").next())
            .expect("compatibility process retirement");
        assert!(compatibility_retirement.contains("self.run_el1_maintenance()"));

        for live_path in [
            "fn pt_edit_and_flush",
            "fn ensure_frame_cow_write",
            "fn ensure_sparse_mmap_backing",
            "fn repoint_private",
            "fn refresh_fork_process_state",
            "fn resolve_frame_cow_fault",
            "fn resolve_stale_stage1_fault",
        ] {
            let body = production
                .split(live_path)
                .nth(1)
                .and_then(|tail| tail.split("\n    fn ").next())
                .unwrap_or_else(|| panic!("production live mutation path {live_path}"));
            assert!(
                body.contains("run_stage1_maintenance"),
                "{live_path} must select ASIDE1IS for a bound process ASID"
            );
            assert!(!body.contains("run_el1_maintenance"));
        }
    }

    #[test]
    fn task_only_terminal_cleanup_never_flushes_all_asids_or_destroys_worker_vcpu() {
        let source = include_str!("engine.rs");
        let cleanup = source
            .split("fn retire_task_address_space")
            .nth(1)
            .and_then(|tail| tail.split("fn build_process_spec").next())
            .expect("task-only terminal cleanup");
        assert!(cleanup.contains("self.vm.process_exit_cleanup()"));
        assert!(!cleanup.contains("run_el1_maintenance"));
        assert!(!cleanup.contains("destroy_vcpu_on_thread_exit"));
    }

    #[test]
    fn existing_sparse_editor_skips_parked_vcpu_bootstrap() {
        let mut bootstrap_calls = 0;
        let result = ensure_sparse_page_table_editor(true, || {
            bootstrap_calls += 1;
            Err(MemoryError::HostMap(
                "parked vCPU cannot read TTBR0".to_owned(),
            ))
        });

        assert!(result.is_ok());
        assert_eq!(bootstrap_calls, 0);
    }

    #[test]
    fn absent_sparse_editor_preserves_live_vcpu_bootstrap() {
        let mut bootstrap_calls = 0;
        let result = ensure_sparse_page_table_editor(false, || {
            bootstrap_calls += 1;
            Ok(())
        });

        assert!(result.is_ok());
        assert_eq!(bootstrap_calls, 1);
    }

    #[test]
    fn snapshot_typed_state_roundtrips_every_task_field() {
        let source = sample();
        let task = aarch64_task_state_from_snapshot(
            &source,
            Some(0x7100),
            Some(221),
            0x7200,
            0x7300,
            0x74,
            true,
            Some(continuation()),
            17,
            19,
        )
        .expect("complete task snapshot");
        let restored = restore_aarch64_task_state(&source, &task).expect("typed restore");
        assert_eq!(restored.gprs, source.gprs);
        assert_eq!(restored.pc, source.pc);
        assert_eq!(restored.pstate, source.pstate);
        assert_eq!(restored.sp_el0, source.sp_el0);
        assert_eq!(restored.elr_el1, source.elr_el1);
        assert_eq!(restored.spsr_el1, source.spsr_el1);
        assert_eq!(restored.ttbr0, source.ttbr0);
        assert_eq!(restored.ttbr1, source.ttbr1);
        assert_eq!(restored.tcr, source.tcr);
        assert_eq!(restored.actlr_el1, source.actlr_el1);
        assert_eq!(restored.tpidr_el0, source.tpidr_el0);
        assert_eq!(restored.tpidrro_el0, source.tpidrro_el0);
        assert_eq!(restored.contextidr_el1, source.contextidr_el1);
        assert_eq!(restored.vregs, source.vregs);
        assert_eq!(restored.fpsr, source.fpsr);
        assert_eq!(restored.fpcr, source.fpcr);
        assert_eq!(task.pending_resume_pc, Some(0x7100));
        assert_eq!(task.pc, 0x7100);
        assert_eq!(task.pstate, source.spsr_el1);
        assert_eq!(task.trap_pc, source.pc);
        assert_eq!(task.trap_pstate, source.pstate);
        assert_eq!(task.last_syscall_nr, Some(221));
        assert_eq!(task.last_syscall_orig_x0, 0x7200);
        assert_eq!(task.last_fault_esr, 0x7300);
        assert_eq!(task.last_exit_class, 0x74);
        assert!(task.is_forked_child);
        assert_eq!(task.syscall_continuation, Some(continuation()));
        assert_eq!(task.mm_generation, 17);
        assert_eq!(task.asid_generation, 19);
    }

    /// A task snapshot must restore every migratable field while retaining the
    /// destination executor's stack/mailbox. The destination must be neutral
    /// before load, then the task's exact EL1 control values are overlaid.
    ///
    /// The historical byte boundary copied source executor-local state here;
    /// this regression test keeps the typed overlay split explicit.
    #[test]
    fn snapshot_roundtrip_preserves_complete_task_state_and_destination_local_state() {
        let mut source = sample();
        source.sctlr ^= 0x3000_0000;
        source.mair ^= 0x1100;
        source.vbar += 0x4000;
        source.cpacr ^= 0x10;
        source.cntkctl_el1 ^= 0x4;
        source.tpidr_el1 = 0xd0ff;
        let neutral = sample();
        let destination = Aarch64VcpuSnapshot {
            sp_el1: 0xd001,
            tpidr_el1: 0,
            vbar: neutral.vbar,
            sctlr: neutral.sctlr,
            mair: neutral.mair,
            cpacr: neutral.cpacr,
            ..sample()
        };

        let task = aarch64_task_state_from_snapshot(
            &source,
            Some(source.elr_el1),
            Some(172),
            source.gprs[0],
            0xdead_0001,
            0x15,
            false,
            Some(continuation()),
            23,
            29,
        )
        .expect("complete snapshot");
        let restored = restore_aarch64_task_state(&destination, &task).expect("cross executor");

        assert_eq!(restored.gprs, source.gprs);
        assert_eq!(restored.pc, source.pc);
        assert_eq!(restored.pstate, source.pstate);
        assert_eq!(restored.sp_el0, source.sp_el0);
        assert_eq!(restored.ttbr0, source.ttbr0);
        assert_eq!(restored.sctlr, source.sctlr);
        assert_eq!(restored.mair, source.mair);
        assert_eq!(restored.vbar, source.vbar);
        assert_eq!(restored.cpacr, source.cpacr);
        assert_eq!(restored.cntkctl_el1, source.cntkctl_el1);
        assert_eq!(restored.tpidr_el1, source.tpidr_el1);
        assert_eq!(restored.sp_el1, destination.sp_el1);
        assert_eq!(restored.ttbr1, source.ttbr1);
        assert_eq!(restored.tcr, source.tcr);
        assert_eq!(restored.actlr_el1, source.actlr_el1);
        assert_eq!(restored.tpidr_el0, source.tpidr_el0);
        assert_eq!(restored.tpidrro_el0, source.tpidrro_el0);
        assert_eq!(restored.contextidr_el1, source.contextidr_el1);
        assert_eq!(restored.vregs, source.vregs);
        assert_eq!(restored.fpsr, source.fpsr);
        assert_eq!(restored.fpcr, source.fpcr);
        assert_eq!(
            restored.sp_el1, destination.sp_el1,
            "SP_EL1 must stay executor-local"
        );
        assert_eq!(task.mm_generation, 23);
        assert_eq!(task.asid_generation, 29);
        assert_eq!(task.syscall_continuation, Some(continuation()));
    }

    #[test]
    fn frame_cow_binding_preserves_strong_asid_generation_distinct_from_mm() {
        let source = include_str!("engine.rs");
        let binding = source
            .split("fn bind_frame_cow(\n        &mut self")
            .nth(1)
            .and_then(|tail| tail.split("fn refresh_fork_process_state").next())
            .expect("AArch64 engine frame-COW binding");
        assert!(binding.contains("self.mm_generation != identity.mm"));
        assert!(!binding.contains("self.asid_generation = identity.mm"));
        assert!(!binding.contains("self.mm_generation = identity.mm"));

        let snapshot = sample();
        let task =
            aarch64_task_state_from_snapshot(&snapshot, None, None, 0, 0, 0, false, None, 64, 2)
                .unwrap();
        assert_eq!(task.mm_generation, 64);
        assert_eq!(task.asid_generation, 2);
    }

    #[test]
    fn wait_diagnostics_prefer_post_syscall_guest_resume_pc() {
        assert_eq!(
            diagnostic_resume_pc(Some(0x0040_1234), 0xffff_0000),
            0x0040_1234
        );
        assert_eq!(diagnostic_resume_pc(None, 0x0040_5678), 0x0040_5678);
    }

    #[test]
    fn core_resume_pair_uses_live_el0_state_outside_a_syscall_trap() {
        let snapshot = sample();
        assert_eq!(
            core_resume_pair(None, &snapshot),
            (snapshot.pc, snapshot.pstate),
            "a force-exited running vCPU has a stale ELR from its last exception"
        );
    }

    #[test]
    fn core_resume_pair_uses_saved_el0_state_during_a_syscall_trap() {
        let snapshot = sample();
        assert_eq!(
            core_resume_pair(Some(snapshot.elr_el1), &snapshot),
            (snapshot.elr_el1, snapshot.spsr_el1),
            "a dispatcher-blocked vCPU is parked in EL1 with its EL0 pair in ELR/SPSR"
        );
    }

    #[test]
    fn core_resume_pair_uses_saved_el0_state_when_fatal_capture_runs_in_el1() {
        let mut snapshot = sample();
        snapshot.pc = 0x2d_0001_0aa0;
        snapshot.pstate = 0x6040_03c5;
        snapshot.elr_el1 = 0x88_0000_9538;
        snapshot.spsr_el1 = 0x6000_03c0;

        assert_eq!(
            core_resume_pair(None, &snapshot),
            (snapshot.elr_el1, snapshot.spsr_el1),
            "a fatal signal raised before returning from the EL1 syscall vector must publish the Linux-visible EL0 pair"
        );
    }

    #[test]
    fn wait_diagnostics_decode_hvpatch_island_back_to_original_svc() {
        // Island layout: svc #0 at 0x2000, then `b 0x1004` at the trapped
        // resume PC 0x2004. The diagnostic call site is the original svc at
        // target-4 = 0x1000.
        assert_eq!(
            decode_hvpatch_island_origin(0x2004, 0xd400_0001, 0x17ff_fc00),
            Some(0x1000)
        );
        assert_eq!(
            decode_hvpatch_island_origin(0x2004, 0xd503_201f, 0x17ff_fc00),
            None,
            "a non-svc predecessor is not an HvPatch island"
        );
        assert_eq!(
            decode_hvpatch_island_origin(0x2004, 0xd400_0001, 0xd503_201f),
            None,
            "the instruction after svc must be an immediate branch"
        );
    }

    #[test]
    fn core_register_capture_rejects_disabled_fpsimd_authority() {
        let error = require_core_fpsimd_authority(false)
            .expect_err("zero-fabricated FP/SIMD state cannot be complete core authority");
        assert!(error.to_string().contains("FP/SIMD"));
        assert!(require_core_fpsimd_authority(true).is_ok());
    }

    #[test]
    fn migratable_snapshot_rejects_disabled_fpsimd_authority() {
        let live = sample();
        assert_ne!(live.vregs, [0; 32]);
        let error = require_migratable_fpsimd_authority(false)
            .expect_err("disabled FP/SIMD cannot publish a zero-filled successful snapshot");
        assert!(error.to_string().contains("FP/SIMD"));
        assert!(require_migratable_fpsimd_authority(true).is_ok());
    }

    #[test]
    fn live_el0_signal_without_caller_hint_uses_live_pc() {
        let mut reads = 0;
        let pc = signal_interrupted_pc_for_live_level(0x2000_03c0, None, || {
            reads += 1;
            Ok(0x0055_0e78)
        })
        .expect("live EL0 PC authority");

        assert_eq!(pc, Some(0x0055_0e78));
        assert_eq!(reads, 1);
    }

    #[test]
    fn live_el0_signal_preserves_supplied_pc_without_reread() {
        let pc = signal_interrupted_pc_for_live_level(0x2000_03c0, Some(0x0040_1234), || {
            panic!("a caller-supplied live PC is already authoritative")
        })
        .expect("caller-supplied live EL0 PC");

        assert_eq!(pc, Some(0x0040_1234));
    }

    #[test]
    fn el1_signal_ignores_stale_caller_pc() {
        let pc = signal_interrupted_pc_for_live_level(0x6040_03c5, Some(0x0040_1234), || {
            panic!("EL1 resumes through ELR_EL1, not live PC")
        })
        .expect("EL1 signal route");

        assert_eq!(pc, None);
    }

    #[test]
    fn el1_signal_recovers_backend_mailbox_return_only_when_caller_has_none() {
        let recovered = pending_syscall_retval_for_boundary(None, None, || Ok(Some(-77)))
            .expect("EL1 mailbox authority");
        assert_eq!(recovered, Some(-77));

        let explicit = pending_syscall_retval_for_boundary(Some(42), None, || {
            panic!("caller-owned return must win")
        })
        .expect("caller return");
        assert_eq!(explicit, Some(42));

        let el0 = pending_syscall_retval_for_boundary(None, Some(0x4000), || {
            panic!("EL0 signal must preserve live x0")
        })
        .expect("EL0 live-register authority");
        assert_eq!(el0, None);
    }

    #[test]
    fn hvpatch_process_aperture_reservation_removes_both_identity_ranges() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let mut manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        assert!(
            manager
                .translate(carrick_mem::memory::LINUX_HVPATCH_GLOBAL_FRAME_BASE)
                .is_some()
        );
        assert!(
            manager
                .translate(carrick_mem::memory::LINUX_HVPATCH_ROOT_SLOT_BASE)
                .is_some()
        );

        assert!(
            reserve_hvpatch_process_apertures(&mut manager)
                .expect("reserve apertures")
                .changed
        );
        assert_eq!(
            manager.translate(carrick_mem::memory::LINUX_HVPATCH_GLOBAL_FRAME_BASE),
            None
        );
        assert_eq!(
            manager.translate(carrick_mem::memory::LINUX_HVPATCH_ROOT_SLOT_BASE),
            None
        );
    }

    #[test]
    fn shared_futex_high_alias_uses_live_stage1_backing_ipa() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let mut manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        let guest_va = carrick_mem::memory::LINUX_HIGH_VA_THRESHOLD;
        let backing_ipa = carrick_mem::memory::LINUX_HVPATCH_GLOBAL_FRAME_BASE + 0x20_0000;
        manager
            .map_aliased(guest_va, backing_ipa, 0x4000, true, None)
            .expect("map high shared-file alias into a global frame");

        let resolved = shared_futex_backing_gpa(&manager, guest_va + 4)
            .expect("shared futex must have a live stage-1 translation");

        assert_eq!(resolved.raw(), backing_ipa + 4);
        assert_ne!(
            resolved.raw(),
            guest_va + 4,
            "the semantic high VA is not a cross-process physical futex key"
        );
    }

    #[test]
    fn fresh_root_engine_and_exec_heap_lifecycle() {
        use carrick_mem::memory::{LINUX_HEAP_BASE, LINUX_HEAP_SIZE};

        // 1. Fresh root / exec seeding: heap starts unmapped.
        let protections = Arc::new(MemoryProtections::default());
        seed_heap_unmapped(&protections);

        assert!(
            protections.range_no_access(LINUX_HEAP_BASE, 0x1000),
            "heap base must start unmapped / no-access"
        );
        assert!(
            protections.range_unmapped(LINUX_HEAP_BASE, 0x1000),
            "heap base must start unmapped"
        );
        assert!(
            protections.range_no_access(LINUX_HEAP_BASE + LINUX_HEAP_SIZE - 0x1000, 0x1000),
            "last heap page must start unmapped"
        );

        // 2. Grow 1 page (0x1000): clearing unmapped makes only the live prefix accessible.
        protections.set_mapping_protection(LINUX_HEAP_BASE, 0x1000, false, false);
        assert!(
            !protections.range_no_access(LINUX_HEAP_BASE, 0x1000),
            "grown page must be accessible"
        );
        assert!(
            protections.range_unmapped(LINUX_HEAP_BASE + 0x1000, 0x1000),
            "ungrown tail must remain unmapped"
        );

        // 3. Copied-mm fork inherits live grown prefix snapshot.
        let child_protections =
            Arc::new(MemoryProtections::from_snapshot(protections.snapshot_all()));
        assert!(
            !child_protections.range_no_access(LINUX_HEAP_BASE, 0x1000),
            "forked child must inherit grown prefix as accessible"
        );
        assert!(
            child_protections.range_unmapped(LINUX_HEAP_BASE + 0x1000, 0x1000),
            "forked child must inherit ungrown tail as unmapped"
        );

        // 4. CLONE_VM sibling shares the exact same Arc.
        let sibling_protections = Arc::clone(&protections);
        assert!(
            Arc::ptr_eq(&protections, &sibling_protections),
            "CLONE_VM sibling must share the same Arc<MemoryProtections>"
        );

        // 5. Exec replacement resets heap on fresh mm.
        let exec_protections = Arc::new(MemoryProtections::default());
        seed_heap_unmapped(&exec_protections);
        assert!(
            exec_protections.range_unmapped(LINUX_HEAP_BASE, 0x1000),
            "execve must seed fresh mm heap as unmapped"
        );
        assert!(
            exec_protections.range_unmapped(LINUX_HEAP_BASE + LINUX_HEAP_SIZE - 0x1000, 0x1000),
            "execve must seed full heap as unmapped"
        );
    }

    #[test]
    fn stage1_protection_edit_fork_cow_downgrade_preserves_requested_exec_not_stale_arm() {
        use carrick_abi::{LINUX_PROT_EXEC, LINUX_PROT_READ, LINUX_PROT_WRITE};
        use carrick_mem::page_table::{
            LeafAccess, terminal_descriptor, terminal_descriptor_permits_el0,
        };

        const PAGE_SIZE: u64 = 0x1000;
        const NON_GLOBAL: u64 = 1 << 11;
        const UXN: u64 = 1 << 54;
        const AP_MASK: u64 = 0b11 << 6;
        const AP_USER_RW: u64 = 0b01 << 6;
        const AP_USER_RO: u64 = 0b11 << 6;
        const PA_MASK_PAGE: u64 = 0x0000_FFFF_FFFF_F000;

        let leaf =
            |mgr: &PageTableManager, va: u64| -> u64 { terminal_descriptor(mgr.debug_walk(va)) };

        // --------------------------------------------------------------------
        // Case 1: Stale arm executable=true -> Requested RW (non-exec)
        // Must remove execution permission (UXN set) while keeping write trap armed (RO).
        // --------------------------------------------------------------------
        let bytes = carrick_mem::memory::stage1_hvpatch_page_tables();
        let mut mgr = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);

        // Non-identity VA and IPA
        let base_va: u64 = 0x40_0088_c000;
        let base_ipa: u64 = carrick_mem::memory::LINUX_HVPATCH_GLOBAL_FRAME_BASE + 0x20_0000;
        let edit_len: usize = 4 * PAGE_SIZE as usize; // 4 pages in edit: [0..4)
        let total_mapped_len: u64 = 5 * PAGE_SIZE; // 5th page is neighbor [4..5)

        mgr.map_private_aliased(base_va, base_ipa, total_mapped_len, true, None)
            .expect("map initial non-identity pages");

        let cow_range_stale_exec = crate::vmm::ForkCowRange {
            va: base_va + PAGE_SIZE,
            len: 2 * PAGE_SIZE as usize, // pages 1 and 2
            executable: true,            // Stale historical fork-arm property
            kernel_only: false,
            granule: crate::vmm::CowGranule::Page,
        };

        let neighbor_va = base_va + 4 * PAGE_SIZE;
        let neighbor_before = leaf(&mgr, neighbor_va);
        assert_ne!(neighbor_before, 0);

        let changed = apply_stage1_protection_edit(
            &mut mgr,
            base_va,
            edit_len,
            LINUX_PROT_READ | LINUX_PROT_WRITE,
            &[cow_range_stale_exec],
        )
        .expect("apply RW protection edit");
        assert!(changed.changed, "protection edit must report changes");
        assert!(
            changed.flush_required,
            "protection edit on valid pages must require flush"
        );

        // Page 0 (un-armed in range): RW, NX, IPA preserved, non-global preserved
        let d0 = leaf(&mgr, base_va);
        assert_eq!(d0 & PA_MASK_PAGE, base_ipa);
        assert_ne!(d0 & NON_GLOBAL, 0, "page 0 must be non-global");
        assert_eq!(d0 & AP_MASK, AP_USER_RW, "page 0 must be RW");
        assert_ne!(d0 & UXN, 0, "page 0 must have UXN set (non-exec)");
        assert!(terminal_descriptor_permits_el0(d0, LeafAccess::Read));
        assert!(terminal_descriptor_permits_el0(d0, LeafAccess::Write));
        assert!(!terminal_descriptor_permits_el0(d0, LeafAccess::Execute));

        // Pages 1 & 2 (armed COW): must be RO, NX (exec removed despite stale arm executable=true),
        // non-identity IPA preserved, non-global preserved.
        for page_idx in 1..=2 {
            let va = base_va + page_idx * PAGE_SIZE;
            let expected_ipa = base_ipa + page_idx * PAGE_SIZE;
            let d = leaf(&mgr, va);

            assert_eq!(
                d & PA_MASK_PAGE,
                expected_ipa,
                "page {page_idx} IPA must be preserved"
            );
            assert_ne!(d & NON_GLOBAL, 0, "page {page_idx} must remain non-global");
            assert_eq!(
                d & AP_MASK,
                AP_USER_RO,
                "page {page_idx} must stay read-only (write trap armed)"
            );
            assert_ne!(
                d & UXN,
                0,
                "page {page_idx} must have UXN set (requested RW removes execution despite stale range.executable=true)"
            );
            assert!(terminal_descriptor_permits_el0(d, LeafAccess::Read));
            assert!(
                !terminal_descriptor_permits_el0(d, LeafAccess::Write),
                "COW page {page_idx} must not be writable"
            );
            assert!(
                !terminal_descriptor_permits_el0(d, LeafAccess::Execute),
                "COW page {page_idx} must not be executable under requested RW"
            );
        }

        // Page 3 (un-armed in range): RW, NX, IPA preserved, non-global preserved
        let d3 = leaf(&mgr, base_va + 3 * PAGE_SIZE);
        assert_eq!(d3 & PA_MASK_PAGE, base_ipa + 3 * PAGE_SIZE);
        assert_ne!(d3 & NON_GLOBAL, 0, "page 3 must be non-global");
        assert_eq!(d3 & AP_MASK, AP_USER_RW, "page 3 must be RW");
        assert_ne!(d3 & UXN, 0, "page 3 must have UXN set (non-exec)");
        assert!(terminal_descriptor_permits_el0(d3, LeafAccess::Read));
        assert!(terminal_descriptor_permits_el0(d3, LeafAccess::Write));
        assert!(!terminal_descriptor_permits_el0(d3, LeafAccess::Execute));

        // Neighbor page 4 (outside clipped/edited range): completely unchanged
        let neighbor_after = leaf(&mgr, neighbor_va);
        assert_eq!(
            neighbor_before, neighbor_after,
            "neighbor page outside edit range must be unchanged"
        );

        // --------------------------------------------------------------------
        // Case 2: Stale arm executable=false -> Requested RWX
        // Must grant execution permission (UXN clear) while keeping write trap armed (RO).
        // --------------------------------------------------------------------
        let bytes = carrick_mem::memory::stage1_hvpatch_page_tables();
        let mut mgr = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);

        mgr.map_private_aliased(base_va, base_ipa, total_mapped_len, true, None)
            .expect("map initial non-identity pages");

        let cow_range_stale_nonexec = crate::vmm::ForkCowRange {
            va: base_va + PAGE_SIZE,
            len: 2 * PAGE_SIZE as usize, // pages 1 and 2
            executable: false,           // Stale historical fork-arm property
            kernel_only: false,
            granule: crate::vmm::CowGranule::Page,
        };

        let neighbor_before = leaf(&mgr, neighbor_va);

        let changed = apply_stage1_protection_edit(
            &mut mgr,
            base_va,
            edit_len,
            LINUX_PROT_READ | LINUX_PROT_WRITE | LINUX_PROT_EXEC,
            &[cow_range_stale_nonexec],
        )
        .expect("apply RWX protection edit");
        assert!(changed.changed, "protection edit must report changes");
        assert!(
            changed.flush_required,
            "protection edit on valid pages must require flush"
        );

        // Page 0 (un-armed in range): RW, Executable, IPA preserved, non-global preserved
        let d0 = leaf(&mgr, base_va);
        assert_eq!(d0 & PA_MASK_PAGE, base_ipa);
        assert_ne!(d0 & NON_GLOBAL, 0, "page 0 must be non-global");
        assert_eq!(d0 & AP_MASK, AP_USER_RW, "page 0 must be RW");
        assert_eq!(d0 & UXN, 0, "page 0 must have UXN clear (executable)");
        assert!(terminal_descriptor_permits_el0(d0, LeafAccess::Read));
        assert!(terminal_descriptor_permits_el0(d0, LeafAccess::Write));
        assert!(terminal_descriptor_permits_el0(d0, LeafAccess::Execute));

        // Pages 1 & 2 (armed COW): must be RO, Executable (exec granted despite stale arm executable=false),
        // non-identity IPA preserved, non-global preserved.
        for page_idx in 1..=2 {
            let va = base_va + page_idx * PAGE_SIZE;
            let expected_ipa = base_ipa + page_idx * PAGE_SIZE;
            let d = leaf(&mgr, va);

            assert_eq!(
                d & PA_MASK_PAGE,
                expected_ipa,
                "page {page_idx} IPA must be preserved"
            );
            assert_ne!(d & NON_GLOBAL, 0, "page {page_idx} must remain non-global");
            assert_eq!(
                d & AP_MASK,
                AP_USER_RO,
                "page {page_idx} must stay read-only (write trap armed)"
            );
            assert_eq!(
                d & UXN,
                0,
                "page {page_idx} must have UXN clear (requested RWX grants execution despite stale range.executable=false)"
            );
            assert!(terminal_descriptor_permits_el0(d, LeafAccess::Read));
            assert!(
                !terminal_descriptor_permits_el0(d, LeafAccess::Write),
                "COW page {page_idx} must not be writable"
            );
            assert!(
                terminal_descriptor_permits_el0(d, LeafAccess::Execute),
                "COW page {page_idx} must be executable under requested RWX"
            );
        }

        // Page 3 (un-armed in range): RW, Executable, IPA preserved, non-global preserved
        let d3 = leaf(&mgr, base_va + 3 * PAGE_SIZE);
        assert_eq!(d3 & PA_MASK_PAGE, base_ipa + 3 * PAGE_SIZE);
        assert_ne!(d3 & NON_GLOBAL, 0, "page 3 must be non-global");
        assert_eq!(d3 & AP_MASK, AP_USER_RW, "page 3 must be RW");
        assert_eq!(d3 & UXN, 0, "page 3 must have UXN clear (executable)");
        assert!(terminal_descriptor_permits_el0(d3, LeafAccess::Read));
        assert!(terminal_descriptor_permits_el0(d3, LeafAccess::Write));
        assert!(terminal_descriptor_permits_el0(d3, LeafAccess::Execute));

        // Neighbor page 4 (outside clipped/edited range): completely unchanged
        let neighbor_after = leaf(&mgr, neighbor_va);
        assert_eq!(
            neighbor_before, neighbor_after,
            "neighbor page outside edit range must be unchanged"
        );
    }

    #[derive(Debug)]
    struct DummyArenaSource(carrick_mem::page_table::TableArenaSourceId);
    impl carrick_mem::page_table::TableArenaSource for DummyArenaSource {
        fn id(&self) -> carrick_mem::page_table::TableArenaSourceId {
            self.0
        }
        fn take_arena(&mut self) -> Option<carrick_guest_mem::Gpa> {
            None
        }
        fn return_arena(&mut self, _base: carrick_guest_mem::Gpa) {}
    }

    #[test]
    fn replace_page_tables_authority_preserves_parent_manager_and_source_when_shared() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        let source_id = carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x1000));
        let parent_authority = Stage1Authority::new_with_manager(Some(manager));
        parent_authority
            .install_source(Box::new(DummyArenaSource(source_id)))
            .expect("set arena source on parent authority");
        assert!(parent_authority.has_source());

        // When shared with vfork child
        parent_authority.share_with_vfork_child();
        let mut child_authority = parent_authority.clone();
        assert!(child_authority.is_shared_with_vfork_child());

        let mut retired = false;
        let mut bound = false;
        replace_page_tables_authority(
            &mut child_authority,
            None,
            |_| {
                retired = true;
                Ok(())
            },
            |_| {
                bound = true;
            },
        )
        .expect("replace page tables authority");

        assert!(
            !retired,
            "must not retire parent's extension arenas when shared"
        );
        assert!(bound, "must bind fresh child authority");

        // Parent tables and source must be completely preserved.
        assert!(
            parent_authority.is_present(),
            "parent manager must not be stolen"
        );
        assert!(
            parent_authority.has_source(),
            "parent must retain its arena source"
        );
        assert!(
            parent_authority.is_exclusive(),
            "parent must be restored to Exclusive after child exec"
        );

        // Child must have detached to a distinct authority and have no source.
        assert!(!parent_authority.shares_exact_authority(&child_authority));
        assert!(!child_authority.has_source());
    }

    #[test]
    fn replace_page_tables_authority_preserves_parent_under_concurrent_vfork_children() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        let source_id = carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x1000));
        let parent_authority = Stage1Authority::new_with_manager(Some(manager));
        parent_authority
            .install_source(Box::new(DummyArenaSource(source_id)))
            .expect("set arena source on parent authority");

        // Two concurrent vfork children are created from parent
        parent_authority.share_with_vfork_child();
        parent_authority.share_with_vfork_child();
        let mut child1_authority = parent_authority.clone();
        let mut child2_authority = parent_authority.clone();
        assert!(child1_authority.is_shared_with_vfork_child());
        assert!(child2_authority.is_shared_with_vfork_child());

        // Child 1 execs first
        let mut retired1 = false;
        let mut bound1 = false;
        replace_page_tables_authority(
            &mut child1_authority,
            None,
            |_| {
                retired1 = true;
                Ok(())
            },
            |_| {
                bound1 = true;
            },
        )
        .expect("replace child1 authority");

        assert!(
            !retired1,
            "parent extension arenas must not be retired by child1"
        );
        assert!(bound1, "must bind fresh child1 authority");
        assert!(!parent_authority.shares_exact_authority(&child1_authority));

        // Parent must STILL have its manager and source, and STILL be shared with child2!
        assert!(
            parent_authority.is_present(),
            "parent manager must not be stolen"
        );
        assert!(
            parent_authority.has_source(),
            "parent source must not be stolen"
        );
        assert!(
            parent_authority.is_shared_with_vfork_child(),
            "parent must still be shared with child2"
        );
        assert!(!parent_authority.is_exclusive());

        // Child 2 execs second
        let mut retired2 = false;
        let mut bound2 = false;
        replace_page_tables_authority(
            &mut child2_authority,
            None,
            |_| {
                retired2 = true;
                Ok(())
            },
            |_| {
                bound2 = true;
            },
        )
        .expect("replace child2 authority");

        assert!(
            !retired2,
            "parent extension arenas must not be retired by child2"
        );
        assert!(bound2, "must bind fresh child2 authority");
        assert!(!parent_authority.shares_exact_authority(&child2_authority));

        // Now that child2 has exec'd, parent is restored to Exclusive!
        assert!(parent_authority.is_present(), "parent manager preserved");
        assert!(parent_authority.has_source(), "parent source preserved");
        assert!(
            parent_authority.is_exclusive(),
            "parent restored to Exclusive"
        );
        assert!(!parent_authority.is_shared_with_vfork_child());
    }

    #[test]
    fn execve_sharing_governed_solely_by_authority_even_on_disagreement() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        let source_id = carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x1000));
        let parent_authority = Stage1Authority::new_with_manager(Some(manager));
        parent_authority
            .install_source(Box::new(DummyArenaSource(source_id)))
            .expect("set arena source on parent authority");

        // Authority is shared with a vfork child (vfork_shares > 0)
        parent_authority.share_with_vfork_child();
        let mut child_authority = parent_authority.clone();

        let mut retired = false;
        let mut bound = false;
        // Even if external caller/runtime expected exclusive (disagreement),
        // replace_page_tables_authority drives through replace_for_exec where
        // vfork_shares > 0 guarantees the exclusive path is NOT taken.
        replace_page_tables_authority(
            &mut child_authority,
            None,
            |_| {
                retired = true;
                Ok(())
            },
            |_| {
                bound = true;
            },
        )
        .expect("replace child authority");

        assert!(
            !retired,
            "parent arenas must NOT be retired while vfork_shares > 0"
        );
        assert!(bound, "new child authority must be bound");
        assert!(
            parent_authority.is_present(),
            "parent manager must not be stolen"
        );
        assert!(
            parent_authority.has_source(),
            "parent source must not be stolen"
        );
        assert_eq!(
            parent_authority.root_base(),
            Some(carrick_mem::memory::LINUX_PAGE_TABLES_BASE)
        );
        assert!(!parent_authority.shares_exact_authority(&child_authority));
    }

    #[test]
    fn replace_page_tables_authority_retires_old_when_unshared() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        let mut authority = Stage1Authority::new_with_manager(Some(manager));
        assert!(authority.is_exclusive());

        let mut retired = false;
        replace_page_tables_authority(
            &mut authority,
            None,
            |_| {
                retired = true;
                Ok(())
            },
            |_| {},
        )
        .expect("replace page tables authority");

        assert!(retired, "must retire old manager when solely owned");
    }

    #[test]
    fn stage1_authority_source_survives_snapshot_image() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        let source_id = carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x2000));
        let authority = Stage1Authority::new_with_manager(Some(manager));
        authority
            .install_source(Box::new(DummyArenaSource(source_id)))
            .expect("install source");
        assert!(authority.has_source());

        let snapshot = authority.snapshot_image().expect("snapshot present");
        assert!(authority.has_source());
        assert_eq!(snapshot.base(), carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
    }

    #[test]
    fn stage1_authority_source_survives_rollback() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        let source_id = carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x3000));
        let authority = Stage1Authority::new_with_manager(Some(manager));
        authority
            .install_source(Box::new(DummyArenaSource(source_id)))
            .expect("install source");

        let snapshot = authority.snapshot_image().expect("snapshot");
        authority
            .edit(
                || unreachable!(),
                |editor| {
                    assert!(editor.has_arena_source());
                    editor.restore_image(snapshot, 6, 0);
                    assert!(editor.has_arena_source());
                    Ok::<(), PageTableError>(())
                },
            )
            .expect("edit");

        assert!(authority.has_source());
    }

    #[test]
    fn stage1_authority_source_survives_exec_while_shared() {
        let bytes = carrick_mem::memory::stage1_identity_page_tables();
        let manager = PageTableManager::new(bytes, carrick_mem::memory::LINUX_PAGE_TABLES_BASE);
        let source_id = carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x4000));
        let parent = Stage1Authority::new_with_manager(Some(manager));
        parent
            .install_source(Box::new(DummyArenaSource(source_id)))
            .expect("install source");
        parent.share_with_vfork_child();

        let mut child = parent.clone();
        let mut retired = false;
        let new_child = child
            .replace_for_exec(
                || Ok::<Option<PageTableManager>, ()>(None),
                |_| {
                    retired = true;
                    Ok(())
                },
            )
            .expect("replace_for_exec");

        assert!(!retired);
        assert!(parent.has_source());
        assert!(parent.is_exclusive());
        assert!(!new_child.has_source());
    }

    #[test]
    fn stage1_authority_sibling_lazy_build_sees_source() {
        let authority = Stage1Authority::new();
        let source_id = carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x5000));
        authority
            .install_source(Box::new(DummyArenaSource(source_id)))
            .expect("deferred install");
        assert!(authority.is_none());
        assert!(authority.has_source());

        let sibling = authority.clone();
        sibling.increment_engine_count();
        assert_eq!(sibling.engines(), 2);

        sibling
            .edit(
                || {
                    let bytes = carrick_mem::memory::stage1_identity_page_tables();
                    Ok::<PageTableManager, PageTableError>(PageTableManager::new(
                        bytes,
                        carrick_mem::memory::LINUX_PAGE_TABLES_BASE,
                    ))
                },
                |editor| {
                    assert!(editor.has_arena_source());
                    Ok::<(), PageTableError>(())
                },
            )
            .expect("lazy build on sibling edit");

        assert!(authority.is_present());
        assert!(authority.has_source());
        assert!(sibling.has_source());
    }

    #[test]
    fn stage1_authority_deferred_install_on_one_clone_then_build_on_another() {
        let clone1 = Stage1Authority::new();
        let clone2 = clone1.clone();

        let source_id = carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x6000));
        clone1
            .install_source(Box::new(DummyArenaSource(source_id)))
            .expect("install on clone1");

        assert!(clone2.has_source());
        assert!(clone2.is_none());

        clone2
            .edit(
                || {
                    let bytes = carrick_mem::memory::stage1_identity_page_tables();
                    Ok::<PageTableManager, PageTableError>(PageTableManager::new(
                        bytes,
                        carrick_mem::memory::LINUX_PAGE_TABLES_BASE,
                    ))
                },
                |editor| {
                    assert!(editor.has_arena_source());
                    Ok::<(), PageTableError>(())
                },
            )
            .expect("edit on clone2");

        assert!(clone1.is_present());
        assert!(clone1.has_source());
    }

    #[test]
    fn stage1_authority_conflicting_lease_rejection() {
        let authority = Stage1Authority::new();
        let source_id1 =
            carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x7000));
        let source_id2 =
            carrick_mem::page_table::TableArenaSourceId(carrick_guest_mem::Gpa(0x8000));

        authority
            .install_source(Box::new(DummyArenaSource(source_id1)))
            .expect("install first source");

        let res = authority.install_source(Box::new(DummyArenaSource(source_id2)));
        assert_eq!(res.unwrap_err(), PageTableError::ConflictingArenaSource);
    }
}

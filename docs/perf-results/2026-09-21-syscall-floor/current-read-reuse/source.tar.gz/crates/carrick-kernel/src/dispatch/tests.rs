static_assertions::assert_impl_all!(crate::dispatch::MmExecutorParticipation: Send);
static_assertions::assert_not_impl_any!(crate::dispatch::MmExecutorParticipation: Sync, Clone, Copy);

#[cfg(test)]
mod overlay_dispatch_tests {
    //! End-to-end overlay tests that drive the public `dispatch` entry
    //! point. The fixture builds a tiny tar-backed RootFs holding one
    //! directory and one file, then exercises the syscall path the same
    //! way the runtime does (SyscallRequest + LinearMemory + compat
    //! reporter). The assertions are what `apt update` needs to keep
    //! working: writable mkdirat, openat O_CREAT + write + read,
    //! unlink-then-ENOENT, rename-moves-overlay-content.
    //!
    //! Keep these tests minimal — there's no need to exercise every
    //! flag combination here, just the four scenarios called out in the
    //! task spec.
    use super::*;
    use carrick_vfs::ProcMapSharing;

    #[test]
    fn mutation_classifier_exactly_matches_the_typed_handler_tables() {
        for number in 0..=512 {
            assert_eq!(
                syscall_requires_mm_mutation(number, SyscallArgs::from([0; 6])),
                resolve_mutation_handler::<LinearMemory>(number).is_some(),
                "mutation classifier drift for syscall {number}"
            );
        }
        assert_eq!(MM_MUTATION_SYSCALLS.len(), 15);
    }
    use crate::compat::CompatReporter;
    use carrick_vfs::rootfs::LayerSource;
    use tar::{Builder, EntryType, Header};
    const SYS_OPENAT: u64 = 56;
    const SYS_CLOSE: u64 = 57;
    const SYS_READ: u64 = 63;
    const SYS_WRITE: u64 = 64;
    const SYS_NEWFSTATAT: u64 = 79;
    const SYS_CLONE: u64 = 220;
    const SYS_CLONE3: u64 = 435;
    const SYS_MKDIRAT: u64 = 34;
    const SYS_UNLINKAT: u64 = 35;
    const SYS_RENAMEAT: u64 = 38;
    const O_CREAT: u64 = 0o100;
    const O_WRONLY: u64 = 1;
    const O_RDONLY: u64 = 0;

    fn eventfd_open_file(counter: u64) -> OpenFile {
        OpenFile::from_open_description_with_status_flags(
            Arc::new(RwLock::new(OpenDescription::EventFd {
                state: Arc::new(EventFdState::new(counter)),
                semaphore: false,
                base: OpenDescriptionBase::new(0),
            })),
            crate::linux_abi::LINUX_O_RDWR,
            0,
        )
    }

    #[test]
    fn eventfd_write_records_the_host_readiness_transition() {
        const EVENTFD_WRITE_EVENT: u8 = 21;
        let dispatcher = SyscallDispatcher::new();
        let state = EventFdState::new(0x0102_0304);
        let increment = LinuxEventfdValue { value: 7 };

        assert!(matches!(
            write_eventfd(&dispatcher, increment.as_bytes(), &state),
            DispatchOutcome::Returned { value: 8 }
        ));
        assert!(
            crate::event_ring::contains_event(EVENTFD_WRITE_EVENT, -1, 0x0102_0304, 0x0102_030b,),
            "the always-on ring must record the in-memory eventfd transition"
        );
    }

    #[test]
    fn fd_install_helpers_reserve_single_and_pair_slots_atomically() {
        let dispatcher = SyscallDispatcher::new();

        let first = match dispatcher.install_fd_at_or_above(3, eventfd_open_file(1)) {
            Ok(fd) => fd,
            Err(_) => panic!("expected first fd install to succeed"),
        };
        assert_eq!(first, 3);

        let pair = match dispatcher.install_fd_pair_at_or_above(
            3,
            eventfd_open_file(2),
            eventfd_open_file(3),
        ) {
            Ok(pair) => pair,
            Err(_) => panic!("expected pair install to succeed"),
        };
        assert_eq!(pair, (4, 5));

        let next = match dispatcher.install_fd_at_or_above(3, eventfd_open_file(4)) {
            Ok(fd) => fd,
            Err(_) => panic!("expected next fd install to succeed"),
        };
        assert_eq!(next, 6);
    }

    #[test]
    fn host_write_kind_classifies_common_host_fds() {
        use std::os::fd::AsRawFd;

        let mut pipe_fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(pipe_fds.as_mut_ptr()) }, 0);
        assert_eq!(
            HostWriteKind::for_host_fd(pipe_fds[0]),
            HostWriteKind::PipeLike
        );

        let mut socket_fds = [-1; 2];
        assert_eq!(
            unsafe {
                libc::socketpair(libc::AF_UNIX, libc::SOCK_STREAM, 0, socket_fds.as_mut_ptr())
            },
            0
        );
        assert_eq!(
            HostWriteKind::for_host_fd(socket_fds[0]),
            HostWriteKind::SocketLike
        );

        let file = tempfile::tempfile().expect("tempfile");
        assert_eq!(
            HostWriteKind::for_host_fd(file.as_raw_fd()),
            HostWriteKind::RegularFile
        );

        unsafe {
            libc::close(pipe_fds[0]);
            libc::close(pipe_fds[1]);
            libc::close(socket_fds[0]);
            libc::close(socket_fds[1]);
        }
    }

    #[test]
    fn large_blocking_host_pipe_write_hands_off_after_partial_progress() {
        let mut fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(fds.as_mut_ptr()) }, 0);
        crate::dispatch::net::set_host_nonblocking(fds[1]);

        let bytes = vec![0xA5; 4 * 1024 * 1024];
        let outcome = write_host_pipe(
            &bytes,
            HostPipeWriteTarget::new(
                fds[1],
                None,
                false,
                HostWriteKind::PipeLike,
                crate::thread::ThreadId::synthetic_for_tests(0x7FFE_0101),
                WaitFdAuthority::internal(InternalWaitKind::CarrierControl),
                &carrick_hal::NullHostSignalBridge::default(),
            )
            .with_sigpipe(true),
        )
        .unwrap();

        unsafe {
            libc::close(fds[0]);
            libc::close(fds[1]);
        }

        let DispatchOutcome::BlockingWrite(write) = outcome else {
            panic!("large pipe write should hand off after partial progress, got {outcome:?}");
        };
        assert!(
            write.offset() > 0 && write.offset() < bytes.len(),
            "expected a positive partial offset after filling the pipe, got {}",
            write.offset()
        );
        assert!(write.sigpipe_on_epipe());
    }

    #[test]
    fn large_nonblocking_host_pipe_write_uses_small_ready_window() {
        let mut fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(fds.as_mut_ptr()) }, 0);
        crate::dispatch::net::set_host_nonblocking(fds[1]);

        let chunk = [0xA5; 4096];
        loop {
            let n = unsafe { libc::write(fds[1], chunk.as_ptr().cast(), chunk.len()) };
            if n > 0 {
                continue;
            }
            let errno = std::io::Error::last_os_error().raw_os_error();
            assert!(matches!(
                errno,
                Some(code) if code == libc::EAGAIN || code == libc::EWOULDBLOCK
            ));
            break;
        }

        let mut byte = [0u8; 1];
        assert_eq!(
            unsafe { libc::read(fds[0], byte.as_mut_ptr().cast(), 1) },
            1
        );

        let bytes = vec![0x5A; 64 * 1024];
        let outcome = write_host_pipe(
            &bytes,
            HostPipeWriteTarget::new(
                fds[1],
                None,
                true,
                HostWriteKind::PipeLike,
                crate::thread::ThreadId::synthetic_for_tests(0x7FFE_0103),
                WaitFdAuthority::internal(InternalWaitKind::CarrierControl),
                &carrick_hal::NullHostSignalBridge::default(),
            ),
        )
        .unwrap();

        unsafe {
            libc::close(fds[0]);
            libc::close(fds[1]);
        }

        let DispatchOutcome::Returned { value } = outcome else {
            panic!("large nonblocking write should make partial progress, got {outcome:?}");
        };
        assert!(
            value > 0 && (value as usize) < bytes.len(),
            "expected a positive partial write, got {value}"
        );
    }

    #[test]
    fn large_nonblocking_host_socket_write_uses_small_ready_window() {
        let mut fds = [-1; 2];
        assert_eq!(
            unsafe { libc::socketpair(libc::AF_UNIX, libc::SOCK_STREAM, 0, fds.as_mut_ptr()) },
            0
        );
        crate::dispatch::net::set_host_nonblocking(fds[0]);

        let chunk = [0xA5; 4096];
        loop {
            let n = unsafe { libc::write(fds[0], chunk.as_ptr().cast(), chunk.len()) };
            if n > 0 {
                continue;
            }
            let errno = std::io::Error::last_os_error().raw_os_error();
            assert!(matches!(
                errno,
                Some(code) if code == libc::EAGAIN || code == libc::EWOULDBLOCK
            ));
            break;
        }

        let mut byte = [0u8; 1];
        assert_eq!(
            unsafe { libc::read(fds[1], byte.as_mut_ptr().cast(), 1) },
            1
        );

        let bytes = vec![0x5A; 64 * 1024];
        let outcome = write_host_pipe(
            &bytes,
            HostPipeWriteTarget::new(
                fds[0],
                None,
                true,
                HostWriteKind::SocketLike,
                crate::thread::ThreadId::synthetic_for_tests(0x7FFE_0104),
                WaitFdAuthority::internal(InternalWaitKind::CarrierControl),
                &carrick_hal::NullHostSignalBridge::default(),
            ),
        )
        .unwrap();

        unsafe {
            libc::close(fds[0]);
            libc::close(fds[1]);
        }

        let DispatchOutcome::Returned { value } = outcome else {
            panic!("large nonblocking socket write should make partial progress, got {outcome:?}");
        };
        assert!(
            value > 0 && (value as usize) < bytes.len(),
            "expected a positive partial socket write, got {value}"
        );
    }

    #[test]
    fn anchored_wait_fds_keep_host_fd_live_after_open_file_drop() {
        let mut fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(fds.as_mut_ptr()) }, 0);
        let owner = HostFdRef::new(fds[0]);
        let open_file = OpenFile::from_open_description_with_status_flags(
            Arc::new(RwLock::new(OpenDescription::HostPipe {
                base: OpenDescriptionBase::new(0),
                host_fd: owner.clone(),
                is_read_end: true,
                pipe_id: 0,
                pty: None,
                bidirectional: false,
                write_kind: HostWriteKind::PipeLike,
                stdio_stream: None,
            })),
            crate::linux_abi::LINUX_O_RDONLY,
            0,
        );
        let wait_fds = WaitFds::anchored_one(fds[0], libc::POLLIN, Some(owner));
        drop(open_file);

        let mut pollfd = libc::pollfd {
            fd: wait_fds[0].fd(),
            events: wait_fds[0].events(),
            revents: 0,
        };
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 0);
        // BLOCKING-IO-OK: test-only 1-byte write to a freshly created, empty pipe
        // to make its read end readable; an empty pipe buffer cannot block here.
        assert_eq!(unsafe { libc::write(fds[1], b"x".as_ptr().cast(), 1) }, 1);
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 1);
        assert_ne!(pollfd.revents & libc::POLLIN, 0);

        drop(wait_fds);
        unsafe {
            libc::close(fds[1]);
        }
    }

    #[test]
    fn wait_fds_empty_with_guest_slots_preserves_empty_authority() {
        let ids = crate::kernel::ids::ObjectIdRegistry::new();
        let files = crate::kernel::objects::FileTable::new(ids.file_table_id().expect("table ID"));
        let wait_fds = WaitFds::raw(Vec::new())
            .with_guest_slots(&files, [])
            .expect("empty fds authorized");
        assert_eq!(*wait_fds.authority(), WaitFdAuthority::Empty);
    }

    #[test]
    fn blocking_host_write_from_owned_bytes_reuses_buffer_storage() {
        let mut fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(fds.as_mut_ptr()) }, 0);

        let bytes = vec![0x5A; 4096];
        let expected_ptr = bytes.as_ptr();
        let expected_capacity = bytes.capacity();
        let write = BlockingWrite::from_vec(
            fds[1],
            bytes,
            128,
            crate::thread::ThreadId::synthetic_for_tests(0x7FFE_0102),
            true,
        )
        .expect("blocking write continuation should be created");

        unsafe {
            libc::close(fds[0]);
            libc::close(fds[1]);
        }

        assert_eq!(
            write.bytes.as_ptr(),
            expected_ptr,
            "owned handoff should move the staged write buffer without cloning it"
        );
        assert_eq!(write.bytes.capacity(), expected_capacity);
        assert_eq!(write.offset(), 128);
        assert!(write.sigpipe_on_epipe());
    }

    #[test]
    fn kernel_exec_publication_filters_cloexec_descriptors() {
        let dispatcher = SyscallDispatcher::new();
        let keep_fd = match dispatcher.install_fd_at_or_above(3, eventfd_open_file(1)) {
            Ok(fd) => fd,
            Err(_) => panic!("expected keep fd install to succeed"),
        };
        let cloexec_fd = match dispatcher.install_fd_at_or_above(
            3,
            OpenFile::from_open_description_with_status_flags(
                Arc::new(RwLock::new(OpenDescription::EventFd {
                    state: Arc::new(EventFdState::new(2)),
                    semaphore: false,
                    base: OpenDescriptionBase::new(0),
                })),
                crate::linux_abi::LINUX_O_RDWR,
                LINUX_FD_CLOEXEC,
            ),
        ) {
            Ok(fd) => fd,
            Err(_) => panic!("expected cloexec fd install to succeed"),
        };

        let context = dispatcher.capture_one_task_context().unwrap();
        let prepared = dispatcher.prepare_one_task_kernel_exec(&context).unwrap();
        dispatcher.commit_one_task_kernel_exec(prepared).unwrap();

        assert!(dispatcher.fd_is_valid(keep_fd));
        assert!(!dispatcher.fd_is_valid(cloexec_fd));
    }

    mod serial_host {
        use super::*;

        fn child_can_acquire_classic_write_lock(host_fd: i32) -> bool {
            let child = unsafe { libc::fork() };
            assert!(child >= 0, "fork lock observer");
            if child == 0 {
                let mut lock = unsafe { std::mem::zeroed::<libc::flock>() };
                lock.l_type = libc::F_WRLCK as _;
                lock.l_whence = libc::SEEK_SET as _;
                let result = unsafe { libc::fcntl(host_fd, libc::F_SETLK, &raw mut lock) };
                unsafe { libc::_exit(i32::from(result < 0)) };
            }
            let mut status = 0;
            assert_eq!(unsafe { libc::waitpid(child, &raw mut status, 0) }, child);
            libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0
        }

        #[test]
        fn non_cloexec_classic_record_lock_survives_exec_transfer() {
            let dispatcher = SyscallDispatcher::new();
            let named = tempfile::NamedTempFile::new().unwrap();
            let host_fd = std::os::fd::IntoRawFd::into_raw_fd(named.reopen().unwrap());
            let observer_fd = std::os::fd::IntoRawFd::into_raw_fd(named.reopen().unwrap());
            let mut lock = unsafe { std::mem::zeroed::<libc::flock>() };
            lock.l_type = libc::F_WRLCK as _;
            lock.l_whence = libc::SEEK_SET as _;
            assert_eq!(
                unsafe { libc::fcntl(host_fd, libc::F_SETLK, &raw mut lock) },
                0
            );
            let description = kernel_file_description(
                Arc::new(RwLock::new(OpenDescription::HostFile {
                    base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_RDWR),
                    host_fd: HostFdRef::new(host_fd),
                    metadata: RootFsMetadata {
                        path: std::path::PathBuf::from("/tmp/exec-lock"),
                        kind: RootFsEntryKind::File,
                        mode: 0o600,
                        size: 0,
                    },
                    writable: true,
                })),
                crate::linux_abi::LINUX_O_RDWR,
            );
            let fd = dispatcher
                .install_fd_at_or_above(3, OpenFile::new(Arc::clone(&description), 0))
                .unwrap();
            assert!(!child_can_acquire_classic_write_lock(observer_fd));

            let context = dispatcher.capture_one_task_context().unwrap();
            let prepared = dispatcher.prepare_one_task_kernel_exec(&context).unwrap();
            dispatcher.commit_one_task_kernel_exec(prepared).unwrap();
            assert!(!child_can_acquire_classic_write_lock(observer_fd));

            let removed = dispatcher
                .captured_file_table()
                .write_open_files()
                .remove(&fd)
                .expect("surviving lock fd");
            dispatcher.close_open_file_and_free_pty(&removed);
            assert!(child_can_acquire_classic_write_lock(observer_fd));
            unsafe { libc::close(observer_fd) };
        }

        #[test]
        fn epoll_et_repolls_host_level_when_mux_misses_wake() {
            let mut h = Harness::new();
            let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as u64;

            let pair_addr = h.reserve(8);
            assert_eq!(
                returned(h.call(
                    199,
                    [
                        LINUX_AF_UNIX as u64,
                        LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                        0,
                        pair_addr,
                        0,
                        0,
                    ],
                )),
                0
            );
            let pair = h.memory.read_bytes(pair_addr, 8).unwrap();
            let reader = i32::from_le_bytes(pair[0..4].try_into().unwrap());
            let writer = i32::from_le_bytes(pair[4..8].try_into().unwrap());

            let ev_addr = h.reserve(16);
            let mut ev = [0u8; 16];
            ev[0..4].copy_from_slice(&(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes());
            ev[8..16].copy_from_slice(&(reader as u64).to_le_bytes());
            h.memory.write_bytes(ev_addr, &ev).unwrap();
            assert_eq!(
                returned(h.call(
                    21,
                    [epfd, LINUX_EPOLL_CTL_ADD, reader as u64, ev_addr, 0, 0],
                )),
                0
            );

            let byte_addr = h.put_bytes(b"x");
            assert_eq!(
                returned(h.call(64, [writer as u64, byte_addr, 1, 0, 0, 0])),
                1
            );

            let epoll_open = h.dispatcher.open_file(epfd as i32).expect("epoll fd");
            {
                let open = epoll_open.description.read().expect("open description");
                let OpenDescription::Epoll { kqueue, .. } = &*open else {
                    panic!("epfd should be an epoll description");
                };
                let host_fd = h
                    .dispatcher
                    .host_fd_for_poll(reader)
                    .expect("reader should be host-backed");
                kqueue.with_mux(|mux| {
                    mux.deregister(host_fd.get())
                        .expect("test setup should remove host wake filter");
                });
            }

            let out_addr = h.reserve(16);
            let n = returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0]));
            assert_eq!(
                n, 1,
                "epoll_pwait must resample host fd levels when the host wake edge is stale"
            );
            let out = h.memory.read_bytes(out_addr, 16).unwrap();
            let events = u32::from_le_bytes(out[0..4].try_into().unwrap());
            let data = u64::from_le_bytes(out[8..16].try_into().unwrap());
            assert_ne!(events & LINUX_EPOLLIN, 0);
            assert_eq!(data, reader as u64);
        }
    }

    #[test]
    fn dropping_drained_exec_generation_does_not_release_surviving_slot_twice() {
        let dispatcher = SyscallDispatcher::new();
        let description = kernel_file_description(
            Arc::new(RwLock::new(OpenDescription::EventFd {
                state: Arc::new(EventFdState::new(1)),
                semaphore: false,
                base: OpenDescriptionBase::new(0),
            })),
            crate::linux_abi::LINUX_O_RDWR,
        );
        let fd = dispatcher
            .install_fd_at_or_above(3, OpenFile::new(Arc::clone(&description), 0))
            .unwrap();
        let old_context = dispatcher.capture_one_task_context().unwrap();
        let old_files = old_context.resources().files();
        let prepared = dispatcher
            .prepare_one_task_kernel_exec(&old_context)
            .unwrap();
        dispatcher.commit_one_task_kernel_exec(prepared).unwrap();

        assert_eq!(description.fd_ref_count(), 1);
        assert!(!old_files.functional_refs_active());
        drop(old_context);
        drop(old_files);
        assert_eq!(description.fd_ref_count(), 1);
        assert!(dispatcher.fd_is_valid(fd));

        let removed = dispatcher
            .captured_file_table()
            .write_open_files()
            .remove(&fd)
            .expect("surviving slot");
        dispatcher.close_open_file_and_free_pty(&removed);
        assert_eq!(description.fd_ref_count(), 0);
        assert!(matches!(
            description.read().as_deref(),
            Some(OpenDescription::Closed { .. })
        ));
    }

    #[test]
    fn retained_exec_generation_does_not_keep_cloexec_pipe_writer_alive() {
        let dispatcher = SyscallDispatcher::new();
        let mut host_fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(host_fds.as_mut_ptr()) }, 0);
        let read_host_fd = host_fds[0];
        let writer = kernel_file_description(
            Arc::new(RwLock::new(OpenDescription::HostPipe {
                host_fd: HostFdRef::new(host_fds[1]),
                is_read_end: false,
                pipe_id: 0x51,
                base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_WRONLY),
                pty: None,
                bidirectional: false,
                write_kind: HostWriteKind::PipeLike,
                stdio_stream: None,
            })),
            crate::linux_abi::LINUX_O_WRONLY,
        );
        let writer_fd = dispatcher
            .install_fd_at_or_above(3, OpenFile::new(Arc::clone(&writer), LINUX_FD_CLOEXEC))
            .unwrap();
        let old_context = dispatcher.capture_one_task_context().unwrap();
        let old_files = old_context.resources().files();
        let prepared = dispatcher
            .prepare_one_task_kernel_exec(&old_context)
            .unwrap();
        let replacement = dispatcher.commit_one_task_kernel_exec(prepared).unwrap();

        assert!(!old_files.functional_refs_active());
        assert!(old_files.read_open_files().contains_key(&writer_fd));
        assert!(replacement.resources().files().slot_count() == 0);
        assert!(matches!(
            writer.read().as_deref(),
            Some(OpenDescription::Closed { .. })
        ));

        let mut pollfd = libc::pollfd {
            fd: read_host_fd,
            events: libc::POLLIN,
            revents: 0,
        };
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 1);
        assert_ne!(pollfd.revents & libc::POLLHUP, 0);

        unsafe { libc::close(read_host_fd) };
    }

    #[test]
    fn threaded_independent_dispatch_support_matches_handler_table() {
        let supported: Vec<u64> = crate::syscall::aarch64_table()
            .iter()
            .filter(|syscall| threaded_independent_dispatch_supports(syscall.number))
            .map(|syscall| syscall.number)
            .collect();
        // Exact equality gates every independent entry, including the
        // deliberate Process/Deferred exceptions (getpid and futex_waitv),
        // while the loop below proves every ThreadLocal entry is included.
        // 130/131 are tkill/tgkill: `dispatch_threaded_independent` resolves
        // both against the kernel graph, so they are independent entries.
        assert_eq!(supported, vec![96, 98, 99, 124, 130, 131, 172, 178, 449]);

        for syscall in crate::syscall::aarch64_table() {
            if syscall.handler == crate::syscall::SyscallHandler::ThreadLocal {
                assert!(
                    threaded_independent_dispatch_supports(syscall.number),
                    "thread-local syscall {} ({}) must be handled without panicking",
                    syscall.number,
                    syscall.name
                );
            }
        }
    }

    #[test]
    fn join_rootfs_path_normalizes_relative_components() {
        assert_eq!(join_rootfs_path("/", "."), "/");
        assert_eq!(join_rootfs_path("/", ".."), "/");
        assert_eq!(join_rootfs_path("/tmp/work", ".."), "/tmp");
        assert_eq!(join_rootfs_path("/tmp/work", "../other/."), "/tmp/other");
        assert_eq!(join_rootfs_path("/tmp/work", "../../.."), "/");
    }

    #[test]
    fn exec_host_fs_fallback_off_for_container_dispatchers() {
        // A bare run-elf dispatcher (no container fs) may fall back to the host
        // filesystem for an execve target (host-staged RunElf fixtures).
        assert!(
            SyscallDispatcher::new().exec_host_fs_fallback(),
            "bare new() dispatcher must allow the host-fs execve fallback"
        );
        // A container dispatcher must NOT: a target absent from the rootfs must
        // ENOENT, never escape to the matching host binary (the containment hole
        // that loaded host glibc /usr/bin/echo into a musl rootfs mid-execvp).
        assert!(
            !SyscallDispatcher::with_rootfs(empty_rootfs()).exec_host_fs_fallback(),
            "with_rootfs dispatcher must forbid the host-fs execve fallback"
        );
        assert!(
            !SyscallDispatcher::with_rootfs_and_executable(empty_rootfs(), "/bin/sh")
                .exec_host_fs_fallback(),
            "with_rootfs_and_executable dispatcher must forbid the host-fs execve fallback"
        );
        // The overlay-only container path (run-oci / --fs host use new() +
        // set_fs_backend, not with_rootfs) opts in explicitly.
        let mut d = SyscallDispatcher::new();
        d.sandbox_exec_to_container();
        assert!(
            !d.exec_host_fs_fallback(),
            "sandbox_exec_to_container() must forbid the host-fs execve fallback"
        );
    }

    #[test]
    fn inode_for_path_reflects_identity_not_textual_spelling() {
        // The same file reached via different textual spellings must map to
        // ONE inode, or TOCTOU identity checks abort: dpkg-preconfigure stats
        // a dir, chdirs in, re-stats ".", and aborts if the inode changed
        // ("directory /var/cache/debconf/tmp.ci changed before chdir").
        // "." after chdir resolves to "/dir/.", so that must hash the same as
        // "/dir".
        let canonical = inode_for_path(Path::new("/tmp/d"));
        assert_eq!(canonical, inode_for_path(Path::new("/tmp/d/.")));
        assert_eq!(canonical, inode_for_path(Path::new("/tmp/d/")));
        assert_eq!(canonical, inode_for_path(Path::new("/tmp//d")));
        assert_eq!(canonical, inode_for_path(Path::new("/tmp/d/sub/..")));
        // Distinct files still get distinct inodes.
        assert_ne!(canonical, inode_for_path(Path::new("/tmp/e")));
        // Never zero — some tools treat st_ino == 0 as "no such entry".
        assert_ne!(inode_for_path(Path::new("/")), 0);
        assert_ne!(inode_for_path(Path::new("/tmp/d")), 0);
    }

    #[test]
    fn inode_fast_path_matches_existing_raw_normalization() {
        use std::os::unix::ffi::OsStrExt;
        let names: &[&[u8]] = &[
            b"",
            b"/",
            b"a",
            b"/a/b",
            b"//a///b/",
            b"/a/./b",
            b"/a/c/../b",
            b"/..",
            b"/a/../../b",
            b"./a",
            b"../a",
            b"/a/\xff",
            "café/文件".as_bytes(),
        ];
        for bytes in names {
            let path = Path::new(std::ffi::OsStr::from_bytes(bytes));
            let normalized = carrick_vfs::fs_backend::normalize_raw(path);
            let expected_bytes = normalized
                .as_ref()
                .map(|p| p.as_os_str().as_bytes())
                .unwrap_or(bytes);
            let expected = expected_bytes
                .iter()
                .fold(0xcbf29ce484222325_u64, |h, b| {
                    (h ^ u64::from(*b)).wrapping_mul(0x100000001b3)
                })
                .max(1);
            assert_eq!(inode_for_path(path), expected, "path={path:?}");
            let encoded = carrick_vfs::pathcodec::encode_path(path);
            assert_eq!(
                inode_for_path(Path::new(&encoded)),
                expected,
                "escaped path identity"
            );
        }
    }

    /// 16 KiB scratch buffer at virtual base 0x4000_0000. Tests pack
    /// pathnames + read/write buffers into this. The dispatcher itself
    /// only needs valid byte addresses for the syscalls under test —
    /// stat/statx writes a small fixed-size struct into the buffer.
    const MEM_BASE: u64 = 0x4000_0000;
    const MEM_LEN: usize = 16 * 1024;

    fn empty_rootfs() -> RootFs {
        // Bake a single layer containing /etc/motd and the directories
        // it lives under, so we can exercise both the rootfs-backed and
        // overlay-backed lookup paths.
        let mut buf: Vec<u8> = Vec::new();
        {
            let mut builder = Builder::new(&mut buf);
            for dir in ["etc", "var", "var/lib", "var/lib/apt"] {
                let mut h = Header::new_gnu();
                h.set_path(format!("{}/", dir)).unwrap();
                h.set_entry_type(EntryType::Directory);
                h.set_size(0);
                h.set_mode(0o755);
                h.set_cksum();
                builder.append(&h, std::io::empty()).unwrap();
            }
            let body: &[u8] = b"hello, world\n";
            let mut h = Header::new_gnu();
            h.set_path("etc/motd").unwrap();
            h.set_size(body.len() as u64);
            h.set_mode(0o644);
            h.set_cksum();
            builder.append(&h, body).unwrap();
            builder.finish().unwrap();
        }
        RootFs::from_layers(std::iter::once(LayerSource::Tar(buf))).unwrap()
    }

    #[cfg(target_os = "macos")]
    fn dispatcher_with_host_lower(
        lower: &std::path::Path,
        upper: &std::path::Path,
    ) -> SyscallDispatcher {
        let rootfs = RootFs::from_immutable_host_dir(lower).unwrap();
        let mut dispatcher = SyscallDispatcher::with_rootfs(rootfs);
        dispatcher.set_fs_backend(Box::new(
            carrick_vfs::fs_backend::HostFsBackend::from_path(upper).unwrap(),
        ));
        dispatcher
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn exec_helpers_use_bounded_reads_and_host_files_from_immutable_lower() {
        use std::io::Read as _;

        let lower = tempfile::TempDir::new().unwrap();
        let upper = tempfile::TempDir::new().unwrap();
        std::fs::create_dir_all(lower.path().join("bin")).unwrap();
        let mut payload = b"#!/bin/sh\n".to_vec();
        payload.resize(2 * 1024 * 1024, b'x');
        std::fs::write(lower.path().join("bin/tool"), &payload).unwrap();

        let dispatcher = dispatcher_with_host_lower(lower.path(), upper.path());
        assert_eq!(
            dispatcher.read_exec_file_head("/bin/tool", 4).as_deref(),
            Some(&b"#!/b"[..])
        );
        let mut file = dispatcher
            .open_exec_host_file("/bin/tool")
            .expect("lower executable should remain file-backed");
        let mut head = [0_u8; 4];
        file.read_exact(&mut head).unwrap();
        assert_eq!(&head, b"#!/b");
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn exec_helpers_never_resurrect_a_shadowed_or_tombstoned_lower() {
        use std::io::Read as _;

        let lower = tempfile::TempDir::new().unwrap();
        let upper = tempfile::TempDir::new().unwrap();
        std::fs::create_dir_all(lower.path().join("bin")).unwrap();
        std::fs::write(lower.path().join("bin/tool"), b"lower").unwrap();
        let dispatcher = dispatcher_with_host_lower(lower.path(), upper.path());

        dispatcher
            .fs
            .rootfs_vfs
            .overlay
            .set_file_contents("/bin/tool", b"upper".to_vec())
            .unwrap();
        assert_eq!(
            dispatcher.read_exec_file("/bin/tool").as_deref(),
            Some(&b"upper"[..])
        );
        let mut upper_file = dispatcher.open_exec_host_file("/bin/tool").unwrap();
        let mut bytes = Vec::new();
        upper_file.read_to_end(&mut bytes).unwrap();
        assert_eq!(bytes, b"upper");

        dispatcher
            .fs
            .rootfs_vfs
            .overlay
            .mark_deleted("/bin/tool")
            .unwrap();
        assert!(dispatcher.read_exec_file("/bin/tool").is_none());
        assert!(dispatcher.read_exec_file_head("/bin/tool", 4).is_none());
        assert!(dispatcher.open_exec_host_file("/bin/tool").is_none());
        assert_eq!(
            std::fs::read(lower.path().join("bin/tool")).unwrap(),
            b"lower"
        );
    }

    struct Harness {
        dispatcher: SyscallDispatcher,
        memory: LinearMemory,
        reporter: CompatReporter,
        cursor: u64,
    }

    impl Harness {
        fn new() -> Self {
            Self {
                dispatcher: SyscallDispatcher::with_rootfs(empty_rootfs()),
                memory: LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]),
                reporter: CompatReporter::default(),
                cursor: MEM_BASE + 4096, // leave the first page for stat bufs etc
            }
        }

        /// Copy `s` (NUL-terminated) into the guest scratch region and
        /// return its address.
        fn put_str(&mut self, s: &str) -> u64 {
            let addr = self.cursor;
            let mut bytes = s.as_bytes().to_vec();
            bytes.push(0);
            self.memory.write_bytes(addr, &bytes).unwrap();
            self.cursor += bytes.len() as u64;
            // 8-byte align for the next allocation.
            self.cursor = (self.cursor + 7) & !7;
            addr
        }

        fn put_bytes(&mut self, b: &[u8]) -> u64 {
            let addr = self.cursor;
            self.memory.write_bytes(addr, b).unwrap();
            self.cursor += b.len() as u64;
            self.cursor = (self.cursor + 7) & !7;
            addr
        }

        fn reserve(&mut self, n: usize) -> u64 {
            let addr = self.cursor;
            self.cursor += n as u64;
            self.cursor = (self.cursor + 7) & !7;
            addr
        }

        fn call(&mut self, number: u64, args: [u64; 6]) -> DispatchOutcome {
            let request = SyscallRequest::new(number, SyscallArgs(args));
            self.dispatcher
                .dispatch(
                    &self.dispatcher.capture_one_task_context().unwrap(),
                    request,
                    &mut self.memory,
                    &self.reporter,
                )
                .expect("dispatch must not surface a fatal error")
        }
    }

    fn returned(outcome: DispatchOutcome) -> i64 {
        match outcome {
            DispatchOutcome::Returned { value } => value,
            other => panic!("expected Returned, got {other:?}"),
        }
    }

    fn errno(outcome: DispatchOutcome) -> i32 {
        match outcome {
            DispatchOutcome::Errno { errno } => errno.get(),
            other => panic!("expected Errno, got {other:?}"),
        }
    }

    #[test]
    fn host_alias_transaction_id_overflow_returns_typed_error() {
        let dispatcher = SyscallDispatcher::new();
        dispatcher
            .host_alias_transactions()
            .next_id
            .store(u64::MAX, std::sync::atomic::Ordering::Relaxed);
        let result = dispatcher.with_host_alias_dispatch_for_test(|guard| {
            guard.publish(HostAliasCommit::mmap(mem::HostAliasMmapCommit {
                start: crate::memory::LINUX_HIGH_VA_THRESHOLD,
                len: LINUX_PAGE_SIZE,
                prot: LinuxProtFlags::READ,
                sharing: ProcMapSharing::Private,
                path: String::new(),
                file_page_offset: None,
                droppable: false,
                semantic_vmas: None,
                locked: None,
                resident: false,
                bus_fault: None,
                write_sealed_shared: false,
                read_only_shared_file: false,
                secretmem: false,
                writable_memfd: None,
                private_file: None,
                shared_file_alias: None,
            }))
        });
        assert!(matches!(
            result,
            Err(crate::run_result::RuntimeError::CarrierFailed(_))
        ));
    }

    #[test]
    fn try_set_credentials_and_cwd_succeed() {
        let dispatcher = SyscallDispatcher::new();
        assert!(
            dispatcher
                .try_set_credentials(carrick_abi::NsUid::new(1000), carrick_abi::NsGid::new(1000))
                .is_ok()
        );
        assert!(dispatcher.try_set_cwd("/test_dir").is_ok());
        assert_eq!(dispatcher.try_cwd().unwrap(), "/test_dir");
        assert!(dispatcher.try_mem_snapshot().is_ok());
    }

    #[test]
    fn empty_epoll_wait_captures_epfd_and_rejects_same_number_reuse() {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as i32;
        let out = h.reserve(16);
        let outcome = h.call(22, [epfd as u64, out, 1, u64::MAX, 0, 0]);
        let authority = match outcome {
            DispatchOutcome::WaitOnFds { fds, .. } => {
                assert_eq!(
                    fds.first().map(|(_, events)| events),
                    Some(libc::POLLIN),
                    "empty-interest wait subscribes to the shared epoll mutation source"
                );
                assert_eq!(
                    fds.logical_authorities_for_test().len(),
                    1,
                    "empty-interest wait still re-resolves epfd on redispatch"
                );
                fds.logical_authorities_for_test()[0]
            }
            other => panic!("expected empty epoll wait, got {other:?}"),
        };
        let context = h.dispatcher.capture_one_task_context().expect("context");
        let files = context.resources().files();
        let number = crate::kernel::FileSlotNumber::for_open_fd(epfd).expect("epfd slot");
        let ids = crate::kernel::ObjectIdRegistry::new();
        files.install(
            number,
            Arc::new(crate::kernel::FileDescription::regular(
                ids.file_description_id().expect("successor description"),
            )),
            false,
        );
        assert!(
            !files.validate_slot_authority(authority),
            "old empty-epoll readiness cannot authorize a successor epfd"
        );
    }

    #[test]
    fn empty_epoll_interest_add_publishes_the_shared_mutation_source() {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as i32;
        let out = h.reserve(16);
        let kqueue_fd = match h.call(22, [epfd as u64, out, 1, u64::MAX, 0, 0]) {
            DispatchOutcome::WaitOnFds { fds, .. } => fds.first().expect("epoll mutation source").0,
            other => panic!("expected shared epoll source, got {other:?}"),
        };
        let ready = returned(h.call(19, [1, 0, 0, 0, 0, 0])) as i32;
        let event_addr = h.reserve(16);
        let mut event = [0u8; 16];
        event[0..4].copy_from_slice(&LINUX_EPOLLIN.to_le_bytes());
        event[8..16].copy_from_slice(&0xbeef_u64.to_le_bytes());
        h.memory.write_bytes(event_addr, &event).expect("event");
        assert_eq!(
            returned(h.call(
                21,
                [
                    epfd as u64,
                    LINUX_EPOLL_CTL_ADD,
                    ready as u64,
                    event_addr,
                    0,
                    0,
                ],
            )),
            0
        );
        let mut pollfd = libc::pollfd {
            fd: kqueue_fd,
            events: libc::POLLIN,
            revents: 0,
        };
        // SAFETY: `kqueue_fd` is the live epoll instance source and `pollfd`
        // names one initialized record. The zero timeout only performs the
        // durable post-registration recheck used by the carrier reactor.
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 1);
        assert_ne!(pollfd.revents & libc::POLLIN, 0);
    }

    #[test]
    fn epoll_watched_reuse_recomputes_registry_without_retargeting_successor() {
        let mut h = Harness::new();
        let watched = returned(h.call(19, [0, 0, 0, 0, 0, 0])) as i32;
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as i32;
        let event_addr = h.reserve(16);
        let mut event = [0u8; 16];
        event[0..4].copy_from_slice(&LINUX_EPOLLIN.to_le_bytes());
        event[8..16].copy_from_slice(&(0xfeed_u64).to_le_bytes());
        h.memory.write_bytes(event_addr, &event).expect("event");
        assert_eq!(
            returned(h.call(
                21,
                [
                    epfd as u64,
                    LINUX_EPOLL_CTL_ADD,
                    watched as u64,
                    event_addr,
                    0,
                    0,
                ],
            )),
            0
        );
        let out = h.reserve(16);
        let blocked = h.call(22, [epfd as u64, out, 1, u64::MAX, 0, 0]);
        let fds = match blocked {
            DispatchOutcome::WaitOnFds { fds, .. } => fds,
            other => panic!("expected blocked epoll, got {other:?}"),
        };
        assert_eq!(fds.logical_authorities_for_test().len(), 1);
        assert_eq!(fds.watched_authorities_for_test().len(), 1);

        assert_eq!(returned(h.call(57, [watched as u64, 0, 0, 0, 0, 0])), 0);
        let successor = returned(h.call(19, [1, 0, 0, 0, 0, 0])) as i32;
        assert_eq!(successor, watched, "numeric slot must be reused");
        assert_eq!(
            returned(h.call(22, [epfd as u64, out, 1, 0, 0, 0])),
            0,
            "old epoll interest was removed; ready successor is not retargeted"
        );
    }

    #[test]
    fn blocked_sendfile_captures_input_and_output_before_input_reuse() {
        let mut h = Harness::new();
        let path = h.put_str("/sendfile-authority");
        let input = returned(h.call(56, [(-100i64) as u64, path, O_CREAT | 2, 0o600, 0, 0])) as i32;
        let byte = h.put_bytes(b"x");
        assert_eq!(returned(h.call(64, [input as u64, byte, 1, 0, 0, 0])), 1);
        assert_eq!(returned(h.call(62, [input as u64, 0, 0, 0, 0, 0])), 0);

        let pair = h.reserve(8);
        assert_eq!(returned(h.call(59, [pair, 0, 0, 0, 0, 0])), 0);
        let pair_bytes = h.memory.read_bytes(pair, 8).expect("pipe pair");
        let output = i32::from_le_bytes(pair_bytes[4..8].try_into().expect("writer"));
        let fill = h.put_bytes(&vec![0x5au8; 4096]);
        for _ in 0..16 {
            assert_eq!(
                returned(h.call(64, [output as u64, fill, 4096, 0, 0, 0])),
                4096
            );
        }

        let outcome = h.call(71, [output as u64, input as u64, 0, 1, 0, 0]);
        let authorities = match outcome {
            DispatchOutcome::WaitOnFds { fds, .. } => {
                assert_eq!(fds.logical_authorities_for_test().len(), 2);
                fds.logical_authorities_for_test().to_vec()
            }
            other => panic!("expected blocked sendfile, got {other:?}"),
        };
        let context = h.dispatcher.capture_one_task_context().expect("context");
        let files = context.resources().files();
        let input_slot = crate::kernel::FileSlotNumber::for_open_fd(input).expect("input slot");
        let ids = crate::kernel::ObjectIdRegistry::new();
        files.install(
            input_slot,
            Arc::new(crate::kernel::FileDescription::regular(
                ids.file_description_id().expect("successor input"),
            )),
            false,
        );
        assert!(
            authorities
                .iter()
                .any(|authority| !files.validate_slot_authority(*authority)),
            "old blocked sendfile cannot re-resolve a reused input slot"
        );
    }

    #[test]
    fn epoll_et_delivers_new_host_edge_while_level_still_ready() {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as u64;

        let pair_addr = h.reserve(8);
        assert_eq!(
            returned(h.call(
                199,
                [
                    LINUX_AF_UNIX as u64,
                    LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                    0,
                    pair_addr,
                    0,
                    0,
                ],
            )),
            0
        );
        let pair = h.memory.read_bytes(pair_addr, 8).unwrap();
        let reader = i32::from_le_bytes(pair[0..4].try_into().unwrap());
        let writer = i32::from_le_bytes(pair[4..8].try_into().unwrap());

        let ev_addr = h.reserve(16);
        let mut ev = [0u8; 16];
        ev[0..4].copy_from_slice(&(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes());
        ev[8..16].copy_from_slice(&(reader as u64).to_le_bytes());
        h.memory.write_bytes(ev_addr, &ev).unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, reader as u64, ev_addr, 0, 0],
            )),
            0
        );

        let first_addr = h.put_bytes(b"a");
        assert_eq!(
            returned(h.call(64, [writer as u64, first_addr, 1, 0, 0, 0])),
            1
        );
        let out_addr = h.reserve(16);
        assert_eq!(returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0])), 1);

        let second_addr = h.put_bytes(b"b");
        assert_eq!(
            returned(h.call(64, [writer as u64, second_addr, 1, 0, 0, 0])),
            1
        );
        let n = returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0]));
        assert_eq!(
            n, 1,
            "a new host ET edge must be delivered even while the fd remains level-readable"
        );
        let out = h.memory.read_bytes(out_addr, 16).unwrap();
        let events = u32::from_le_bytes(out[0..4].try_into().unwrap());
        let data = u64::from_le_bytes(out[8..16].try_into().unwrap());
        assert_ne!(events & LINUX_EPOLLIN, 0);
        assert_eq!(data, reader as u64);
    }

    #[test]
    fn io_uring_fd_generic_operations_match_linux_anonymous_inode_semantics() {
        let mut h = Harness::new();
        let params = h.reserve(core::mem::size_of::<crate::linux_abi::LinuxIoUringParams>());
        let ring_fd = returned(h.call(425, [8, params, 0, 0, 0, 0])) as i32;

        let stat = h.reserve(core::mem::size_of::<crate::linux_abi::LinuxStat>());
        assert_eq!(returned(h.call(80, [ring_fd as u64, stat, 0, 0, 0, 0])), 0);
        assert_eq!(
            returned(h.call(25, [ring_fd as u64, LINUX_F_GETFL, 0, 0, 0, 0])),
            LINUX_O_RDWR as i64
        );
        let byte = h.put_bytes(&[0]);
        assert_eq!(
            errno(h.call(63, [ring_fd as u64, byte, 1, 0, 0, 0])),
            LINUX_EINVAL.get()
        );
        assert_eq!(
            errno(h.call(64, [ring_fd as u64, byte, 1, 0, 0, 0])),
            LINUX_EINVAL.get()
        );

        let path = h.put_str(&format!("/proc/self/fd/{ring_fd}"));
        let link = h.reserve(64);
        let link_len = returned(h.call(78, [LINUX_AT_FDCWD, path, link, 64, 0, 0])) as usize;
        assert_eq!(
            h.memory.read_bytes(link, link_len).unwrap(),
            b"anon_inode:[io_uring]"
        );

        let pollfd = h.put_bytes(
            &[
                (ring_fd as u32).to_le_bytes().as_slice(),
                LINUX_POLLOUT.to_le_bytes().as_slice(),
                0_i16.to_le_bytes().as_slice(),
            ]
            .concat(),
        );
        assert_eq!(returned(h.call(73, [pollfd, 1, 0, 0, 0, 0])), 1);
        let observed = h.memory.read_bytes(pollfd, 8).unwrap();
        assert_ne!(
            i16::from_le_bytes(observed[6..8].try_into().unwrap()) & LINUX_POLLOUT,
            0
        );

        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as i32;
        let event = h.put_bytes(
            &[
                LINUX_EPOLLIN.to_le_bytes().as_slice(),
                0_u32.to_le_bytes().as_slice(),
                1_u64.to_le_bytes().as_slice(),
            ]
            .concat(),
        );
        assert_eq!(
            returned(h.call(
                21,
                [
                    epfd as u64,
                    LINUX_EPOLL_CTL_ADD,
                    ring_fd as u64,
                    event,
                    0,
                    0,
                ],
            )),
            0
        );
    }

    #[test]
    fn epoll_et_read_via_dup_rearms_registered_sibling() {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as u64;

        let pair_addr = h.reserve(8);
        assert_eq!(
            returned(h.call(
                199,
                [
                    LINUX_AF_UNIX as u64,
                    LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                    0,
                    pair_addr,
                    0,
                    0,
                ],
            )),
            0
        );
        let pair = h.memory.read_bytes(pair_addr, 8).unwrap();
        let reader = i32::from_le_bytes(pair[0..4].try_into().unwrap());
        let writer = i32::from_le_bytes(pair[4..8].try_into().unwrap());
        let registered_reader = returned(h.call(23, [reader as u64, 0, 0, 0, 0, 0])) as i32;
        assert_eq!(
            h.dispatcher.host_fd_for_poll(reader),
            h.dispatcher.host_fd_for_poll(registered_reader),
            "dup siblings should share the same host fd"
        );

        let ev_addr = h.reserve(16);
        let mut ev = [0u8; 16];
        ev[0..4].copy_from_slice(&(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes());
        ev[8..16].copy_from_slice(&(registered_reader as u64).to_le_bytes());
        h.memory.write_bytes(ev_addr, &ev).unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [
                    epfd,
                    LINUX_EPOLL_CTL_ADD,
                    registered_reader as u64,
                    ev_addr,
                    0,
                    0,
                ],
            )),
            0
        );
        let epoll_description = h
            .dispatcher
            .open_file(epfd as i32)
            .expect("epoll description")
            .description;
        let target_description = h
            .dispatcher
            .open_file(registered_reader)
            .expect("registered description")
            .description;
        let (_, is_epoll, interests, backing, owners, _, _) = epoll_description
            .snapshot_for_test(std::time::Instant::now() + std::time::Duration::from_secs(1))
            .expect("concrete epoll snapshot");
        assert!(is_epoll);
        assert_eq!(interests, vec![target_description.id()]);
        assert!(owners.is_empty());
        let backing = backing.expect("concrete backing summary");
        assert_eq!(
            backing.kind(),
            crate::kernel::FileDescriptionBackingKind::Epoll
        );
        assert_eq!(backing.epoll_interests(), interests);

        let out_addr = h.reserve(16);
        let first_addr = h.put_bytes(b"a");
        assert_eq!(
            returned(h.call(64, [writer as u64, first_addr, 1, 0, 0, 0])),
            1
        );
        assert_eq!(returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0])), 1);

        let read_addr = h.reserve(1);
        let read_args = SyscallArgs::from([reader as u64, read_addr, 1, 0, 0, 0]);
        let read_request = SyscallRequest::new(63, read_args);
        let read_outcome = h
            .dispatcher
            .dispatch(
                &h.dispatcher.capture_one_task_context().unwrap(),
                read_request,
                &mut h.memory,
                &h.reporter,
            )
            .expect("read dispatch");
        assert!(matches!(
            read_outcome,
            DispatchOutcome::Returned { value: 1 }
        ));
        assert!(
            h.dispatcher
                .captured_file_table()
                .read_epoll_fds()
                .contains(&(epfd as i32)),
            "epoll fd should be tracked for rearm"
        );
        h.dispatcher
            .epoll_rearm_after_io(&read_request, &read_outcome);
        {
            let epoll_open = h.dispatcher.open_file(epfd as i32).expect("epoll fd");
            let open = epoll_open
                .description
                .read()
                .expect("epoll open description");
            let OpenDescription::Epoll { interest, .. } = &*open else {
                panic!("epfd should be an epoll description");
            };
            let slot = interest
                .get(&registered_reader)
                .expect("registered dup interest");
            assert_eq!(
                slot.last_ready & LINUX_EPOLLIN,
                0,
                "read through a dup sibling must clear the registered fd latch"
            );
        }

        let second_addr = h.put_bytes(b"b");
        assert_eq!(
            returned(h.call(64, [writer as u64, second_addr, 1, 0, 0, 0])),
            1
        );
        let host_fd = h
            .dispatcher
            .host_fd_for_poll(registered_reader)
            .expect("registered reader host fd");
        let mut pfd = libc::pollfd {
            fd: host_fd.get(),
            events: libc::POLLIN,
            revents: 0,
        };
        let poll_rc = unsafe { libc::poll(&mut pfd, 1, 0) };
        assert_eq!(poll_rc, 1, "second write should make host fd readable");
        assert_ne!(pfd.revents & libc::POLLIN, 0);
        let n = returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0]));
        assert_eq!(
            n, 1,
            "consuming readiness through a dup sibling must re-arm ET interest"
        );
        let out = h.memory.read_bytes(out_addr, 16).unwrap();
        let events = u32::from_le_bytes(out[0..4].try_into().unwrap());
        let data = u64::from_le_bytes(out[8..16].try_into().unwrap());
        assert_ne!(events & LINUX_EPOLLIN, 0);
        assert_eq!(data, registered_reader as u64);
    }

    // The host TCP handshake that completes a listening socket's accept queue
    // is asynchronous relative to `connect()` returning on the client side: the
    // client-side call can return before the LISTENER side's kernel state (and
    // thus carrick's epoll/kqueue bridge) has observed the new connection. A
    // single immediate `epoll_wait` can therefore race a real, still-in-flight
    // host completion (a time-assumption, not a dispatcher correctness issue —
    // once the edge is observed it is never re-delivered, so retrying only
    // gives the async completion a bounded, unhurried chance to land before
    // failing the assertion for real).
    fn epoll_wait_ready(h: &mut Harness, epfd: u64, out_addr: u64) -> i64 {
        let start = std::time::Instant::now();
        loop {
            let n = returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0]));
            if n != 0 || start.elapsed() >= std::time::Duration::from_millis(200) {
                return n;
            }
            std::thread::sleep(std::time::Duration::from_millis(1));
        }
    }

    #[test]
    fn epoll_et_delivers_listener_edge_without_read_byte_growth() {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as u64;

        let listener = returned(h.call(
            198,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        )) as i32;

        let bind_addr = h.reserve(16);
        let mut sockaddr = [0u8; 16];
        sockaddr[0..2].copy_from_slice(&(LINUX_AF_INET as u16).to_ne_bytes());
        sockaddr[2..4].copy_from_slice(&0u16.to_be_bytes());
        sockaddr[4..8].copy_from_slice(&[127, 0, 0, 1]);
        h.memory.write_bytes(bind_addr, &sockaddr).unwrap();
        assert_eq!(
            returned(h.call(200, [listener as u64, bind_addr, 16, 0, 0, 0])),
            0
        );
        assert_eq!(returned(h.call(201, [listener as u64, 8, 0, 0, 0, 0])), 0);

        let name_addr = h.reserve(16);
        let name_len_addr = h.reserve(4);
        h.memory
            .write_bytes(name_len_addr, &(16u32).to_ne_bytes())
            .unwrap();
        assert_eq!(
            returned(h.call(204, [listener as u64, name_addr, name_len_addr, 0, 0, 0],)),
            0
        );
        let bound = h.memory.read_bytes(name_addr, 16).unwrap();
        let port = u16::from_be_bytes([bound[2], bound[3]]);
        assert_ne!(port, 0);

        let ev_addr = h.reserve(16);
        let mut ev = [0u8; 16];
        ev[0..4].copy_from_slice(&(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes());
        ev[8..16].copy_from_slice(&(listener as u64).to_le_bytes());
        h.memory.write_bytes(ev_addr, &ev).unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, listener as u64, ev_addr, 0, 0],
            )),
            0
        );

        let mut host_addr: libc::sockaddr_in = unsafe { std::mem::zeroed() };
        #[cfg(any(
            target_os = "macos",
            target_os = "freebsd",
            target_os = "netbsd",
            target_os = "openbsd",
            target_os = "dragonfly"
        ))]
        {
            host_addr.sin_len = std::mem::size_of::<libc::sockaddr_in>() as u8;
        }
        host_addr.sin_family = libc::AF_INET as libc::sa_family_t;
        host_addr.sin_port = port.to_be();
        host_addr.sin_addr = libc::in_addr {
            s_addr: u32::from_ne_bytes([127, 0, 0, 1]),
        };
        let connect_client = || {
            let client = unsafe { libc::socket(libc::AF_INET, libc::SOCK_STREAM, 0) };
            assert!(client >= 0, "host client socket");
            let rc = unsafe {
                libc::connect(
                    client,
                    &host_addr as *const _ as *const libc::sockaddr,
                    std::mem::size_of::<libc::sockaddr_in>() as libc::socklen_t,
                )
            };
            assert_eq!(rc, 0, "host client connect");
            client
        };

        let out_addr = h.reserve(16);
        let client1 = connect_client();
        assert_eq!(epoll_wait_ready(&mut h, epfd, out_addr), 1);
        assert_eq!(
            returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0])),
            0,
            "EPOLLET must not blindly redeliver a still-unaccepted listener level"
        );

        let client2 = connect_client();
        let n = epoll_wait_ready(&mut h, epfd, out_addr);
        unsafe {
            libc::close(client1);
            libc::close(client2);
        }
        assert_eq!(
            n, 1,
            "a later listener EPOLLET edge must be delivered even though FIONREAD stays zero"
        );
        let out = h.memory.read_bytes(out_addr, 16).unwrap();
        let events = u32::from_le_bytes(out[0..4].try_into().unwrap());
        let data = u64::from_le_bytes(out[8..16].try_into().unwrap());
        assert_ne!(events & LINUX_EPOLLIN, 0);
        assert_eq!(data, listener as u64);
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn epoll_et_host_then_inzone_arrival_tracks_separate_latches() {
        check_mixed_listener_arrivals(false);
    }

    #[cfg(target_os = "macos")]
    #[test]
    fn epoll_et_inzone_then_host_arrival_tracks_separate_latches() {
        check_mixed_listener_arrivals(true);
    }

    /// Each order starts with a fresh listener, so the second source cannot
    /// inherit a baseline from an earlier arrival of the same source.
    #[cfg(target_os = "macos")]
    fn check_mixed_listener_arrivals(inzone_first: bool) {
        use carrick_abi::{LINUX_SO_ERROR, LINUX_SOL_SOCKET};

        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as u64;
        let listener = returned(h.call(
            198,
            [
                LINUX_AF_INET as u64,
                LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                0,
                0,
                0,
                0,
            ],
        )) as i32;
        let bind_addr = h.reserve(16);
        let mut sockaddr = [0u8; 16];
        sockaddr[0..2].copy_from_slice(&(LINUX_AF_INET as u16).to_ne_bytes());
        sockaddr[2..4].copy_from_slice(&0u16.to_be_bytes());
        sockaddr[4..8].copy_from_slice(&[127, 0, 0, 1]);
        h.memory.write_bytes(bind_addr, &sockaddr).unwrap();
        assert_eq!(
            returned(h.call(200, [listener as u64, bind_addr, 16, 0, 0, 0])),
            0
        );
        assert_eq!(returned(h.call(201, [listener as u64, 128, 0, 0, 0, 0])), 0);

        let name_addr = h.reserve(16);
        let name_len_addr = h.reserve(4);
        h.memory
            .write_bytes(name_len_addr, &(16u32).to_ne_bytes())
            .unwrap();
        assert_eq!(
            returned(h.call(204, [listener as u64, name_addr, name_len_addr, 0, 0, 0])),
            0
        );
        let bound = h.memory.read_bytes(name_addr, 16).unwrap();
        let port = u16::from_be_bytes([bound[2], bound[3]]);

        let event_addr = h.reserve(16);
        let mut event = [0u8; 16];
        event[0..4].copy_from_slice(&(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes());
        event[8..16].copy_from_slice(&(listener as u64).to_le_bytes());
        h.memory.write_bytes(event_addr, &event).unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, listener as u64, event_addr, 0, 0]
            )),
            0
        );

        let connect_guest = |h: &mut Harness| {
            let client = returned(h.call(
                198,
                [
                    LINUX_AF_INET as u64,
                    LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                    0,
                    0,
                    0,
                    0,
                ],
            )) as i32;
            let client_addr = h.reserve(16);
            let mut target = [0u8; 16];
            target[0..2].copy_from_slice(&(LINUX_AF_INET as u16).to_ne_bytes());
            target[2..4].copy_from_slice(&port.to_be_bytes());
            target[4..8].copy_from_slice(&[127, 0, 0, 1]);
            h.memory.write_bytes(client_addr, &target).unwrap();
            assert_eq!(
                errno(h.call(203, [client as u64, client_addr, 16, 0, 0, 0])),
                115
            );

            let poll_addr = h.reserve(8);
            let timeout_addr = h.reserve(16);
            let mut pollfd = [0u8; 8];
            pollfd[0..4].copy_from_slice(&client.to_le_bytes());
            pollfd[4..6].copy_from_slice(&LINUX_POLLOUT.to_le_bytes());
            h.memory.write_bytes(poll_addr, &pollfd).unwrap();
            let mut timeout = [0u8; 16];
            timeout[0..8].copy_from_slice(&1i64.to_le_bytes());
            h.memory.write_bytes(timeout_addr, &timeout).unwrap();
            match h.call(73, [poll_addr, 1, timeout_addr, 0, 0, 0]) {
                DispatchOutcome::Returned { value } => assert_eq!(value, 1),
                DispatchOutcome::WaitOnFds { fds, .. } => {
                    let (host_fd, events) = fds.first().expect("connect wait fd");
                    let mut pfd = libc::pollfd {
                        fd: host_fd,
                        events,
                        revents: 0,
                    };
                    assert_eq!(
                        unsafe { libc::poll(&mut pfd, 1, 1000) },
                        1,
                        "connect completion"
                    );
                    assert_eq!(
                        returned(h.call(73, [poll_addr, 1, timeout_addr, 0, 0, 0])),
                        1
                    );
                }
                other => panic!("ppoll guest nonblocking connect: {other:?}"),
            }
            let revents = i16::from_le_bytes(
                h.memory
                    .read_bytes(poll_addr + 6, 2)
                    .unwrap()
                    .try_into()
                    .unwrap(),
            );
            assert_ne!(revents & LINUX_POLLOUT, 0);
            let error_addr = h.reserve(4);
            let error_len_addr = h.reserve(4);
            h.memory
                .write_bytes(error_len_addr, &4u32.to_le_bytes())
                .unwrap();
            assert_eq!(
                returned(h.call(
                    209,
                    [
                        client as u64,
                        LINUX_SOL_SOCKET as u64,
                        LINUX_SO_ERROR as u64,
                        error_addr,
                        error_len_addr,
                        0
                    ]
                )),
                0
            );
            assert_eq!(
                i32::from_le_bytes(
                    h.memory
                        .read_bytes(error_addr, 4)
                        .unwrap()
                        .try_into()
                        .unwrap()
                ),
                0
            );
            client
        };

        let out_addr = h.reserve(16);
        let host_addr = std::net::SocketAddr::from(([127, 0, 0, 1], port));
        let connect_host = || {
            std::net::TcpStream::connect_timeout(&host_addr, Duration::from_secs(1))
                .expect("host TCP connection completes")
        };
        // Keep host clients alive with RAII, including during assertion unwind.
        let mut host_clients = Vec::new();
        if inzone_first {
            connect_guest(&mut h);
        } else {
            host_clients.push(connect_host());
        }
        assert_eq!(epoll_wait_ready(&mut h, epfd, out_addr), 1);
        assert_eq!(
            returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0])),
            0,
            "first unread arrival must not be delivered twice"
        );

        if inzone_first {
            host_clients.push(connect_host());
        } else {
            connect_guest(&mut h);
        }
        assert_eq!(
            epoll_wait_ready(&mut h, epfd, out_addr),
            1,
            "arrival from the other source must produce a fresh edge"
        );
        let event = h.memory.read_bytes(out_addr, 16).unwrap();
        assert_ne!(
            u32::from_le_bytes(event[0..4].try_into().unwrap()) & LINUX_EPOLLIN,
            0
        );
        assert_eq!(
            u64::from_le_bytes(event[8..16].try_into().unwrap()),
            listener as u64
        );
        assert_eq!(
            returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0])),
            0,
            "second unread arrival must not be delivered twice"
        );
    }

    // A listener's ET readiness is "a connection ARRIVED since you last
    // drained", NOT "the accept queue got deeper": its readiness COUNT (the
    // kqueue `EVFILT_READ` `data` = pending accept-queue depth, which is the
    // only count a listener has — FIONREAD is always 0) is not monotonic,
    // because accepting drains it. So the low-rate SEQUENTIAL-connect shape
    // below cycles the depth 0 -> 1 -> 0 and every arrival after the first is
    // reported at a depth EQUAL to (never greater than) the depth the previous
    // edge was reported at:
    //
    //   connN arrives (depth 1) -> epoll_wait MUST deliver the edge
    //   accept to EAGAIN        (depth 0)
    //
    // `epoll_pwait`'s depth-growth term (`observed > last_read_avail`) cannot
    // see that arrival — it is the CONSUMPTION re-arm (`epoll_rearm_after_io`:
    // an accept-family syscall on the listener clears the read latch AND zeroes
    // the count baseline) that turns it back into a fresh `raw & !last_ready`
    // edge. This test pins that contract from the guest's side: if the drain
    // ever stopped resetting the latch/baseline (e.g. by decrementing the depth
    // instead of clearing it), connection N would stall until connection N+1
    // pushed the depth to 2 — a real hang for an ET accept loop.
    // (Sibling test `..._without_read_byte_growth` drives the depth
    // MONOTONICALLY 1 -> 2 without ever accepting, so it covers only the
    // growth term and cannot see this.)
    #[test]
    fn epoll_et_delivers_listener_edge_after_accept_drain() {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as u64;

        // Non-blocking listener: the ET contract is "accept until EAGAIN".
        let listener = returned(h.call(
            198,
            [
                LINUX_AF_INET as u64,
                LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                0,
                0,
                0,
                0,
            ],
        )) as i32;

        let bind_addr = h.reserve(16);
        let mut sockaddr = [0u8; 16];
        sockaddr[0..2].copy_from_slice(&(LINUX_AF_INET as u16).to_ne_bytes());
        sockaddr[2..4].copy_from_slice(&0u16.to_be_bytes());
        sockaddr[4..8].copy_from_slice(&[127, 0, 0, 1]);
        h.memory.write_bytes(bind_addr, &sockaddr).unwrap();
        assert_eq!(
            returned(h.call(200, [listener as u64, bind_addr, 16, 0, 0, 0])),
            0
        );
        assert_eq!(returned(h.call(201, [listener as u64, 8, 0, 0, 0, 0])), 0);

        let name_addr = h.reserve(16);
        let name_len_addr = h.reserve(4);
        h.memory
            .write_bytes(name_len_addr, &(16u32).to_ne_bytes())
            .unwrap();
        assert_eq!(
            returned(h.call(204, [listener as u64, name_addr, name_len_addr, 0, 0, 0],)),
            0
        );
        let bound = h.memory.read_bytes(name_addr, 16).unwrap();
        let port = u16::from_be_bytes([bound[2], bound[3]]);
        assert_ne!(port, 0);

        let ev_addr = h.reserve(16);
        let mut ev = [0u8; 16];
        ev[0..4].copy_from_slice(&(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes());
        ev[8..16].copy_from_slice(&(listener as u64).to_le_bytes());
        h.memory.write_bytes(ev_addr, &ev).unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, listener as u64, ev_addr, 0, 0],
            )),
            0
        );

        let listener_host_fd = h
            .dispatcher
            .host_fd_for_poll(listener)
            .expect("listener host fd")
            .get();

        let mut host_addr: libc::sockaddr_in = unsafe { std::mem::zeroed() };
        #[cfg(any(
            target_os = "macos",
            target_os = "freebsd",
            target_os = "netbsd",
            target_os = "openbsd",
            target_os = "dragonfly"
        ))]
        {
            host_addr.sin_len = std::mem::size_of::<libc::sockaddr_in>() as u8;
        }
        host_addr.sin_family = libc::AF_INET as libc::sa_family_t;
        host_addr.sin_port = port.to_be();
        host_addr.sin_addr = libc::in_addr {
            s_addr: u32::from_ne_bytes([127, 0, 0, 1]),
        };
        // The TCP handshake is asynchronous relative to the client's connect()
        // returning, so BLOCK (bounded) on the listener's host readability
        // instead of sleeping: once poll(2) reports POLLIN the connection is in
        // the accept queue and every assertion below is deterministic.
        let connect_client = || {
            let client = unsafe { libc::socket(libc::AF_INET, libc::SOCK_STREAM, 0) };
            assert!(client >= 0, "host client socket");
            let rc = unsafe {
                libc::connect(
                    client,
                    &host_addr as *const _ as *const libc::sockaddr,
                    std::mem::size_of::<libc::sockaddr_in>() as libc::socklen_t,
                )
            };
            assert_eq!(rc, 0, "host client connect");
            let mut pfd = libc::pollfd {
                fd: listener_host_fd,
                events: libc::POLLIN,
                revents: 0,
            };
            let poll_rc = unsafe { libc::poll(&mut pfd, 1, 10_000) };
            assert_eq!(poll_rc, 1, "listener must become readable after connect");
            assert_ne!(pfd.revents & libc::POLLIN, 0);
            client
        };

        let out_addr = h.reserve(16);
        let accepted_addr = h.reserve(16);
        let accepted_len_addr = h.reserve(4);
        let accept_once = |h: &mut Harness| {
            h.memory
                .write_bytes(accepted_len_addr, &(16u32).to_ne_bytes())
                .unwrap();
            h.call(
                202,
                [listener as u64, accepted_addr, accepted_len_addr, 0, 0, 0],
            )
        };
        let listener_latch = |h: &Harness| {
            let epoll_open = h.dispatcher.open_file(epfd as i32).expect("epoll fd");
            let open = epoll_open
                .description
                .read()
                .expect("epoll open description");
            let OpenDescription::Epoll { interest, .. } = &*open else {
                panic!("epfd should be an epoll description");
            };
            let slot = interest.get(&listener).expect("listener interest");
            (slot.last_ready, slot.last_read_avail)
        };

        let mut clients = Vec::new();
        let mut accepted = Vec::new();
        let mut latch_after_drain = Vec::new();
        // Three sequential arrivals. Round 1 is the only one a "count grew"
        // predicate could carry; rounds 2 and 3 arrive at the SAME depth (1)
        // round 1 was reported at.
        for round in 1..=3 {
            clients.push(connect_client());

            let n = returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0]));
            assert_eq!(
                n, 1,
                "round {round}: the listener EPOLLET edge for a connection that \
                 arrived after an accept-drain must be delivered — the depth is \
                 back at 1, so growth-over-baseline cannot see it"
            );
            let out = h.memory.read_bytes(out_addr, 16).unwrap();
            let events = u32::from_le_bytes(out[0..4].try_into().unwrap());
            let data = u64::from_le_bytes(out[8..16].try_into().unwrap());
            assert_ne!(events & LINUX_EPOLLIN, 0, "round {round}: EPOLLIN");
            assert_eq!(data, listener as u64, "round {round}: epoll_data");
            let (last_ready, _) = listener_latch(&h);
            assert_ne!(
                last_ready & LINUX_EPOLLIN,
                0,
                "round {round}: delivery must latch the reported readiness"
            );

            // The same, still-unaccepted connection must NOT be redelivered:
            // the latch masks it and the count baseline records the depth it was
            // reported at, so the not-yet-drained kqueue knote cannot masquerade
            // as growth.
            assert_eq!(
                returned(h.call(22, [epfd, out_addr, 1, 0, 0, 0])),
                0,
                "round {round}: EPOLLET must not redeliver a still-unaccepted \
                 listener level"
            );

            // Drain to EAGAIN, exactly as an ET accept loop does.
            let fd = returned(accept_once(&mut h)) as i32;
            assert!(fd >= 0, "round {round}: accept must yield the connection");
            accepted.push(fd);
            assert_eq!(
                errno(accept_once(&mut h)),
                LINUX_EAGAIN.get(),
                "round {round}: listener must drain to EAGAIN"
            );

            latch_after_drain.push((round, listener_latch(&h)));
        }

        for client in clients {
            unsafe { libc::close(client) };
        }

        // The MECHANISM behind the deliveries above, asserted after the fact so
        // a regression reports the guest-visible stall first: the drain is what
        // re-arms the ET edge, so both the latch and the depth baseline must be
        // back to "nothing reported" and the next arrival is a fresh
        // `raw & !last_ready` edge at depth 1 again.
        for (round, latch) in latch_after_drain {
            assert_eq!(
                latch,
                (0, 0),
                "round {round}: an accept-drain must reset the listener ET read \
                 latch AND its readiness-count baseline"
            );
        }
    }

    fn staged_write_fixture() -> (Harness, u64, i32, u64) {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0; 6])) as u64;
        let pair_addr = h.reserve(8);
        assert_eq!(
            returned(h.call(
                199,
                [
                    LINUX_AF_UNIX as u64,
                    LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                    0,
                    pair_addr,
                    0,
                    0
                ]
            )),
            0
        );
        let pair = h.memory.read_bytes(pair_addr, 8).unwrap();
        let writer = i32::from_le_bytes(pair[..4].try_into().unwrap());
        let mut event = [0u8; 16];
        event[..4].copy_from_slice(&(LINUX_EPOLLOUT | LINUX_EPOLLET).to_le_bytes());
        event[8..].copy_from_slice(&17u64.to_le_bytes());
        let event_addr = h.put_bytes(&event);
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, writer as u64, event_addr, 0, 0]
            )),
            0
        );
        set_write_latch(&h.dispatcher.open_file(epfd as i32).unwrap(), writer);
        (h, epfd, writer, event_addr)
    }

    fn set_epoll_latch(epoll: &OpenFile, target: i32, ready: u32, read_avail: u64) {
        let mut open = epoll.description.write().unwrap();
        let OpenDescription::Epoll { interest, .. } = &mut *open else {
            panic!("epoll")
        };
        let slot = interest.get_mut(&target).unwrap();
        slot.last_ready = ready;
        slot.last_read_avail = read_avail;
    }

    fn set_write_latch(epoll: &OpenFile, writer: i32) {
        set_epoll_latch(epoll, writer, LINUX_EPOLLOUT, 0);
    }

    fn staged_slot_state(epoll: &OpenFile, target: i32) -> (u32, u64, bool, u64, u32, u64) {
        let open = epoll.description.read().unwrap();
        let OpenDescription::Epoll { interest, .. } = &*open else {
            panic!("epoll")
        };
        let slot = interest.get(&target).unwrap();
        (
            slot.last_ready,
            slot.io_gen,
            slot.write_backpressured,
            slot.last_read_avail,
            slot.event.events,
            slot.event.data,
        )
    }

    fn staged_write_state(epoll: &OpenFile, writer: i32) -> (u32, u64, bool, u32, u64) {
        let (ready, io_gen, backpressured, _, events, data) = staged_slot_state(epoll, writer);
        (ready, io_gen, backpressured, events, data)
    }

    #[test]
    fn staged_write_rearm_consumes_no_file_table_authority() {
        let (h, epfd, writer, _) = staged_write_fixture();
        let epoll = h.dispatcher.open_file(epfd as i32).unwrap();
        let context = h.dispatcher.capture_one_task_context().unwrap();
        resources::with_captured_resources(&context, || {
            let receipt =
                net::WriteRearm::new(h.dispatcher.open_file(writer).map(|file| file.description));
            resources::finish_files_for_host_wait(&context).unwrap();
            receipt.complete(&DispatchOutcome::Returned { value: 4 });
        });
        assert_eq!(
            staged_write_state(&epoll, writer),
            (0, 1, false, LINUX_EPOLLOUT | LINUX_EPOLLET, 17)
        );
    }

    fn staged_read_fixture() -> (Harness, u64, i32, u64) {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0; 6])) as u64;
        let pair_addr = h.reserve(8);
        assert_eq!(
            returned(h.call(
                199,
                [
                    LINUX_AF_UNIX as u64,
                    LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                    0,
                    pair_addr,
                    0,
                    0
                ]
            )),
            0
        );
        let pair = h.memory.read_bytes(pair_addr, 8).unwrap();
        let reader = i32::from_le_bytes(pair[..4].try_into().unwrap());
        let mut event = [0u8; 16];
        event[..4].copy_from_slice(&(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes());
        event[8..].copy_from_slice(&19u64.to_le_bytes());
        let event_addr = h.put_bytes(&event);
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, reader as u64, event_addr, 0, 0]
            )),
            0
        );
        set_epoll_latch(
            &h.dispatcher.open_file(epfd as i32).unwrap(),
            reader,
            LINUX_EPOLLIN,
            4,
        );
        (h, epfd, reader, event_addr)
    }

    #[test]
    fn staged_read_rearm_consumes_no_file_table_authority() {
        let (h, epfd, reader, _) = staged_read_fixture();
        let epoll = h.dispatcher.open_file(epfd as i32).unwrap();
        let context = h.dispatcher.capture_one_task_context().unwrap();
        resources::with_captured_resources(&context, || {
            let receipt =
                net::IoRearm::read(h.dispatcher.open_file(reader).map(|file| file.description));
            resources::finish_files_for_host_wait(&context).unwrap();
            receipt.complete(&DispatchOutcome::Returned { value: 4 });
        });
        assert_eq!(
            staged_slot_state(&epoll, reader),
            (0, 1, false, 0, LINUX_EPOLLIN | LINUX_EPOLLET, 19)
        );
    }

    #[test]
    fn staged_write_rearm_distinguishes_error_eagain_and_progress() {
        let (h, epfd, writer, _) = staged_write_fixture();
        let epoll = h.dispatcher.open_file(epfd as i32).unwrap();
        for outcome in [
            DispatchOutcome::Returned { value: 0 },
            DispatchOutcome::errno(carrick_abi::LINUX_EIO),
        ] {
            net::WriteRearm::new(h.dispatcher.open_file(writer).map(|file| file.description))
                .complete(&outcome);
            assert_eq!(staged_write_state(&epoll, writer).0, LINUX_EPOLLOUT);
            assert_eq!(staged_write_state(&epoll, writer).1, 0);
        }
        net::WriteRearm::new(h.dispatcher.open_file(writer).map(|file| file.description))
            .complete(&DispatchOutcome::errno(LINUX_EAGAIN));
        assert_eq!(
            staged_write_state(&epoll, writer),
            (LINUX_EPOLLOUT, 0, true, LINUX_EPOLLOUT | LINUX_EPOLLET, 17)
        );
        net::WriteRearm::new(h.dispatcher.open_file(writer).map(|file| file.description))
            .complete(&DispatchOutcome::Returned { value: 1 });
        assert_eq!(
            staged_write_state(&epoll, writer),
            (0, 1, false, LINUX_EPOLLOUT | LINUX_EPOLLET, 17)
        );
    }

    #[test]
    fn staged_write_rearm_includes_a_registration_added_while_io_is_pending() {
        let (mut h, epfd, writer, event_addr) = staged_write_fixture();
        let receipt =
            net::WriteRearm::new(h.dispatcher.open_file(writer).map(|file| file.description));
        assert_eq!(
            returned(h.call(21, [epfd, LINUX_EPOLL_CTL_DEL, writer as u64, 0, 0, 0])),
            0
        );
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, writer as u64, event_addr, 0, 0]
            )),
            0
        );
        let epoll = h.dispatcher.open_file(epfd as i32).unwrap();
        set_write_latch(&epoll, writer);
        receipt.complete(&DispatchOutcome::Returned { value: 4 });
        assert_eq!(
            staged_write_state(&epoll, writer),
            (0, 1, false, LINUX_EPOLLOUT | LINUX_EPOLLET, 17)
        );
    }

    #[test]
    fn staged_write_rearm_preserves_modified_events_and_data() {
        let (mut h, epfd, writer, event_addr) = staged_write_fixture();
        let receipt =
            net::WriteRearm::new(h.dispatcher.open_file(writer).map(|file| file.description));
        h.memory
            .write_bytes(event_addr, &(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes())
            .unwrap();
        h.memory
            .write_bytes(event_addr + 8, &99u64.to_le_bytes())
            .unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [
                    epfd,
                    carrick_abi::LINUX_EPOLL_CTL_MOD,
                    writer as u64,
                    event_addr,
                    0,
                    0
                ]
            )),
            0
        );
        receipt.complete(&DispatchOutcome::Returned { value: 4 });
        let epoll = h.dispatcher.open_file(epfd as i32).unwrap();
        assert_eq!(
            staged_write_state(&epoll, writer),
            (0, 1, false, LINUX_EPOLLIN | LINUX_EPOLLET, 99)
        );
    }

    #[test]
    fn staged_write_rearm_includes_current_owners_of_the_same_description() {
        let (mut h, epfd, writer, event_addr) = staged_write_fixture();
        let old_epoll = h.dispatcher.open_file(epfd as i32).unwrap();
        let receipt =
            net::WriteRearm::new(h.dispatcher.open_file(writer).map(|file| file.description));
        let alias = returned(h.call(23, [epfd, 0, 0, 0, 0, 0]));
        assert!(alias >= 0);
        assert_eq!(returned(h.call(57, [epfd, 0, 0, 0, 0, 0])), 0);
        let replacement = returned(h.call(20, [0; 6])) as u64;
        assert_eq!(replacement, epfd);
        assert_eq!(
            returned(h.call(
                21,
                [
                    replacement,
                    LINUX_EPOLL_CTL_ADD,
                    writer as u64,
                    event_addr,
                    0,
                    0
                ]
            )),
            0
        );
        let new_epoll = h.dispatcher.open_file(replacement as i32).unwrap();
        set_write_latch(&new_epoll, writer);
        receipt.complete(&DispatchOutcome::Returned { value: 4 });
        assert_eq!(staged_write_state(&old_epoll, writer).0, 0);
        assert_eq!(staged_write_state(&old_epoll, writer).1, 1);
        assert_eq!(staged_write_state(&new_epoll, writer).0, 0);
        assert_eq!(staged_write_state(&new_epoll, writer).1, 1);
    }

    #[test]
    fn staged_write_rearm_does_not_follow_reused_writer_number() {
        let (mut h, epfd, writer, event_addr) = staged_write_fixture();
        let old_epoll = h.dispatcher.open_file(epfd as i32).unwrap();
        let alias = returned(h.call(23, [writer as u64, 0, 0, 0, 0, 0])) as u64;
        let receipt =
            net::WriteRearm::new(h.dispatcher.open_file(writer).map(|file| file.description));
        // A dup keeps the original open description registered after fd reuse.
        let pair_addr = h.reserve(8);
        assert_eq!(
            returned(h.call(
                199,
                [
                    LINUX_AF_UNIX as u64,
                    LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                    0,
                    pair_addr,
                    0,
                    0
                ]
            )),
            0
        );
        let pair = h.memory.read_bytes(pair_addr, 8).unwrap();
        let replacement = i32::from_le_bytes(pair[..4].try_into().unwrap()) as u64;
        assert_eq!(
            returned(h.call(24, [replacement, writer as u64, 0, 0, 0, 0])),
            writer as i64
        );
        let new_epfd = returned(h.call(20, [0; 6])) as u64;
        assert_eq!(
            returned(h.call(
                21,
                [
                    new_epfd,
                    LINUX_EPOLL_CTL_ADD,
                    writer as u64,
                    event_addr,
                    0,
                    0
                ]
            )),
            0
        );
        let new_epoll = h.dispatcher.open_file(new_epfd as i32).unwrap();
        set_write_latch(&new_epoll, writer);
        receipt.complete(&DispatchOutcome::Returned { value: 4 });
        assert_eq!(staged_write_state(&old_epoll, writer).0, 0);
        assert_eq!(staged_write_state(&old_epoll, writer).1, 1);
        assert_eq!(staged_write_state(&new_epoll, writer).0, LINUX_EPOLLOUT);
        assert_eq!(staged_write_state(&new_epoll, writer).1, 0);
        assert!(h.dispatcher.open_file(alias as i32).is_some());
    }

    #[test]
    fn epoll_et_write_eagain_after_partial_write_keeps_write_filter_armed() {
        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as u64;

        let pair_addr = h.reserve(8);
        assert_eq!(
            returned(h.call(
                199,
                [
                    LINUX_AF_UNIX as u64,
                    LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                    0,
                    pair_addr,
                    0,
                    0,
                ],
            )),
            0
        );
        let pair = h.memory.read_bytes(pair_addr, 8).unwrap();
        let writer = i32::from_le_bytes(pair[0..4].try_into().unwrap());

        let ev_addr = h.reserve(16);
        let mut ev = [0u8; 16];
        ev[0..4].copy_from_slice(&(LINUX_EPOLLOUT | LINUX_EPOLLET).to_le_bytes());
        ev[8..16].copy_from_slice(&(writer as u64).to_le_bytes());
        h.memory.write_bytes(ev_addr, &ev).unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, writer as u64, ev_addr, 0, 0,],
            )),
            0
        );

        let epoll_open = h.dispatcher.open_file(epfd as i32).expect("epoll fd");
        {
            let mut open = epoll_open
                .description
                .write()
                .expect("epoll open description");
            let OpenDescription::Epoll { interest, .. } = &mut *open else {
                panic!("epfd should be an epoll description");
            };
            let slot = interest.get_mut(&writer).expect("writer interest");
            slot.last_ready = LINUX_EPOLLOUT;
            slot.write_backpressured = false;
        }

        let write_request =
            SyscallRequest::new(64, SyscallArgs::from([writer as u64, MEM_BASE, 1, 0, 0, 0]));
        h.dispatcher
            .epoll_rearm_after_io(&write_request, &DispatchOutcome::Returned { value: 1 });
        {
            let open = epoll_open
                .description
                .read()
                .expect("epoll open description");
            let OpenDescription::Epoll { interest, .. } = &*open else {
                panic!("epfd should be an epoll description");
            };
            let slot = interest.get(&writer).expect("writer interest");
            assert_eq!(slot.last_ready & LINUX_EPOLLOUT, 0);
            assert!(!slot.write_backpressured);
        }

        h.dispatcher.epoll_rearm_after_io(
            &write_request,
            &DispatchOutcome::Errno {
                errno: LINUX_EAGAIN,
            },
        );
        {
            let open = epoll_open
                .description
                .read()
                .expect("epoll open description");
            let OpenDescription::Epoll { interest, .. } = &*open else {
                panic!("epfd should be an epoll description");
            };
            let slot = interest.get(&writer).expect("writer interest");
            assert!(
                slot.write_backpressured,
                "write EAGAIN after a partial nonblocking write must keep EPOLLET/EPOLLOUT armed"
            );
        }
    }

    #[test]
    fn epoll_close_rebinds_shared_host_fd_survivor() {
        use std::time::Duration;

        let mut h = Harness::new();
        let epfd = returned(h.call(20, [0, 0, 0, 0, 0, 0])) as u64;

        let pair_addr = h.reserve(8);
        assert_eq!(
            returned(h.call(
                199,
                [
                    LINUX_AF_UNIX as u64,
                    LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                    0,
                    pair_addr,
                    0,
                    0,
                ],
            )),
            0
        );
        let pair = h.memory.read_bytes(pair_addr, 8).unwrap();
        let survivor = i32::from_le_bytes(pair[0..4].try_into().unwrap());
        let peer = i32::from_le_bytes(pair[4..8].try_into().unwrap());
        let closing_dup = returned(h.call(23, [survivor as u64, 0, 0, 0, 0, 0])) as i32;

        let ev_addr = h.reserve(16);
        let mut ev = [0u8; 16];
        ev[0..4].copy_from_slice(&(LINUX_EPOLLIN | LINUX_EPOLLET).to_le_bytes());
        ev[8..16].copy_from_slice(&(survivor as u64).to_le_bytes());
        h.memory.write_bytes(ev_addr, &ev).unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, survivor as u64, ev_addr, 0, 0],
            )),
            0
        );

        ev[8..16].copy_from_slice(&(closing_dup as u64).to_le_bytes());
        h.memory.write_bytes(ev_addr, &ev).unwrap();
        assert_eq!(
            returned(h.call(
                21,
                [epfd, LINUX_EPOLL_CTL_ADD, closing_dup as u64, ev_addr, 0, 0,],
            )),
            0
        );

        assert_eq!(returned(h.call(57, [closing_dup as u64, 0, 0, 0, 0, 0])), 0);
        {
            let epoll_open = h.dispatcher.open_file(epfd as i32).expect("epoll fd");
            let open = epoll_open
                .description
                .read()
                .expect("epoll open description");
            let OpenDescription::Epoll { interest, .. } = &*open else {
                panic!("epfd should be an epoll description");
            };
            assert!(interest.contains_key(&survivor));
            assert!(
                interest.contains_key(&closing_dup),
                "Linux retains a dup-keyed registration until the description's final fd closes"
            );
        }

        let byte_addr = h.put_bytes(b"x");
        assert_eq!(
            returned(h.call(64, [peer as u64, byte_addr, 1, 0, 0, 0])),
            1
        );

        let delivered_guest_fd = {
            let epoll_open = h.dispatcher.open_file(epfd as i32).expect("epoll fd");
            let open = epoll_open.description.read().expect("open description");
            let OpenDescription::Epoll { kqueue, .. } = &*open else {
                panic!("epfd should be an epoll description");
            };
            let mut events = Vec::new();
            let n = kqueue
                .with_mux(|mux| mux.wait(&mut events, Some(Duration::from_millis(100))))
                .expect("kqueue wait");
            assert!(n > 0, "peer write should wake the epoll instance");
            let io_tokens = events
                .iter()
                .filter(|event| event.readiness.read || event.readiness.write || event.eof)
                .map(|event| (event.token & 0xffff_ffff) as u32 as i32)
                .collect::<Vec<_>>();
            assert_eq!(io_tokens.len(), 1, "expected one routed IO readiness event");
            io_tokens[0]
        };

        assert_eq!(
            delivered_guest_fd, survivor,
            "close of a dup must rebind the shared host-fd registration to a surviving guest fd"
        );
        assert_eq!(returned(h.call(57, [survivor as u64, 0, 0, 0, 0, 0])), 0);
        let epoll_open = h.dispatcher.open_file(epfd as i32).expect("epoll fd");
        let open = epoll_open
            .description
            .read()
            .expect("epoll open description");
        let OpenDescription::Epoll { interest, .. } = &*open else {
            panic!("epfd should be an epoll description");
        };
        assert!(!interest.contains_key(&survivor));
        assert!(!interest.contains_key(&closing_dup));
    }

    #[test]
    fn unix_accept_unnamed_peer_writes_family_only_sockaddr() {
        let mut h = Harness::new();
        let listener = returned(h.call(
            198,
            [
                LINUX_AF_UNIX as u64,
                LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                0,
                0,
                0,
                0,
            ],
        )) as i32;
        let client = returned(h.call(
            198,
            [
                LINUX_AF_UNIX as u64,
                LINUX_SOCK_STREAM as u64 | LINUX_O_NONBLOCK,
                0,
                0,
                0,
                0,
            ],
        )) as i32;

        let path = format!("/var/carrick-accept-{}", std::process::id());
        let mut sockaddr = vec![0u8; 2 + path.len() + 1];
        sockaddr[0..2].copy_from_slice(&(LINUX_AF_UNIX as u16).to_ne_bytes());
        sockaddr[2..2 + path.len()].copy_from_slice(path.as_bytes());
        let sockaddr_addr = h.put_bytes(&sockaddr);
        assert_eq!(
            returned(h.call(
                200,
                [
                    listener as u64,
                    sockaddr_addr,
                    sockaddr.len() as u64,
                    0,
                    0,
                    0
                ],
            )),
            0
        );
        assert_eq!(returned(h.call(201, [listener as u64, 1, 0, 0, 0, 0])), 0);
        assert_eq!(
            returned(h.call(
                203,
                [client as u64, sockaddr_addr, sockaddr.len() as u64, 0, 0, 0],
            )),
            0
        );

        let peer_addr = h.reserve(128);
        let peer_len_addr = h.reserve(4);
        h.memory
            .write_bytes(peer_len_addr, &128u32.to_ne_bytes())
            .unwrap();
        let accepted = returned(h.call(202, [listener as u64, peer_addr, peer_len_addr, 0, 0, 0]));
        assert!(
            accepted >= 0,
            "accept must return a guest fd, got {accepted}"
        );

        let peer_len = h.memory.read_bytes(peer_len_addr, 4).unwrap();
        assert_eq!(
            u32::from_ne_bytes(peer_len.try_into().unwrap()),
            2,
            "Linux reports only sa_family for an unnamed AF_UNIX peer"
        );
        let peer = h.memory.read_bytes(peer_addr, 2).unwrap();
        assert_eq!(
            u16::from_ne_bytes(peer.try_into().unwrap()),
            LINUX_AF_UNIX as u16
        );
    }

    /// GROUNDED REGRESSION GATE (Rust, in-tree, cross-platform: macOS kqueue +
    /// Linux epoll-emulation) for the epoll EPOLLET edge-loss hang. It drives the
    /// REAL `epoll_pwait`/`epoll_ctl`/`pipe2` handlers through the threaded
    /// dispatch path, mirroring the Go netpoller + os/exec pipe churn that hung
    /// `go build`: worker threads concurrently create a pipe, register the
    /// read-end EPOLLET in a SHARED epoll, write+close the write-end (EOF), and
    /// wait for a netpoller thread's `epoll_pwait` loop to report it. A pipe
    /// read-end at EOF MUST eventually be reported (EPOLLHUP/EPOLLIN); a lost edge
    /// ⇒ the worker times out ⇒ this test FAILS.
    ///
    /// ROOT CAUSE (fixed): `close(fd)` freed the fd number from `open_files` and
    /// only THEN detached it from epoll interest sets. In the window between, a
    /// sibling thread recycled that fd number and `epoll_ctl(ADD)`d it, and the
    /// late detach ripped out the NEW registration's interest — whose EPOLLET edge
    /// then never re-fired. Fixed by detaching BEFORE freeing the fd number (see
    /// `close` in dispatch/fs.rs). Routing is hardened with a generational udata
    /// handle (`EpollInterest::reg_gen`) against the residual drain-then-recycle
    /// ABA. Was RED on every run pre-fix (~3-5s); GREEN in ~0.1s after.
    #[cfg(unix)]
    #[test]
    fn epoll_et_pipe_eof_not_lost_under_concurrent_churn() {
        use std::sync::atomic::{AtomicBool, AtomicI64, AtomicUsize, Ordering};
        use std::time::{Duration, Instant};

        const NWORKERS: usize = 6;
        const TOTAL: usize = 600;
        const EPOLLIN: u32 = 0x1;
        const EPOLLHUP: u32 = 0x10;
        const EPOLLERR: u32 = 0x8;
        const EPOLLET: u32 = 0x8000_0000;
        const CTL_ADD: u64 = 1;
        const CTL_DEL: u64 = 2;
        const EV_STRIDE: u64 = 16; // aarch64 LinuxEpollEvent stride

        let dispatcher = SyscallDispatcher::with_rootfs(empty_rootfs());
        let reporter = CompatReporter::default();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(1000));
        let futex = crate::thread::FutexTable::new();

        // Create the shared epoll instance up front.
        let epfd = {
            let mut mem = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
            let out = dispatcher
                .dispatch_threaded(
                    &dispatcher.capture_one_task_context().unwrap(),
                    SyscallRequest::new(20, SyscallArgs::from([0u64; 6])),
                    &mut mem,
                    &reporter,
                    ThreadCtx::new(
                        crate::thread::ThreadId::synthetic_for_tests(1),
                        &registry,
                        &futex,
                    ),
                )
                .expect("epoll_create1");
            returned(out) as u64
        };

        let eof_seen: Vec<AtomicBool> = (0..TOTAL).map(|_| AtomicBool::new(false)).collect();
        let next_slot = AtomicUsize::new(0);
        let active = AtomicUsize::new(NWORKERS);
        let stop = AtomicBool::new(false);
        let failed = AtomicI64::new(-1);

        let dispatcher = &dispatcher;
        let reporter = &reporter;
        let registry = &registry;
        let futex = &futex;
        let eof_seen = &eof_seen;
        let next_slot = &next_slot;
        let active = &active;
        let stop = &stop;
        let failed = &failed;

        std::thread::scope(|s| {
            // ---- netpoller ----
            s.spawn(move || {
                let mut mem = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
                let ev_buf = MEM_BASE + 0x800;
                let max = 32u64;
                while !stop.load(Ordering::Relaxed) {
                    let out = dispatcher
                        .dispatch_threaded(
                            &dispatcher.capture_one_task_context().unwrap(),
                            SyscallRequest::new(
                                22,
                                SyscallArgs::from([epfd, ev_buf, max, 50, 0, 0]),
                            ),
                            &mut mem,
                            reporter,
                            ThreadCtx::new(
                                crate::thread::ThreadId::synthetic_for_tests(2),
                                registry,
                                futex,
                            ),
                        )
                        .expect("epoll_pwait");
                    match out {
                        DispatchOutcome::Returned { value } if value > 0 => {
                            for i in 0..(value as u64) {
                                let off = ev_buf + i * EV_STRIDE;
                                let b = mem.read_bytes(off, 16).unwrap();
                                let events = u32::from_le_bytes(b[0..4].try_into().unwrap());
                                let data = u64::from_le_bytes(b[8..16].try_into().unwrap());
                                let slot = data as usize;
                                if events & (EPOLLHUP | EPOLLIN | EPOLLERR) != 0 && slot < TOTAL {
                                    eof_seen[slot].store(true, Ordering::Relaxed);
                                }
                            }
                        }
                        DispatchOutcome::Returned { .. } => {}
                        DispatchOutcome::WaitOnFds { fds, timeout, .. } => {
                            if let Some((fd, events)) = fds.first() {
                                let mut pfd = libc::pollfd {
                                    fd,
                                    events,
                                    revents: 0,
                                };
                                let ms =
                                    timeout.map(|d| d.as_millis().min(50) as i32).unwrap_or(50);
                                // SAFETY: one valid pollfd, bounded non-blocking wait.
                                unsafe {
                                    libc::poll(&mut pfd, 1, ms);
                                }
                            } else {
                                let ms =
                                    timeout.map(|d| d.as_millis().min(50) as u64).unwrap_or(50);
                                std::thread::sleep(Duration::from_millis(ms));
                            }
                        }
                        _ => {}
                    }
                }
            });

            // ---- workers ----
            for w in 0..NWORKERS {
                s.spawn(move || {
                    let mut mem = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
                    let tid = crate::thread::ThreadId::synthetic_for_tests(100 + w as i32);
                    let pipe_out = MEM_BASE + 0x100;
                    let ev_in = MEM_BASE + 0x120;
                    let wbuf = MEM_BASE + 0x140;
                    mem.write_bytes(wbuf, b"x").unwrap();
                    let call =
                        |mem: &mut LinearMemory, num: u64, args: [u64; 6]| -> DispatchOutcome {
                            dispatcher
                                .dispatch_threaded(
                                    &dispatcher.capture_one_task_context().unwrap(),
                                    SyscallRequest::new(num, SyscallArgs::from(args)),
                                    mem,
                                    reporter,
                                    ThreadCtx::new(tid, registry, futex),
                                )
                                .expect("dispatch")
                        };
                    loop {
                        if stop.load(Ordering::Relaxed) || failed.load(Ordering::Relaxed) >= 0 {
                            break;
                        }
                        let slot = next_slot.fetch_add(1, Ordering::Relaxed);
                        if slot >= TOTAL {
                            break;
                        }
                        // pipe2(0): carrick makes the host ends non-blocking itself.
                        if !matches!(
                            call(&mut mem, 59, [pipe_out, 0, 0, 0, 0, 0]),
                            DispatchOutcome::Returned { value: 0 }
                        ) {
                            continue;
                        }
                        let fp = mem.read_bytes(pipe_out, 8).unwrap();
                        let rd = i32::from_le_bytes(fp[0..4].try_into().unwrap()) as u64;
                        let wr = i32::from_le_bytes(fp[4..8].try_into().unwrap()) as u64;
                        // epoll_ctl ADD rd, EPOLLIN|EPOLLET, data=slot
                        let mut ev = [0u8; 16];
                        ev[0..4].copy_from_slice(&(EPOLLIN | EPOLLET).to_le_bytes());
                        ev[8..16].copy_from_slice(&(slot as u64).to_le_bytes());
                        mem.write_bytes(ev_in, &ev).unwrap();
                        call(&mut mem, 21, [epfd, CTL_ADD, rd, ev_in, 0, 0]);
                        // write a byte, then close the write end (EOF).
                        call(&mut mem, 64, [wr, wbuf, 1, 0, 0, 0]);
                        call(&mut mem, 57, [wr, 0, 0, 0, 0, 0]);
                        // The read-end is now at EOF — the netpoller MUST report it.
                        let t0 = Instant::now();
                        while !eof_seen[slot].load(Ordering::Relaxed) {
                            if t0.elapsed() > Duration::from_secs(3) {
                                failed.store(slot as i64, Ordering::Relaxed);
                                stop.store(true, Ordering::Relaxed);
                                break;
                            }
                            std::thread::yield_now();
                        }
                        call(&mut mem, 21, [epfd, CTL_DEL, rd, 0, 0, 0]);
                        call(&mut mem, 57, [rd, 0, 0, 0, 0, 0]);
                    }
                    if active.fetch_sub(1, Ordering::Relaxed) == 1 {
                        stop.store(true, Ordering::Relaxed);
                    }
                });
            }
        });

        let f = failed.load(Ordering::Relaxed);
        assert!(
            f < 0,
            "epoll LOST the EOF edge for slot {f} under concurrent churn \
             (the Go-netpoller hang); native epoll never does this"
        );
    }

    /// FOCUSED regression gate for the close/reuse/detach ORDERING race that
    /// caused the edge-loss above. It isolates the exact mechanism: dedicated
    /// "recycler" threads `epoll_ctl(ADD)` a pipe read-end and immediately
    /// `close()` it with NO `EPOLL_CTL_DEL`, so `close`'s `detach_fd_from_epolls`
    /// is the sole remover AND the freed fd number is fed straight back to a
    /// victim's next `pipe2`. If `close` frees the fd number before detaching,
    /// the recycler's late detach rips out the victim's freshly-registered
    /// interest for that recycled fd and its EOF edge is lost. Distinct from the
    /// symmetric stress test above, which uses DEL+close; here close-detach is the
    /// only path under test. Was RED pre-fix; GREEN after detach-before-free.
    #[cfg(unix)]
    #[test]
    fn epoll_close_recycle_does_not_drop_interest() {
        use std::sync::atomic::{AtomicBool, AtomicI64, AtomicUsize, Ordering};
        use std::time::{Duration, Instant};

        const VICTIMS: usize = 4;
        const RECYCLERS: usize = 2;
        const TOTAL: usize = 400;
        const EPOLLIN: u32 = 0x1;
        const EPOLLHUP: u32 = 0x10;
        const EPOLLERR: u32 = 0x8;
        const EPOLLET: u32 = 0x8000_0000;
        const CTL_ADD: u64 = 1;
        const CTL_DEL: u64 = 2;
        const EV_STRIDE: u64 = 16;

        let dispatcher = SyscallDispatcher::with_rootfs(empty_rootfs());
        let reporter = CompatReporter::default();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(1000));
        let futex = crate::thread::FutexTable::new();

        let epfd = {
            let mut mem = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
            let out = dispatcher
                .dispatch_threaded(
                    &dispatcher.capture_one_task_context().unwrap(),
                    SyscallRequest::new(20, SyscallArgs::from([0u64; 6])),
                    &mut mem,
                    &reporter,
                    ThreadCtx::new(
                        crate::thread::ThreadId::synthetic_for_tests(1),
                        &registry,
                        &futex,
                    ),
                )
                .expect("epoll_create1");
            returned(out) as u64
        };

        let eof_seen: Vec<AtomicBool> = (0..TOTAL).map(|_| AtomicBool::new(false)).collect();
        let next_slot = AtomicUsize::new(0);
        let active = AtomicUsize::new(VICTIMS);
        let stop = AtomicBool::new(false);
        let failed = AtomicI64::new(-1);

        let dispatcher = &dispatcher;
        let reporter = &reporter;
        let registry = &registry;
        let futex = &futex;
        let eof_seen = &eof_seen;
        let next_slot = &next_slot;
        let active = &active;
        let stop = &stop;
        let failed = &failed;

        std::thread::scope(|s| {
            // ---- netpoller ----
            s.spawn(move || {
                let mut mem = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
                let ev_buf = MEM_BASE + 0x800;
                let max = 32u64;
                while !stop.load(Ordering::Relaxed) {
                    let out = dispatcher
                        .dispatch_threaded(
                            &dispatcher.capture_one_task_context().unwrap(),
                            SyscallRequest::new(
                                22,
                                SyscallArgs::from([epfd, ev_buf, max, 50, 0, 0]),
                            ),
                            &mut mem,
                            reporter,
                            ThreadCtx::new(
                                crate::thread::ThreadId::synthetic_for_tests(2),
                                registry,
                                futex,
                            ),
                        )
                        .expect("epoll_pwait");
                    match out {
                        DispatchOutcome::Returned { value } if value > 0 => {
                            for i in 0..(value as u64) {
                                let off = ev_buf + i * EV_STRIDE;
                                let b = mem.read_bytes(off, 16).unwrap();
                                let events = u32::from_le_bytes(b[0..4].try_into().unwrap());
                                let data = u64::from_le_bytes(b[8..16].try_into().unwrap());
                                let slot = data as usize;
                                if events & (EPOLLHUP | EPOLLIN | EPOLLERR) != 0 && slot < TOTAL {
                                    eof_seen[slot].store(true, Ordering::Relaxed);
                                }
                            }
                        }
                        DispatchOutcome::Returned { .. } => {}
                        DispatchOutcome::WaitOnFds { fds, timeout, .. } => {
                            if let Some((fd, events)) = fds.first() {
                                let mut pfd = libc::pollfd {
                                    fd,
                                    events,
                                    revents: 0,
                                };
                                let ms =
                                    timeout.map(|d| d.as_millis().min(50) as i32).unwrap_or(50);
                                // SAFETY: one valid pollfd, bounded non-blocking wait.
                                unsafe {
                                    libc::poll(&mut pfd, 1, ms);
                                }
                            } else {
                                let ms =
                                    timeout.map(|d| d.as_millis().min(50) as u64).unwrap_or(50);
                                std::thread::sleep(Duration::from_millis(ms));
                            }
                        }
                        _ => {}
                    }
                }
            });

            // ---- recyclers: ADD a read-end then close it (NO DEL) to churn fd
            // numbers through close()'s detach path while victims reuse them. ----
            for r in 0..RECYCLERS {
                s.spawn(move || {
                    let mut mem = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
                    let tid = crate::thread::ThreadId::synthetic_for_tests(200 + r as i32);
                    let pipe_out = MEM_BASE + 0x100;
                    let ev_in = MEM_BASE + 0x120;
                    let call =
                        |mem: &mut LinearMemory, num: u64, args: [u64; 6]| -> DispatchOutcome {
                            dispatcher
                                .dispatch_threaded(
                                    &dispatcher.capture_one_task_context().unwrap(),
                                    SyscallRequest::new(num, SyscallArgs::from(args)),
                                    mem,
                                    reporter,
                                    ThreadCtx::new(tid, registry, futex),
                                )
                                .expect("dispatch")
                        };
                    let mut ev = [0u8; 16];
                    ev[0..4].copy_from_slice(&(EPOLLIN | EPOLLET).to_le_bytes());
                    while !stop.load(Ordering::Relaxed) {
                        if !matches!(
                            call(&mut mem, 59, [pipe_out, 0, 0, 0, 0, 0]),
                            DispatchOutcome::Returned { value: 0 }
                        ) {
                            continue;
                        }
                        let fp = mem.read_bytes(pipe_out, 8).unwrap();
                        let rd = i32::from_le_bytes(fp[0..4].try_into().unwrap()) as u64;
                        let wr = i32::from_le_bytes(fp[4..8].try_into().unwrap()) as u64;
                        mem.write_bytes(ev_in, &ev).unwrap();
                        call(&mut mem, 21, [epfd, CTL_ADD, rd, ev_in, 0, 0]);
                        // close the read-end WITHOUT DEL: close()'s detach is the
                        // remover, and rd's number is now free for a victim's pipe2.
                        call(&mut mem, 57, [rd, 0, 0, 0, 0, 0]);
                        call(&mut mem, 57, [wr, 0, 0, 0, 0, 0]);
                    }
                });
            }

            // ---- victims ----
            for w in 0..VICTIMS {
                s.spawn(move || {
                    let mut mem = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
                    let tid = crate::thread::ThreadId::synthetic_for_tests(100 + w as i32);
                    let pipe_out = MEM_BASE + 0x100;
                    let ev_in = MEM_BASE + 0x120;
                    let wbuf = MEM_BASE + 0x140;
                    mem.write_bytes(wbuf, b"x").unwrap();
                    let call =
                        |mem: &mut LinearMemory, num: u64, args: [u64; 6]| -> DispatchOutcome {
                            dispatcher
                                .dispatch_threaded(
                                    &dispatcher.capture_one_task_context().unwrap(),
                                    SyscallRequest::new(num, SyscallArgs::from(args)),
                                    mem,
                                    reporter,
                                    ThreadCtx::new(tid, registry, futex),
                                )
                                .expect("dispatch")
                        };
                    loop {
                        if stop.load(Ordering::Relaxed) || failed.load(Ordering::Relaxed) >= 0 {
                            break;
                        }
                        let slot = next_slot.fetch_add(1, Ordering::Relaxed);
                        if slot >= TOTAL {
                            break;
                        }
                        if !matches!(
                            call(&mut mem, 59, [pipe_out, 0, 0, 0, 0, 0]),
                            DispatchOutcome::Returned { value: 0 }
                        ) {
                            continue;
                        }
                        let fp = mem.read_bytes(pipe_out, 8).unwrap();
                        let rd = i32::from_le_bytes(fp[0..4].try_into().unwrap()) as u64;
                        let wr = i32::from_le_bytes(fp[4..8].try_into().unwrap()) as u64;
                        let mut ev = [0u8; 16];
                        ev[0..4].copy_from_slice(&(EPOLLIN | EPOLLET).to_le_bytes());
                        ev[8..16].copy_from_slice(&(slot as u64).to_le_bytes());
                        mem.write_bytes(ev_in, &ev).unwrap();
                        call(&mut mem, 21, [epfd, CTL_ADD, rd, ev_in, 0, 0]);
                        call(&mut mem, 64, [wr, wbuf, 1, 0, 0, 0]);
                        call(&mut mem, 57, [wr, 0, 0, 0, 0, 0]);
                        let t0 = Instant::now();
                        while !eof_seen[slot].load(Ordering::Relaxed) {
                            if t0.elapsed() > Duration::from_secs(3) {
                                failed.store(slot as i64, Ordering::Relaxed);
                                stop.store(true, Ordering::Relaxed);
                                break;
                            }
                            std::thread::yield_now();
                        }
                        call(&mut mem, 21, [epfd, CTL_DEL, rd, 0, 0, 0]);
                        call(&mut mem, 57, [rd, 0, 0, 0, 0, 0]);
                    }
                    if active.fetch_sub(1, Ordering::Relaxed) == 1 {
                        stop.store(true, Ordering::Relaxed);
                    }
                });
            }
        });

        let f = failed.load(Ordering::Relaxed);
        assert!(
            f < 0,
            "epoll lost the EOF edge for slot {f}: a sibling close() recycled the \
             fd number and a detach-after-free dropped the victim's new interest"
        );
    }

    #[test]
    fn read_kernel_struct_accepts_unaligned_abi_reads_and_rejects_bad_pointers() {
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let address = MEM_BASE + 3;
        let expected = LinuxTimespec::new(12, 34);
        memory.write_bytes(address, expected.abi_bytes()).unwrap();

        let actual: LinuxTimespec = read_kernel_struct(&memory, address).unwrap();
        let tv_sec = actual.tv_sec;
        let tv_nsec = actual.tv_nsec;
        assert_eq!((tv_sec, tv_nsec), (12, 34));

        assert_eq!(
            read_kernel_struct::<LinuxTimespec>(&memory, 0),
            Err(LINUX_EFAULT)
        );
        assert_eq!(
            read_kernel_struct::<LinuxTimespec>(&memory, MEM_BASE + MEM_LEN as u64 - 1),
            Err(LINUX_EFAULT)
        );
    }

    #[test]
    fn read_kernel_prefix_zero_fills_truncated_clone_args_and_rejects_overlarge_reads() {
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let address = MEM_BASE + 5;
        let flags = LinuxCloneFlags::THREAD_MASK | LinuxCloneFlags::SETTLS.bits();
        memory.write_bytes(address, &flags.to_ne_bytes()).unwrap();

        let args: LinuxCloneArgs = read_kernel_prefix(&memory, address, 8).unwrap();
        let actual_flags = args.flags;
        let tls = args.tls;
        assert_eq!(actual_flags, flags);
        assert_eq!(tls, 0);

        assert_eq!(
            read_kernel_prefix::<LinuxCloneArgs>(
                &memory,
                address,
                <LinuxCloneArgs as KernelAbi>::ABI_SIZE + 1,
            ),
            Err(LINUX_EFAULT)
        );
    }

    #[test]
    fn clone_thread_requires_thread_bit_not_pthread_superset() {
        let mut h = Harness::new();
        let flags = LinuxCloneFlags::VM.bits()
            | LinuxCloneFlags::SIGHAND.bits()
            | LinuxCloneFlags::THREAD.bits()
            | LinuxCloneFlags::CHILD_CLEARTID.bits()
            | u64::from(crate::linux_abi::LINUX_SIGCHLD as u32);
        let child_tid = h.reserve(4);

        let outcome = h.call(SYS_CLONE, [flags, MEM_BASE + 0x800, 0, 0, child_tid, 0]);

        assert!(matches!(
            outcome,
            DispatchOutcome::CloneThread {
                child_tid_addr,
                clear_child_tid_addr,
                tls: None,
                parent_tid_addr: 0,
                ..
            } if child_tid_addr == 0 && clear_child_tid_addr == child_tid
        ));
    }

    #[test]
    fn clone_preserves_parent_and_tid_pointer_semantics_for_fork_path() {
        let mut h = Harness::new();
        let parent_tid = h.reserve(4);
        let child_tid = h.reserve(4);
        let flags = LinuxCloneFlags::PARENT.bits()
            | LinuxCloneFlags::PARENT_SETTID.bits()
            | LinuxCloneFlags::CHILD_SETTID.bits()
            | u64::from(crate::linux_abi::LINUX_SIGCHLD as u32);

        let outcome = h.call(SYS_CLONE, [flags, 0, parent_tid, 0, child_tid, 0]);

        assert!(matches!(
            outcome,
            DispatchOutcome::Fork {
                clone_parent: true,
                parent_tid_addr: Some(p),
                child_tid_addr: Some(c),
                ..
            } if p == parent_tid && c == child_tid
        ));
    }

    #[test]
    fn clone3_preserves_parent_and_tid_pointer_semantics_for_fork_path() {
        let mut h = Harness::new();
        let args_addr = h.reserve(<LinuxCloneArgs as KernelAbi>::ABI_SIZE);
        let parent_tid = h.reserve(4);
        let child_tid = h.reserve(4);
        let args = LinuxCloneArgs {
            flags: LinuxCloneFlags::PARENT.bits()
                | LinuxCloneFlags::PARENT_SETTID.bits()
                | LinuxCloneFlags::CHILD_SETTID.bits(),
            pidfd: 0,
            child_tid,
            parent_tid,
            exit_signal: u64::from(crate::linux_abi::LINUX_SIGCHLD as u32),
            stack: 0,
            stack_size: 0,
            tls: 0,
            set_tid: 0,
            set_tid_size: 0,
            cgroup: 0,
        };
        h.memory.write_bytes(args_addr, args.abi_bytes()).unwrap();

        let outcome = h.call(
            SYS_CLONE3,
            [
                args_addr,
                <LinuxCloneArgs as KernelAbi>::ABI_SIZE as u64,
                0,
                0,
                0,
                0,
            ],
        );

        assert!(matches!(
            outcome,
            DispatchOutcome::Fork {
                clone_parent: true,
                parent_tid_addr: Some(p),
                child_tid_addr: Some(c),
                ..
            } if p == parent_tid && c == child_tid
        ));
    }

    const AT_FDCWD: u64 = (-100i64) as u64;

    #[test]
    fn mkdirat_creates_overlay_dir_and_fstatat_sees_it() {
        let mut h = Harness::new();
        let path = h.put_str("/var/lib/apt/lists");
        let outcome = h.call(SYS_MKDIRAT, [AT_FDCWD, path, 0o755, 0, 0, 0]);
        assert_eq!(returned(outcome), 0);

        // fstatat must succeed and report a directory. The Linux stat
        // layout puts st_mode at bytes 16..20; bit S_IFDIR=0o040000.
        let statbuf = h.reserve(160);
        let path2 = h.put_str("/var/lib/apt/lists");
        let outcome = h.call(SYS_NEWFSTATAT, [AT_FDCWD, path2, statbuf, 0, 0, 0]);
        assert_eq!(returned(outcome), 0);
        let mode_bytes = h.memory.read_bytes(statbuf + 16, 4).unwrap();
        let mode = u32::from_le_bytes(mode_bytes.try_into().unwrap());
        assert_eq!(mode & 0o170000, 0o040000, "S_IFDIR not set in stat mode");
    }

    #[test]
    fn openat_o_creat_then_write_then_read_round_trips() {
        let mut h = Harness::new();
        // O_CREAT|O_WRONLY: writable, brand-new file inside an existing
        // rootfs directory.
        let path = h.put_str("/var/lib/apt/lock");
        let outcome = h.call(
            SYS_OPENAT,
            [AT_FDCWD, path, O_CREAT | O_WRONLY, 0o644, 0, 0],
        );
        let fd = returned(outcome) as u64;
        assert!(fd >= 3, "expected real fd, got {fd}");

        // Write four bytes.
        let payload = h.put_bytes(b"OKAY");
        let outcome = h.call(SYS_WRITE, [fd, payload, 4, 0, 0, 0]);
        assert_eq!(returned(outcome), 4);
        let outcome = h.call(SYS_CLOSE, [fd, 0, 0, 0, 0, 0]);
        assert_eq!(returned(outcome), 0);

        // Re-open O_RDONLY and read back.
        let path = h.put_str("/var/lib/apt/lock");
        let outcome = h.call(SYS_OPENAT, [AT_FDCWD, path, O_RDONLY, 0, 0, 0]);
        let fd = returned(outcome) as u64;
        let dest = h.reserve(16);
        let outcome = h.call(SYS_READ, [fd, dest, 16, 0, 0, 0]);
        assert_eq!(returned(outcome), 4);
        let bytes = h.memory.read_bytes(dest, 4).unwrap();
        assert_eq!(&bytes, b"OKAY");
    }

    #[test]
    fn unlinkat_on_rootfs_file_then_openat_returns_enoent() {
        let mut h = Harness::new();
        // /etc/motd lives in the rootfs.
        let path = h.put_str("/etc/motd");
        let outcome = h.call(SYS_UNLINKAT, [AT_FDCWD, path, 0, 0, 0, 0]);
        assert_eq!(returned(outcome), 0);

        let path = h.put_str("/etc/motd");
        let outcome = h.call(SYS_OPENAT, [AT_FDCWD, path, O_RDONLY, 0, 0, 0]);
        assert_eq!(errno(outcome), LINUX_ENOENT.get());
    }

    #[test]
    fn renameat_moves_overlay_backed_file() {
        let mut h = Harness::new();
        // Create a file in the overlay first.
        let path = h.put_str("/var/lib/apt/lock");
        let outcome = h.call(
            SYS_OPENAT,
            [AT_FDCWD, path, O_CREAT | O_WRONLY, 0o644, 0, 0],
        );
        let fd = returned(outcome) as u64;
        let payload = h.put_bytes(b"DATA");
        let _ = h.call(SYS_WRITE, [fd, payload, 4, 0, 0, 0]);
        let _ = h.call(SYS_CLOSE, [fd, 0, 0, 0, 0, 0]);

        let from = h.put_str("/var/lib/apt/lock");
        let to = h.put_str("/var/lib/apt/lock.new");
        let outcome = h.call(SYS_RENAMEAT, [AT_FDCWD, from, AT_FDCWD, to, 0, 0]);
        assert_eq!(returned(outcome), 0);

        // Source must now ENOENT, destination must read back the data.
        let path = h.put_str("/var/lib/apt/lock");
        let outcome = h.call(SYS_OPENAT, [AT_FDCWD, path, O_RDONLY, 0, 0, 0]);
        assert_eq!(errno(outcome), LINUX_ENOENT.get());

        let path = h.put_str("/var/lib/apt/lock.new");
        let outcome = h.call(SYS_OPENAT, [AT_FDCWD, path, O_RDONLY, 0, 0, 0]);
        let fd = returned(outcome) as u64;
        let dest = h.reserve(16);
        let outcome = h.call(SYS_READ, [fd, dest, 16, 0, 0, 0]);
        assert_eq!(returned(outcome), 4);
        let bytes = h.memory.read_bytes(dest, 4).unwrap();
        assert_eq!(&bytes, b"DATA");
    }

    /// Validates the systematic unknown-flag detector: when the guest
    /// passes a flag bit the dispatcher doesn't know about, the
    /// compat report must surface it as an `UnknownSyscallFlags`
    /// entry, regardless of whether the syscall ultimately returns
    /// success or EINVAL. The user explicitly asked for this loudness.
    #[test]
    fn unknown_pipe2_flag_is_recorded_in_compat_report() {
        let mut h = Harness::new();
        let buf = h.reserve(8);
        // Bit 0x80 (octal 0o200) is NOT one of O_CLOEXEC | O_NONBLOCK.
        // Send it through pipe2 — the handler returns EINVAL, and we
        // want the report to ALSO list the unknown bit so the operator
        // can fix it.
        const SYS_PIPE2: u64 = 59;
        let _ = h.call(SYS_PIPE2, [buf, 0x80, 0, 0, 0, 0]);

        // Finish the report and look for the entry.
        let report = std::mem::take(&mut h.reporter).finish();
        let entry = report
            .unknown_syscall_flags
            .iter()
            .find(|e| e.number == 59 && e.argument == 1)
            .expect("pipe2's unknown-flag bit 0x80 should appear in the report");
        assert!(entry.unknown_bits.contains("0x80"), "got {:?}", entry);
        assert_eq!(entry.count, 1);
        assert_eq!(entry.name, "pipe2");
    }

    /// Negative test: a syscall flag arg that has NO unknown bits set
    /// must NOT produce an UnknownSyscallFlags entry.
    #[test]
    fn known_pipe2_flag_is_silent() {
        let mut h = Harness::new();
        let buf = h.reserve(8);
        // O_CLOEXEC | O_NONBLOCK — both are in the supported mask.
        let _ = h.call(
            SYS_PIPE2,
            [buf, LINUX_O_CLOEXEC | LINUX_O_NONBLOCK, 0, 0, 0, 0],
        );
        let report = std::mem::take(&mut h.reporter).finish();
        assert!(
            report.unknown_syscall_flags.is_empty(),
            "no unknown bits should be reported; got {:?}",
            report.unknown_syscall_flags
        );
    }

    const SYS_PIPE2: u64 = 59;

    #[cfg(target_os = "macos")]
    #[test]
    fn host_syscall_result_translates_captured_host_errno() {
        use carrick_host_bsd::errno::linux_errno;
        use carrick_vfs::errno::HostSyscallResult;

        carrick_portable::set_errno(libc::EINPROGRESS);
        let err = (-1i32).host_syscall_result().unwrap_err();
        assert_eq!(err.raw_errno(), libc::EINPROGRESS);
        assert_eq!(err.linux_errno(), linux_errno::EINPROGRESS);
        assert_ne!(err.linux_errno().get(), libc::EINPROGRESS);

        carrick_portable::set_errno(libc::EAGAIN);
        assert_eq!(
            (-1isize).host_syscall_result().unwrap_err().linux_errno(),
            linux_errno::EAGAIN
        );

        carrick_portable::set_errno(libc::ECONNREFUSED);
        assert_eq!(
            (-1i64).host_syscall_errno().unwrap_err(),
            linux_errno::ECONNREFUSED
        );

        assert_eq!(0i32.host_syscall_result().unwrap(), 0);
    }

    /// A MAP_SHARED futex word the dispatcher's software memory view can't
    /// translate (read fails) must still be read via the fork-coherent shared
    /// host pointer — never surfaced as EFAULT, which aborts glibc's futex code.
    /// Regression for the CPython multiprocessing SyncManager SIGABRT (a forked
    /// child's timed wait on a shared semaphore at the high mmap aperture).
    #[test]
    fn read_futex_word_falls_back_to_shared_mapping() {
        struct SharedOnly {
            word: u32,
        }
        impl GuestMemory for SharedOnly {
            fn read_bytes_raw(&self, address: u64, length: usize) -> Result<Vec<u8>, MemoryError> {
                Err(MemoryError::OutOfBounds { address, length })
            }
            fn write_bytes_raw(&mut self, address: u64, bytes: &[u8]) -> Result<(), MemoryError> {
                Err(MemoryError::OutOfBounds {
                    address,
                    length: bytes.len(),
                })
            }
            fn shared_futex_location(
                &self,
                _guest_addr: u64,
            ) -> Option<carrick_guest_mem::SharedFutexLocation> {
                Some(carrick_guest_mem::SharedFutexLocation::Direct {
                    word: HostVa(&self.word as *const u32 as usize),
                    waiter_key: &self.word as *const u32 as usize,
                })
            }
        }

        impl CurrentMmMemory for SharedOnly {}
        // Software read fails, but the shared host pointer yields the word.
        let mem = SharedOnly { word: 0x00C0_FFEE };
        assert_eq!(read_futex_word(&mem, 0x0100_0160_0000), Ok(0x00C0_FFEE));

        // No shared mapping -> EFAULT propagates unchanged (no regression for
        // a genuinely bad private/anon address).
        let lin = LinearMemory::new(0x1000, vec![0u8; 8]);
        assert_eq!(read_futex_word(&lin, 0x9_9999_9999), Err(LINUX_EFAULT));
    }

    struct CountingMemory {
        base: u64,
        bytes: Vec<u8>,
        reads: std::cell::Cell<usize>,
        writes: std::cell::Cell<usize>,
        shared_futex_lookups: std::cell::Cell<usize>,
    }

    impl CountingMemory {
        fn new(base: u64, bytes: Vec<u8>) -> Self {
            Self {
                base,
                bytes,
                reads: std::cell::Cell::new(0),
                writes: std::cell::Cell::new(0),
                shared_futex_lookups: std::cell::Cell::new(0),
            }
        }
    }

    impl GuestMemory for CountingMemory {
        fn read_bytes_raw(&self, address: u64, length: usize) -> Result<Vec<u8>, MemoryError> {
            self.reads.set(self.reads.get() + 1);
            let offset = address
                .checked_sub(self.base)
                .ok_or(MemoryError::OutOfBounds { address, length })?;
            let offset = usize::try_from(offset)
                .map_err(|_| MemoryError::OutOfBounds { address, length })?;
            let end = offset
                .checked_add(length)
                .ok_or(MemoryError::OutOfBounds { address, length })?;
            if end > self.bytes.len() {
                return Err(MemoryError::OutOfBounds { address, length });
            }
            Ok(self.bytes[offset..end].to_vec())
        }

        fn write_bytes_raw(&mut self, address: u64, bytes: &[u8]) -> Result<(), MemoryError> {
            self.writes.set(self.writes.get() + 1);
            let offset = address
                .checked_sub(self.base)
                .ok_or(MemoryError::OutOfBounds {
                    address,
                    length: bytes.len(),
                })?;
            let offset = usize::try_from(offset).map_err(|_| MemoryError::OutOfBounds {
                address,
                length: bytes.len(),
            })?;
            let end = offset
                .checked_add(bytes.len())
                .ok_or(MemoryError::OutOfBounds {
                    address,
                    length: bytes.len(),
                })?;
            if end > self.bytes.len() {
                return Err(MemoryError::OutOfBounds {
                    address,
                    length: bytes.len(),
                });
            }
            self.bytes[offset..end].copy_from_slice(bytes);
            Ok(())
        }

        fn shared_futex_location(
            &self,
            _guest_addr: u64,
        ) -> Option<carrick_guest_mem::SharedFutexLocation> {
            self.shared_futex_lookups
                .set(self.shared_futex_lookups.get() + 1);
            None
        }
    }

    impl CurrentMmMemory for CountingMemory {}

    #[test]
    fn private_futex_wake_skips_shared_mapping_lookup() {
        let mut memory = CountingMemory::new(0x10000, vec![0u8; 0x1000]);
        memory.write_bytes(0x10800, &0u32.to_le_bytes()).unwrap();
        let reporter = CompatReporter::default();
        let futex = crate::thread::FutexTable::new();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(1000));
        let request = SyscallRequest::new(
            98,
            SyscallArgs::from([
                0x10800,
                LINUX_FUTEX_WAKE | LinuxFutexFlags::PRIVATE.bits(),
                1,
                0,
                0,
                0,
            ]),
        );

        let clock = crate::kernel::container::ClockDomain::default();
        let outcome = dispatch_threaded_futex(
            &clock,
            request,
            &mut memory,
            &reporter,
            &futex,
            crate::thread::ThreadId::synthetic_for_tests(1001),
            &registry,
            None,
            None,
        );

        assert_eq!(outcome, DispatchOutcome::Returned { value: 0 });
        assert_eq!(memory.shared_futex_lookups.get(), 0);
        assert!(crate::event_ring::contains_event(
            crate::event_ring::FUTEXWAKE,
            0x10800,
            0,
            0
        ));
    }

    #[test]
    fn non_private_futex_wake_checks_shared_mapping_lookup() {
        let mut memory = CountingMemory::new(0x10000, vec![0u8; 0x1000]);
        memory.write_bytes(0x10800, &0u32.to_le_bytes()).unwrap();
        let reporter = CompatReporter::default();
        let futex = crate::thread::FutexTable::new();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(1000));
        let request = SyscallRequest::new(
            98,
            SyscallArgs::from([0x10800, LINUX_FUTEX_WAKE, 1, 0, 0, 0]),
        );

        let clock = crate::kernel::container::ClockDomain::default();
        let outcome = dispatch_threaded_futex(
            &clock,
            request,
            &mut memory,
            &reporter,
            &futex,
            crate::thread::ThreadId::synthetic_for_tests(1001),
            &registry,
            None,
            None,
        );

        assert_eq!(outcome, DispatchOutcome::Returned { value: 0 });
        assert_eq!(memory.shared_futex_lookups.get(), 1);
    }

    /// Task 7 fix #4: a non-private `FUTEX_WAKE` whose word lives in a genuine
    /// `MAP_SHARED` mapping (`shared_futex_location` → `Some`) must be routed
    /// through the `PlatformFutex::shared_wake` seam — i.e. returned as a
    /// `DispatchOutcome::SharedFutexWake`, NOT a `Returned` from an inline
    /// `ulock::wake`. The loop then drives the backend wake (HVF __ulock / KVM
    /// SYS_futex), keeping the shared wait+wake pair on ONE seam. (Before the fix
    /// the dispatcher called `ulock::wake` directly, so `KvmFutex::shared_wake`
    /// was never reached on Linux.)
    #[test]
    fn shared_futex_wake_routes_through_platform_seam() {
        struct SharedWord {
            word: u32,
        }
        impl GuestMemory for SharedWord {
            fn read_bytes_raw(&self, _address: u64, length: usize) -> Result<Vec<u8>, MemoryError> {
                Ok(self.word.to_le_bytes()[..length.min(4)].to_vec())
            }
            fn write_bytes_raw(&mut self, address: u64, bytes: &[u8]) -> Result<(), MemoryError> {
                Err(MemoryError::OutOfBounds {
                    address,
                    length: bytes.len(),
                })
            }
            fn shared_futex_location(
                &self,
                _guest_addr: u64,
            ) -> Option<carrick_guest_mem::SharedFutexLocation> {
                Some(carrick_guest_mem::SharedFutexLocation::Direct {
                    word: HostVa(&self.word as *const u32 as usize),
                    waiter_key: &self.word as *const u32 as usize,
                })
            }
        }

        impl CurrentMmMemory for SharedWord {}
        let mut memory = SharedWord { word: 0 };
        let location = carrick_guest_mem::SharedFutexLocation::Direct {
            word: HostVa(&memory.word as *const u32 as usize),
            waiter_key: &memory.word as *const u32 as usize,
        };
        let reporter = CompatReporter::default();
        let futex = crate::thread::FutexTable::new();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(1000));
        // Non-private FUTEX_WAKE (no PRIVATE flag) of up to 3 waiters.
        let request = SyscallRequest::new(
            98,
            SyscallArgs::from([0x10800, LINUX_FUTEX_WAKE, 3, 0, 0, 0]),
        );

        let clock = crate::kernel::container::ClockDomain::default();
        let outcome = dispatch_threaded_futex(
            &clock,
            request,
            &mut memory,
            &reporter,
            &futex,
            crate::thread::ThreadId::synthetic_for_tests(1001),
            &registry,
            None,
            None,
        );

        assert_eq!(
            outcome,
            DispatchOutcome::SharedFutexWake {
                target: SharedFutexTarget::new(location, location.waiter_key()),
                count: 3,
            },
            "a shared FUTEX_WAKE must defer to the PlatformFutex::shared_wake seam"
        );
    }

    /// On the LIVE multithreaded futex path (`dispatch_threaded_futex`), a present
    /// (non-NULL) `{tv_sec:0, tv_nsec:0}` relative `FUTEX_WAIT` timeout means
    /// "expire NOW" (ETIMEDOUT immediately), NOT "block forever" (the NULL-timeout
    /// case). Commit 519dd40f fixed this on the proc.rs `dispatch_normalized` path
    /// but the threaded path still collapsed `{0,0}` to `None`, parking forever.
    /// The parked `FutexWait` must carry `Some(Duration::ZERO)` (a deadline of
    /// `now`), never `None`.
    #[test]
    fn threaded_futex_wait_zero_but_present_timeout_parks_with_zero_deadline() {
        let mut memory = CountingMemory::new(0x10000, vec![0u8; 0x1000]);
        // Futex word == the expected value, so WAIT does not short-circuit to
        // EAGAIN and must consult the timeout.
        memory.write_bytes(0x10800, &7u32.to_le_bytes()).unwrap();
        // A present (non-NULL) relative timespec of {0, 0} at 0x10810.
        memory.write_bytes(0x10810, &[0u8; 16]).unwrap();
        let reporter = CompatReporter::default();
        let futex = crate::thread::FutexTable::new();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(1000));
        // Private FUTEX_WAIT (no shared mapping) so the park stays in the
        // in-process parking-lot table and returns a `FutexWait` outcome.
        let request = SyscallRequest::new(
            98,
            SyscallArgs::from([
                0x10800,
                LINUX_FUTEX_WAIT | LinuxFutexFlags::PRIVATE.bits(),
                7,
                0x10810,
                0,
                0,
            ]),
        );

        let clock = crate::kernel::container::ClockDomain::default();
        let outcome = dispatch_threaded_futex(
            &clock,
            request,
            &mut memory,
            &reporter,
            &futex,
            crate::thread::ThreadId::synthetic_for_tests(1001),
            &registry,
            None,
            None,
        );

        match outcome {
            DispatchOutcome::FutexWait { timeout, .. } => assert_eq!(
                timeout,
                Some(std::time::Duration::ZERO),
                "a present {{0,0}} timeout must park with a zero deadline (expire now), \
                 not None (block forever)"
            ),
            other => panic!("expected a FutexWait park outcome, got {other:?}"),
        }
    }

    #[test]
    fn fresh_shared_anon_mmap_skips_zero_write() {
        let reporter = CompatReporter::default();
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = CountingMemory::new(0x10000, vec![0u8; 0x1000]);

        let outcome = dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(
                    222,
                    SyscallArgs::from([
                        0,
                        0x4000,
                        LINUX_PROT_READ | LINUX_PROT_WRITE,
                        LINUX_MAP_SHARED | LINUX_MAP_ANONYMOUS,
                        u64::MAX,
                        0,
                    ]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();

        assert_eq!(
            outcome,
            DispatchOutcome::Returned {
                value: crate::memory::LINUX_SHARED_FILE_BASE as i64
            }
        );
        assert_eq!(
            memory.writes.get(),
            0,
            "fresh MAP_SHARED|MAP_ANON should use the boot-zeroed shared aperture without materializing a zero buffer"
        );
        assert!(reporter.finish().unhandled_syscalls.is_empty());
    }

    // A `munmap`'d shared-anon slot that a later mmap recycles MUST be scrubbed
    // before reuse (no prior-tenant bytes leak into the new mapping). The scrub
    // runs `zero_anonymous_reuse` over the whole recycled HVF page, so the test
    // memory must actually be able to hold the scrubbed range: `CountingMemory`
    // is based at `LINUX_SHARED_FILE_BASE` with the full slot backed, otherwise
    // the scrub write faults `OutOfBounds` and the mmap fails ENOMEM.
    #[test]
    fn reused_shared_anon_mmap_zeroes_recycled_range() {
        let reporter = CompatReporter::default();
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory =
            CountingMemory::new(crate::memory::LINUX_SHARED_FILE_BASE, vec![0u8; 0x4000]);
        let mmap_args = SyscallArgs::from([
            0,
            0x4000,
            LINUX_PROT_READ | LINUX_PROT_WRITE,
            LINUX_MAP_SHARED | LINUX_MAP_ANONYMOUS,
            u64::MAX,
            0,
        ]);

        assert_eq!(
            dispatcher
                .dispatch(
                    &dispatcher.capture_one_task_context().unwrap(),
                    SyscallRequest::new(222, mmap_args),
                    &mut memory,
                    &reporter
                )
                .unwrap(),
            DispatchOutcome::Returned {
                value: crate::memory::LINUX_SHARED_FILE_BASE as i64
            }
        );
        memory.writes.set(0);

        assert_eq!(
            dispatcher
                .dispatch(
                    &dispatcher.capture_one_task_context().unwrap(),
                    SyscallRequest::new(
                        215,
                        SyscallArgs::from([
                            crate::memory::LINUX_SHARED_FILE_BASE,
                            0x4000,
                            0,
                            0,
                            0,
                            0,
                        ]),
                    ),
                    &mut memory,
                    &reporter,
                )
                .unwrap(),
            DispatchOutcome::Returned { value: 0 }
        );
        memory.writes.set(0);

        assert_eq!(
            dispatcher
                .dispatch(
                    &dispatcher.capture_one_task_context().unwrap(),
                    SyscallRequest::new(222, mmap_args),
                    &mut memory,
                    &reporter
                )
                .unwrap(),
            DispatchOutcome::Returned {
                value: crate::memory::LINUX_SHARED_FILE_BASE as i64
            }
        );
        // The recycled slot is one HVF page (`HVF_PAGE_SIZE` = 0x4000) and the
        // scrub streams it through `zero_range_chunked` in 4 KiB `ZERO_CHUNK`
        // writes, so 0x4000 / 0x1000 = 4 raw writes cover it exactly once.
        assert_eq!(
            memory.writes.get(),
            4,
            "reused MAP_SHARED|MAP_ANON ranges must still be scrubbed before reuse"
        );
        assert!(reporter.finish().unhandled_syscalls.is_empty());
    }

    #[test]
    fn read_guest_c_string_reads_in_chunks_not_one_byte_at_a_time() {
        let mut bytes = vec![b'a'; 300];
        bytes.push(0);
        bytes.resize(512, 0);
        let memory = CountingMemory::new(0x4000, bytes);

        let value = read_guest_c_string(&memory, 0x4000).unwrap();

        assert_eq!(value.len(), 300);
        assert!(
            memory.reads.get() <= 3,
            "read_guest_c_string should chunk reads, not issue {} byte reads",
            memory.reads.get(),
        );
    }

    #[test]
    fn every_migrated_syscall_is_claimed_by_the_normalized_table() {
        let d = SyscallDispatcher::new();
        let mut mem = LinearMemory::new(0, vec![0u8; 4096]);
        let reporter = CompatReporter::default();
        // Numbers that used to live in the deleted legacy match. Each must now
        // be claimed by the normalized table (Some), never None.
        for nr in [
            5u64, 7, 8, 10, 11, 13, 14, 43, 44, 45, 74, 93, 151, 152, 159, 172, 173, 174, 175, 176,
            177, 178, 243, 269, 283, 293, 435,
        ] {
            let req = SyscallRequest::new(nr, SyscallArgs::from([0, 0, 0, 0, 0, 0]));
            assert!(
                d.dispatch_normalized(
                    &d.capture_one_task_context().unwrap(),
                    req,
                    &mut mem,
                    &reporter,
                    None
                )
                .is_some(),
                "syscall {nr} fell through the normalized table",
            );
        }
    }

    #[test]
    fn resolve_exec_path_absolutizes_relative_against_cwd() {
        let d = SyscallDispatcher::new();
        // Default cwd is "/": a relative exec path resolves against it. This is
        // the Go os/exec TestCommandRelativeName shape (cmd.Path="b/foo",
        // cmd.Dir="/").
        assert_eq!(d.resolve_exec_path("b/os_exec.test"), "/b/os_exec.test");
        // With a deeper cwd, the relative path joins onto it.
        d.set_cwd("/run/src/os/exec");
        assert_eq!(d.resolve_exec_path("./echo"), "/run/src/os/exec/echo");
        assert_eq!(d.resolve_exec_path("../x"), "/run/src/os/x");
        // Absolute paths are normalized but not cwd-joined.
        assert_eq!(d.resolve_exec_path("/bin/sh"), "/bin/sh");
        assert_eq!(d.resolve_exec_path("/bin/../bin/sh"), "/bin/sh");
    }

    #[test]
    fn unknown_syscall_returns_enosys_without_panicking() {
        let mut d = SyscallDispatcher::new();
        let mut mem = LinearMemory::new(0, vec![0u8; 4096]);
        let reporter = CompatReporter::default();
        // 999 is not a real aarch64 syscall and is not in the table.
        let req = SyscallRequest::new(999, SyscallArgs::from([0, 0, 0, 0, 0, 0]));
        let outcome = d
            .dispatch(
                &d.capture_one_task_context().unwrap(),
                req,
                &mut mem,
                &reporter,
            )
            .expect("must not error");
        assert_eq!(
            outcome,
            DispatchOutcome::Errno {
                errno: LINUX_ENOSYS
            }
        );
    }

    /// The dispatcher's `pty_table()` accessor must return the same
    /// `Arc`-wrapped table that was cloned into the `/dev` and `/dev/pts`
    /// mounts. Because all three hold clones of the same `Arc`, mutations
    /// through one pointer are visible through any other.
    #[test]
    fn dispatcher_shares_pty_table_with_dev_mounts() {
        let dispatcher = SyscallDispatcher::with_rootfs(empty_rootfs());
        // A freshly constructed dispatcher has an empty pty table.
        assert!(
            dispatcher.pty_table().lock().live_indices().is_empty(),
            "pty table should start empty"
        );
        // Confirm the Arc is genuinely shared: insert an entry directly into
        // the table and verify the dispatcher sees it through its accessor.
        let index = dispatcher
            .pty_table()
            .lock()
            .insert("dummy-slave".to_string(), 1234);
        assert_eq!(
            dispatcher.pty_table().lock().live_indices(),
            vec![index],
            "inserted index must be visible through the dispatcher accessor"
        );
    }

    #[test]
    fn dns_overrides_render_resolv_conf() {
        let spec = carrick_spec::NetworkNamespaceSpec {
            dns_servers: vec!["1.1.1.1".parse().unwrap(), "9.9.9.9".parse().unwrap()],
            dns_search: vec!["example.test".to_string()],
            dns_options: vec!["ndots:2".to_string()],
            ..Default::default()
        };

        let model = crate::network::model::LinuxNetworkModel::from_spec(&spec);
        let contents = String::from_utf8(resolv_conf_contents_for_network(&model)).unwrap();
        assert!(contents.contains("nameserver 1.1.1.1\n"));
        assert!(contents.contains("nameserver 9.9.9.9\n"));
        assert!(contents.contains("search example.test\n"));
        assert!(contents.contains("options ndots:2\n"));
    }

    #[test]
    fn with_network_mounts_sys_class_net_from_model() {
        let mut spec = carrick_spec::NetworkNamespaceSpec::bridge_default(
            Some("web".to_string()),
            Vec::new(),
            Vec::new(),
        );
        spec.attachments = vec![
            carrick_spec::NetworkAttachmentSpec::bridge_default(
                carrick_spec::BridgeId::new("front"),
                Some("web".to_string()),
                vec!["web-front".to_string()],
                Some(std::net::Ipv4Addr::new(172, 31, 0, 44)),
            ),
            carrick_spec::NetworkAttachmentSpec::bridge_default(
                carrick_spec::BridgeId::new("back"),
                Some("web".to_string()),
                vec!["web-back".to_string()],
                Some(std::net::Ipv4Addr::new(172, 32, 0, 44)),
            ),
        ];
        spec.bridge_id = spec.attachments[0].bridge_id.clone();
        spec.ipv4 = spec.attachments[0].ipv4;
        spec.gateway_v4 = spec.attachments[0].gateway_v4;
        let network = std::sync::Arc::new(crate::network::RuntimeNetwork::create(&spec).unwrap());
        let dispatcher = SyscallDispatcher::with_network(network);
        let sys = dispatcher.fs.vfs_mounts.resolve("/sys/class/net").unwrap();

        let names = sys
            .vfs
            .readdir("/sys/class/net")
            .unwrap()
            .into_iter()
            .map(|entry| entry.name)
            .collect::<Vec<_>>();
        assert_eq!(names, vec!["lo", "eth0", "eth1"]);

        let eth1 = sys
            .vfs
            .open(
                "/sys/class/net/eth1/ifindex",
                carrick_vfs::OpenFlags::default(),
                &carrick_vfs::OpenContext::default(),
            )
            .unwrap();
        let carrick_vfs::VfsHandle::Bytes { contents, .. } = eth1 else {
            panic!("model-backed /sys/class/net ifindex should open as bytes");
        };
        assert_eq!(String::from_utf8(contents).unwrap(), "3\n");
    }

    /// Host mode gives the guest a LINUX namespace whose links mirror the host
    /// wire — never the Mac's own interface list.
    ///
    /// This replaces `with_host_network_preserves_host_sys_class_net`, which
    /// asserted the opposite and was the defect written down as a test: on the
    /// default lane `/sys/class/net` listed `en0`, `awdl0`, `bridge0` and
    /// `utun*` while the rtnetlink dump the same guest read advertised `lo` and
    /// `eth0`.
    #[test]
    fn with_host_network_shows_linux_link_names() {
        let network = std::sync::Arc::new(crate::network::RuntimeNetwork::host_default());
        let host_dispatcher = SyscallDispatcher::with_network(network);
        let host_sys = host_dispatcher
            .fs
            .vfs_mounts
            .resolve("/sys/class/net")
            .unwrap();

        let names = host_sys
            .vfs
            .readdir("/sys/class/net")
            .unwrap()
            .into_iter()
            .map(|entry| entry.name)
            .collect::<Vec<_>>();

        assert!(names.contains(&"lo".to_string()), "{names:?}");
        assert!(
            names.iter().all(|name| name == "lo"
                || name
                    .strip_prefix("eth")
                    .is_some_and(|n| n.parse::<u32>().is_ok())),
            "host mode must still show a Linux namespace: {names:?}"
        );
    }

    /// The Linux errno constants we publish must match the
    /// asm-generic kernel headers. Pinned values from
    /// linux/include/uapi/asm-generic/errno{,-base}.h.
    #[test]
    fn linux_errno_constants_match_kernel_uapi() {
        use crate::dispatch::linux_errno::*;
        assert_eq!(EPERM.get(), 1);
        assert_eq!(ENOENT.get(), 2);
        assert_eq!(EAGAIN.get(), 11);
        assert_eq!(ENOMEM.get(), 12);
        assert_eq!(EFAULT.get(), 14);
        assert_eq!(EINVAL.get(), 22);
        assert_eq!(ESPIPE.get(), 29);
        assert_eq!(EDEADLK.get(), 35);
        assert_eq!(ENAMETOOLONG.get(), 36);
        assert_eq!(ENOSYS.get(), 38);
        assert_eq!(EINPROGRESS.get(), 115);
        assert_eq!(ETIMEDOUT.get(), 110);
        assert_eq!(ECONNREFUSED.get(), 111);
    }

    #[test]
    fn status_flags_are_one_value_owned_by_description_common() {
        let open_file = eventfd_open_file(0);
        let description = &open_file.description;

        // The description answers without taking the backing lock...
        assert_eq!(
            description.common().status_flags(),
            crate::linux_abi::LINUX_O_RDWR
        );

        description
            .common()
            .set_status_flags(carrick_abi::LINUX_O_NONBLOCK);
        assert_eq!(
            description.common().status_flags(),
            carrick_abi::LINUX_O_NONBLOCK
        );

        description.common().set_status_flags(0);
        assert_eq!(description.common().status_flags(), 0);
    }

    #[test]
    fn generic_description_state_outlives_the_backing_close() {
        let open_file = eventfd_open_file(0);
        let description = std::sync::Arc::clone(&open_file.description);

        description.common().retain_fd_ref();
        description
            .common()
            .set_lease(crate::linux_abi::LINUX_F_WRLCK);
        assert_eq!(
            description.common().lease(),
            crate::linux_abi::LINUX_F_WRLCK
        );
        description
            .common()
            .set_owner(crate::kernel::objects::AsyncIoOwner {
                owner_type: 2,
                owner_pid: 77,
            });
        assert_eq!(
            description.common().owner(),
            crate::kernel::objects::AsyncIoOwner {
                owner_type: 2,
                owner_pid: 77,
            }
        );
        description
            .common()
            .set_async_sig(carrick_abi::LINUX_SIGUSR2);
        assert_eq!(description.common().async_sig(), carrick_abi::LINUX_SIGUSR2);
        description.common().set_seals(Some(0b0010));
        assert_eq!(description.common().seals(), Some(0b0010));
        description.common().set_secretmem(true);
        assert!(description.common().secretmem());

        // Drain the backing to its Closed identity shell. Reaching this state used
        // to abort the process through OpenDescription::base().
        *description.write().expect("open description write guard") =
            OpenDescription::Closed { was_epoll: false };

        assert_eq!(description.common().fd_refs(), 1);
        assert_eq!(
            description.common().lease(),
            crate::linux_abi::LINUX_F_WRLCK
        );
        assert_eq!(
            description.common().owner(),
            crate::kernel::objects::AsyncIoOwner {
                owner_type: 2,
                owner_pid: 77,
            }
        );
        assert_eq!(description.common().async_sig(), carrick_abi::LINUX_SIGUSR2);
        assert_eq!(description.common().seals(), Some(0b0010));
        assert!(description.common().secretmem());
    }
}

#[cfg(test)]
mod rosetta_handshake_tests {
    use super::*;

    const BASE: u64 = 0x4000;

    fn mem() -> LinearMemory {
        LinearMemory::new(BASE, vec![0xABu8; 256])
    }

    #[test]
    fn non_rosetta_ioctl_passes_through() {
        // A normal ioctl (e.g. TCGETS=0x5401) is not claimed by the handshake.
        let mut m = mem();
        assert!(rosetta_handshake_ioctl(&mut m, 0x5401, BASE).is_none());
    }

    #[test]
    fn info_ioctl_returns_zero_and_zeroes_buffer() {
        // 0x80806123: size field = 0x80 (128). Not memcmp'd; success + zeroed.
        let mut m = mem();
        let outcome =
            rosetta_handshake_ioctl(&mut m, 0x80806123, BASE).expect("info ioctl must be handled");
        assert_eq!(outcome, DispatchOutcome::Returned { value: 0 });
        let buf = m.read_bytes(BASE, 128).unwrap();
        assert!(buf.iter().all(|&b| b == 0), "info buffer must be zeroed");
    }

    #[test]
    fn license_ioctl_writes_blob_when_rosetta_present() {
        // 0x80456125: size field = 0x45 (69). When Rosetta is installed the
        // buffer is filled with its verification blob; either way it succeeds.
        let mut m = mem();
        let outcome = rosetta_handshake_ioctl(&mut m, 0x80456125, BASE)
            .expect("licence ioctl must be handled");
        assert_eq!(outcome, DispatchOutcome::Returned { value: 0 });
        if super::rosetta::rosetta_license_blob().is_some() {
            let buf = m.read_bytes(BASE, 13).unwrap();
            assert_eq!(&buf, b"Our hard work");
        }
    }

    #[test]
    fn faulting_address_returns_efault() {
        // An out-of-bounds buffer address must surface EFAULT, not panic.
        let mut m = mem();
        let outcome = rosetta_handshake_ioctl(&mut m, 0x80806123, 0xDEAD_0000)
            .expect("info ioctl must be handled");
        assert_eq!(
            outcome,
            DispatchOutcome::Errno {
                errno: LINUX_EFAULT
            }
        );
    }
}

#[cfg(test)]
mod hvpatch_in_process_fork_tests {
    use super::*;

    pub(super) fn fork_dispatcher(
        parent: &SyscallDispatcher,
        parent_tid: crate::thread::ThreadId,
        child_tid: crate::thread::ThreadId,
        parent_guest_pid: u32,
        child_guest_pid: u32,
    ) -> (SyscallDispatcher, crate::kernel::KernelContext) {
        fork_dispatcher_with_clone_flags(
            parent,
            parent_tid,
            child_tid,
            parent_guest_pid,
            child_guest_pid,
            carrick_abi::LinuxCloneFlags::empty(),
        )
    }

    fn fork_dispatcher_with_clone_flags(
        parent: &SyscallDispatcher,
        parent_tid: crate::thread::ThreadId,
        child_tid: crate::thread::ThreadId,
        parent_guest_pid: u32,
        child_guest_pid: u32,
        flags: carrick_abi::LinuxCloneFlags,
    ) -> (SyscallDispatcher, crate::kernel::KernelContext) {
        let parent_context = parent.capture_one_task_context().unwrap();
        let plan = crate::kernel::ClonePlan::from_flags(flags).unwrap();
        let child_context = parent_context
            .kernel()
            .reserve_fork(
                &parent_context,
                plan,
                "dispatcher-fork-test".to_owned(),
                None,
            )
            .unwrap()
            .prepare_reference(child_tid)
            .unwrap()
            .commit()
            .unwrap()
            .into_parts()
            .unwrap()
            .0;
        let child =
            parent.fork_clone_in_process(parent_tid, child_tid, parent_guest_pid, child_guest_pid);
        *child.kernel_binding.write() = child_context.task_binding();
        (child, child_context)
    }

    #[test]
    fn hvpatch_close_range_unshare_splits_clone_files_before_closing_child_fd() {
        let parent = SyscallDispatcher::new();
        let parent_context = parent.capture_one_task_context().unwrap();
        let parent_tid = parent_context.thread().registry_id();
        let description = kernel_file_description(
            Arc::new(RwLock::new(OpenDescription::SyntheticFile {
                base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_RDWR),
                path: "/close-range-unshare".to_owned(),
                contents: b"payload".to_vec(),
                offset: 0,
            })),
            crate::linux_abi::LINUX_O_RDWR,
        );
        parent
            .captured_file_table()
            .write_open_files()
            .insert(3, OpenFile::new(Arc::clone(&description), 0));
        retain_open_file(&description);
        let parent_files = parent.captured_file_table();
        let parent_slot = parent_files
            .read_open_files()
            .get(&3)
            .cloned()
            .expect("parent fd 3");

        let child_tid = crate::thread::ThreadId::synthetic_for_tests(4102);
        let (mut child, child_context) = fork_dispatcher_with_clone_flags(
            &parent,
            parent_tid,
            child_tid,
            43,
            44,
            carrick_abi::LinuxCloneFlags::FILES,
        );
        assert!(Arc::ptr_eq(
            &parent_files,
            &child_context.resources().files()
        ));

        let mut memory = LinearMemory::new(0x10000, vec![0u8; 0x1000]);
        let outcome = child
            .dispatch(
                &child_context,
                SyscallRequest::new(
                    436,
                    SyscallArgs::from([
                        3,
                        3,
                        carrick_abi::LINUX_CLOSE_RANGE_UNSHARE as u64,
                        0,
                        0,
                        0,
                    ]),
                ),
                &mut memory,
                &CompatReporter::default(),
            )
            .expect("close_range dispatch");
        assert_eq!(outcome, DispatchOutcome::Returned { value: 0 });

        let child_successor = child
            .capture_one_task_context()
            .unwrap()
            .resources()
            .files();
        assert!(!Arc::ptr_eq(&parent_files, &child_successor));
        assert!(!child_successor.read_open_files().contains_key(&3));
        let parent_after = parent_files
            .read_open_files()
            .get(&3)
            .cloned()
            .expect("parent fd 3 retained");
        assert!(Arc::ptr_eq(
            &parent_slot.description,
            &parent_after.description
        ));
        assert!(Arc::ptr_eq(&description, &parent_after.description));
        assert_eq!(parent_after.description.fd_ref_count(), 1);
    }

    #[test]
    fn fcntl_pipe_set_capacity_works_on_successor_table_after_close_range_unshare() {
        let mut parent = SyscallDispatcher::new();
        let parent_context = parent.capture_one_task_context().unwrap();
        let parent_files = parent_context.resources().files();
        parent
            .activate_file_authority(Arc::clone(&parent_files))
            .expect("activate FileAuthority on launch root");

        let mut memory = LinearMemory::new(0x10000, vec![0u8; 0x1000]);
        let reporter = CompatReporter::default();

        // 1. Create a pipe on the parent.
        let pipe_res = parent
            .dispatch(
                &parent_context,
                SyscallRequest::new(59, SyscallArgs::from([0x10200, 0, 0, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .expect("pipe2 dispatch");
        assert_eq!(pipe_res, DispatchOutcome::Returned { value: 0 });
        let pair = memory.read_bytes(0x10200, 8).unwrap();
        let read_fd = i32::from_ne_bytes(pair[0..4].try_into().unwrap()) as u64;
        let write_fd = i32::from_ne_bytes(pair[4..8].try_into().unwrap()) as u64;

        // Verify initial capacity is default 65536
        let get_init = parent
            .dispatch(
                &parent_context,
                SyscallRequest::new(
                    25,
                    SyscallArgs::from([read_fd, carrick_abi::LINUX_F_GETPIPE_SZ, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("getpipe_sz dispatch");
        assert_eq!(get_init, DispatchOutcome::Returned { value: 65536 });

        // 2. Fork a child sharing the file table (CLONE_FILES).
        let parent_tid = parent_context.thread().registry_id();
        let child_tid = crate::thread::ThreadId::synthetic_for_tests(4199);
        let (mut child, child_context) = fork_dispatcher_with_clone_flags(
            &parent,
            parent_tid,
            child_tid,
            41,
            42,
            carrick_abi::LinuxCloneFlags::FILES,
        );
        assert!(Arc::ptr_eq(
            &parent_files,
            &child_context.resources().files()
        ));

        // 3. Child unshares file table via close_range with CLOSE_RANGE_UNSHARE on an unrelated fd.
        let unshare_res = child
            .dispatch(
                &child_context,
                SyscallRequest::new(
                    436,
                    SyscallArgs::from([
                        99,
                        99,
                        carrick_abi::LINUX_CLOSE_RANGE_UNSHARE as u64,
                        0,
                        0,
                        0,
                    ]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("close_range unshare dispatch");
        assert_eq!(unshare_res, DispatchOutcome::Returned { value: 0 });

        let child_successor_context = child.capture_one_task_context().unwrap();
        let child_successor_files = child_successor_context.resources().files();
        assert!(!Arc::ptr_eq(&parent_files, &child_successor_files));

        // Activation must not repeat: attempting to activate authority with successor table is rejected
        let repeat_activation = child.activate_file_authority(Arc::clone(&child_successor_files));
        assert!(matches!(
            repeat_activation,
            Err(crate::file_authority::AuthorityFatal::InvariantViolation(_))
        ));

        // Old launch root must not authorize calls on successor slot
        let successor_slot = child_successor_files
            .capture_slot_authority(
                crate::kernel::FileSlotNumber::for_open_fd(read_fd as i32).unwrap(),
            )
            .expect("slot authority on successor table");
        let command = crate::file_authority::Command::SetCanonicalPipeCapacity {
            slot: successor_slot,
            capacity: crate::file_authority::PipeCapacity::bounded(131072).unwrap(),
            accounting: crate::kernel::objects::PipeCapacityAccounting::InMemory,
        };
        let mismatched_auth_call =
            child.authority_call(Arc::clone(&parent_files), successor_slot, command);
        assert!(matches!(
            mismatched_auth_call,
            Err(crate::dispatch::AuthorityCallError::Fatal(
                crate::file_authority::AuthorityFatal::InvariantViolation(_)
            ))
        ));

        // 4. F_SETPIPE_SZ succeeds on the published successor table through normal dispatch!
        let set_res = child
            .dispatch(
                &child_successor_context,
                SyscallRequest::new(
                    25,
                    SyscallArgs::from([read_fd, carrick_abi::LINUX_F_SETPIPE_SZ, 131072, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("fcntl setpipe_sz dispatch on successor");
        assert_eq!(set_res, DispatchOutcome::Returned { value: 131072 });

        // Both ends reflect new capacity on successor
        let get_read = child
            .dispatch(
                &child_successor_context,
                SyscallRequest::new(
                    25,
                    SyscallArgs::from([read_fd, carrick_abi::LINUX_F_GETPIPE_SZ, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("getpipe_sz read");
        assert_eq!(get_read, DispatchOutcome::Returned { value: 131072 });

        let get_write = child
            .dispatch(
                &child_successor_context,
                SyscallRequest::new(
                    25,
                    SyscallArgs::from([write_fd, carrick_abi::LINUX_F_GETPIPE_SZ, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("getpipe_sz write");
        assert_eq!(get_write, DispatchOutcome::Returned { value: 131072 });
    }

    #[test]
    fn hvpatch_pi_futex_owner_uses_kernel_linux_tid() {
        let parent = SyscallDispatcher::new();
        let parent_context = parent.capture_one_task_context().unwrap();
        let parent_tid = parent_context.thread().registry_id();
        let child_registry_id = crate::thread::ThreadId::synthetic_for_tests(4101);
        let (child, child_context) =
            fork_dispatcher(&parent, parent_tid, child_registry_id, 41, 42);

        // HVPatch's host-thread registry id is execution machinery, not the
        // Linux-visible tid allocated by the authoritative kernel graph.
        let transport_tid = crate::thread::ThreadId::synthetic_for_tests(9101);
        let registry = crate::thread::ThreadRegistry::new(transport_tid);
        let mut memory = LinearMemory::new(0x10000, vec![0u8; 0x1000]);
        let address = 0x10800;
        write_u32(&mut memory, address, 0).unwrap();

        let outcome = child
            .dispatch_threaded(
                &child_context,
                SyscallRequest::new(
                    98,
                    SyscallArgs::from([
                        address,
                        LINUX_FUTEX_LOCK_PI | LINUX_FUTEX_PRIVATE_FLAG,
                        0,
                        0,
                        0,
                        0,
                    ]),
                ),
                &mut memory,
                &CompatReporter::default(),
                ThreadCtx::new(transport_tid, &registry, &crate::thread::FutexTable::new()),
            )
            .unwrap();

        assert_eq!(outcome, DispatchOutcome::Returned { value: 0 });
        assert_eq!(
            read_u32(&memory, address).unwrap(),
            u32::try_from(child_context.thread().key().tid.raw()).unwrap()
        );
    }

    #[test]
    pub(super) fn dispatcher_fork_clone_splits_process_state_without_duping_descriptions() {
        let child_tid = crate::thread::ThreadId::synthetic_for_tests(4101);
        let parent = SyscallDispatcher::new();
        let parent_context = parent.capture_one_task_context().unwrap();
        let parent_tid = parent_context.thread().registry_id();
        let description = kernel_file_description(
            Arc::new(RwLock::new(OpenDescription::SyntheticFile {
                base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_RDWR),
                path: "/fork-clone".to_owned(),
                contents: b"payload".to_vec(),
                offset: 2,
            })),
            crate::linux_abi::LINUX_O_RDWR,
        );
        parent.captured_file_table().write_open_files().insert(
            3,
            OpenFile::new(Arc::clone(&description), crate::linux_abi::LINUX_FD_CLOEXEC),
        );
        parent.restore_signal_mask(
            &parent_context,
            parent_tid,
            carrick_abi::SigSet::EMPTY.with(12),
        );
        parent.mark_signal_pending(&parent_context, parent_tid, 15);
        parent.proc.lock().pdeathsig = 9;
        parent.proc.lock().membarrier_ready = u64::MAX;
        parent.mem().lock().brk_current = 0x1234_0000;

        let (child, child_context) = fork_dispatcher(&parent, parent_tid, child_tid, 41, 42);

        let child_file = child
            .captured_file_table()
            .read_open_files()
            .get(&3)
            .cloned()
            .unwrap();
        assert!(Arc::ptr_eq(&description, &child_file.description));
        assert_eq!(child_file.fd_flags, crate::linux_abi::LINUX_FD_CLOEXEC);
        assert_eq!(
            child.signal_mask_for(&child_context, child_tid).raw(),
            1 << 11
        );
        assert!(child_context.thread().signal_state().pending().is_empty());
        assert_eq!(child.proc.lock().pdeathsig, 0);
        assert_eq!(child.proc.lock().membarrier_ready, 0);
        assert_eq!(child.mem().lock().brk_current, 0x1234_0000);

        child.captured_file_table().write_open_files().remove(&3);
        child.mem().lock().brk_current = 0x5678_0000;
        assert!(
            parent
                .captured_file_table()
                .read_open_files()
                .contains_key(&3)
        );
        assert_eq!(parent.mem().lock().brk_current, 0x1234_0000);
    }

    #[test]
    fn in_memory_file_open_handle_survives_fork_and_reexec_filtering() {
        let child_tid = crate::thread::ThreadId::synthetic_for_tests(4102);
        let parent = SyscallDispatcher::new();
        let parent_context = parent.capture_one_task_context().unwrap();
        let parent_tid = parent_context.thread().registry_id();

        let shared_buf = Arc::new(RwLock::new(carrick_vfs::SparseBuffer::from(
            b"initial_data".to_vec(),
        )));
        let desc_non_cloexec = kernel_file_description(
            Arc::new(RwLock::new(OpenDescription::InMemoryFile {
                base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_RDWR),
                path: "/in_memory_1.txt".to_string(),
                contents: Arc::clone(&shared_buf),
                offset: 0,
                writable: true,
                max_size: 1024 * 1024,
            })),
            crate::linux_abi::LINUX_O_RDWR,
        );
        let desc_cloexec = kernel_file_description(
            Arc::new(RwLock::new(OpenDescription::InMemoryFile {
                base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_RDWR),
                path: "/in_memory_2.txt".to_string(),
                contents: Arc::new(RwLock::new(carrick_vfs::SparseBuffer::from(
                    b"secret".to_vec(),
                ))),
                offset: 0,
                writable: true,
                max_size: 1024 * 1024,
            })),
            crate::linux_abi::LINUX_O_RDWR,
        );

        parent
            .captured_file_table()
            .write_open_files()
            .insert(3, OpenFile::new(Arc::clone(&desc_non_cloexec), 0));
        parent.captured_file_table().write_open_files().insert(
            4,
            OpenFile::new(
                Arc::clone(&desc_cloexec),
                crate::linux_abi::LINUX_FD_CLOEXEC,
            ),
        );

        let (child, _child_context) = fork_dispatcher(&parent, parent_tid, child_tid, 51, 52);

        // 1. Fork preserves both open file descriptions in child
        {
            let child_ft = child.captured_file_table();
            let child_files = child_ft.read_open_files();
            let child_f3 = child_files.get(&3).unwrap();
            let child_f4 = child_files.get(&4).unwrap();
            assert!(Arc::ptr_eq(&desc_non_cloexec, &child_f3.description));
            assert!(Arc::ptr_eq(&desc_cloexec, &child_f4.description));
            assert_eq!(child_f3.fd_flags, 0);
            assert_eq!(child_f4.fd_flags, crate::linux_abi::LINUX_FD_CLOEXEC);
        }

        // 2. Modifying shared buffer via child is visible to parent
        shared_buf.write().extend_from_slice(b"_appended").unwrap();
        assert_eq!(&*shared_buf.read(), b"initial_data_appended");

        // 3. Exec retains non-CLOEXEC file (fd 3) and closes CLOEXEC file (fd 4)
        {
            let child_files = child.captured_file_table();
            let mut table = child_files.write_open_files();
            let cloexec: Vec<i32> = table
                .iter()
                .filter(|(_, of)| {
                    carrick_abi::LinuxFdFlags::from_bits_truncate(of.fd_flags)
                        .contains(carrick_abi::LinuxFdFlags::CLOEXEC)
                })
                .map(|(fd, _)| *fd)
                .collect();
            for fd in cloexec {
                table.remove(&fd);
            }
        }
        let child_ft = child.captured_file_table();
        let post_exec_files = child_ft.read_open_files();
        assert!(post_exec_files.contains_key(&3));
        assert!(!post_exec_files.contains_key(&4));
    }

    #[test]
    fn hvpatch_exit_notification_observes_retired_inherited_pipe_writer() {
        let mut host_fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(host_fds.as_mut_ptr()) }, 0);
        let read_host_fd = host_fds[0];
        let write_host_fd = host_fds[1];

        let parent = SyscallDispatcher::new();
        parent.captured_file_table().write_open_files().insert(
            3,
            OpenFile::from_open_description_with_status_flags(
                Arc::new(RwLock::new(OpenDescription::HostPipe {
                    host_fd: HostFdRef::new(read_host_fd),
                    is_read_end: true,
                    pipe_id: 1,
                    base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_RDONLY),
                    pty: None,
                    bidirectional: false,
                    write_kind: HostWriteKind::PipeLike,
                    stdio_stream: None,
                })),
                crate::linux_abi::LINUX_O_RDONLY,
                0,
            ),
        );
        parent.captured_file_table().write_open_files().insert(
            4,
            OpenFile::from_open_description_with_status_flags(
                Arc::new(RwLock::new(OpenDescription::HostPipe {
                    host_fd: HostFdRef::new(write_host_fd),
                    is_read_end: false,
                    pipe_id: 1,
                    base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_WRONLY),
                    pty: None,
                    bidirectional: false,
                    write_kind: HostWriteKind::PipeLike,
                    stdio_stream: None,
                })),
                crate::linux_abi::LINUX_O_WRONLY,
                0,
            ),
        );
        for open_file in parent.captured_file_table().read_open_files().values() {
            retain_open_file(&open_file.description);
        }

        let parent_tid = crate::thread::ThreadId::synthetic_for_tests(5100);
        let child_tid = crate::thread::ThreadId::synthetic_for_tests(5101);
        let (child, child_context) = fork_dispatcher(&parent, parent_tid, child_tid, 51, 52);
        let parent_writer = parent
            .captured_file_table()
            .write_open_files()
            .remove(&4)
            .unwrap();
        parent.close_open_file_and_free_pty(&parent_writer);
        drop(parent_writer);

        let mut pollfd = libc::pollfd {
            fd: read_host_fd,
            events: libc::POLLIN,
            revents: 0,
        };
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 0);

        child_context
            .kernel()
            .exit_task_key_eventually_notifying(
                child_context.task().key(),
                crate::kernel::LinuxWaitStatus::from_wait_encoding(0),
                None,
                |_| {
                    child.retire_hvpatch_process_fds(&child_context);
                    pollfd.revents = 0;
                    assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 1);
                    assert_ne!(pollfd.revents & libc::POLLHUP, 0);
                },
            )
            .unwrap();

        pollfd.revents = 0;
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 1);
        assert_ne!(pollfd.revents & libc::POLLHUP, 0);
    }

    /// The process-terminal path closes the exiting task's fds BEFORE it
    /// takes the retirement topology lock (Linux `exit_files` precedes
    /// `exit_notify`), so the task is still registered when its table is
    /// retired. The census must exclude the exiting task itself; a census
    /// that counted it kept the table alive, deferred every close to the
    /// topology-locked tail, and wedged `ltp-fork07` / `forkreadexitcow`
    /// against a sibling's first copy-on-write fault inside `read(2)`.
    #[test]
    fn hvpatch_exiting_task_fds_retire_while_task_is_still_registered() {
        let mut host_fds = [-1; 2];
        assert_eq!(unsafe { libc::pipe(host_fds.as_mut_ptr()) }, 0);
        let read_host_fd = host_fds[0];
        let write_host_fd = host_fds[1];

        let parent = SyscallDispatcher::new();
        parent.captured_file_table().write_open_files().insert(
            3,
            OpenFile::from_open_description_with_status_flags(
                Arc::new(RwLock::new(OpenDescription::HostPipe {
                    host_fd: HostFdRef::new(read_host_fd),
                    is_read_end: true,
                    pipe_id: 1,
                    base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_RDONLY),
                    pty: None,
                    bidirectional: false,
                    write_kind: HostWriteKind::PipeLike,
                    stdio_stream: None,
                })),
                crate::linux_abi::LINUX_O_RDONLY,
                0,
            ),
        );
        parent.captured_file_table().write_open_files().insert(
            4,
            OpenFile::from_open_description_with_status_flags(
                Arc::new(RwLock::new(OpenDescription::HostPipe {
                    host_fd: HostFdRef::new(write_host_fd),
                    is_read_end: false,
                    pipe_id: 1,
                    base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_WRONLY),
                    pty: None,
                    bidirectional: false,
                    write_kind: HostWriteKind::PipeLike,
                    stdio_stream: None,
                })),
                crate::linux_abi::LINUX_O_WRONLY,
                0,
            ),
        );
        for open_file in parent.captured_file_table().read_open_files().values() {
            retain_open_file(&open_file.description);
        }

        let parent_tid = crate::thread::ThreadId::synthetic_for_tests(5110);
        let child_tid = crate::thread::ThreadId::synthetic_for_tests(5111);
        let (child, child_context) = fork_dispatcher(&parent, parent_tid, child_tid, 53, 54);
        let parent_writer = parent
            .captured_file_table()
            .write_open_files()
            .remove(&4)
            .unwrap();
        parent.close_open_file_and_free_pty(&parent_writer);
        drop(parent_writer);

        let mut pollfd = libc::pollfd {
            fd: read_host_fd,
            events: libc::POLLIN,
            revents: 0,
        };
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 0);

        // The child is still a live, registered task: its own reference to
        // the table must not defer the retirement.
        assert!(
            child_context
                .kernel()
                .task_is_live(child_context.task().key().id)
        );
        child.retire_hvpatch_process_fds(&child_context);
        pollfd.revents = 0;
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 1);
        assert_ne!(pollfd.revents & libc::POLLHUP, 0);

        // Exit publication afterwards finds nothing left to close.
        child_context
            .kernel()
            .exit_task_key_eventually_notifying(
                child_context.task().key(),
                crate::kernel::LinuxWaitStatus::from_wait_encoding(0),
                None,
                |_| {},
            )
            .unwrap();
        pollfd.revents = 0;
        assert_eq!(unsafe { libc::poll(&mut pollfd, 1, 0) }, 1);
        assert_ne!(pollfd.revents & libc::POLLHUP, 0);
    }

    #[test]
    fn hvpatch_inherited_fd_close_is_not_the_last_logical_reference() {
        let dispatcher = SyscallDispatcher::new();
        let description = Arc::new(RwLock::new(OpenDescription::SyntheticFile {
            base: OpenDescriptionBase::new(crate::linux_abi::LINUX_O_RDONLY),
            path: "epoll-inherited-owner".to_owned(),
            contents: Vec::new(),
            offset: 0,
        }));
        let fd = dispatcher
            .install_fd_at_or_above(
                3,
                OpenFile::from_open_description_with_status_flags(
                    Arc::clone(&description),
                    crate::linux_abi::LINUX_O_RDONLY,
                    0,
                ),
            )
            .unwrap();
        let parent_tid = crate::thread::ThreadId::synthetic_for_tests(5200);
        let child_tid = crate::thread::ThreadId::synthetic_for_tests(5201);
        let (child, _) = fork_dispatcher(&dispatcher, parent_tid, child_tid, 61, 62);

        let child_file = child.open_file(fd).unwrap();
        assert_eq!(child_file.description.fd_ref_count(), 2);
        assert!(!is_last_open_file_ref(&child_file));

        let child_file = child
            .captured_file_table()
            .write_open_files()
            .remove(&fd)
            .unwrap();
        child.close_open_file_and_free_pty(&child_file);
        let parent_file = dispatcher.open_file(fd).unwrap();
        assert_eq!(parent_file.description.fd_ref_count(), 1);
        assert!(is_last_open_file_ref(&parent_file));
    }

    /// Linux epoll registrations attach to the monitored open-file
    /// description, not to one process's numeric fd slot.  After fork the
    /// parent and child share both descriptions.  If the child replaces its
    /// inherited monitored slot with dup3(), the parent's registration must
    /// survive until the parent's reference to the original description is
    /// closed.
    ///
    /// This is the reduced form of the HvPatch Go os/exec hang: the child fd
    /// shuffle replaced an inherited pipe slot and Carrick detached the shared
    /// epoll interest by guest-fd number after installing the replacement.
    #[cfg(unix)]
    #[test]
    fn final_target_close_detaches_epoll_owner_from_another_file_table() {
        const MEM_BASE: u64 = 0x5210_0000;
        const MEM_LEN: usize = 0x1000;

        let parent = SyscallDispatcher::new();
        let reporter = crate::compat::CompatReporter::default();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(5400));
        let futex = crate::thread::FutexTable::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0; MEM_LEN]);
        let tid = crate::thread::ThreadId::synthetic_for_tests(5401);
        let call = |dispatcher: &SyscallDispatcher,
                    memory: &mut LinearMemory,
                    number: u64,
                    args: [u64; 6]| {
            dispatcher
                .dispatch_threaded(
                    &dispatcher.capture_one_task_context().unwrap(),
                    SyscallRequest::new(number, SyscallArgs::from(args)),
                    memory,
                    &reporter,
                    ThreadCtx::new(tid, &registry, &futex),
                )
                .expect("dispatch")
        };

        let epfd = match call(&parent, &mut memory, 20, [0; 6]) {
            DispatchOutcome::Returned { value } => value as i32,
            other => panic!("epoll_create1 failed: {other:?}"),
        };
        let pipe_addr = MEM_BASE + 0x100;
        assert_eq!(
            call(&parent, &mut memory, 59, [pipe_addr, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        let pipe_fds = memory.read_bytes(pipe_addr, 8).unwrap();
        let read_fd = i32::from_le_bytes(pipe_fds[0..4].try_into().unwrap());
        let event_addr = MEM_BASE + 0x120;
        let mut event = [0_u8; 16];
        event[0..4].copy_from_slice(&LINUX_EPOLLIN.to_le_bytes());
        memory.write_bytes(event_addr, &event).unwrap();
        assert_eq!(
            call(
                &parent,
                &mut memory,
                21,
                [
                    epfd as u64,
                    LINUX_EPOLL_CTL_ADD,
                    read_fd as u64,
                    event_addr,
                    0,
                    0
                ],
            ),
            DispatchOutcome::Returned { value: 0 }
        );

        let target_description = parent
            .open_file(read_fd)
            .expect("parent target fd")
            .description;
        let epoll_description = parent.open_file(epfd).expect("parent epoll fd").description;
        let (_, _, _, _, owners, _, _) = target_description
            .snapshot_for_test(std::time::Instant::now() + std::time::Duration::from_secs(1))
            .expect("target reverse epoll snapshot");
        assert_eq!(owners, vec![(epoll_description.id(), read_fd)]);

        let (child, _) = fork_dispatcher(
            &parent,
            crate::thread::ThreadId::synthetic_for_tests(5401),
            crate::thread::ThreadId::synthetic_for_tests(5402),
            81,
            82,
        );
        assert_eq!(
            call(&child, &mut memory, 57, [epfd as u64, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        assert_eq!(
            call(&parent, &mut memory, 57, [read_fd as u64, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        assert_eq!(
            call(&child, &mut memory, 57, [read_fd as u64, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );

        let (_, _, _, _, owners, _, _) = target_description
            .snapshot_for_test(std::time::Instant::now() + std::time::Duration::from_secs(1))
            .expect("detached target snapshot");
        assert!(owners.is_empty());
        let epoll = parent.open_file(epfd).expect("parent epoll fd");
        let epoll = epoll.description.read().expect("epoll open description");
        let OpenDescription::Epoll { interest, .. } = &*epoll else {
            panic!("epoll fd changed description kind");
        };
        assert!(
            !interest.contains_key(&read_fd),
            "final target close did not detach the epoll owner in another table"
        );
    }

    #[test]
    fn hvpatch_child_dup3_does_not_detach_parent_epoll_interest() {
        const MEM_BASE: u64 = 0x5200_0000;
        const MEM_LEN: usize = 0x1000;
        const EPOLLIN: u32 = 0x1;
        const EPOLLET: u32 = 0x8000_0000;

        let parent = SyscallDispatcher::new();
        let reporter = crate::compat::CompatReporter::default();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(5300));
        let futex = crate::thread::FutexTable::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0; MEM_LEN]);
        let tid = crate::thread::ThreadId::synthetic_for_tests(5301);

        macro_rules! call {
            ($dispatcher:expr, $number:expr, $args:expr $(,)?) => {
                $dispatcher
                    .dispatch_threaded(
                        &$dispatcher.capture_one_task_context().unwrap(),
                        SyscallRequest::new($number, SyscallArgs::from($args)),
                        &mut memory,
                        &reporter,
                        ThreadCtx::new(tid, &registry, &futex),
                    )
                    .expect("dispatch")
            };
        }

        let epfd = match call!(&parent, 20, [0; 6]) {
            DispatchOutcome::Returned { value } => value as i32,
            other => panic!("epoll_create1 failed: {other:?}"),
        };
        let pipe_addr = MEM_BASE + 0x100;
        assert_eq!(
            call!(&parent, 59, [pipe_addr, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        let pipe_fds = memory.read_bytes(pipe_addr, 8).unwrap();
        let read_fd = i32::from_le_bytes(pipe_fds[0..4].try_into().unwrap());
        let write_fd = i32::from_le_bytes(pipe_fds[4..8].try_into().unwrap());

        let event_addr = MEM_BASE + 0x120;
        let mut event = [0u8; 16];
        event[0..4].copy_from_slice(&(EPOLLIN | EPOLLET).to_le_bytes());
        event[8..16].copy_from_slice(&0xfeed_face_u64.to_le_bytes());
        memory.write_bytes(event_addr, &event).unwrap();
        assert_eq!(
            call!(
                &parent,
                21,
                [epfd as u64, 1, read_fd as u64, event_addr, 0, 0],
            ),
            DispatchOutcome::Returned { value: 0 }
        );

        let (child, _) = fork_dispatcher(
            &parent,
            crate::thread::ThreadId::synthetic_for_tests(5301),
            crate::thread::ThreadId::synthetic_for_tests(5302),
            71,
            72,
        );
        assert_eq!(
            call!(&child, 24, [write_fd as u64, read_fd as u64, 0, 0, 0, 0],),
            DispatchOutcome::Returned {
                value: read_fd as i64
            }
        );

        // Make `read_fd` name a child-only description, then close its final
        // logical reference. Numeric-only auto-detach used to remove the
        // parent's registration here even though the registered description
        // and the closing description are unrelated.
        let child_pipe_addr = MEM_BASE + 0x180;
        assert_eq!(
            call!(&child, 59, [child_pipe_addr, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        let child_pipe_fds = memory.read_bytes(child_pipe_addr, 8).unwrap();
        let child_read_fd = i32::from_le_bytes(child_pipe_fds[0..4].try_into().unwrap());
        let child_write_fd = i32::from_le_bytes(child_pipe_fds[4..8].try_into().unwrap());
        assert_eq!(
            call!(
                &child,
                24,
                [child_write_fd as u64, read_fd as u64, 0, 0, 0, 0],
            ),
            DispatchOutcome::Returned {
                value: read_fd as i64
            }
        );
        assert_eq!(
            call!(&child, 57, [child_read_fd as u64, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        assert_eq!(
            call!(&child, 57, [child_write_fd as u64, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        assert_eq!(
            call!(&child, 57, [read_fd as u64, 0, 0, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );

        let epoll = parent.open_file(epfd).expect("parent epoll fd");
        let epoll = epoll.description.read().expect("epoll open description");
        let OpenDescription::Epoll { interest, .. } = &*epoll else {
            panic!("epoll fd changed description kind");
        };
        assert!(
            interest.contains_key(&read_fd),
            "child dup3 detached the parent's inherited epoll registration"
        );
        drop(epoll);

        // Drain the child-close wake before making the pipe readable.  The
        // parent's inherited registration must still arm the host
        // multiplexer: a level re-sample after the write would hide a deleted
        // knote/epoll entry, whereas polling the instance fd proves the wake
        // source itself survived the child's non-final close.
        let ready_addr = MEM_BASE + 0x1c0;
        assert_eq!(
            call!(&parent, 22, [epfd as u64, ready_addr, 1, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        let byte_addr = MEM_BASE + 0x1e0;
        memory.write_bytes(byte_addr, b"x").unwrap();
        assert_eq!(
            call!(&parent, 64, [write_fd as u64, byte_addr, 1, 0, 0, 0],),
            DispatchOutcome::Returned { value: 1 }
        );
        let epoll = parent.open_file(epfd).expect("parent epoll fd");
        let poll_fd = {
            let epoll = epoll.description.read().expect("open description");
            let OpenDescription::Epoll { kqueue, .. } = &*epoll else {
                panic!("epoll fd changed description kind");
            };
            kqueue.poll_fd()
        };
        let mut pollfd = libc::pollfd {
            fd: poll_fd,
            events: libc::POLLIN,
            revents: 0,
        };
        assert_eq!(
            unsafe { libc::poll(&mut pollfd, 1, 100) },
            1,
            "child non-final close deleted the parent's host epoll registration"
        );
        assert_ne!(pollfd.revents & libc::POLLIN, 0);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    struct ContinueInterceptor;

    impl crate::observe::SyscallInterceptor for ContinueInterceptor {
        fn intercept(
            &self,
            _process: &crate::observe::ProcessInfo<'_>,
            _call: &crate::observe::InterceptedSyscall<'_>,
        ) -> crate::observe::InterceptAction {
            crate::observe::InterceptAction::Continue
        }
    }

    struct RecordingInterceptor {
        position: usize,
        calls: Arc<Mutex<Vec<usize>>>,
    }

    impl crate::observe::SyscallInterceptor for RecordingInterceptor {
        fn intercept(
            &self,
            _process: &crate::observe::ProcessInfo<'_>,
            _call: &crate::observe::InterceptedSyscall<'_>,
        ) -> crate::observe::InterceptAction {
            self.calls.lock().push(self.position);
            crate::observe::InterceptAction::Continue
        }
    }

    #[test]
    fn interceptor_disables_identity_fast_path() {
        let mut dispatcher = SyscallDispatcher::new();
        assert!(dispatcher.identity_fast_path_enabled());
        assert!(dispatcher.identity_fast_path_word().is_some());
        assert!(!dispatcher.requires_syscall_traps());

        dispatcher.install_interceptor(Arc::new(ContinueInterceptor));

        assert!(!dispatcher.identity_fast_path_enabled());
        assert!(dispatcher.identity_fast_path_word().is_none());
        assert!(dispatcher.requires_syscall_traps());
    }

    #[test]
    fn interceptor_chain_arc_is_inherited_by_fork() {
        let mut parent = SyscallDispatcher::new();
        parent.install_interceptor(Arc::new(ContinueInterceptor));
        let parent_chain = Arc::clone(parent.interceptors().expect("installed chain"));
        let child = parent.fork_clone_in_process(
            crate::thread::ThreadId::synthetic_for_tests(7000),
            crate::thread::ThreadId::synthetic_for_tests(7001),
            7000,
            7001,
        );

        assert!(Arc::ptr_eq(
            &parent_chain,
            child.interceptors().expect("inherited chain")
        ));
        assert!(child.requires_syscall_traps());
    }

    #[test]
    fn interceptor_registration_preserves_order() {
        let calls = Arc::new(Mutex::new(Vec::new()));
        let mut dispatcher = SyscallDispatcher::new();
        for position in [1, 2] {
            dispatcher.install_interceptor(Arc::new(RecordingInterceptor {
                position,
                calls: Arc::clone(&calls),
            }));
        }
        let context = dispatcher.capture_one_task_context().unwrap();
        let request = SyscallRequest::new(172, SyscallArgs::new([0; 6]));

        dispatcher
            .interceptors()
            .expect("installed chain")
            .apply(&crate::observe::ProcessInfo::new(&context), &request)
            .expect("interceptor chain");

        assert_eq!(*calls.lock(), vec![1, 2]);
    }

    #[derive(Clone, Copy, Debug)]
    enum InterceptionEntryPoint {
        Single,
        Threaded,
    }

    #[derive(Clone, Copy)]
    struct FixedInterceptor(crate::observe::InterceptAction);

    impl crate::observe::SyscallInterceptor for FixedInterceptor {
        fn intercept(
            &self,
            _process: &crate::observe::ProcessInfo<'_>,
            _call: &crate::observe::InterceptedSyscall<'_>,
        ) -> crate::observe::InterceptAction {
            self.0
        }
    }

    #[derive(Default)]
    struct EffectiveArgsObserver {
        args: Mutex<Vec<SyscallArgs>>,
        action: Mutex<Option<crate::observe::SyscallAction>>,
        returns: Mutex<Vec<(SyscallArgs, SyscallArgs, crate::observe::SyscallOutcome)>>,
    }

    impl EffectiveArgsObserver {
        fn with_action(action: crate::observe::SyscallAction) -> Self {
            Self {
                args: Mutex::new(Vec::new()),
                action: Mutex::new(Some(action)),
                returns: Mutex::new(Vec::new()),
            }
        }
    }

    impl crate::observe::SyscallObserver for EffectiveArgsObserver {
        fn on_syscall(
            &self,
            _process: &crate::observe::ProcessInfo<'_>,
            call: &crate::observe::SyscallInfo<'_>,
        ) -> crate::observe::SyscallAction {
            self.args.lock().push(call.raw_args());
            self.action
                .lock()
                .as_ref()
                .copied()
                .unwrap_or(crate::observe::SyscallAction::Allow)
        }

        fn on_syscall_return(
            &self,
            _process: &crate::observe::ProcessInfo<'_>,
            call: &crate::observe::SyscallInfo<'_>,
            outcome: &crate::observe::SyscallOutcome,
        ) {
            self.returns
                .lock()
                .push((call.original_args(), call.raw_args(), *outcome));
        }
    }

    fn run_interception_entry(
        entry: InterceptionEntryPoint,
        dispatcher: &mut SyscallDispatcher,
        request: SyscallRequest,
        reporter: &CompatReporter,
    ) -> DispatchOutcome {
        let context = dispatcher.capture_one_task_context().unwrap();
        let mut memory = LinearMemory::new(0x4000_0000, vec![0u8; 4096]);
        match entry {
            InterceptionEntryPoint::Single => dispatcher
                .dispatch(&context, request, &mut memory, reporter)
                .expect("single dispatch"),
            InterceptionEntryPoint::Threaded => {
                let tid = crate::thread::ThreadId::synthetic_for_tests(7100);
                let registry = crate::thread::ThreadRegistry::new(tid);
                dispatcher
                    .dispatch_threaded_for_test(
                        &context,
                        request,
                        &mut memory,
                        reporter,
                        ThreadCtx::new(tid, &registry, &crate::thread::FutexTable::new()),
                    )
                    .expect("threaded dispatch")
            }
        }
    }

    #[test]
    fn interception_order_applies_to_both_dispatch_entry_points() {
        const SYS_PERSONALITY: u64 = 92;
        const DENIED_PERSONALITY: u64 = 0x80_0000;
        const REWRITTEN_PERSONALITY: u64 = 1;

        for entry in [
            InterceptionEntryPoint::Single,
            InterceptionEntryPoint::Threaded,
        ] {
            let mut dispatcher = SyscallDispatcher::new();
            dispatcher.apply_seccomp_policy(carrick_spec::SeccompPolicy::ContainerDefault);
            dispatcher.install_interceptor(Arc::new(FixedInterceptor(
                crate::observe::InterceptAction::RewriteArgs(SyscallArgs::from([
                    DENIED_PERSONALITY,
                    0,
                    0,
                    0,
                    0,
                    0,
                ])),
            )));
            assert_eq!(
                run_interception_entry(
                    entry,
                    &mut dispatcher,
                    SyscallRequest::new(SYS_PERSONALITY, SyscallArgs::from([0; 6])),
                    &CompatReporter::default(),
                ),
                DispatchOutcome::Errno { errno: LINUX_EPERM },
                "rewrite must precede launch policy for {entry:?}"
            );

            let mut dispatcher = SyscallDispatcher::new();
            dispatcher.apply_seccomp_policy(carrick_spec::SeccompPolicy::ContainerDefault);
            dispatcher.install_interceptor(Arc::new(FixedInterceptor(
                crate::observe::InterceptAction::Return(7),
            )));
            assert_eq!(
                run_interception_entry(
                    entry,
                    &mut dispatcher,
                    SyscallRequest::new(
                        SYS_PERSONALITY,
                        SyscallArgs::from([DENIED_PERSONALITY, 0, 0, 0, 0, 0]),
                    ),
                    &CompatReporter::default(),
                ),
                DispatchOutcome::Errno { errno: LINUX_EPERM },
                "launch policy must veto proposed success for {entry:?}"
            );

            let mut dispatcher = SyscallDispatcher::new();
            dispatcher.install_interceptor(Arc::new(FixedInterceptor(
                crate::observe::InterceptAction::Return(7),
            )));
            dispatcher
                .seccomp
                .install(vec![crate::seccomp::SockFilter {
                    code: 0x06,
                    jt: 0,
                    jf: 0,
                    k: crate::seccomp::SECCOMP_RET_ERRNO | LINUX_EACCES.get() as u32,
                }])
                .expect("test seccomp filter");
            assert_eq!(
                run_interception_entry(
                    entry,
                    &mut dispatcher,
                    SyscallRequest::new(SYS_PERSONALITY, SyscallArgs::from([0; 6])),
                    &CompatReporter::default(),
                ),
                DispatchOutcome::Errno {
                    errno: LINUX_EACCES
                },
                "guest seccomp must veto proposed success for {entry:?}"
            );

            let observer = Arc::new(EffectiveArgsObserver::default());
            let mut dispatcher = SyscallDispatcher::new();
            dispatcher.install_interceptor(Arc::new(FixedInterceptor(
                crate::observe::InterceptAction::RewriteArgs(SyscallArgs::from([
                    REWRITTEN_PERSONALITY,
                    0,
                    0,
                    0,
                    0,
                    0,
                ])),
            )));
            dispatcher.install_observer(observer.clone());
            assert_eq!(
                run_interception_entry(
                    entry,
                    &mut dispatcher,
                    SyscallRequest::new(SYS_PERSONALITY, SyscallArgs::from([0; 6])),
                    &CompatReporter::default(),
                ),
                DispatchOutcome::Returned { value: 0 }
            );
            assert_eq!(
                observer.args.lock().as_slice(),
                &[SyscallArgs::from([REWRITTEN_PERSONALITY, 0, 0, 0, 0, 0])]
            );
            assert_eq!(dispatcher.proc.lock().personality, REWRITTEN_PERSONALITY);

            let observer = Arc::new(EffectiveArgsObserver::with_action(
                crate::observe::SyscallAction::Deny(LINUX_EACCES),
            ));
            let mut dispatcher = SyscallDispatcher::new();
            dispatcher.install_interceptor(Arc::new(FixedInterceptor(
                crate::observe::InterceptAction::Errno(LINUX_EPERM),
            )));
            dispatcher.install_observer(observer);
            assert_eq!(
                run_interception_entry(
                    entry,
                    &mut dispatcher,
                    SyscallRequest::new(
                        SYS_PERSONALITY,
                        SyscallArgs::from([REWRITTEN_PERSONALITY, 0, 0, 0, 0, 0]),
                    ),
                    &CompatReporter::default(),
                ),
                DispatchOutcome::Errno {
                    errno: LINUX_EACCES
                }
            );
            assert_eq!(dispatcher.proc.lock().personality, 0);

            let observer = Arc::new(EffectiveArgsObserver::with_action(
                crate::observe::SyscallAction::Short(1),
            ));
            let reporter = CompatReporter::default();
            let mut dispatcher = SyscallDispatcher::new();
            dispatcher.install_interceptor(Arc::new(FixedInterceptor(
                crate::observe::InterceptAction::Return(7),
            )));
            dispatcher.install_observer(observer);
            assert_eq!(
                run_interception_entry(
                    entry,
                    &mut dispatcher,
                    SyscallRequest::new(
                        SYS_PERSONALITY,
                        SyscallArgs::from([REWRITTEN_PERSONALITY, 0, 9, 0, 0, 0]),
                    ),
                    &reporter,
                ),
                DispatchOutcome::Returned { value: 7 }
            );
            assert_eq!(dispatcher.proc.lock().personality, 0);
            let report = reporter.snapshot();
            assert_eq!(report.summary.syscall_invocations, 1);
            assert_eq!(report.summary.syscall_returns_ok, 0);
            assert_eq!(report.summary.syscall_returns_errno, 0);

            let observer = Arc::new(EffectiveArgsObserver::with_action(
                crate::observe::SyscallAction::Short(4),
            ));
            let mut dispatcher = SyscallDispatcher::new();
            dispatcher.install_observer(observer.clone());
            let eventfd = OpenFile::from_open_description_with_status_flags(
                Arc::new(RwLock::new(OpenDescription::EventFd {
                    state: Arc::new(EventFdState::new(1)),
                    semaphore: false,
                    base: OpenDescriptionBase::new(0),
                })),
                crate::linux_abi::LINUX_O_RDWR,
                0,
            );
            let fd = dispatcher
                .install_fd_at_or_above(3, eventfd)
                .expect("install eventfd for short-read handler proof");
            assert_eq!(
                run_interception_entry(
                    entry,
                    &mut dispatcher,
                    SyscallRequest::new(
                        63,
                        SyscallArgs::from([fd as u64, 0x4000_0000, 8, 0, 0, 0]),
                    ),
                    &CompatReporter::default(),
                ),
                DispatchOutcome::Errno {
                    errno: LINUX_EINVAL
                },
                "eventfd read must receive the shortened four-byte count for {entry:?}"
            );
            assert_eq!(
                observer.args.lock().as_slice(),
                &[SyscallArgs::from([fd as u64, 0x4000_0000, 8, 0, 0, 0])]
            );
        }
    }

    #[test]
    fn interception_policy_kill_cannot_be_downgraded_by_observer() {
        const SYS_PERSONALITY: u64 = 92;

        for entry in [
            InterceptionEntryPoint::Single,
            InterceptionEntryPoint::Threaded,
        ] {
            let observer = Arc::new(EffectiveArgsObserver::with_action(
                crate::observe::SyscallAction::Deny(LINUX_EACCES),
            ));
            let mut dispatcher = SyscallDispatcher::new();
            dispatcher
                .seccomp
                .install(vec![crate::seccomp::SockFilter {
                    code: 0x06,
                    jt: 0,
                    jf: 0,
                    k: crate::seccomp::SECCOMP_RET_KILL_PROCESS,
                }])
                .expect("test seccomp filter");
            dispatcher.install_observer(observer);

            assert_eq!(
                run_interception_entry(
                    entry,
                    &mut dispatcher,
                    SyscallRequest::new(SYS_PERSONALITY, SyscallArgs::from([0; 6])),
                    &CompatReporter::default(),
                ),
                DispatchOutcome::SignalDeath {
                    signum: crate::linux_abi::LINUX_SIGSYS,
                },
                "an observer denial must not downgrade seccomp's kill for {entry:?}"
            );
        }
    }

    #[test]
    fn interception_order_completion_reports_actual_return_once() {
        let observer = Arc::new(EffectiveArgsObserver::default());
        let reporter = CompatReporter::default();
        let mut dispatcher = SyscallDispatcher::new();
        dispatcher.install_interceptor(Arc::new(FixedInterceptor(
            crate::observe::InterceptAction::RewriteArgs(SyscallArgs::from([1, 2, 3, 4, 5, 6])),
        )));
        dispatcher.install_observer(observer.clone());
        let context = dispatcher.capture_one_task_context().unwrap();
        let original_args = SyscallArgs::from([9, 8, 7, 6, 5, 4]);
        let prepared = dispatcher
            .prepare_syscall(&context, SyscallRequest::new(92, original_args), &reporter)
            .expect("prepare syscall");
        let PreparedDispatch::Invoke(syscall) = prepared else {
            panic!("rewrite-only interception must invoke the real handler");
        };
        let mut token = Some(SyscallCompletionToken::new(
            syscall,
            context.retain_exact(),
            dispatcher.observers().cloned(),
        ));

        assert_eq!(reporter.snapshot().summary.syscall_invocations, 1);
        assert_eq!(reporter.snapshot().summary.syscall_returns_ok, 0);
        token
            .take()
            .expect("installed completion token")
            .publish_return(&reporter, 17);

        assert!(token.is_none(), "terminal publication consumes the token");
        let report = reporter.snapshot();
        assert_eq!(report.summary.syscall_invocations, 1);
        assert_eq!(report.summary.syscall_returns_ok, 1);
        assert_eq!(report.summary.syscall_returns_errno, 0);
        assert_eq!(
            observer.returns.lock().as_slice(),
            &[(
                original_args,
                SyscallArgs::from([1, 2, 3, 4, 5, 6]),
                crate::observe::SyscallOutcome::returned(17)
            )]
        );
    }

    #[test]
    fn dispatcher_fork_clone_splits_process_state_without_duping_descriptions() {
        super::hvpatch_in_process_fork_tests::dispatcher_fork_clone_splits_process_state_without_duping_descriptions();
    }
}

#[cfg(test)]
mod container_policy_dispatch_tests {
    //! End-to-end tests for the launch-time container syscall policy at the
    //! dispatch-entry seam: deny hit, miss passthrough, unconfined opt-out
    //! (handlers stay honest ENOSYS), both dispatch paths, fork inheritance,
    //! and survival across the dispatcher's execve-time state resets.
    use super::*;
    use crate::compat::CompatReporter;
    use carrick_abi::LINUX_ENOKEY;
    use carrick_spec::SeccompPolicy;

    const SYS_ADD_KEY: u64 = 217;
    const SYS_REQUEST_KEY: u64 = 218;
    const SYS_KEYCTL: u64 = 219;
    const SYS_GETPID: u64 = 172;
    const MEM_BASE: u64 = 0x4000_0000;

    fn confined_dispatcher() -> SyscallDispatcher {
        let mut dispatcher = SyscallDispatcher::new();
        dispatcher.apply_seccomp_policy(SeccompPolicy::ContainerDefault);
        dispatcher
    }

    fn dispatch_one(dispatcher: &mut SyscallDispatcher, nr: u64) -> DispatchOutcome {
        let reporter = CompatReporter::default();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; 4096]);
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(nr, SyscallArgs([0; 6])),
                &mut memory,
                &reporter,
            )
            .expect("dispatch")
    }

    #[test]
    fn policy_denies_keyring_family_with_eperm_before_handler() {
        let mut dispatcher = confined_dispatcher();
        for nr in [SYS_ADD_KEY, SYS_REQUEST_KEY, SYS_KEYCTL] {
            assert_eq!(
                dispatch_one(&mut dispatcher, nr),
                DispatchOutcome::Errno { errno: LINUX_EPERM },
                "syscall {nr} must be policy-denied EPERM at dispatch entry"
            );
        }
    }

    #[test]
    fn policy_denial_reports_as_policy_not_unimplemented() {
        let dispatcher = confined_dispatcher();
        let reporter = CompatReporter::default();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; 4096]);
        let mut dispatcher = dispatcher;
        dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(SYS_ADD_KEY, SyscallArgs([0; 6])),
                &mut memory,
                &reporter,
            )
            .expect("dispatch");
        let report = reporter.snapshot();
        assert!(
            report
                .partial_syscalls
                .iter()
                .any(|e| e.name == "add_key" && e.reason.contains("container syscall policy")),
            "policy denial must surface as a policy event: {report:?}"
        );
        assert!(
            !report
                .unhandled_syscalls
                .iter()
                .any(|e| e.name == "add_key"),
            "policy denial must NOT count as an unimplemented handler: {report:?}"
        );
    }

    #[test]
    fn policy_miss_passes_through_to_handler() {
        let mut dispatcher = confined_dispatcher();
        // getpid is NOT in the deny table: the handler must run and answer.
        match dispatch_one(&mut dispatcher, SYS_GETPID) {
            DispatchOutcome::Returned { value } => assert!(value > 0, "getpid returned {value}"),
            other => panic!("getpid must reach its handler under the policy, got {other:?}"),
        }
    }

    #[test]
    fn unconfined_opt_out_reaches_the_real_keyring_handlers() {
        // Unconfined (run-elf default / --security-opt seccomp=unconfined):
        // the policy layer is off and the syscall reaches carrick's keyring
        // implementation. The differential recorded in `container_policy.rs`
        // is that these SUCCEED unprivileged on real Linux, so the one thing
        // that must never come back is ENOSYS — an honest "absent backend"
        // answer that stopped being true when the subsystem landed.
        //
        // `dispatch_one` passes all-zero arguments, i.e. a NULL `type`
        // pointer for add_key/request_key and command 0
        // (`KEYCTL_GET_KEYRING_ID`) with key id 0 for keyctl. Linux answers
        // those EFAULT and ENOKEY respectively, and so does carrick.
        let mut dispatcher = SyscallDispatcher::new();
        dispatcher.apply_seccomp_policy(SeccompPolicy::Unconfined);
        for (nr, expected) in [
            (SYS_ADD_KEY, LINUX_EFAULT),
            (SYS_REQUEST_KEY, LINUX_EFAULT),
            (SYS_KEYCTL, LINUX_ENOKEY),
        ] {
            assert_eq!(
                dispatch_one(&mut dispatcher, nr),
                DispatchOutcome::Errno { errno: expected },
                "unconfined keyring syscall {nr} must reach its handler"
            );
        }
        // And a fresh dispatcher (no policy applied at all) is unconfined too.
        let mut bare = SyscallDispatcher::new();
        assert_eq!(
            dispatch_one(&mut bare, SYS_ADD_KEY),
            DispatchOutcome::Errno {
                errno: LINUX_EFAULT
            }
        );
    }

    #[test]
    fn unconfined_add_key_and_keyctl_succeed_unprivileged() {
        // The other half of the recorded Docker-unconfined differential
        // (`container_policy.rs`): `add_key` returns a key SERIAL and
        // `keyctl(KEYCTL_JOIN_SESSION_KEYRING, NULL)` returns a keyring serial,
        // both without any privilege. A guest that only ever saw errnos could
        // not tell a real keyring from a well-shaped refusal, so assert the
        // success path end-to-end through the dispatcher.
        let mut dispatcher = SyscallDispatcher::new();
        dispatcher.apply_seccomp_policy(SeccompPolicy::Unconfined);
        let reporter = CompatReporter::default();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; 4096]);
        // "user\0" then "desc\0" then a two-byte payload.
        let type_at = MEM_BASE;
        let desc_at = MEM_BASE + 0x20;
        let payload_at = MEM_BASE + 0x40;
        memory.write_bytes(type_at, b"user\0").unwrap();
        memory.write_bytes(desc_at, b"desc\0").unwrap();
        memory.write_bytes(payload_at, b"hi").unwrap();

        let context = dispatcher.capture_one_task_context().unwrap();
        let joined = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_KEYCTL,
                    SyscallArgs([
                        carrick_abi::keyring::KeyctlOp::JoinSessionKeyring
                            .raw()
                            .into(),
                        0,
                        0,
                        0,
                        0,
                        0,
                    ]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch");
        let DispatchOutcome::Returned { value: session } = joined else {
            panic!("JOIN_SESSION_KEYRING must return a serial, got {joined:?}");
        };
        assert!(session > 0, "session keyring serial {session} must be > 0");

        let added = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_ADD_KEY,
                    SyscallArgs([
                        type_at,
                        desc_at,
                        payload_at,
                        2,
                        // KEY_SPEC_SESSION_KEYRING, sign-extended as the guest
                        // passes it.
                        carrick_abi::keyring::KeySpec::Session.serial().get() as u64,
                        0,
                    ]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch");
        let DispatchOutcome::Returned { value: serial } = added else {
            panic!("add_key must return a serial, got {added:?}");
        };
        assert!(serial > 0, "key serial {serial} must be > 0");
        assert_ne!(serial, session, "the key must not be the keyring itself");
    }

    #[test]
    fn policy_applies_on_threaded_dispatch_path_too() {
        let dispatcher = confined_dispatcher();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(2200));
        let reporter = CompatReporter::default();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; 4096]);
        let outcome = dispatcher
            .dispatch_threaded(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(SYS_KEYCTL, SyscallArgs([0; 6])),
                &mut memory,
                &reporter,
                ThreadCtx::new(
                    registry.main_tid(),
                    &registry,
                    &crate::thread::FutexTable::new(),
                ),
            )
            .expect("threaded dispatch");
        assert_eq!(outcome, DispatchOutcome::Errno { errno: LINUX_EPERM });
    }

    #[test]
    fn threaded_sched_yield_reaches_the_vcpu_scheduler() {
        let dispatcher = SyscallDispatcher::new();
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(2201));
        let reporter = CompatReporter::default();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; 4096]);
        let outcome = dispatcher
            .dispatch_threaded(
                &dispatcher.capture_one_task_context().unwrap(),
                SyscallRequest::new(124, SyscallArgs([0; 6])),
                &mut memory,
                &reporter,
                ThreadCtx::new(
                    registry.main_tid(),
                    &registry,
                    &crate::thread::FutexTable::new(),
                ),
            )
            .expect("threaded sched_yield dispatch");

        assert_eq!(outcome, DispatchOutcome::SchedulerYield);
    }

    #[test]
    fn policy_survives_execve_time_dispatcher_resets() {
        // carrick's guest execve keeps the dispatcher object and selectively
        // resets per-image state (signal handlers, executable path). The
        // policy must survive those resets — like a Linux seccomp filter
        // surviving execve.
        let mut dispatcher = confined_dispatcher();
        dispatcher.reset_signal_handlers_on_execve(&dispatcher.exact_signal_context_for_test());
        dispatcher.set_executable_path("/replaced/image".to_string());
        assert_eq!(
            dispatch_one(&mut dispatcher, SYS_ADD_KEY),
            DispatchOutcome::Errno { errno: LINUX_EPERM }
        );
    }

    #[test]
    fn docker_default_policy_keeps_identity_fast_path() {
        // The Docker default model never denies identity syscalls, so a
        // container run must NOT lose the EL1-shim fast path.
        let dispatcher = confined_dispatcher();
        assert!(dispatcher.identity_fast_path_enabled());
        // A guest seccomp filter still disables it, policy or not.
        dispatcher
            .seccomp
            .install(vec![crate::seccomp::SockFilter {
                code: 0x06,
                jt: 0,
                jf: 0,
                k: crate::seccomp::SECCOMP_RET_ALLOW,
            }])
            .expect("install guest seccomp filter");
        assert!(!dispatcher.identity_fast_path_enabled());
    }

    mod serial_host {
        use super::*;

        #[test]
        fn policy_is_inherited_by_forked_children() {
            // The runtime's guest fork is a host fork: the child inherits the
            // dispatcher (and thus the policy table) via the process memory copy.
            // Prove it with a real fork — the child dispatches add_key and reports
            // the outcome through its exit code.
            let mut dispatcher = confined_dispatcher();
            let child = unsafe { libc::fork() };
            assert!(child >= 0, "fork failed");
            if child == 0 {
                let denied = matches!(
                    dispatch_one(&mut dispatcher, SYS_ADD_KEY),
                    DispatchOutcome::Errno { errno } if errno == LINUX_EPERM
                );
                // SAFETY: _exit is async-signal-safe; no cleanup wanted post-fork.
                unsafe { libc::_exit(if denied { 0 } else { 1 }) };
            }
            let mut status = 0;
            assert_eq!(unsafe { libc::waitpid(child, &mut status, 0) }, child);
            assert!(
                libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0,
                "forked child must inherit the deny table (status {status:#x})"
            );
        }
    }

    #[test]
    fn synthetic_device_stat_source_reports_chardev_and_rdev() {
        use carrick_vfs::SyntheticDeviceKind;

        let kinds = [
            (SyntheticDeviceKind::Null, "/dev/null"),
            (SyntheticDeviceKind::Zero, "/dev/zero"),
            (SyntheticDeviceKind::Full, "/dev/full"),
            (SyntheticDeviceKind::Random, "/dev/random"),
            (SyntheticDeviceKind::Urandom, "/dev/urandom"),
        ];

        for (kind, expected_path) in kinds {
            let desc = OpenDescription::SyntheticDevice {
                base: OpenDescriptionBase::new(0),
                kind,
            };
            assert_eq!(desc.open_path(), Some(expected_path));
            assert_eq!(desc.readlink_target(), None);
            match desc.stat_source() {
                OpenStatSource::Record(record) => {
                    assert_eq!(record.mode & LINUX_S_IFMT, LINUX_S_IFCHR);
                    assert_eq!(record.rdev, kind.rdev());
                }
                other => panic!("expected OpenStatSource::Record, got {:?}", other),
            }
        }
    }

    #[test]
    fn prepared_fork_mm_rejects_replaced_authority_with_equal_revision() {
        let dispatcher = SyscallDispatcher::new();
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(1).unwrap();
        let child_mm_id = crate::kernel::MmId::from_raw_u64(2).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            )
            .unwrap();

        let replacement = Arc::new(DispatchMmAuthority::new_for_test_with_revision(
            prepared.parent_revision,
        ));
        dispatcher.replace_current_mm_for_test(replacement);

        let result =
            dispatcher.fork_clone_with_prepared_mm(parent_mm_id, child_mm_id, 100, 101, prepared);
        assert!(matches!(
            result,
            Err(crate::kernel::SnapshotError::ChangedDuringObservation)
        ));
    }

    #[test]
    fn prepared_fork_mm_clone_vm_uses_exact_dispatch_mm_authority_arc() {
        let dispatcher = SyscallDispatcher::new();
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(1).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                parent_mm_id,
                crate::kernel::CloneObjectMode::Share,
            )
            .unwrap();

        assert!(Arc::ptr_eq(&prepared.parent_mm, &prepared.child_mm));
        assert!(prepared.fork_projection_plan().is_shared());

        let child_dispatcher = dispatcher
            .fork_clone_with_prepared_mm(parent_mm_id, parent_mm_id, 100, 101, prepared)
            .expect("install shared fork mm");

        assert!(!Arc::ptr_eq(
            &dispatcher.mm_binding,
            &child_dispatcher.mm_binding
        ));
        assert!(Arc::ptr_eq(
            &dispatcher.mm_binding.current.load_full(),
            &child_dispatcher.mm_binding.current.load_full()
        ));
    }

    #[test]
    fn clone_vm_distinct_dispatcher_cannot_claim_sole_mm_with_peer_active() {
        let dispatcher = SyscallDispatcher::new();
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(1).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                parent_mm_id,
                crate::kernel::CloneObjectMode::Share,
            )
            .unwrap();
        let child_dispatcher = dispatcher
            .fork_clone_with_prepared_mm(parent_mm_id, parent_mm_id, 100, 101, prepared)
            .expect("install shared fork mm");
        let parent_executor = dispatcher
            .enter_mm_executor()
            .expect("admit parent MM executor");
        let mut child_executor = child_dispatcher
            .enter_mm_executor()
            .expect("admit child MM executor");
        let registry =
            crate::thread::ThreadRegistry::new(crate::thread::ThreadId::synthetic_for_tests(101));
        let futex = crate::thread::FutexTable::new();
        let reporter = CompatReporter::default();
        let mut memory = LinearMemory::new(0x10000, vec![0; 0x1000]);
        let request = SyscallRequest::new(214, SyscallArgs::from([0; 6]));

        assert!(matches!(
            child_dispatcher.dispatch_threaded_with_mm_executor(
                &mut child_executor,
                &child_dispatcher.capture_one_task_context().unwrap(),
                request,
                &mut memory,
                &reporter,
                ThreadCtx::new(registry.main_tid(), &registry, &futex),
            ),
            Err(DispatchError::MmMutationPeerExecutor)
        ));

        drop(parent_executor);
        assert_eq!(
            child_dispatcher
                .dispatch_threaded_with_mm_executor(
                    &mut child_executor,
                    &child_dispatcher.capture_one_task_context().unwrap(),
                    request,
                    &mut memory,
                    &reporter,
                    ThreadCtx::new(registry.main_tid(), &registry, &futex),
                )
                .unwrap(),
            DispatchOutcome::Returned {
                value: crate::memory::LINUX_HEAP_BASE as i64,
            }
        );

        drop(child_executor);
        let mut sole_executor = dispatcher
            .enter_mm_executor()
            .expect("readmit sole parent MM executor");
        let (attempted_tx, attempted_rx) = std::sync::mpsc::sync_channel(1);
        let (admitted_tx, admitted_rx) = std::sync::mpsc::sync_channel(1);
        let peer = std::thread::spawn(move || {
            attempted_tx.send(()).expect("announce peer admission");
            let peer = child_dispatcher
                .enter_mm_executor()
                .expect("admit peer after sole authority releases");
            admitted_tx.send(()).expect("announce peer admitted");
            peer
        });
        crate::dispatch::mm_quiesce::with_sole_mm_stage1(&mut sole_executor, |_authority| {
            attempted_rx
                .recv()
                .expect("peer attempts exact-MM admission");
            assert_eq!(
                admitted_rx.recv_timeout(std::time::Duration::from_millis(25)),
                Err(std::sync::mpsc::RecvTimeoutError::Timeout),
                "a peer entered while the sole-MM authority was live"
            );
        })
        .expect("sole executor must mint sealed MM authority");
        admitted_rx
            .recv_timeout(std::time::Duration::from_secs(1))
            .expect("peer enters after sole-MM authority releases");
        drop(peer.join().expect("peer admission worker exits"));
    }

    #[test]
    fn prepared_fork_mm_install_excludes_peer_vma_publication() {
        let dispatcher = Arc::new(SyscallDispatcher::new());
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(1).unwrap();
        let child_mm_id = crate::kernel::MmId::from_raw_u64(2).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            )
            .unwrap();
        let install_complete = Arc::new(std::sync::atomic::AtomicBool::new(false));
        let (attempted_tx, attempted_rx) = std::sync::mpsc::channel();
        let (acquired_tx, acquired_rx) = std::sync::mpsc::channel();
        let mut peer = None;

        let child_dispatcher = dispatcher
            .fork_clone_with_prepared_mm_observed(
                parent_mm_id,
                child_mm_id,
                100,
                101,
                prepared,
                |constructed| {
                    if !constructed {
                        let peer_dispatcher = Arc::clone(&dispatcher);
                        let peer_complete = Arc::clone(&install_complete);
                        let attempted_tx = attempted_tx.clone();
                        let acquired_tx = acquired_tx.clone();
                        peer = Some(std::thread::spawn(move || {
                            attempted_tx.send(()).unwrap();
                            peer_dispatcher.with_vma_dispatch_for_test(|_vma| {
                                acquired_tx
                                    .send(peer_complete.load(std::sync::atomic::Ordering::Acquire))
                                    .unwrap();
                            });
                        }));
                        attempted_rx.recv().unwrap();
                        assert!(acquired_rx.try_recv().is_err());
                    } else {
                        assert!(acquired_rx.try_recv().is_err());
                        install_complete.store(true, std::sync::atomic::Ordering::Release);
                    }
                },
            )
            .expect("install copied fork mm");

        assert!(acquired_rx.recv().unwrap());
        peer.unwrap().join().unwrap();
        assert!(!Arc::ptr_eq(
            &dispatcher.mm_binding.current.load_full(),
            &child_dispatcher.mm_binding.current.load_full()
        ));
    }

    #[test]
    fn prepared_fork_mm_copied_fork_request_names_real_parent_mm() {
        let dispatcher = SyscallDispatcher::new();
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(42).unwrap();
        let child_mm_id = crate::kernel::MmId::from_raw_u64(43).unwrap();
        let wrong_mm_id = crate::kernel::MmId::from_raw_u64(44).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            )
            .unwrap();

        assert_eq!(prepared.parent_mm_id, parent_mm_id);
        let request_plan = prepared.fork_projection_plan();
        assert!(!request_plan.is_shared());
        assert_eq!(request_plan.parent_mm(), parent_mm_id.raw());
        assert_eq!(request_plan.child_mm(), child_mm_id.raw());
        assert_ne!(request_plan.parent_mm(), request_plan.child_mm());
        assert!(!Arc::ptr_eq(&prepared.parent_mm, &prepared.child_mm));

        let result =
            dispatcher.fork_clone_with_prepared_mm(wrong_mm_id, child_mm_id, 100, 101, prepared);
        assert!(matches!(
            result,
            Err(crate::kernel::SnapshotError::ChangedDuringObservation)
        ));
    }

    #[test]
    fn prepared_fork_mm_rejects_wrong_child_identity_at_install() {
        let dispatcher = SyscallDispatcher::new();
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(51).unwrap();
        let child_mm_id = crate::kernel::MmId::from_raw_u64(52).unwrap();
        let wrong_child_mm_id = crate::kernel::MmId::from_raw_u64(53).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            )
            .unwrap();

        assert!(matches!(
            dispatcher.fork_clone_with_prepared_mm(
                parent_mm_id,
                wrong_child_mm_id,
                100,
                101,
                prepared,
            ),
            Err(crate::kernel::SnapshotError::ChangedDuringObservation)
        ));
    }

    #[test]
    fn prepared_fork_mm_mode_requires_structurally_matching_mm_identities() {
        let dispatcher = SyscallDispatcher::new();
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(61).unwrap();
        let child_mm_id = crate::kernel::MmId::from_raw_u64(62).unwrap();

        assert!(matches!(
            dispatcher.prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Share,
            ),
            Err(PrepareDispatchMmForkError::SharedIdentityMismatch)
        ));
        assert!(matches!(
            dispatcher.prepare_fork_mm(
                parent_mm_id,
                parent_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            ),
            Err(PrepareDispatchMmForkError::CopiedIdentityCollision)
        ));
    }

    #[test]
    fn prepared_fork_mm_copied_child_authority_is_independent_of_parent() {
        let dispatcher = SyscallDispatcher::new();
        dispatcher.set_address_space_regions(vec![carrick_vfs::ProcMapsEntry {
            start: 0x10000,
            end: 0x20000,
            read: true,
            write: true,
            execute: false,
            sharing: carrick_vfs::ProcMapSharing::Private,
            path: "[anon]".to_string(),
        }]);
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(1).unwrap();
        let child_mm_id = crate::kernel::MmId::from_raw_u64(2).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            )
            .unwrap();
        let child_dispatcher = dispatcher
            .fork_clone_with_prepared_mm(parent_mm_id, child_mm_id, 100, 101, prepared)
            .expect("install copied fork mm");

        // Mutating parent does not mutate child
        dispatcher.record_dynamic_mapping(
            0x30000,
            0x1000,
            LinuxProtFlags::READ | LinuxProtFlags::WRITE,
            carrick_vfs::ProcMapSharing::Private,
            "[parent_only]".to_string(),
        );

        let parent_vmas = dispatcher.mem().lock().semantic_vmas.clone();
        let child_vmas = child_dispatcher.mem().lock().semantic_vmas.clone();
        assert!(parent_vmas.iter().any(|v| v.path == "[parent_only]"));
        assert!(!child_vmas.iter().any(|v| v.path == "[parent_only]"));
    }

    #[test]
    fn deferred_anonymous_copied_fork_preserves_residency_and_isolates_state() {
        let dispatcher = SyscallDispatcher::new();
        dispatcher.record_dynamic_mapping(
            0x10000,
            0x3000,
            LinuxProtFlags::READ | LinuxProtFlags::WRITE,
            carrick_vfs::ProcMapSharing::Private,
            "[anon]".to_string(),
        );
        let parent_state = Arc::clone(&dispatcher.mem().lock().deferred_anonymous);
        parent_state
            .reserve_fresh(GuestVa(0x10000), 0x3000)
            .unwrap();
        for page in [0x10000, 0x11000, 0x12000] {
            assert!(
                parent_state
                    .copy_pristine_zero(GuestVa(page), &mut [1; 4])
                    .unwrap()
            );
        }
        let before = parent_state.snapshot();
        let parent_mm = crate::kernel::MmId::from_raw_u64(1).unwrap();
        let child_mm = crate::kernel::MmId::from_raw_u64(2).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(parent_mm, child_mm, crate::kernel::CloneObjectMode::Copy)
            .unwrap();
        let child = dispatcher
            .fork_clone_with_prepared_mm(parent_mm, child_mm, 100, 101, prepared)
            .unwrap();
        let child_state = Arc::clone(&child.mem().lock().deferred_anonymous);
        assert!(!Arc::ptr_eq(&parent_state, &child_state));
        assert_eq!(child_state.snapshot(), before);
        child_state.retire(GuestVa(0x10000), 0x1000).unwrap();
        assert_eq!(parent_state.snapshot(), before);
        parent_state
            .begin_materialization(GuestVa(0x12000), 0x1000)
            .unwrap()
            .commit();
        assert!(
            child_state
                .copy_pristine_zero(GuestVa(0x12000), &mut [1; 4])
                .unwrap()
        );
        assert!(
            !parent_state
                .copy_pristine_zero(GuestVa(0x12000), &mut [1; 4])
                .unwrap()
        );
    }

    #[test]
    fn deferred_anonymous_copied_fork_applies_dontfork_and_wipeonfork() {
        let dispatcher = SyscallDispatcher::new();
        dispatcher.record_dynamic_mapping(
            0x10000,
            0x3000,
            LinuxProtFlags::READ | LinuxProtFlags::WRITE,
            carrick_vfs::ProcMapSharing::Private,
            "[anon]".to_string(),
        );
        let parent_state = Arc::clone(&dispatcher.mem().lock().deferred_anonymous);
        parent_state
            .reserve_fresh(GuestVa(0x10000), 0x3000)
            .unwrap();
        for page in [0x10000, 0x11000, 0x12000] {
            assert!(
                parent_state
                    .copy_pristine_zero(GuestVa(page), &mut [1; 4])
                    .unwrap()
            );
        }
        dispatcher.update_madvise_vma_policy(
            0x10000,
            0x1000,
            Some(carrick_abi::VmaForkCopyPolicy::Omit),
            None,
            None,
        );
        dispatcher.update_madvise_vma_policy(
            0x11000,
            0x1000,
            None,
            Some(carrick_abi::VmaForkChildPolicy::ZeroInChild),
            None,
        );
        let before = parent_state.snapshot();
        let parent_mm = crate::kernel::MmId::from_raw_u64(1).unwrap();
        let child_mm = crate::kernel::MmId::from_raw_u64(2).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(parent_mm, child_mm, crate::kernel::CloneObjectMode::Copy)
            .unwrap();
        let child = dispatcher
            .fork_clone_with_prepared_mm(parent_mm, child_mm, 100, 101, prepared)
            .unwrap();
        let child_state = Arc::clone(&child.mem().lock().deferred_anonymous);
        assert_eq!(
            child_state.snapshot().pristine,
            vec![GuestVa(0x11000)..GuestVa(0x13000)]
        );
        assert_eq!(
            child_state.snapshot().zero_read_resident,
            vec![GuestVa(0x12000)..GuestVa(0x13000)]
        );
        let mut bytes = [7; 4];
        assert!(
            !child_state
                .copy_pristine_zero(GuestVa(0x10000), &mut bytes)
                .unwrap()
        );
        assert_eq!(bytes, [7; 4]);
        assert!(
            child_state
                .copy_pristine_zero(GuestVa(0x11000), &mut bytes)
                .unwrap()
        );
        assert_eq!(bytes, [0; 4]);
        assert_eq!(parent_state.snapshot(), before);
    }

    #[test]
    fn fork_projection_copied_is_total_and_holes_are_absent() {
        let dispatcher = SyscallDispatcher::new();
        dispatcher.set_address_space_regions(vec![
            carrick_vfs::ProcMapsEntry {
                start: 0x10000,
                end: 0x14000,
                read: true,
                write: true,
                execute: false,
                sharing: carrick_vfs::ProcMapSharing::Private,
                path: "[anon1]".to_string(),
            },
            carrick_vfs::ProcMapsEntry {
                start: 0x20000,
                end: 0x24000,
                read: true,
                write: true,
                execute: false,
                sharing: carrick_vfs::ProcMapSharing::Private,
                path: "[anon2]".to_string(),
            },
        ]);

        // Mark 0x10000..0x12000 as DONTFORK
        dispatcher.update_madvise_vma_policy(
            0x10000,
            0x2000,
            Some(carrick_abi::VmaForkCopyPolicy::Omit),
            None,
            None,
        );
        // Mark 0x22000..0x24000 as WIPEONFORK
        dispatcher.update_madvise_vma_policy(
            0x22000,
            0x2000,
            None,
            Some(carrick_abi::VmaForkChildPolicy::ZeroInChild),
            None,
        );

        let parent_mm_id = crate::kernel::MmId::from_raw_u64(1).unwrap();
        let child_mm_id = crate::kernel::MmId::from_raw_u64(2).unwrap();
        let prepared = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            )
            .unwrap();
        let plan = prepared.fork_projection_plan();
        let ranges = plan.ranges();

        // Check totality over live leaves
        assert_eq!(
            carrick_hal::lookup_fork_projection(ranges, 0x10000),
            Some(carrick_hal::ForkLeafDisposition::Omit)
        );
        assert_eq!(
            carrick_hal::lookup_fork_projection(ranges, 0x12000),
            Some(carrick_hal::ForkLeafDisposition::Preserve)
        );
        assert_eq!(
            carrick_hal::lookup_fork_projection(ranges, 0x20000),
            Some(carrick_hal::ForkLeafDisposition::Preserve)
        );
        assert_eq!(
            carrick_hal::lookup_fork_projection(ranges, 0x22000),
            Some(carrick_hal::ForkLeafDisposition::Zero)
        );

        // Gap/hole between 0x14000 and 0x20000 must be absent (None, never defaulting to Preserve)
        assert_eq!(carrick_hal::lookup_fork_projection(ranges, 0x15000), None);
        assert_eq!(carrick_hal::lookup_fork_projection(ranges, 0x1f000), None);
    }

    #[test]
    fn fork_projection_brk_grow_and_shrink_tracks_heap_and_revision() {
        let dispatcher = SyscallDispatcher::new();
        let heap_base = dispatcher.mem().lock().layout.heap_base;
        let initial_revision = dispatcher.mem().vma_revision();
        dispatcher.with_vma_dispatch_for_test(|_vma| {
            let authority = dispatcher.mem();
            let mut state = authority.lock();
            mem::update_semantic_heap_pages(&mut state, heap_base, heap_base + 0x3000);
            state.brk_current = heap_base + 0x3000;
        });
        let grown_revision = dispatcher.mem().vma_revision();
        assert!(grown_revision.raw() > initial_revision.raw());

        let parent_mm_id = crate::kernel::MmId::from_raw_u64(71).unwrap();
        let child_mm_id = crate::kernel::MmId::from_raw_u64(72).unwrap();
        let grown = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            )
            .unwrap();
        assert_eq!(
            carrick_hal::lookup_fork_projection(
                grown.fork_projection_plan().ranges(),
                heap_base + 0x2000,
            ),
            Some(carrick_hal::ForkLeafDisposition::Preserve)
        );

        dispatcher.with_vma_dispatch_for_test(|_vma| {
            let authority = dispatcher.mem();
            let mut state = authority.lock();
            mem::update_semantic_heap_pages(&mut state, heap_base + 0x3000, heap_base + 0x1000);
            state.brk_current = heap_base + 0x1000;
        });
        assert!(dispatcher.mem().vma_revision().raw() > grown_revision.raw());
        let shrunk = dispatcher
            .prepare_fork_mm(
                parent_mm_id,
                child_mm_id,
                crate::kernel::CloneObjectMode::Copy,
            )
            .unwrap();
        assert_eq!(
            carrick_hal::lookup_fork_projection(shrunk.fork_projection_plan().ranges(), heap_base,),
            Some(carrick_hal::ForkLeafDisposition::Preserve)
        );
        assert_eq!(
            carrick_hal::lookup_fork_projection(
                shrunk.fork_projection_plan().ranges(),
                heap_base + 0x1000,
            ),
            None
        );
    }

    #[test]
    fn fork_projection_brk_growth_does_not_inherit_modified_tail_semantics() {
        let dispatcher = SyscallDispatcher::new();
        let heap_base = dispatcher.mem().lock().layout.heap_base;
        let authority = dispatcher.mem();
        let mut state = authority.lock();
        mem::update_semantic_heap_pages(&mut state, heap_base, heap_base + 0x1000);
        let tail = state
            .semantic_vmas
            .iter_mut()
            .find(|vma| vma.start == heap_base && vma.end == heap_base + 0x1000)
            .expect("initial heap VMA");
        tail.read = false;
        tail.write = false;
        tail.fork_policy.copy = carrick_abi::VmaForkCopyPolicy::Omit;
        tail.fork_policy.child_contents = carrick_abi::VmaForkChildPolicy::ZeroInChild;
        tail.droppable = true;

        mem::update_semantic_heap_pages(&mut state, heap_base + 0x1000, heap_base + 0x3000);
        let grown = state
            .semantic_vmas
            .iter()
            .find(|vma| vma.start == heap_base + 0x1000 && vma.end == heap_base + 0x3000)
            .expect("new default heap VMA");
        assert!(grown.read);
        assert!(grown.write);
        assert!(!grown.execute);
        assert_eq!(grown.fork_policy, carrick_abi::VmaForkPolicy::DEFAULT);
        assert!(!grown.droppable);
    }

    #[test]
    fn fork_projection_rejects_invalid_gapped_overflow_unaligned_overlapping_fail_closed() {
        use carrick_hal::{
            ForkLeafDisposition, ForkProjectionError, ForkProjectionRange,
            validate_fork_projection, validate_total_fork_projection,
        };

        // Zero length
        let zero_len = [ForkProjectionRange {
            va: 0x1000,
            len: 0,
            disposition: ForkLeafDisposition::Preserve,
        }];
        assert_eq!(
            validate_fork_projection(&zero_len),
            Err(ForkProjectionError::ZeroLength)
        );

        // Unaligned VA
        let unaligned_va = [ForkProjectionRange {
            va: 0x1001,
            len: 0x1000,
            disposition: ForkLeafDisposition::Preserve,
        }];
        assert_eq!(
            validate_fork_projection(&unaligned_va),
            Err(ForkProjectionError::Unaligned {
                va: 0x1001,
                len: 0x1000
            })
        );

        // Unaligned length
        let unaligned_len = [ForkProjectionRange {
            va: 0x1000,
            len: 0x1001,
            disposition: ForkLeafDisposition::Preserve,
        }];
        assert_eq!(
            validate_fork_projection(&unaligned_len),
            Err(ForkProjectionError::Unaligned {
                va: 0x1000,
                len: 0x1001
            })
        );

        // Overflow
        let overflow = [ForkProjectionRange {
            va: 0xFFFF_FFFF_FFFF_F000,
            len: 0x2000,
            disposition: ForkLeafDisposition::Preserve,
        }];
        assert_eq!(
            validate_fork_projection(&overflow),
            Err(ForkProjectionError::Overflow)
        );

        // Overlapping
        let overlapping = [
            ForkProjectionRange {
                va: 0x1000,
                len: 0x2000,
                disposition: ForkLeafDisposition::Preserve,
            },
            ForkProjectionRange {
                va: 0x2000,
                len: 0x2000,
                disposition: ForkLeafDisposition::Preserve,
            },
        ];
        assert_eq!(
            validate_fork_projection(&overlapping),
            Err(ForkProjectionError::OverlappingOrUnsorted)
        );

        // Unsorted
        let unsorted = [
            ForkProjectionRange {
                va: 0x3000,
                len: 0x1000,
                disposition: ForkLeafDisposition::Preserve,
            },
            ForkProjectionRange {
                va: 0x1000,
                len: 0x1000,
                disposition: ForkLeafDisposition::Preserve,
            },
        ];
        assert_eq!(
            validate_fork_projection(&unsorted),
            Err(ForkProjectionError::OverlappingOrUnsorted)
        );

        let gapped = [ForkProjectionRange {
            va: 0x1000,
            len: 0x1000,
            disposition: ForkLeafDisposition::Preserve,
        }];
        assert_eq!(
            validate_total_fork_projection(&gapped, &[(0x1000, 0x3000)]),
            Err(ForkProjectionError::IncompleteCoverage)
        );

        // Valid sorted, non-overlapping, aligned
        let valid = [
            ForkProjectionRange {
                va: 0x1000,
                len: 0x1000,
                disposition: ForkLeafDisposition::Preserve,
            },
            ForkProjectionRange {
                va: 0x3000,
                len: 0x2000,
                disposition: ForkLeafDisposition::Zero,
            },
        ];
        assert_eq!(validate_fork_projection(&valid), Ok(()));
    }

    #[test]
    fn fork_projection_invalid_semantic_vma_is_rejected_by_prepare() {
        let dispatcher = SyscallDispatcher::new();
        dispatcher
            .mem()
            .lock()
            .semantic_vmas
            .push(mem::SemanticVma {
                start: 0x1001,
                end: 0x2000,
                read: true,
                write: true,
                execute: false,
                provenance: mem::VmaBackingProvenance::PrivateAnonymous,
                fork_policy: carrick_abi::VmaForkPolicy::DEFAULT,
                dump_policy: carrick_abi::VmaDumpPolicy::Include,
                droppable: false,
                path: "[invalid]".to_owned(),
                file_page_offset: None,
            });
        let parent_mm_id = crate::kernel::MmId::from_raw_u64(1).unwrap();
        assert!(matches!(
            dispatcher.prepare_fork_mm(
                parent_mm_id,
                crate::kernel::MmId::from_raw_u64(2).unwrap(),
                crate::kernel::CloneObjectMode::Copy,
            ),
            Err(PrepareDispatchMmForkError::Projection(
                carrick_hal::ForkProjectionError::Unaligned { .. }
            ))
        ));
    }
}

#[cfg(test)]
mod container_clock_tests {
    //! Two containers in one carrier keep independent CLOCK_REALTIME
    //! authorities. Each `SyscallDispatcher::new()` bootstraps its own root
    //! task and therefore its own `Container`; the clock a handler reads must
    //! be that container's `ClockDomain`, never a process static.
    use super::*;
    use crate::compat::CompatReporter;
    use carrick_abi::*;
    use std::time::{Duration, SystemTime, UNIX_EPOCH};

    const SYS_TIMERFD_CREATE: u64 = 85;
    const SYS_TIMERFD_SETTIME: u64 = 86;
    const SYS_CLOSE: u64 = 57;
    const SYS_READ: u64 = 63;
    const SYS_CLOCK_SETTIME: u64 = 112;
    const SYS_CLOCK_GETTIME: u64 = 113;
    const SYS_CLOCK_ADJTIME: u64 = 266;
    const MEM_BASE: u64 = 0x4000_0000;
    const MEM_LEN: usize = 4096;
    const TIMESPEC_ADDR: u64 = MEM_BASE + 0x100;
    const ITIMERSPEC_ADDR: u64 = MEM_BASE + 0x200;
    const TIMEX_ADDR: u64 = MEM_BASE + 0x300;
    const SLACK: Duration = Duration::from_secs(5);

    fn wall_now() -> Duration {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or(Duration::ZERO)
    }

    fn assert_within(actual: Duration, expected: Duration, what: &str) {
        let delta = actual.abs_diff(expected);
        assert!(
            delta <= SLACK,
            "{what}: actual {actual:?}, expected {expected:?} (delta {delta:?})"
        );
    }

    fn realtime_via_syscall(
        dispatcher: &mut SyscallDispatcher,
        memory: &mut LinearMemory,
    ) -> Duration {
        let reporter = CompatReporter::default();
        let outcome = dispatcher
            .dispatch(
                &dispatcher.capture_one_task_context().expect("task context"),
                SyscallRequest::new(
                    SYS_CLOCK_GETTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMESPEC_ADDR, 0, 0, 0, 0]),
                ),
                memory,
                &reporter,
            )
            .expect("dispatch clock_gettime");
        assert_eq!(outcome, DispatchOutcome::Returned { value: 0 });
        let bytes = memory
            .read_bytes(TIMESPEC_ADDR, 16)
            .expect("timespec bytes");
        let secs = i64::from_le_bytes(bytes[0..8].try_into().expect("tv_sec"));
        let nanos = i64::from_le_bytes(bytes[8..16].try_into().expect("tv_nsec"));
        Duration::new(secs as u64, nanos as u32)
    }

    fn write_timespec(memory: &mut LinearMemory, address: u64, value: Duration) {
        let mut bytes = [0u8; 16];
        bytes[0..8].copy_from_slice(&(value.as_secs() as i64).to_le_bytes());
        bytes[8..16].copy_from_slice(&i64::from(value.subsec_nanos()).to_le_bytes());
        memory.write_bytes(address, &bytes).expect("write timespec");
    }

    #[test]
    fn clock_gettime_realtime_reads_the_callers_container_domain() {
        let mut a = SyscallDispatcher::new();
        let mut b = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        const OFFSET: Duration = Duration::from_secs(3600);
        b.capture_one_task_context()
            .expect("b context")
            .task()
            .container()
            .clock()
            .set_realtime_offset_ns(OFFSET.as_nanos() as i64);

        assert_within(
            realtime_via_syscall(&mut a, &mut memory),
            wall_now(),
            "A follows the wall clock",
        );
        assert_within(
            realtime_via_syscall(&mut b, &mut memory),
            wall_now() + OFFSET,
            "B is shifted by its own domain",
        );
        assert_within(
            realtime_via_syscall(&mut a, &mut memory),
            wall_now(),
            "A is untouched by B's offset",
        );
    }

    #[test]
    fn clock_settime_moves_only_the_callers_container() {
        let mut a = SyscallDispatcher::new();
        let mut b = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        // clock_settime is CAP_SYS_TIME-gated and the Docker default set lacks it.
        let a_context = a.capture_one_task_context().expect("a context");
        a_context
            .task()
            .with_caps(|caps| *caps = crate::namespace::process::CapabilitySet::full());
        const AHEAD: Duration = Duration::from_secs(7200);
        write_timespec(&mut memory, TIMESPEC_ADDR, wall_now() + AHEAD);
        let outcome = a
            .dispatch(
                &a_context,
                SyscallRequest::new(
                    SYS_CLOCK_SETTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMESPEC_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch clock_settime");
        assert_eq!(outcome, DispatchOutcome::Returned { value: 0 });

        assert_within(
            realtime_via_syscall(&mut a, &mut memory),
            wall_now() + AHEAD,
            "A moved",
        );
        assert_within(
            realtime_via_syscall(&mut b, &mut memory),
            wall_now(),
            "B did not move",
        );
        assert_eq!(
            b.capture_one_task_context()
                .expect("b context")
                .task()
                .container()
                .clock()
                .realtime_offset_ns(),
            0,
            "B's domain never observed A's clock_settime"
        );
    }

    #[test]
    fn clock_settime_rejects_realtime_before_monotonic_uptime() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");
        context
            .task()
            .with_caps(|caps| *caps = crate::namespace::process::CapabilitySet::full());

        write_timespec(&mut memory, TIMESPEC_ADDR, Duration::from_secs(2));
        let outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_SETTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMESPEC_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch clock_settime");

        assert_eq!(outcome, DispatchOutcome::errno(LINUX_EINVAL));
    }

    #[test]
    fn clock_adjtime_privileged_rejects_tick_outside_linux_bounds() {
        const ADJ_TICK: u32 = 0x4000;
        const MIN_TICK_USEC: i64 = 900_000 / LINUX_CLK_TCK;
        const MAX_TICK_USEC: i64 = 1_100_000 / LINUX_CLK_TCK;

        for invalid_tick in [MIN_TICK_USEC - 1, MAX_TICK_USEC + 1] {
            let mut dispatcher = SyscallDispatcher::new();
            let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
            let reporter = CompatReporter::default();
            let context = dispatcher.capture_one_task_context().expect("task context");
            context
                .task()
                .with_caps(|caps| *caps = crate::namespace::process::CapabilitySet::full());
            let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
            timex.modes = ADJ_TICK;
            timex.tick = invalid_tick;
            memory
                .write_bytes(TIMEX_ADDR, timex.abi_bytes())
                .expect("write timex");

            let outcome = dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(
                        SYS_CLOCK_ADJTIME,
                        SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                    ),
                    &mut memory,
                    &reporter,
                )
                .expect("dispatch clock_adjtime");

            assert_eq!(
                outcome,
                DispatchOutcome::errno(LINUX_EINVAL),
                "ADJ_TICK={invalid_tick} must be range-validated after CAP_SYS_TIME"
            );
        }
    }

    #[test]
    fn clock_adjtime_read_reports_time_ok_by_default() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");
        let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
        timex.modes = 0;
        memory
            .write_bytes(TIMEX_ADDR, timex.abi_bytes())
            .expect("write timex");

        let outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch clock_adjtime");

        assert_eq!(
            outcome,
            DispatchOutcome::Returned {
                value: LINUX_TIME_OK
            }
        );
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).expect("read timex");
        assert_eq!({ read.offset }, 0);
        assert_eq!({ read.freq }, 0);
        assert_eq!({ read.maxerror }, 16_000_000);
        assert_eq!({ read.esterror }, 16_000_000);
        assert_eq!({ read.status }, 0);
        assert_eq!({ read.constant }, 2);
        assert_eq!({ read.tick }, 10_000);
        assert_eq!({ read.tai }, 0);
    }

    #[test]
    fn clock_adjtime_reports_time_error_when_sta_unsync_set() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");
        context
            .task()
            .with_caps(|caps| *caps = crate::namespace::process::CapabilitySet::full());

        let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
        timex.modes = LINUX_ADJ_STATUS;
        timex.status = LINUX_STA_UNSYNC;
        memory
            .write_bytes(TIMEX_ADDR, timex.abi_bytes())
            .expect("write timex");

        let outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch clock_adjtime");
        assert_eq!(
            outcome,
            DispatchOutcome::Returned {
                value: LINUX_TIME_ERROR
            }
        );

        // Subsequent read-only call must now report TIME_ERROR because STA_UNSYNC is set
        timex.modes = 0;
        memory
            .write_bytes(TIMEX_ADDR, timex.abi_bytes())
            .expect("write timex");
        let read_outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch clock_adjtime");
        assert_eq!(
            read_outcome,
            DispatchOutcome::Returned {
                value: LINUX_TIME_ERROR
            }
        );
    }

    #[test]
    fn clock_adjtime_unprivileged_modifying_modes_fail_with_eperm() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");

        for mode in [
            LINUX_ADJ_OFFSET,
            LINUX_ADJ_FREQUENCY,
            LINUX_ADJ_MAXERROR,
            LINUX_ADJ_ESTERROR,
            LINUX_ADJ_STATUS,
            LINUX_ADJ_TIMECONST,
            LINUX_ADJ_TAI,
            LINUX_ADJ_TICK,
            LINUX_ADJ_SETOFFSET,
            LINUX_ADJ_OFFSET_SINGLESHOT,
        ] {
            let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
            timex.modes = mode;
            timex.tick = 10_000;
            memory
                .write_bytes(TIMEX_ADDR, timex.abi_bytes())
                .expect("write timex");

            let outcome = dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(
                        SYS_CLOCK_ADJTIME,
                        SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                    ),
                    &mut memory,
                    &reporter,
                )
                .expect("dispatch clock_adjtime");

            assert_eq!(
                outcome,
                DispatchOutcome::errno(LINUX_EPERM),
                "mode {mode:#x} without CAP_SYS_TIME must be EPERM"
            );
        }
    }

    #[test]
    fn clock_adjtime_privileged_roundtrips_all_adj_modes() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");
        context
            .task()
            .with_caps(|caps| *caps = crate::namespace::process::CapabilitySet::full());

        // 1. ADJ_OFFSET
        let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
        timex.modes = LINUX_ADJ_OFFSET;
        timex.offset = 42_000;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.offset }, 42_000);

        // 2. ADJ_FREQUENCY
        timex.modes = LINUX_ADJ_FREQUENCY;
        timex.freq = 12_345;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.freq }, 12_345);

        // 3. ADJ_MAXERROR
        timex.modes = LINUX_ADJ_MAXERROR;
        timex.maxerror = 500_000;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.maxerror }, 500_000);

        // 4. ADJ_ESTERROR
        timex.modes = LINUX_ADJ_ESTERROR;
        timex.esterror = 250_000;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.esterror }, 250_000);

        // 5. ADJ_TIMECONST
        timex.modes = LINUX_ADJ_TIMECONST;
        timex.constant = 8;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.constant }, 8);

        // 6. ADJ_TAI
        timex.modes = LINUX_ADJ_TAI;
        timex.constant = 37;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.tai }, 37);

        // 7. ADJ_TICK
        timex.modes = LINUX_ADJ_TICK;
        timex.tick = 10_500;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.tick }, 10_500);

        // 8. ADJ_STATUS
        timex.modes = LINUX_ADJ_STATUS;
        timex.status = LINUX_STA_PLL | LINUX_STA_PPSFREQ;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!(
            { read.status } & (LINUX_STA_PLL | LINUX_STA_PPSFREQ),
            LINUX_STA_PLL | LINUX_STA_PPSFREQ
        );

        // 9. ADJ_NANO
        timex.modes = LINUX_ADJ_NANO;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_ne!({ read.status } & LINUX_STA_NANO, 0);

        // 10. ADJ_MICRO
        timex.modes = LINUX_ADJ_MICRO;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.status } & LINUX_STA_NANO, 0);
    }

    #[test]
    fn clock_adjtime_setoffset_moves_realtime() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");
        context
            .task()
            .with_caps(|caps| *caps = crate::namespace::process::CapabilitySet::full());

        let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(100, 500_000));
        timex.modes = LINUX_ADJ_SETOFFSET;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();

        let outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch clock_adjtime");
        assert_eq!(
            outcome,
            DispatchOutcome::Returned {
                value: LINUX_TIME_OK
            }
        );

        let offset_ns = context.task().container().clock().realtime_offset_ns();
        assert_eq!(offset_ns, 100 * 1_000_000_000 + 500_000 * 1_000);
    }

    #[test]
    fn clock_adjtime_offset_singleshot_moves_realtime() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");
        context
            .task()
            .with_caps(|caps| *caps = crate::namespace::process::CapabilitySet::full());

        let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
        timex.modes = LINUX_ADJ_OFFSET_SINGLESHOT;
        timex.offset = 50_000;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();

        let outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch clock_adjtime");
        assert_eq!(
            outcome,
            DispatchOutcome::Returned {
                value: LINUX_TIME_OK
            }
        );

        let offset_ns = context.task().container().clock().realtime_offset_ns();
        assert_eq!(offset_ns, 50_000 * 1_000);

        // SS_READ reports 0 remaining slew
        timex.modes = LINUX_ADJ_OFFSET_SS_READ;
        timex.offset = 999;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        let outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .expect("dispatch clock_adjtime");
        assert_eq!(
            outcome,
            DispatchOutcome::Returned {
                value: LINUX_TIME_OK
            }
        );
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        assert_eq!({ read.offset }, 0);
    }

    #[test]
    fn clock_adjtime_rejects_out_of_range_values_with_einval() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");
        context
            .task()
            .with_caps(|caps| *caps = crate::namespace::process::CapabilitySet::full());

        // Oversized freq is CLAMPED to +/-MAXFREQ, not refused (native
        // arm64 oracle, probe `adjtimexmodel` `oversized_freq_accepted`).
        for (bad_freq, clamped) in [(35_000_000, 32_768_000), (-35_000_000, -32_768_000)] {
            let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
            timex.modes = LINUX_ADJ_FREQUENCY;
            timex.freq = bad_freq;
            memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
            let outcome = dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(
                        SYS_CLOCK_ADJTIME,
                        SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                    ),
                    &mut memory,
                    &reporter,
                )
                .unwrap();
            assert_ne!(outcome, DispatchOutcome::errno(LINUX_EINVAL));
            let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
            let read_freq = { read.freq };
            assert_eq!(
                read_freq, clamped,
                "freq {bad_freq} must clamp to {clamped}"
            );
        }

        // Out-of-range singleshot offset
        for bad_offset in [131_072, -131_072] {
            let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
            timex.modes = LINUX_ADJ_OFFSET_SINGLESHOT;
            timex.offset = bad_offset;
            memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
            let outcome = dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(
                        SYS_CLOCK_ADJTIME,
                        SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                    ),
                    &mut memory,
                    &reporter,
                )
                .unwrap();
            assert_eq!(outcome, DispatchOutcome::errno(LINUX_EINVAL));
        }

        // Undefined status bits are IGNORED, not refused (oracle accepts
        // `1 << 20`; `unknown_status_bits_accepted`).
        let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
        timex.modes = LINUX_ADJ_STATUS;
        timex.status = 1 << 20;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        let outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        assert_ne!(outcome, DispatchOutcome::errno(LINUX_EINVAL));
        let read = read_kernel_struct::<LinuxTimex>(&memory, TIMEX_ADDR).unwrap();
        let read_status = { read.status };
        assert_eq!(
            read_status & (1 << 20),
            0,
            "undefined status bit must be dropped"
        );

        // Invalid SETOFFSET tv_usec
        for bad_usec in [-1, 1_000_000] {
            let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(10, bad_usec));
            timex.modes = LINUX_ADJ_SETOFFSET;
            memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
            let outcome = dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(
                        SYS_CLOCK_ADJTIME,
                        SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                    ),
                    &mut memory,
                    &reporter,
                )
                .unwrap();
            assert_eq!(outcome, DispatchOutcome::errno(LINUX_EINVAL));
        }

        // MICRO|NANO together and TAI|TIMECONST together are accepted
        // (oracle); neither is EINVAL.
        for modes in [
            LINUX_ADJ_MICRO | LINUX_ADJ_NANO,
            LINUX_ADJ_TAI | LINUX_ADJ_TIMECONST,
        ] {
            let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
            timex.modes = modes;
            memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
            let outcome = dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(
                        SYS_CLOCK_ADJTIME,
                        SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                    ),
                    &mut memory,
                    &reporter,
                )
                .unwrap();
            assert_ne!(
                outcome,
                DispatchOutcome::errno(LINUX_EINVAL),
                "modes {modes:#x}"
            );
        }

        // Singleshot flag without OFFSET
        let mut timex = LinuxTimex::new_read_state(LinuxTimeval::new(0, 0));
        timex.modes = LINUX_ADJ_OFFSET_SINGLESHOT_FLAG_ONLY;
        memory.write_bytes(TIMEX_ADDR, timex.abi_bytes()).unwrap();
        let outcome = dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_CLOCK_ADJTIME,
                    SyscallArgs([LINUX_CLOCK_REALTIME, TIMEX_ADDR, 0, 0, 0, 0]),
                ),
                &mut memory,
                &reporter,
            )
            .unwrap();
        assert_eq!(outcome, DispatchOutcome::errno(LINUX_EINVAL));
    }

    fn armed_absolute_timerfd(
        dispatcher: &mut SyscallDispatcher,
        memory: &mut LinearMemory,
        deadline: Duration,
    ) -> Arc<TimerFdState> {
        let (_, state, _) = armed_absolute_timerfd_with_flags(dispatcher, memory, deadline, 0);
        state
    }

    fn armed_absolute_timerfd_with_flags(
        dispatcher: &mut SyscallDispatcher,
        memory: &mut LinearMemory,
        deadline: Duration,
        flags: u64,
    ) -> (u64, Arc<TimerFdState>, Arc<crate::kernel::FileDescription>) {
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");
        let fd = match dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(
                    SYS_TIMERFD_CREATE,
                    SyscallArgs([LINUX_CLOCK_REALTIME, flags, 0, 0, 0, 0]),
                ),
                memory,
                &reporter,
            )
            .expect("dispatch timerfd_create")
        {
            DispatchOutcome::Returned { value } => value as u64,
            other => panic!("timerfd_create failed: {other:?}"),
        };
        // struct itimerspec { it_interval (zero); it_value = deadline }
        let mut spec = [0u8; 32];
        spec[16..24].copy_from_slice(&(deadline.as_secs() as i64).to_le_bytes());
        spec[24..32].copy_from_slice(&i64::from(deadline.subsec_nanos()).to_le_bytes());
        memory
            .write_bytes(ITIMERSPEC_ADDR, &spec)
            .expect("write itimerspec");
        assert_eq!(
            dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(
                        SYS_TIMERFD_SETTIME,
                        SyscallArgs([
                            fd,
                            LinuxTfdFlags::TIMER_ABSTIME.bits(),
                            ITIMERSPEC_ADDR,
                            0,
                            0,
                            0
                        ]),
                    ),
                    memory,
                    &reporter,
                )
                .expect("dispatch timerfd_settime"),
            DispatchOutcome::Returned { value: 0 }
        );
        let open_file = dispatcher.open_file(fd as i32).expect("timerfd open file");
        let description = open_file.description();
        let open = description.read().expect("timerfd open description");
        let OpenDescription::TimerFd { state, .. } = &*open else {
            panic!("fd {fd} is not a timerfd");
        };
        let state = Arc::clone(state);
        drop(open);
        (fd, state, description)
    }

    #[test]
    fn timerfd_deadline_is_bound_to_the_creating_containers_clock() {
        let mut a = SyscallDispatcher::new();
        let mut b = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let deadline = wall_now() + Duration::from_secs(3600);
        let timer_a = armed_absolute_timerfd(&mut a, &mut memory, deadline);
        let timer_b = armed_absolute_timerfd(&mut b, &mut memory, deadline);
        assert_eq!(timerfd_ready_count(&timer_a), 0);
        assert_eq!(timerfd_ready_count(&timer_b), 0);

        // Move only A's clock past the deadline.
        a.capture_one_task_context()
            .expect("a context")
            .task()
            .container()
            .clock()
            .set_realtime_offset_ns(Duration::from_secs(7200).as_nanos() as i64);

        assert_eq!(
            timerfd_ready_count(&timer_a),
            1,
            "A's timerfd follows A's clock"
        );
        assert_eq!(
            timerfd_ready_count(&timer_b),
            0,
            "B's timerfd is bound to B's clock"
        );
    }

    #[test]
    fn timerfd_ready_bad_destination_consumes_expiration() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let deadline = wall_now() + Duration::from_secs(3600);
        let (fd, _state, _) = armed_absolute_timerfd_with_flags(
            &mut dispatcher,
            &mut memory,
            deadline,
            LINUX_TFD_NONBLOCK,
        );
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");

        context
            .task()
            .container()
            .clock()
            .set_realtime_offset_ns(Duration::from_secs(7200).as_nanos() as i64);

        assert_eq!(
            dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(SYS_READ, SyscallArgs([fd, MEM_BASE - 8, 8, 0, 0, 0])),
                    &mut memory,
                    &reporter,
                )
                .expect("dispatch ready timerfd read to invalid destination"),
            DispatchOutcome::errno(LINUX_EFAULT)
        );
        assert_eq!(
            dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(SYS_READ, SyscallArgs([fd, TIMESPEC_ADDR, 8, 0, 0, 0])),
                    &mut memory,
                    &reporter,
                )
                .expect("dispatch nonblocking timerfd read after EFAULT"),
            DispatchOutcome::errno(LINUX_EAGAIN),
            "the failed copyout consumes the ready expiration"
        );
    }

    #[test]
    fn blocking_timerfd_read_keeps_its_description_across_close_and_fd_reuse() {
        let mut dispatcher = SyscallDispatcher::new();
        let mut memory = LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]);
        let first_deadline = wall_now() + Duration::from_secs(3600);
        let (fd, _old_state, old_description) =
            armed_absolute_timerfd_with_flags(&mut dispatcher, &mut memory, first_deadline, 0);
        let reporter = CompatReporter::default();
        let context = dispatcher.capture_one_task_context().expect("task context");

        let blocked_read = match dispatcher
            .dispatch(
                &context,
                SyscallRequest::new(SYS_READ, SyscallArgs([fd, TIMESPEC_ADDR, 8, 0, 0, 0])),
                &mut memory,
                &reporter,
            )
            .expect("dispatch blocking timerfd read")
        {
            DispatchOutcome::BlockingTimerFdRead(read) => read,
            other => panic!("expected blocking timerfd read, got {other:?}"),
        };

        assert_eq!(
            dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(SYS_CLOSE, SyscallArgs([fd, 0, 0, 0, 0, 0])),
                    &mut memory,
                    &reporter,
                )
                .expect("close old timerfd"),
            DispatchOutcome::Returned { value: 0 }
        );

        let second_deadline = first_deadline + Duration::from_secs(7200);
        let (reused_fd, new_state, new_description) = armed_absolute_timerfd_with_flags(
            &mut dispatcher,
            &mut memory,
            second_deadline,
            LINUX_TFD_NONBLOCK,
        );
        assert_eq!(
            reused_fd, fd,
            "timerfd slot must be reused for this regression"
        );
        assert!(
            !Arc::ptr_eq(&old_description, &new_description),
            "the reused slot must name a different file description"
        );

        context
            .task()
            .container()
            .clock()
            .set_realtime_offset_ns(Duration::from_secs(7200).as_nanos() as i64);
        assert_eq!(
            timerfd_ready_count(&new_state),
            0,
            "new timer must remain unready"
        );

        match blocked_read.complete(&mut memory) {
            super::format_time::TimerFdReadStep::Done(DispatchOutcome::Returned { value }) => {
                assert_eq!(value, 8)
            }
            other => {
                panic!("old timerfd continuation did not complete from its own timer: {other:?}")
            }
        }
        let expirations = u64::from_le_bytes(
            memory
                .read_bytes(TIMESPEC_ADDR, 8)
                .expect("read old timerfd result")
                .try_into()
                .expect("timerfd result width"),
        );
        assert_eq!(expirations, 1);

        assert_eq!(
            dispatcher
                .dispatch(
                    &context,
                    SyscallRequest::new(
                        SYS_READ,
                        SyscallArgs([reused_fd, TIMESPEC_ADDR, 8, 0, 0, 0])
                    ),
                    &mut memory,
                    &reporter,
                )
                .expect("read reused nonblocking timerfd"),
            DispatchOutcome::errno(LINUX_EAGAIN),
            "the reused descriptor must not satisfy the old continuation"
        );
    }
}

#[test]
fn statx_sync_flags_are_mutually_exclusive() {
    assert!(linux_statx_flags_are_supported(0));
    assert!(linux_statx_flags_are_supported(LINUX_AT_STATX_FORCE_SYNC));
    assert!(linux_statx_flags_are_supported(LINUX_AT_STATX_DONT_SYNC));
    assert!(!linux_statx_flags_are_supported(
        LINUX_AT_STATX_FORCE_SYNC | LINUX_AT_STATX_DONT_SYNC
    ));
}

#[test]
fn synthetic_proc_snapshot_and_in_process_fork_do_not_deadlock() {
    let dispatcher = Arc::new(SyscallDispatcher::new());
    let bootstrap = crate::kernel::RootBootstrap::for_reference_model(
        100,
        crate::thread::ThreadId::synthetic_for_tests(100),
        "proc-mm-lock-order".to_owned(),
    )
    .expect("bootstrap root for /proc/MM race");
    let (_binding, context) =
        crate::kernel::Kernel::bootstrap_root(bootstrap).expect("bootstrap /proc/MM root");
    let context = Arc::new(context);
    let (at_snapshot, reached_snapshot) = std::sync::mpsc::sync_channel(0);
    let (resume_snapshot, resume) = std::sync::mpsc::sync_channel(0);
    let renderer_dispatcher = Arc::clone(&dispatcher);
    let renderer = std::thread::spawn(move || {
        let proc = renderer_dispatcher.synthetic_proc_context_observed(&context, || {
            at_snapshot
                .send(())
                .expect("announce completed process snapshot");
            resume.recv().expect("resume MM snapshot");
        });
        assert_eq!(proc.task_comm, "exe");
    });

    let mut proc_acquirer = None;
    let (acquired, acquisition) = std::sync::mpsc::channel();
    let acquired_while_alias_held = dispatcher.with_host_alias_dispatch_for_test(|_alias| {
        reached_snapshot
            .recv_timeout(std::time::Duration::from_secs(2))
            .expect("renderer reached process/MM boundary");
        let acquirer_dispatcher = Arc::clone(&dispatcher);
        proc_acquirer = Some(std::thread::spawn(move || {
            let _proc = acquirer_dispatcher.proc.lock();
            acquired
                .send(())
                .expect("announce process lock acquisition");
        }));

        let acquired_while_alias_held = acquisition
            .recv_timeout(std::time::Duration::from_millis(250))
            .is_ok();
        resume_snapshot
            .send(())
            .expect("release renderer toward MM snapshot");
        acquired_while_alias_held
    });

    renderer.join().expect("renderer join");
    proc_acquirer
        .expect("process-lock acquirer")
        .join()
        .expect("process-lock acquirer join");
    assert!(
        acquired_while_alias_held,
        "synthetic /proc retained process lock while MM alias authority was held"
    );
}

#[cfg(test)]
mod container_caps_tests {
    //! Launch-time `--cap-add` grants are container state. Two containers in
    //! one carrier must give their root tasks — and their launch policies —
    //! different privilege, which a process-global grant cannot express.
    use super::*;
    use crate::kernel::container::Container;
    use crate::kernel::{Kernel, KernelContext, RootBootstrap};
    use crate::namespace::process::{CAP_SYS_ADMIN, CAP_SYS_PTRACE, DOCKER_DEFAULT_CAPS};
    use carrick_spec::SeccompPolicy;

    /// aarch64 `unshare`: Docker's default profile denies it unless the
    /// container holds CAP_SYS_ADMIN (`container_policy.rs`, `SYS_UNSHARE`).
    const SYS_UNSHARE: u64 = 97;

    fn container_with(cap_add: &[&str]) -> Arc<Container> {
        let names: Vec<String> = cap_add.iter().map(|name| (*name).to_owned()).collect();
        Arc::new(Container::for_reference_model().with_launch_capabilities(&names))
    }

    fn root_context_in(container: Arc<Container>, pid: i32) -> KernelContext {
        let bootstrap = RootBootstrap::for_reference_model(
            pid,
            crate::thread::ThreadId::synthetic_for_tests(pid),
            "container-caps-root".to_owned(),
        )
        .expect("root bootstrap")
        .with_container(container);
        Kernel::bootstrap_root(bootstrap).expect("root kernel").1
    }

    #[test]
    fn root_task_capabilities_come_from_its_container() {
        let plain = root_context_in(container_with(&[]), 7101);
        let ptrace = root_context_in(container_with(&["SYS_PTRACE"]), 7102);
        let bit = 1u64 << CAP_SYS_PTRACE;
        assert_eq!(plain.task().caps().effective, DOCKER_DEFAULT_CAPS);
        assert_eq!(plain.task().caps().effective & bit, 0);
        let granted = ptrace.task().caps();
        assert_ne!(granted.effective & bit, 0);
        assert_ne!(granted.permitted & bit, 0);
        assert_ne!(granted.bounding & bit, 0);
        assert_eq!(granted.inheritable, 0);
        // Bootstrapping the second container never changed the first.
        assert_eq!(plain.task().caps().effective, DOCKER_DEFAULT_CAPS);
    }

    #[test]
    fn launch_policy_follows_the_containers_grant() {
        let mut plain = SyscallDispatcher::new();
        plain.apply_launch_privileges(SeccompPolicy::ContainerDefault, &container_with(&[]));
        let mut admin = SyscallDispatcher::new();
        admin.apply_launch_privileges(
            SeccompPolicy::ContainerDefault,
            &container_with(&["SYS_ADMIN"]),
        );
        assert_eq!(
            plain
                .container_policy()
                .expect("plain policy")
                .denied_errno_for_args(SYS_UNSHARE, 0),
            Some(LINUX_EPERM),
            "without CAP_SYS_ADMIN the Docker model denies unshare"
        );
        assert_eq!(
            admin
                .container_policy()
                .expect("admin policy")
                .denied_errno_for_args(SYS_UNSHARE, 0),
            None,
            "the container's own CAP_SYS_ADMIN lifts the denial"
        );
        let bit = 1u64 << CAP_SYS_ADMIN;
        assert_ne!(
            container_with(&["SYS_ADMIN"]).granted_caps().effective & bit,
            0
        );
        assert_eq!(container_with(&[]).granted_caps().effective & bit, 0);
    }
}

#[test]
fn a_backing_with_no_open_description_answers_generic_questions_without_aborting() {
    // A backing that is NOT RwLock<OpenDescription> and carries no shadow copy
    // of one. Before this change, asking it a generic question reached
    // the open description resolver, which aborted the process.
    #[derive(Debug)]
    struct BareBacking;

    impl crate::kernel::FileDescriptionBacking for BareBacking {
        fn is_epoll(&self) -> bool {
            false
        }

        fn epoll_targets(&self) -> Option<Vec<std::sync::Arc<crate::kernel::FileDescription>>> {
            None
        }

        fn snapshot_until(
            &self,
            _deadline: std::time::Instant,
        ) -> Option<crate::kernel::FileDescriptionBackingSnapshot> {
            None
        }

        fn readiness(
            &self,
            _description_id: crate::kernel::FileDescriptionId,
            _interest: carrick_abi::LinuxEpollEvents,
            _cx: &dyn crate::kernel::ReadinessContext,
        ) -> carrick_abi::LinuxEpollEvents {
            carrick_abi::LinuxEpollEvents::empty()
        }

        fn as_any(&self) -> &dyn std::any::Any {
            self
        }
    }

    let description = crate::kernel::FileDescription::concrete_with_common(
        std::sync::Arc::new(BareBacking),
        std::sync::Arc::new(crate::kernel::DescriptionCommon::new(
            carrick_abi::LINUX_O_NONBLOCK,
        )),
    )
    .expect("file description identity");

    assert_eq!(
        description.common().status_flags(),
        carrick_abi::LINUX_O_NONBLOCK
    );
    assert_eq!(description.common().fd_refs(), 0);
    assert!(!description.is_epoll());
    assert!(description.open_description().is_none());
    assert!(description.read().is_none());
    assert!(description.write().is_none());

    // Exercise retain_fd_ref() and release_fd_ref() directly on FileDescription,
    // asserting common counts after each and proving default no-op hooks make a third backing valid.
    description.retain_fd_ref();
    assert_eq!(description.common().fd_refs(), 1);
    description.retain_fd_ref();
    assert_eq!(description.common().fd_refs(), 2);
    description.release_fd_ref();
    assert_eq!(description.common().fd_refs(), 1);
    description.release_fd_ref();
    assert_eq!(description.common().fd_refs(), 0);
}

#[test]
fn closing_unpolled_pipe_does_not_materialize_readiness_fds() {
    let dispatcher = SyscallDispatcher::new();
    let pipe = Arc::new(crate::dispatch::fs::PipeInner::new(41, 65536));
    let mut read_base = OpenDescriptionBase::new(LINUX_O_RDONLY);
    read_base.set_pipe_capacity_cell(Arc::clone(&pipe.capacity_cell));
    let mut write_base = OpenDescriptionBase::new(LINUX_O_WRONLY);
    write_base.set_pipe_capacity_cell(Arc::clone(&pipe.capacity_cell));
    let read_file = OpenFile::from_open_description_with_status_flags(
        Arc::new(RwLock::new(OpenDescription::PipeReader {
            base: read_base,
            pipe: Arc::clone(&pipe),
        })),
        LINUX_O_RDONLY,
        0,
    );
    let write_file = OpenFile::from_open_description_with_status_flags(
        Arc::new(RwLock::new(OpenDescription::PipeWriter {
            base: write_base,
            pipe: Arc::clone(&pipe),
        })),
        LINUX_O_WRONLY,
        0,
    );
    let (read_fd, write_fd) = dispatcher
        .install_fd_pair_at_or_above(3, read_file, write_file)
        .expect("install pipe pair");

    assert_eq!(pipe.readiness_pipes_initialized(), (false, false));
    dispatcher.detach_fd_from_epolls(read_fd);
    dispatcher.detach_fd_from_epolls(write_fd);
    assert_eq!(
        pipe.readiness_pipes_initialized(),
        (false, false),
        "closing a pipe that was never polled must not allocate host readiness fds"
    );
}

#[test]
fn pipe_lifecycle_tracks_logical_fd_references_across_dup_and_close() {
    fn poll_fd_readable(fd: i32) -> bool {
        let mut pfd = libc::pollfd {
            fd,
            events: libc::POLLIN,
            revents: 0,
        };
        let rc = unsafe { libc::poll(&mut pfd as *mut _, 1, 0) };
        rc == 1 && pfd.revents & libc::POLLIN != 0
    }

    let parent = SyscallDispatcher::new();
    let pipe = Arc::new(crate::dispatch::fs::PipeInner::new(42, 65536));
    let mut read_base = OpenDescriptionBase::new(LINUX_O_RDONLY);
    read_base.set_pipe_capacity_cell(Arc::clone(&pipe.capacity_cell));
    let mut write_base = OpenDescriptionBase::new(LINUX_O_WRONLY);
    write_base.set_pipe_capacity_cell(Arc::clone(&pipe.capacity_cell));

    let read_desc = Arc::new(RwLock::new(OpenDescription::PipeReader {
        base: read_base,
        pipe: Arc::clone(&pipe),
    }));
    let write_desc = Arc::new(RwLock::new(OpenDescription::PipeWriter {
        base: write_base,
        pipe: Arc::clone(&pipe),
    }));

    let read_file = OpenFile::from_open_description_with_status_flags(
        Arc::clone(&read_desc),
        LINUX_O_RDONLY,
        0,
    );
    let write_file = OpenFile::from_open_description_with_status_flags(
        Arc::clone(&write_desc),
        LINUX_O_WRONLY,
        0,
    );

    let (read_fd, write_fd) = parent
        .install_fd_pair_at_or_above(3, read_file, write_file)
        .expect("install pipe pair");

    let read_description = parent.open_file(read_fd).expect("read file").description();
    let write_description = parent
        .open_file(write_fd)
        .expect("write file")
        .description();

    let read_poll_fd = pipe.read_poll_fd().expect("read poll fd").raw();
    let write_poll_fd = pipe.write_poll_fd().expect("write poll fd").raw();

    // 1. Initial installation activates exactly one reader/writer endpoint and readiness state.
    assert_eq!(read_description.common().fd_refs(), 1);
    assert_eq!(write_description.common().fd_refs(), 1);
    {
        let state = pipe.state.lock();
        assert_eq!(state.readers, 1);
        assert_eq!(state.writers, 1);
    }
    // Pipe has active writer and empty buffer: not readable, but is writable.
    assert!(
        !poll_fd_readable(read_poll_fd),
        "an empty pipe with an active writer must not be read-ready"
    );
    assert!(
        poll_fd_readable(write_poll_fd),
        "an empty pipe with an active reader must be write-ready"
    );

    // 2. Real in-process fork path increments DescriptionCommon fd_refs
    // without duplicating backing pipe endpoints or perturbing readiness.
    let parent_tid = crate::thread::ThreadId::synthetic_for_tests(6000);
    let child_tid = crate::thread::ThreadId::synthetic_for_tests(6001);
    let (child, _) =
        hvpatch_in_process_fork_tests::fork_dispatcher(&parent, parent_tid, child_tid, 71, 72);

    assert_eq!(read_description.common().fd_refs(), 2);
    assert_eq!(write_description.common().fd_refs(), 2);
    {
        let state = pipe.state.lock();
        assert_eq!(
            state.readers, 1,
            "fork copy must not increment backing reader endpoint count"
        );
        assert_eq!(
            state.writers, 1,
            "fork copy must not increment backing writer endpoint count"
        );
    }
    assert!(
        !poll_fd_readable(read_poll_fd),
        "fork copy must not publish EOF/read readiness"
    );

    // 3. Intermediate close of the write end (in parent) decrements logical ref to 1
    // but retains the backing endpoint (writers=1) and does NOT publish EOF or wake readers.
    parent.close_fd_for_internal_rollback(write_fd);
    assert_eq!(write_description.common().fd_refs(), 1);
    {
        let state = pipe.state.lock();
        assert_eq!(
            state.writers, 1,
            "intermediate close must retain backing writer count"
        );
        assert!(
            matches!(&*write_desc.read(), OpenDescription::PipeWriter { .. }),
            "intermediate close must not close the OpenDescription backing"
        );
    }
    assert!(
        !poll_fd_readable(read_poll_fd),
        "intermediate close of write end must not publish EOF to readers"
    );

    // 4. Final release of the write end (in child) drops logical ref to 0, decrements
    // backing endpoint (writers=0), publishes EOF to readers, and transitions backing to Closed.
    child.close_fd_for_internal_rollback(write_fd);
    assert_eq!(write_description.common().fd_refs(), 0);
    {
        let state = pipe.state.lock();
        assert_eq!(
            state.writers, 0,
            "final release must decrement backing writer count to 0"
        );
        assert!(
            matches!(&*write_desc.read(), OpenDescription::Closed { .. }),
            "final release must transition OpenDescription to Closed"
        );
    }
    assert!(
        poll_fd_readable(read_poll_fd),
        "final release of last writer must publish EOF / wake readers"
    );

    // 5. Intermediate close of read end (in parent) retains reader endpoint (readers=1).
    parent.close_fd_for_internal_rollback(read_fd);
    assert_eq!(read_description.common().fd_refs(), 1);
    {
        let state = pipe.state.lock();
        assert_eq!(
            state.readers, 1,
            "intermediate close must retain backing reader count"
        );
        assert!(
            matches!(&*read_desc.read(), OpenDescription::PipeReader { .. }),
            "intermediate close must not close reader OpenDescription backing"
        );
    }

    // 6. Final release of read end (in child) drops logical ref to 0, decrements readers=0,
    // and transitions OpenDescription to Closed.
    child.close_fd_for_internal_rollback(read_fd);
    assert_eq!(read_description.common().fd_refs(), 0);
    {
        let state = pipe.state.lock();
        assert_eq!(
            state.readers, 0,
            "final release must decrement backing reader count to 0"
        );
        assert!(
            matches!(&*read_desc.read(), OpenDescription::Closed { .. }),
            "final release must transition reader OpenDescription to Closed"
        );
    }
}

#[cfg(test)]
mod scm_rights_tests {
    //! `SCM_RIGHTS` must carry EVERY guest fd, not only the host-backed ones.
    //!
    //! Guest pipes are carrick-owned (`PipeReader`/`PipeWriter` over a
    //! `PipeInner`, no host fd), so the multiprocessing forkserver's
    //! `sendfds(os.pipe())` handoff answered EBADF and every forkserver test
    //! errored. Linux passes any fd: the receiver gets a NEW fd sharing the
    //! SAME open file description. Driven through the public `dispatch`
    //! entry point with aarch64 syscall numbers, exactly as the guest does.
    use super::*;
    use crate::compat::CompatReporter;
    use carrick_abi::{LINUX_SCM_RIGHTS, LINUX_SOL_SOCKET};

    const SYS_CLOSE: u64 = 57;
    const SYS_PIPE2: u64 = 59;
    const SYS_READ: u64 = 63;
    const SYS_WRITE: u64 = 64;
    const SYS_SOCKETPAIR: u64 = 199;
    const SYS_SENDMSG: u64 = 211;
    const SYS_RECVMSG: u64 = 212;
    const MEM_BASE: u64 = 0x4000_0000;
    const MEM_LEN: usize = 0x4000;
    const AF_UNIX: u64 = 1;
    const SOCK_STREAM: u64 = 1;
    const O_NONBLOCK: u64 = 0o4000;
    /// Scratch layout inside the 16 KiB guest window.
    const SV: u64 = MEM_BASE;
    const PIPEFD: u64 = MEM_BASE + 0x10;
    const MSGHDR: u64 = MEM_BASE + 0x100;
    const IOV: u64 = MEM_BASE + 0x200;
    const PAYLOAD: u64 = MEM_BASE + 0x300;
    const CONTROL: u64 = MEM_BASE + 0x400;
    const DATA: u64 = MEM_BASE + 0x800;
    const CONTROL_CAP: u64 = 64;

    struct Guest {
        dispatcher: SyscallDispatcher,
        reporter: CompatReporter,
        mem: LinearMemory,
    }

    impl Guest {
        fn new() -> Self {
            Self {
                dispatcher: SyscallDispatcher::new(),
                reporter: CompatReporter::default(),
                mem: LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]),
            }
        }

        fn call(&mut self, nr: u64, args: [u64; 6]) -> DispatchOutcome {
            let kernel = self.dispatcher.capture_one_task_context().unwrap();
            self.dispatcher
                .dispatch(
                    &kernel,
                    SyscallRequest::new(nr, SyscallArgs(args)),
                    &mut self.mem,
                    &self.reporter,
                )
                .expect("dispatch")
        }

        fn ok(&mut self, nr: u64, args: [u64; 6]) -> i64 {
            match self.call(nr, args) {
                DispatchOutcome::Returned { value } => value,
                other => panic!("syscall {nr} failed: {other:?}"),
            }
        }

        fn u32_at(&self, addr: u64) -> i32 {
            let bytes = self.mem.read_bytes(addr, 4).unwrap();
            i32::from_ne_bytes([bytes[0], bytes[1], bytes[2], bytes[3]])
        }

        /// Write a Linux-layout `msghdr` with one iovec over `PAYLOAD` and
        /// an `SCM_RIGHTS` cmsg carrying `fds` (empty → no control).
        fn write_msghdr(&mut self, payload: &[u8], fds: &[i32], controllen: u64) {
            self.mem.write_bytes(PAYLOAD, payload).unwrap();
            let mut iov = Vec::new();
            iov.extend_from_slice(&PAYLOAD.to_ne_bytes());
            iov.extend_from_slice(&(payload.len() as u64).to_ne_bytes());
            self.mem.write_bytes(IOV, &iov).unwrap();
            if !fds.is_empty() {
                let mut cmsg = Vec::new();
                cmsg.extend_from_slice(&((16 + 4 * fds.len()) as u64).to_ne_bytes());
                cmsg.extend_from_slice(&LINUX_SOL_SOCKET.to_ne_bytes());
                cmsg.extend_from_slice(&LINUX_SCM_RIGHTS.to_ne_bytes());
                for fd in fds {
                    cmsg.extend_from_slice(&fd.to_ne_bytes());
                }
                while cmsg.len() % 8 != 0 {
                    cmsg.push(0);
                }
                self.mem.write_bytes(CONTROL, &cmsg).unwrap();
            }
            let mut hdr = Vec::new();
            hdr.extend_from_slice(&0u64.to_ne_bytes()); // name
            hdr.extend_from_slice(&0u64.to_ne_bytes()); // namelen + pad
            hdr.extend_from_slice(&IOV.to_ne_bytes());
            hdr.extend_from_slice(&1u64.to_ne_bytes());
            hdr.extend_from_slice(&CONTROL.to_ne_bytes());
            hdr.extend_from_slice(&controllen.to_ne_bytes());
            hdr.extend_from_slice(&0u64.to_ne_bytes()); // flags + pad
            self.mem.write_bytes(MSGHDR, &hdr).unwrap();
        }

        fn received_fds(&self) -> Vec<i32> {
            let controllen = u64::from_ne_bytes(
                self.mem
                    .read_bytes(MSGHDR + 40, 8)
                    .unwrap()
                    .try_into()
                    .unwrap(),
            );
            let control = self.mem.read_bytes(CONTROL, controllen as usize).unwrap();
            super::net::support::parse_linux_scm_rights_fds(&control)
        }
    }

    #[test]
    fn carrick_owned_pipe_ends_cross_scm_rights_as_shared_descriptions() {
        let mut g = Guest::new();
        assert_eq!(g.ok(SYS_SOCKETPAIR, [AF_UNIX, SOCK_STREAM, 0, SV, 0, 0]), 0);
        let (sock_a, sock_b) = (g.u32_at(SV), g.u32_at(SV + 4));
        assert_eq!(g.ok(SYS_PIPE2, [PIPEFD, O_NONBLOCK, 0, 0, 0, 0]), 0);
        let (pipe_r, pipe_w) = (g.u32_at(PIPEFD), g.u32_at(PIPEFD + 4));

        g.write_msghdr(b"x", &[pipe_r, pipe_w], 24);
        assert_eq!(
            g.ok(SYS_SENDMSG, [sock_a as u64, MSGHDR, 0, 0, 0, 0]),
            1,
            "sendmsg(SCM_RIGHTS) of carrick-owned pipe ends must succeed"
        );

        g.write_msghdr(b"\0", &[], CONTROL_CAP);
        assert_eq!(g.ok(SYS_RECVMSG, [sock_b as u64, MSGHDR, 0, 0, 0, 0]), 1);
        let got = g.received_fds();
        assert_eq!(got.len(), 2, "two fds must arrive, got {got:?}");
        let (recv_r, recv_w) = (got[0], got[1]);
        assert!(
            recv_r != pipe_r && recv_w != pipe_w,
            "received fds are NEW fds"
        );

        // The received ends share the pipe with the originals in both
        // directions: write through the received writer, read from the
        // original reader, and vice versa.
        g.mem.write_bytes(DATA, b"hello").unwrap();
        assert_eq!(g.ok(SYS_WRITE, [recv_w as u64, DATA, 5, 0, 0, 0]), 5);
        assert_eq!(
            g.ok(SYS_READ, [pipe_r as u64, DATA + 0x100, 16, 0, 0, 0]),
            5
        );
        assert_eq!(&g.mem.read_bytes(DATA + 0x100, 5).unwrap(), b"hello");
        g.mem.write_bytes(DATA, b"world").unwrap();
        assert_eq!(g.ok(SYS_WRITE, [pipe_w as u64, DATA, 5, 0, 0, 0]), 5);
        assert_eq!(
            g.ok(SYS_READ, [recv_r as u64, DATA + 0x100, 16, 0, 0, 0]),
            5
        );
        assert_eq!(&g.mem.read_bytes(DATA + 0x100, 5).unwrap(), b"world");

        // Closing the ORIGINAL writer must not EOF the pipe while the
        // received writer is still open (the description is shared, so its
        // writer count is 1 until the last reference goes).
        assert_eq!(g.ok(SYS_CLOSE, [pipe_w as u64, 0, 0, 0, 0, 0]), 0);
        assert_eq!(
            g.call(SYS_READ, [recv_r as u64, DATA, 16, 0, 0, 0]),
            DispatchOutcome::errno(carrick_abi::LINUX_EAGAIN),
            "a shared writer keeps the pipe open"
        );
        assert_eq!(g.ok(SYS_CLOSE, [recv_w as u64, 0, 0, 0, 0, 0]), 0);
        assert_eq!(
            g.ok(SYS_READ, [recv_r as u64, DATA, 16, 0, 0, 0]),
            0,
            "last writer gone → EOF"
        );
    }

    #[test]
    fn a_host_backed_file_crosses_scm_rights_as_the_same_description() {
        // A host-backed regular file (anything under `--fs host`, /dev/shm,
        // /tmp) is what multiprocessing's `Arena` passes to the forkserver
        // child, which then `mmap`s it PROT_WRITE|MAP_SHARED. Linux hands the
        // receiver the SAME open file description: identical status flags
        // (O_RDWR), identical path, writable. Re-wrapping the raw host fd as a
        // fresh read-only description made that mmap EACCES.
        use crate::dispatch::fd_table::{HostFdRef, OpenDescriptionBase, OpenFile};
        use carrick_abi::LINUX_O_RDWR;
        use carrick_vfs::rootfs::{RootFsEntryKind, RootFsMetadata};
        use std::os::fd::IntoRawFd;
        const SYS_FCNTL: u64 = 25;
        const SYS_READLINKAT: u64 = 78;
        const F_GETFL: u64 = 3;
        const AT_FDCWD: u64 = (-100i64) as u64;

        let mut g = Guest::new();
        assert_eq!(g.ok(SYS_SOCKETPAIR, [AF_UNIX, SOCK_STREAM, 0, SV, 0, 0]), 0);
        let (sock_a, sock_b) = (g.u32_at(SV), g.u32_at(SV + 4));
        let host_fd = tempfile::tempfile().expect("tempfile").into_raw_fd();
        let description = super::fd_table::kernel_file_description(
            Arc::new(RwLock::new(OpenDescription::HostFile {
                base: OpenDescriptionBase::new(LINUX_O_RDWR),
                host_fd: HostFdRef::new(host_fd),
                metadata: RootFsMetadata {
                    path: std::path::PathBuf::from("/tmp/arena"),
                    kind: RootFsEntryKind::File,
                    mode: 0o600,
                    size: 0,
                },
                writable: true,
            })),
            LINUX_O_RDWR,
        );
        let file_fd = g
            .dispatcher
            .install_fd_at_or_above(3, OpenFile::new(description, 0))
            .expect("install");

        g.write_msghdr(b"x", &[file_fd], 20);
        assert_eq!(g.ok(SYS_SENDMSG, [sock_a as u64, MSGHDR, 0, 0, 0, 0]), 1);
        g.write_msghdr(b"\0", &[], CONTROL_CAP);
        assert_eq!(g.ok(SYS_RECVMSG, [sock_b as u64, MSGHDR, 0, 0, 0, 0]), 1);
        let got = g.received_fds();
        assert_eq!(got.len(), 1, "one fd must arrive, got {got:?}");
        let recv_fd = got[0];
        assert_ne!(recv_fd, file_fd);

        let orig_flags = g.ok(SYS_FCNTL, [file_fd as u64, F_GETFL, 0, 0, 0, 0]);
        let recv_flags = g.ok(SYS_FCNTL, [recv_fd as u64, F_GETFL, 0, 0, 0, 0]);
        assert_eq!(
            recv_flags, orig_flags,
            "the received fd shares the description's status flags"
        );
        assert_eq!(recv_flags & 0o3, LINUX_O_RDWR as i64);
        g.mem.write_bytes(DATA, b"hello").unwrap();
        assert_eq!(
            g.ok(SYS_WRITE, [recv_fd as u64, DATA, 5, 0, 0, 0]),
            5,
            "the received fd is writable"
        );

        // `/proc/self/fd/N` resolves to the file's path, not a placeholder.
        let link = format!("/proc/self/fd/{recv_fd}\0");
        g.mem.write_bytes(DATA, link.as_bytes()).unwrap();
        let n = g.ok(SYS_READLINKAT, [AT_FDCWD, DATA, DATA + 0x100, 64, 0, 0]);
        assert_eq!(
            g.mem.read_bytes(DATA + 0x100, n as usize).unwrap(),
            b"/tmp/arena"
        );
    }

    #[test]
    fn unread_in_flight_rights_are_released_when_the_receiver_never_reads() {
        // Linux GC's in-flight fds: a passed pipe writer whose message is
        // never received must not keep the pipe open forever. Send the writer,
        // close both the sender's copy and the receiving socket (dropping the
        // in-flight message), and the reader must see EOF.
        let mut g = Guest::new();
        assert_eq!(g.ok(SYS_SOCKETPAIR, [AF_UNIX, SOCK_STREAM, 0, SV, 0, 0]), 0);
        let (sock_a, sock_b) = (g.u32_at(SV), g.u32_at(SV + 4));
        assert_eq!(g.ok(SYS_PIPE2, [PIPEFD, O_NONBLOCK, 0, 0, 0, 0]), 0);
        let (pipe_r, pipe_w) = (g.u32_at(PIPEFD), g.u32_at(PIPEFD + 4));
        g.write_msghdr(b"x", &[pipe_w], 20);
        assert_eq!(g.ok(SYS_SENDMSG, [sock_a as u64, MSGHDR, 0, 0, 0, 0]), 1);
        assert_eq!(g.ok(SYS_CLOSE, [pipe_w as u64, 0, 0, 0, 0, 0]), 0);
        assert_eq!(g.ok(SYS_CLOSE, [sock_b as u64, 0, 0, 0, 0, 0]), 0);
        assert_eq!(g.ok(SYS_CLOSE, [sock_a as u64, 0, 0, 0, 0, 0]), 0);
        assert_eq!(
            g.ok(SYS_READ, [pipe_r as u64, DATA, 16, 0, 0, 0]),
            0,
            "the in-flight writer must be collected once nothing can receive it"
        );
    }

    #[test]
    fn fd_wait_outcomes_pin_poll_select_and_plain_wait_for_same_fd_set() {
        const SYS_PSELECT6: u64 = 72;
        const SYS_PPOLL: u64 = 73;

        let mut g = Guest::new();
        assert_eq!(g.ok(SYS_PIPE2, [PIPEFD, 0, 0, 0, 0, 0]), 0);
        let (pipe_r, pipe_w) = (g.u32_at(PIPEFD), g.u32_at(PIPEFD + 4));

        let timeout_addr = MEM_BASE + 0x500;
        let timespec: [u64; 2] = [0, 50_000_000]; // 50ms
        g.mem
            .write_bytes(timeout_addr, zerocopy::IntoBytes::as_bytes(&timespec))
            .unwrap();

        // 1. Plain fd wait: read from empty blocking pipe
        let read_outcome = g.call(SYS_READ, [pipe_r as u64, DATA, 16, 0, 0, 0]);
        match &read_outcome {
            DispatchOutcome::WaitOnFds {
                fds,
                timeout,
                completion,
                ..
            } => {
                assert!(!fds.is_empty(), "plain wait must contain host poll target");
                assert_eq!(*timeout, None);
                assert_eq!(
                    *completion,
                    FdWaitCompletion::Fd {
                        on_timeout: carrick_abi::LINUX_EAGAIN.guest_retval()
                    }
                );
            }
            other => panic!("expected WaitOnFds for empty pipe read, got {other:?}"),
        }

        // 2. Poll: ppoll on the same pipe_r for POLLIN (host pipe -> WaitOnFds with Fd completion on_timeout: 0)
        let pollfd_addr = MEM_BASE + 0x520;
        let mut pfd = [0u8; 8];
        pfd[0..4].copy_from_slice(&pipe_r.to_ne_bytes());
        pfd[4..6].copy_from_slice(&libc::POLLIN.to_ne_bytes());
        g.mem.write_bytes(pollfd_addr, &pfd).unwrap();

        let poll_outcome = g.call(SYS_PPOLL, [pollfd_addr, 1, timeout_addr, 0, 0, 0]);
        match &poll_outcome {
            DispatchOutcome::WaitOnFds {
                fds,
                timeout,
                completion,
                ..
            } => {
                assert!(!fds.is_empty(), "ppoll must contain host poll target");
                assert_eq!(*timeout, Some(Duration::from_millis(50)));
                assert_eq!(*completion, FdWaitCompletion::Fd { on_timeout: 0 });
            }
            other => panic!("expected WaitOnFds for host ppoll, got {other:?}"),
        }

        // 3. Select: pselect6 on the same pipe_r in readfds
        let readfds_addr = MEM_BASE + 0x540;
        let mut fdset = [0u8; 128];
        fdset[(pipe_r / 8) as usize] |= 1 << (pipe_r % 8);
        g.mem.write_bytes(readfds_addr, &fdset).unwrap();

        let select_outcome = g.call(
            SYS_PSELECT6,
            [pipe_r as u64 + 1, readfds_addr, 0, 0, timeout_addr, 0],
        );
        match &select_outcome {
            DispatchOutcome::WaitOnFds {
                fds,
                timeout,
                completion: FdWaitCompletion::Select { clear_on_timeout },
                ..
            } => {
                assert!(!fds.is_empty(), "pselect6 must contain host poll target");
                assert_eq!(*timeout, Some(Duration::from_millis(50)));
                assert_eq!(clear_on_timeout.len(), 1);
                assert_eq!(clear_on_timeout[0].0, readfds_addr);
                // On timeout, select zeroes the fd_set:
                for (addr, len) in clear_on_timeout {
                    g.mem.write_bytes(*addr, &vec![0u8; *len]).unwrap();
                }
                assert_eq!(g.mem.read_bytes(readfds_addr, 128).unwrap(), vec![0u8; 128]);
            }
            other => panic!("expected WaitOnFds for pselect6, got {other:?}"),
        }

        // 4. Polling wait: epoll_pwait on epfd watching pipe_r yields WaitOnFds with Poll completion
        const SYS_EPOLL_CREATE1: u64 = 20;
        const SYS_EPOLL_CTL: u64 = 21;
        const SYS_EPOLL_PWAIT: u64 = 22;
        let epfd = g.ok(SYS_EPOLL_CREATE1, [0, 0, 0, 0, 0, 0]) as i32;
        let event_addr = MEM_BASE + 0x600;
        let mut epoll_ev = [0u8; 16];
        epoll_ev[0..4].copy_from_slice(&(carrick_abi::LINUX_EPOLLIN as u32).to_le_bytes());
        g.mem.write_bytes(event_addr, &epoll_ev).unwrap();
        assert_eq!(
            g.ok(
                SYS_EPOLL_CTL,
                [
                    epfd as u64,
                    carrick_abi::LINUX_EPOLL_CTL_ADD,
                    pipe_r as u64,
                    event_addr,
                    0,
                    0
                ]
            ),
            0
        );

        let events_out = MEM_BASE + 0x620;
        let epoll_outcome = g.call(SYS_EPOLL_PWAIT, [epfd as u64, events_out, 1, 50, 0, 0]);
        match &epoll_outcome {
            DispatchOutcome::WaitOnFds {
                fds,
                timeout,
                completion: FdWaitCompletion::Poll { on_timeout },
                ..
            } => {
                assert!(!fds.is_empty(), "poll wait must contain poll target");
                assert_eq!(*timeout, Some(Duration::from_millis(50)));
                assert_eq!(*on_timeout, 0);
            }
            other => panic!("expected WaitOnFds for epoll_pwait, got {other:?}"),
        }

        assert_eq!(g.ok(SYS_CLOSE, [epfd as u64, 0, 0, 0, 0, 0]), 0);

        assert_eq!(g.ok(SYS_CLOSE, [pipe_r as u64, 0, 0, 0, 0, 0]), 0);
        assert_eq!(g.ok(SYS_CLOSE, [pipe_w as u64, 0, 0, 0, 0, 0]), 0);
    }

    #[test]
    fn update_fs_umask_typed_error_on_exited_task() {
        let dispatcher = SyscallDispatcher::new();
        let cx = dispatcher.capture_one_task_context().unwrap();

        // Calling update_fs_umask on active task succeeds.
        let _ = dispatcher.update_fs_umask(&cx, 0o027).unwrap();
        assert_eq!(dispatcher.update_fs_umask(&cx, 0o022).unwrap(), 0o027);

        // Terminate the task in the kernel.
        let _ = cx
            .kernel()
            .exit_task(
                cx.task().key().id,
                crate::kernel::LinuxWaitStatus::from_wait_encoding(0),
                None,
            )
            .unwrap();

        // Calling update_fs_umask on an exited task returns Err(ParentExited) rather than aborting.
        let err = dispatcher.update_fs_umask(&cx, 0o022).unwrap_err();
        assert!(matches!(
            err,
            crate::kernel::KernelOperationError::ParentExited
        ));
    }

    #[test]
    fn file_slot_from_open_description_with_common_preserves_common() {
        let state = Arc::new(EventFdState::new(0));
        let desc = Arc::new(RwLock::new(OpenDescription::EventFd {
            state,
            semaphore: false,
            base: OpenDescriptionBase::new(0),
        }));
        let common = Arc::new(crate::kernel::DescriptionCommon::new(0));
        let slot = crate::kernel::FileSlot::from_open_description_with_common(
            desc,
            Arc::clone(&common),
            42,
        );
        assert_eq!(slot.fd_flags, 42);
        assert!(std::ptr::eq(slot.description.common(), &*common));
    }
}

#[cfg(test)]
mod inzone_tcp {
    use super::*;
    use crate::compat::CompatReporter;
    use carrick_abi::{
        LINUX_AF_INET, LINUX_AF_UNSPEC, LINUX_ECONNRESET, LINUX_EFAULT, LINUX_EINVAL,
        LINUX_EISCONN, LINUX_ENOTSOCK, LINUX_MSG_OOB, LINUX_POLLIN, LINUX_SO_ERROR,
        LINUX_SOCK_STREAM, LINUX_SOL_SOCKET,
    };

    const POLLPRI: i16 = 2;

    const SYS_CLOSE: u64 = 57;
    const SYS_PIPE2: u64 = 59;
    const SYS_READ: u64 = 63;
    const SYS_WRITE: u64 = 64;
    const SYS_SPLICE: u64 = 76;
    const SYS_SOCKET: u64 = 198;
    const SYS_BIND: u64 = 200;
    const SYS_LISTEN: u64 = 201;
    const SYS_ACCEPT: u64 = 202;
    const SYS_CONNECT: u64 = 203;
    const SYS_GETSOCKNAME: u64 = 204;
    const SYS_GETPEERNAME: u64 = 205;
    const SYS_GETSOCKOPT: u64 = 209;

    const MEM_BASE: u64 = 0x4000_0000;
    const MEM_LEN: usize = 0x4000;
    const ADDR_SCRATCH: u64 = MEM_BASE;
    const ADDRLEN_SCRATCH: u64 = MEM_BASE + 0x40;
    const DATA_SCRATCH: u64 = MEM_BASE + 0x100;

    struct InZoneGuest {
        dispatcher: SyscallDispatcher,
        reporter: CompatReporter,
        mem: LinearMemory,
    }

    impl InZoneGuest {
        fn new() -> Self {
            Self {
                dispatcher: SyscallDispatcher::new(),
                reporter: CompatReporter::default(),
                mem: LinearMemory::new(MEM_BASE, vec![0u8; MEM_LEN]),
            }
        }

        fn call(&mut self, nr: u64, args: [u64; 6]) -> DispatchOutcome {
            let kernel = self.dispatcher.capture_one_task_context().unwrap();
            self.dispatcher
                .dispatch(
                    &kernel,
                    SyscallRequest::new(nr, SyscallArgs(args)),
                    &mut self.mem,
                    &self.reporter,
                )
                .expect("dispatch")
        }

        fn ok(&mut self, nr: u64, args: [u64; 6]) -> i64 {
            match self.call(nr, args) {
                DispatchOutcome::Returned { value } => value,
                other => panic!("syscall {nr} failed: {other:?}"),
            }
        }

        fn make_sockaddr_in(&mut self, addr: u64, port: u16, ip: [u8; 4]) {
            let mut sa = Vec::with_capacity(16);
            sa.extend_from_slice(&(LINUX_AF_INET as u16).to_ne_bytes());
            sa.extend_from_slice(&port.to_be_bytes());
            sa.extend_from_slice(&ip);
            sa.extend_from_slice(&[0u8; 8]);
            self.mem.write_bytes(addr, &sa).unwrap();
        }

        fn read_sockaddr_in(&self, addr: u64) -> (u16, [u8; 4]) {
            let bytes = self.mem.read_bytes(addr, 16).unwrap();
            let port = u16::from_be_bytes([bytes[2], bytes[3]]);
            let ip = [bytes[4], bytes[5], bytes[6], bytes[7]];
            (port, ip)
        }
    }

    #[test]
    fn connect_accept_pairs_in_zone_with_no_host_accept() {
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        assert!(listen_fd >= 3);

        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);

        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);
        assert_ne!(port, 0);

        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        assert!(client_fd >= 3);

        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );

        // Client must be replaced with InMemorySocket
        let client_of = g.dispatcher.open_file(client_fd).unwrap();
        let client_desc = client_of.description();
        let client_guard = client_desc.read().unwrap();
        assert!(
            matches!(&*client_guard, OpenDescription::InMemorySocket { .. }),
            "client description must be InMemorySocket"
        );
        drop(client_guard);

        // Accept connection
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        let accepted_fd = g.ok(
            SYS_ACCEPT,
            [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
        ) as i32;
        assert!(accepted_fd >= 3);

        let accepted_of = g.dispatcher.open_file(accepted_fd).unwrap();
        let accepted_desc = accepted_of.description();
        let accepted_guard = accepted_desc.read().unwrap();
        assert!(
            matches!(&*accepted_guard, OpenDescription::InMemorySocket { .. }),
            "accepted description must be InMemorySocket"
        );
        drop(accepted_guard);

        // A connected in-zone stream is still a socket. Linux validates the
        // supplied sockaddr before reporting EISCONN, and both the connecting
        // and accepted halves report EISCONN for a valid reconnect attempt.
        assert_eq!(
            g.call(SYS_CONNECT, [client_fd as u64, 1, 16, 0, 0, 0]),
            DispatchOutcome::errno(LINUX_EFAULT)
        );
        assert_eq!(
            g.call(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 1, 0, 0, 0]),
            DispatchOutcome::errno(LINUX_EINVAL)
        );
        assert_eq!(
            g.call(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            DispatchOutcome::errno(LINUX_EISCONN)
        );
        assert_eq!(
            g.call(SYS_CONNECT, [accepted_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            DispatchOutcome::errno(LINUX_EISCONN)
        );
        // Data round trip
        g.mem.write_bytes(DATA_SCRATCH, b"hello in-zone").unwrap();
        assert_eq!(
            g.ok(SYS_WRITE, [client_fd as u64, DATA_SCRATCH, 13, 0, 0, 0]),
            13
        );
        let read_scratch = DATA_SCRATCH + 0x50;
        assert_eq!(
            g.ok(SYS_READ, [accepted_fd as u64, read_scratch, 64, 0, 0, 0]),
            13
        );
        assert_eq!(
            &g.mem.read_bytes(read_scratch, 13).unwrap(),
            b"hello in-zone"
        );

        // getpeername(accepted) == getsockname(client)
        let addr_accepted_peer = ADDR_SCRATCH;
        let len_accepted_peer = ADDRLEN_SCRATCH;
        g.mem
            .write_bytes(len_accepted_peer, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETPEERNAME,
                [
                    accepted_fd as u64,
                    addr_accepted_peer,
                    len_accepted_peer,
                    0,
                    0,
                    0,
                ],
            ),
            0
        );
        let (peer_port, peer_ip) = g.read_sockaddr_in(addr_accepted_peer);

        let addr_client_local = ADDR_SCRATCH + 0x20;
        let len_client_local = ADDRLEN_SCRATCH + 0x10;
        g.mem
            .write_bytes(len_client_local, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [
                    client_fd as u64,
                    addr_client_local,
                    len_client_local,
                    0,
                    0,
                    0,
                ],
            ),
            0
        );
        let (client_port, client_ip) = g.read_sockaddr_in(addr_client_local);

        assert_eq!((peer_port, peer_ip), (client_port, client_ip));

        // Host socket must have had no host accept performed
        let listen_of = g.dispatcher.open_file(listen_fd).unwrap();
        let listen_desc = listen_of.description();
        let listen_guard = listen_desc.read().unwrap();
        if let OpenDescription::HostSocket { host_fd, .. } = &*listen_guard {
            let mut pfd = libc::pollfd {
                fd: host_fd.raw(),
                events: libc::POLLIN,
                revents: 0,
            };
            let rc = unsafe { libc::poll(&mut pfd, 1, 0) };
            assert_eq!(
                rc, 0,
                "host listener must have no connections on host queue"
            );
        }
        drop(listen_guard);

        // AF_UNSPEC explicitly resets an in-zone TCP association while retaining
        // the local endpoint and open-description identity for reconnect.
        let description_before_disconnect = Arc::clone(&client_desc);
        g.mem.write_bytes(DATA_SCRATCH, b"queued").unwrap();
        assert_eq!(
            g.ok(SYS_WRITE, [client_fd as u64, DATA_SCRATCH, 6, 0, 0, 0]),
            6
        );
        g.mem
            .write_bytes(ADDR_SCRATCH, &(LINUX_AF_UNSPEC as u16).to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.call(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            DispatchOutcome::Returned { value: 0 }
        );
        assert!(Arc::ptr_eq(
            &description_before_disconnect,
            &g.dispatcher.open_file(client_fd).unwrap().description()
        ));
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.call(
                SYS_GETPEERNAME,
                [client_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0]
            ),
            DispatchOutcome::errno(carrick_abi::LINUX_ENOTCONN)
        );
        assert_eq!(
            g.ok(SYS_READ, [accepted_fd as u64, DATA_SCRATCH, 6, 0, 0, 0]),
            6
        );
        assert_eq!(&g.mem.read_bytes(DATA_SCRATCH, 6).unwrap(), b"queued");
        assert_eq!(
            g.call(SYS_READ, [accepted_fd as u64, DATA_SCRATCH, 1, 0, 0, 0]),
            DispatchOutcome::errno(LINUX_ECONNRESET)
        );
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [client_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0]
            ),
            0
        );
        assert_eq!(g.read_sockaddr_in(ADDR_SCRATCH).0, client_port);
        g.make_sockaddr_in(ADDR_SCRATCH, 1, [127, 0, 0, 1]);
        assert_eq!(
            g.call(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            DispatchOutcome::errno(LINUX_ENOTSOCK)
        );
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.call(
                SYS_GETPEERNAME,
                [client_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0]
            ),
            DispatchOutcome::errno(carrick_abi::LINUX_ENOTCONN)
        );
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [client_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0]
            ),
            0
        );
        assert_eq!(g.read_sockaddr_in(ADDR_SCRATCH).0, client_port);
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        let reaccepted_fd = g.ok(SYS_ACCEPT, [listen_fd as u64, 0, 0, 0, 0, 0]) as i32;
        assert_eq!(g.ok(SYS_CLOSE, [accepted_fd as u64, 0, 0, 0, 0, 0]), 0);
        g.mem.write_bytes(DATA_SCRATCH, b"r").unwrap();
        assert_eq!(
            g.ok(SYS_WRITE, [client_fd as u64, DATA_SCRATCH, 1, 0, 0, 0]),
            1
        );
        assert_eq!(
            g.ok(
                SYS_READ,
                [reaccepted_fd as u64, DATA_SCRATCH + 1, 1, 0, 0, 0]
            ),
            1
        );
    }

    #[test]
    fn readiness_agrees_when_one_connection_is_queued() {
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;

        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);

        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

        // Before connect: no POLLIN
        let poll_revents = g.dispatcher.poll_ready_events(listen_fd, LINUX_POLLIN);
        assert_eq!(poll_revents & LINUX_POLLIN, 0);
        let epoll_revents = g
            .dispatcher
            .epoll_ready_events(listen_fd, carrick_abi::LINUX_EPOLLIN);
        assert_eq!(epoll_revents & carrick_abi::LINUX_EPOLLIN, 0);

        // Connect client
        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );

        // With one queued in-zone connection: both poll and readiness report readable
        let poll_revents_after = g.dispatcher.poll_ready_events(listen_fd, LINUX_POLLIN);
        let epoll_revents_after = g
            .dispatcher
            .epoll_ready_events(listen_fd, carrick_abi::LINUX_EPOLLIN);
        assert_ne!(
            poll_revents_after & LINUX_POLLIN,
            0,
            "poll_ready_events must report POLLIN"
        );
        assert_ne!(
            epoll_revents_after & carrick_abi::LINUX_EPOLLIN,
            0,
            "epoll_ready_events must report EPOLLIN"
        );
    }

    /// A guest that blocks in `poll(2)` on its listener (the probe's case 2,
    /// Go's `net/http` accept loop under poll(2), any C server)
    /// must see POLLIN for a connection that was paired in-zone. The all-host
    /// fast path of `ppoll` used to take readiness from the host `poll(0)`
    /// alone, which never learns about an in-memory pairing.
    #[test]
    fn poll_on_listener_reports_in_zone_queued_connection() {
        const SYS_PPOLL: u64 = 73;
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

        // pollfd { fd, events: POLLIN, revents: 0 }, timeout 0 (a probe, never a wait).
        let pollfd_addr = DATA_SCRATCH;
        let mut pollfd = Vec::with_capacity(8);
        pollfd.extend_from_slice(&listen_fd.to_ne_bytes());
        pollfd.extend_from_slice(&(LINUX_POLLIN as i16).to_ne_bytes());
        pollfd.extend_from_slice(&0i16.to_ne_bytes());
        g.mem.write_bytes(pollfd_addr, &pollfd).unwrap();
        let timeout_addr = DATA_SCRATCH + 0x40;
        g.mem.write_bytes(timeout_addr, &[0u8; 16]).unwrap();
        assert_eq!(
            g.ok(SYS_PPOLL, [pollfd_addr, 1, timeout_addr, 0, 8, 0]),
            0,
            "no connection queued: poll must report nothing"
        );

        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );

        g.mem.write_bytes(pollfd_addr, &pollfd).unwrap();
        assert_eq!(
            g.ok(SYS_PPOLL, [pollfd_addr, 1, timeout_addr, 0, 8, 0]),
            1,
            "an in-zone queued connection must make the listener readable"
        );
        let out = g.mem.read_bytes(pollfd_addr, 8).unwrap();
        let revents = i16::from_ne_bytes([out[6], out[7]]);
        assert_eq!(revents & LINUX_POLLIN as i16, LINUX_POLLIN as i16);
    }

    #[test]
    fn closing_listener_with_queued_half_gives_econnreset_eof() {
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;

        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);

        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );

        // Close listener while connection is queued
        assert_eq!(g.ok(SYS_CLOSE, [listen_fd as u64, 0, 0, 0, 0, 0]), 0);

        // The `inzonetcp` oracle (case 7): the first recv reports the reset
        // and consumes it, so SO_ERROR afterwards reads 0 and a later read is
        // EOF.
        let read_res = g.call(SYS_READ, [client_fd as u64, DATA_SCRATCH, 64, 0, 0, 0]);
        assert_eq!(
            read_res,
            DispatchOutcome::errno(LINUX_ECONNRESET),
            "the first read reports the pending reset"
        );
        assert_eq!(
            g.ok(SYS_READ, [client_fd as u64, DATA_SCRATCH, 64, 0, 0, 0]),
            0,
            "the reset is consumed; the next read is EOF"
        );

        let optval = ADDR_SCRATCH;
        let optlen = ADDRLEN_SCRATCH;
        // SO_ERROR after the reported reset reads 0
        g.mem.write_bytes(optlen, &4u32.to_ne_bytes()).unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKOPT,
                [
                    client_fd as u64,
                    LINUX_SOL_SOCKET as u64,
                    LINUX_SO_ERROR as u64,
                    optval,
                    optlen,
                    0,
                ],
            ),
            0
        );
        let err_bytes2 = g.mem.read_bytes(optval, 4).unwrap();
        let err2 = i32::from_ne_bytes([err_bytes2[0], err_bytes2[1], err_bytes2[2], err_bytes2[3]]);
        assert_eq!(err2, 0, "SO_ERROR second read must be 0");
    }

    /// A blocking `read(2)` on an in-zone TCP half with nothing buffered must
    /// park on the socket's wait queue (re-dispatched when the peer writes),
    /// never hand EAGAIN to a blocking guest (probe `socketpartialsend`: a
    /// std `read_to_end` panicked with WouldBlock). Non-blocking still gets
    /// EAGAIN. Same for `recvfrom`.
    #[test]
    fn blocking_read_on_empty_in_zone_socket_parks_instead_of_eagain() {
        const SYS_RECVFROM: u64 = 207;
        const SYS_FCNTL: u64 = 25;
        const F_SETFL: u64 = 4;
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);
        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        let server_fd = g.ok(
            SYS_ACCEPT,
            [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
        ) as i32;

        // Blocking read and recvfrom on the empty half: a wait, not EAGAIN.
        for (nr, args) in [
            (SYS_READ, [server_fd as u64, DATA_SCRATCH, 64, 0, 0, 0]),
            (SYS_RECVFROM, [server_fd as u64, DATA_SCRATCH, 64, 0, 0, 0]),
        ] {
            match g.call(nr, args) {
                DispatchOutcome::WaitOnFds { fds, .. } => {
                    assert!(
                        fds.first().is_none_or(|(fd, _)| fd < 0),
                        "an in-memory socket has no host fd to poll"
                    );
                }
                other => panic!("syscall {nr} on an empty blocking in-zone socket: {other:?}"),
            }
        }

        // The peer writes: the same read now returns the bytes.
        g.mem.write_bytes(DATA_SCRATCH + 0x100, b"late").unwrap();
        assert_eq!(
            g.ok(
                SYS_WRITE,
                [client_fd as u64, DATA_SCRATCH + 0x100, 4, 0, 0, 0]
            ),
            4
        );
        assert_eq!(
            g.ok(SYS_READ, [server_fd as u64, DATA_SCRATCH, 64, 0, 0, 0]),
            4
        );

        // O_NONBLOCK: EAGAIN.
        assert_eq!(
            g.ok(
                SYS_FCNTL,
                [
                    server_fd as u64,
                    F_SETFL,
                    carrick_abi::LINUX_O_NONBLOCK,
                    0,
                    0,
                    0
                ],
            ),
            0
        );
        assert_eq!(
            g.call(SYS_READ, [server_fd as u64, DATA_SCRATCH, 64, 0, 0, 0]),
            DispatchOutcome::errno(carrick_abi::LINUX_EAGAIN)
        );
    }

    /// `sendto` on a connected in-zone stream ignores the destination but
    /// validates it first, like Linux `move_addr_to_kernel` (probe
    /// `streamdestmatrix` 2.8-2.10): negative or oversized addrlen is EINVAL,
    /// an unreadable address with a positive addrlen is EFAULT, and nothing
    /// is delivered in those cases.
    #[test]
    fn sendto_on_in_zone_stream_validates_the_ignored_destination() {
        const SYS_SENDTO: u64 = 206;
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);
        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        let server_fd = g.ok(
            SYS_ACCEPT,
            [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
        ) as i32;

        g.mem.write_bytes(DATA_SCRATCH, b"payload").unwrap();
        let neg_len = (-1i32) as u32 as u64;
        let unmapped = 0x10u64; // below MEM_BASE: unreadable
        assert_eq!(
            g.call(
                SYS_SENDTO,
                [client_fd as u64, DATA_SCRATCH, 7, 0, ADDR_SCRATCH, neg_len],
            ),
            DispatchOutcome::errno(carrick_abi::LINUX_EINVAL)
        );
        assert_eq!(
            g.call(
                SYS_SENDTO,
                [client_fd as u64, DATA_SCRATCH, 7, 0, ADDR_SCRATCH, 129],
            ),
            DispatchOutcome::errno(carrick_abi::LINUX_EINVAL)
        );
        assert_eq!(
            g.call(
                SYS_SENDTO,
                [client_fd as u64, DATA_SCRATCH, 7, 0, unmapped, 16]
            ),
            DispatchOutcome::errno(carrick_abi::LINUX_EFAULT)
        );
        // Nothing was delivered by the rejected calls.
        let poll_in = g.dispatcher.poll_ready_events(server_fd, LINUX_POLLIN);
        assert_eq!(
            poll_in & LINUX_POLLIN,
            0,
            "rejected sendto must not deliver"
        );
        // An unreadable address with addrlen 0, a NULL address with a positive
        // addrlen, and a valid ignored destination all deliver.
        assert_eq!(
            g.ok(
                SYS_SENDTO,
                [client_fd as u64, DATA_SCRATCH, 7, 0, unmapped, 0]
            ),
            7
        );
        assert_eq!(
            g.ok(SYS_SENDTO, [client_fd as u64, DATA_SCRATCH, 7, 0, 0, 16]),
            7
        );
        assert_eq!(
            g.ok(
                SYS_SENDTO,
                [client_fd as u64, DATA_SCRATCH, 7, 0, ADDR_SCRATCH, 16]
            ),
            7
        );
    }

    #[test]
    fn tcp_oob_urgent_data_readiness_and_recv() {
        const SYS_SENDTO: u64 = 206;
        const SYS_RECVFROM: u64 = 207;

        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;

        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);

        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );

        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        let server_fd = g.ok(
            SYS_ACCEPT,
            [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
        ) as i32;
        assert!(server_fd >= 3);

        // Before OOB send: client not ready for POLLPRI / EPOLLPRI
        assert_eq!(
            g.dispatcher.poll_ready_events(client_fd, POLLPRI) & POLLPRI,
            0
        );
        assert_eq!(
            g.dispatcher
                .epoll_ready_events(client_fd, carrick_abi::LINUX_EPOLLPRI)
                & carrick_abi::LINUX_EPOLLPRI,
            0
        );

        // Server sends 1 byte with MSG_OOB
        g.mem.write_bytes(DATA_SCRATCH, b"!").unwrap();
        assert_eq!(
            g.ok(
                SYS_SENDTO,
                [
                    server_fd as u64,
                    DATA_SCRATCH,
                    1,
                    LINUX_MSG_OOB as u64,
                    0,
                    0
                ],
            ),
            1
        );

        // Client now reports POLLPRI and EPOLLPRI
        assert_eq!(
            g.dispatcher.poll_ready_events(client_fd, POLLPRI) & POLLPRI,
            POLLPRI,
            "poll_ready_events must report POLLPRI for pending OOB"
        );
        assert_eq!(
            g.dispatcher
                .epoll_ready_events(client_fd, carrick_abi::LINUX_EPOLLPRI)
                & carrick_abi::LINUX_EPOLLPRI,
            carrick_abi::LINUX_EPOLLPRI,
            "epoll_ready_events must report EPOLLPRI for pending OOB"
        );

        // Client reads OOB byte with recvfrom(MSG_OOB)
        let recv_scratch = DATA_SCRATCH + 0x50;
        assert_eq!(
            g.ok(
                SYS_RECVFROM,
                [
                    client_fd as u64,
                    recv_scratch,
                    1,
                    LINUX_MSG_OOB as u64,
                    0,
                    0
                ],
            ),
            1
        );
        let read_back = g.mem.read_bytes(recv_scratch, 1).unwrap();
        assert_eq!(read_back, b"!");

        // After reading OOB byte, POLLPRI / EPOLLPRI are cleared
        assert_eq!(
            g.dispatcher.poll_ready_events(client_fd, POLLPRI) & POLLPRI,
            0,
            "poll_ready_events must clear POLLPRI after OOB read"
        );
        assert_eq!(
            g.dispatcher
                .epoll_ready_events(client_fd, carrick_abi::LINUX_EPOLLPRI)
                & carrick_abi::LINUX_EPOLLPRI,
            0,
            "epoll_ready_events must clear EPOLLPRI after OOB read"
        );
    }

    #[test]
    fn tcp_splice_socket_to_pipe_and_pipe_to_socket() {
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;

        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);

        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );

        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        let server_fd = g.ok(
            SYS_ACCEPT,
            [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
        ) as i32;
        assert!(server_fd >= 3);

        let pipe_scratch = DATA_SCRATCH + 0x100;
        assert_eq!(g.ok(SYS_PIPE2, [pipe_scratch, 0, 0, 0, 0, 0]), 0);
        let pipe_fds = g.mem.read_bytes(pipe_scratch, 8).unwrap();
        let pipe_r = i32::from_ne_bytes([pipe_fds[0], pipe_fds[1], pipe_fds[2], pipe_fds[3]]);
        let pipe_w = i32::from_ne_bytes([pipe_fds[4], pipe_fds[5], pipe_fds[6], pipe_fds[7]]);

        // Server writes to socket
        g.mem.write_bytes(DATA_SCRATCH, b"spliced-data").unwrap();
        assert_eq!(
            g.ok(SYS_WRITE, [server_fd as u64, DATA_SCRATCH, 12, 0, 0, 0]),
            12
        );

        // Splice from client_fd into pipe_w
        assert_eq!(
            g.ok(SYS_SPLICE, [client_fd as u64, 0, pipe_w as u64, 0, 12, 0],),
            12
        );

        // Splice from pipe_r into server_fd
        assert_eq!(
            g.ok(SYS_SPLICE, [pipe_r as u64, 0, server_fd as u64, 0, 12, 0],),
            12
        );

        // Client reads back what was spliced into server_fd
        let recv_scratch = DATA_SCRATCH + 0x50;
        assert_eq!(
            g.ok(SYS_READ, [client_fd as u64, recv_scratch, 12, 0, 0, 0]),
            12
        );
        let read_back = g.mem.read_bytes(recv_scratch, 12).unwrap();
        assert_eq!(read_back, b"spliced-data");
    }

    #[test]
    fn pselect6_inzone_listener_with_pending_connection_returns_ready_instead_of_parking() {
        const SYS_PSELECT6: u64 = 72;
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

        // Before connect, pselect6 with a timeout must park on WaitOnFds.
        let readfds_addr = MEM_BASE + 0x540;
        let mut fdset = [0u8; 128];
        fdset[(listen_fd / 8) as usize] |= 1 << (listen_fd % 8);
        g.mem.write_bytes(readfds_addr, &fdset).unwrap();

        let timeout_addr = MEM_BASE + 0x500;
        let timespec: [u64; 2] = [5, 0]; // 5 seconds
        g.mem
            .write_bytes(timeout_addr, zerocopy::IntoBytes::as_bytes(&timespec))
            .unwrap();

        let empty_outcome = g.call(
            SYS_PSELECT6,
            [listen_fd as u64 + 1, readfds_addr, 0, 0, timeout_addr, 0],
        );
        match empty_outcome {
            DispatchOutcome::WaitOnFds { .. } => {}
            other => panic!("expected WaitOnFds for empty in-zone listener, got {other:?}"),
        }

        // Connect from in-zone client.
        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );

        // After connect, pselect6 must sample sample_description and return 1 immediately
        // rather than re-parking into WaitOnFds due to host libc::poll returning 0.
        g.mem.write_bytes(readfds_addr, &fdset).unwrap();
        let ready_outcome = g.call(
            SYS_PSELECT6,
            [listen_fd as u64 + 1, readfds_addr, 0, 0, timeout_addr, 0],
        );
        match ready_outcome {
            DispatchOutcome::Returned { value: 1 } => {}
            other => panic!(
                "expected Returned {{ value: 1 }} for in-zone listener with pending connect, got {other:?}"
            ),
        }
        let out_fdset = g.mem.read_bytes(readfds_addr, 128).unwrap();
        assert_eq!(
            out_fdset[(listen_fd / 8) as usize] & (1 << (listen_fd % 8)),
            1 << (listen_fd % 8)
        );
    }

    /// The ONE wait source a single-fd `ppoll`/`pselect6` park registered.
    ///
    /// The park used to carry two independently built lists joined by one
    /// `logical_interest` scalar; asserting on the registration proves the fd
    /// named its own source, and that nothing was left unclassified.
    fn sole_wait_source(outcome: &DispatchOutcome) -> crate::dispatch::wait_source::WaitSource {
        let authority = match outcome {
            DispatchOutcome::WaitOnFds { fds, .. } => fds.authority().clone(),
            DispatchOutcome::BlockingFdWait { wait, .. } => wait.authority().clone(),
            other => panic!("expected WaitOnFds or BlockingFdWait, got {other:?}"),
        };
        match authority {
            WaitFdAuthority::Logical {
                registrations,
                unclassified,
                ..
            } => {
                assert!(
                    unclassified.is_empty(),
                    "ppoll/pselect6 classify every fd they name"
                );
                match registrations.as_slice() {
                    [registration] => registration.source(),
                    other => panic!("expected exactly one registration, got {other:?}"),
                }
            }
            other => panic!("expected WaitFdAuthority::Logical, got {other:?}"),
        }
    }

    fn inzone_connected_pair() -> (InZoneGuest, i32, i32) {
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);
        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        let accepted_fd = g.ok(
            SYS_ACCEPT,
            [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
        ) as i32;
        (g, client_fd, accepted_fd)
    }

    #[test]
    fn ppoll_on_inzone_accepted_stream_registers_a_probed_pollin_source() {
        const SYS_PPOLL: u64 = 73;
        let (mut g, _client_fd, accepted_fd) = inzone_connected_pair();

        let timeout_addr = MEM_BASE + 0x500;
        let timespec: [u64; 2] = [5, 0]; // 5 seconds
        g.mem
            .write_bytes(timeout_addr, zerocopy::IntoBytes::as_bytes(&timespec))
            .unwrap();

        let pollfd_addr = MEM_BASE + 0x520;
        let mut pfd = [0u8; 8];
        pfd[0..4].copy_from_slice(&accepted_fd.to_ne_bytes());
        pfd[4..6].copy_from_slice(&libc::POLLIN.to_ne_bytes());
        g.mem.write_bytes(pollfd_addr, &pfd).unwrap();

        let outcome = g.call(SYS_PPOLL, [pollfd_addr, 1, timeout_addr, 0, 0, 0]);
        let source = sole_wait_source(&outcome);
        assert_eq!(
            source
                .description_interest()
                .map(crate::dispatch::wait_source::WaitInterest::events),
            Some(carrick_abi::LinuxPollEvents::IN),
            "ppoll: the fd's OWN POLLIN interest, not a scalar folded across the wait"
        );
        assert!(
            source.probe_after_enrol(),
            "ppoll: an in-zone producer landing in the enrollment gap is recovered \
             only by the post-enrollment probe"
        );
    }

    #[test]
    fn pselect6_on_inzone_accepted_stream_registers_a_probed_pollin_source() {
        const SYS_PSELECT6: u64 = 72;
        let (mut g, _client_fd, accepted_fd) = inzone_connected_pair();

        let timeout_addr = MEM_BASE + 0x500;
        let timespec: [u64; 2] = [5, 0]; // 5 seconds
        g.mem
            .write_bytes(timeout_addr, zerocopy::IntoBytes::as_bytes(&timespec))
            .unwrap();

        let readfds_addr = MEM_BASE + 0x540;
        let mut fdset = [0u8; 128];
        fdset[(accepted_fd / 8) as usize] |= 1 << (accepted_fd % 8);
        g.mem.write_bytes(readfds_addr, &fdset).unwrap();

        let outcome = g.call(
            SYS_PSELECT6,
            [accepted_fd as u64 + 1, readfds_addr, 0, 0, timeout_addr, 0],
        );
        let source = sole_wait_source(&outcome);
        assert_eq!(
            source
                .description_interest()
                .map(crate::dispatch::wait_source::WaitInterest::events),
            Some(carrick_abi::LinuxPollEvents::IN),
            "pselect6: the fd's OWN POLLIN interest, not a scalar folded across the wait"
        );
        assert!(
            source.probe_after_enrol(),
            "pselect6: an in-zone producer landing in the enrollment gap is recovered \
             only by the post-enrollment probe"
        );
    }

    fn inzone_listener() -> (InZoneGuest, i32) {
        let mut g = InZoneGuest::new();
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);
        (g, listen_fd)
    }

    #[test]
    fn ppoll_on_inzone_listener_registers_a_dual_host_peers_only_source() {
        const SYS_PPOLL: u64 = 73;
        let (mut g, listen_fd) = inzone_listener();

        let timeout_addr = MEM_BASE + 0x500;
        let timespec: [u64; 2] = [5, 0]; // 5 seconds
        g.mem
            .write_bytes(timeout_addr, zerocopy::IntoBytes::as_bytes(&timespec))
            .unwrap();

        let pollfd_addr = MEM_BASE + 0x520;
        let mut pfd = [0u8; 8];
        pfd[0..4].copy_from_slice(&listen_fd.to_ne_bytes());
        pfd[4..6].copy_from_slice(&libc::POLLIN.to_ne_bytes());
        g.mem.write_bytes(pollfd_addr, &pfd).unwrap();

        let outcome = g.call(SYS_PPOLL, [pollfd_addr, 1, timeout_addr, 0, 0, 0]);
        let source = sole_wait_source(&outcome);
        assert_eq!(
            source
                .description_interest()
                .map(crate::dispatch::wait_source::WaitInterest::events),
            Some(carrick_abi::LinuxPollEvents::IN),
            "ppoll: the fd's OWN POLLIN interest, not a scalar folded across the wait"
        );
        assert!(
            source.probe_after_enrol(),
            "ppoll: an in-zone producer landing in the enrollment gap is recovered \
             only by the post-enrollment probe"
        );
        assert!(
            matches!(
                source,
                crate::dispatch::wait_source::WaitSource::Dual {
                    coverage: crate::dispatch::wait_source::HostProxyCoverage::HostPeersOnly,
                    ..
                }
            ),
            "ppoll: an in-zone listener is dual — the Darwin listen socket sees host \
             peers only, so the description still takes the probe; got {source:?}"
        );
    }

    #[test]
    fn pselect6_on_inzone_listener_registers_a_dual_host_peers_only_source() {
        const SYS_PSELECT6: u64 = 72;
        let (mut g, listen_fd) = inzone_listener();

        let timeout_addr = MEM_BASE + 0x500;
        let timespec: [u64; 2] = [5, 0]; // 5 seconds
        g.mem
            .write_bytes(timeout_addr, zerocopy::IntoBytes::as_bytes(&timespec))
            .unwrap();

        let readfds_addr = MEM_BASE + 0x540;
        let mut fdset = [0u8; 128];
        fdset[(listen_fd / 8) as usize] |= 1 << (listen_fd % 8);
        g.mem.write_bytes(readfds_addr, &fdset).unwrap();

        let outcome = g.call(
            SYS_PSELECT6,
            [listen_fd as u64 + 1, readfds_addr, 0, 0, timeout_addr, 0],
        );
        let source = sole_wait_source(&outcome);
        assert_eq!(
            source
                .description_interest()
                .map(crate::dispatch::wait_source::WaitInterest::events),
            Some(carrick_abi::LinuxPollEvents::IN),
            "pselect6: the fd's OWN POLLIN interest, not a scalar folded across the wait"
        );
        assert!(
            source.probe_after_enrol(),
            "pselect6: an in-zone producer landing in the enrollment gap is recovered \
             only by the post-enrollment probe"
        );
        assert!(
            matches!(
                source,
                crate::dispatch::wait_source::WaitSource::Dual {
                    coverage: crate::dispatch::wait_source::HostProxyCoverage::HostPeersOnly,
                    ..
                }
            ),
            "pselect6: an in-zone listener is dual — the Darwin listen socket sees host \
             peers only, so the description still takes the probe; got {source:?}"
        );
    }

    #[test]
    fn refused_nonblocking_inzone_connect_leaves_socket_reconnectable() {
        const SYS_FCNTL: u64 = 25;
        const F_SETFL: u64 = 4;
        const SYS_PPOLL: u64 = 73;

        let mut g = InZoneGuest::new();

        // 1. Bound-not-listening in-zone target
        let listen_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
        assert_eq!(
            g.ok(SYS_BIND, [listen_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            0
        );

        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKNAME,
                [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ),
            0
        );
        let (port, _) = g.read_sockaddr_in(ADDR_SCRATCH);
        assert_ne!(port, 0);

        // 2. Client socket set nonblocking
        let client_fd = g.ok(
            SYS_SOCKET,
            [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
        ) as i32;
        assert_eq!(
            g.ok(
                SYS_FCNTL,
                [
                    client_fd as u64,
                    F_SETFL,
                    carrick_abi::LINUX_O_NONBLOCK,
                    0,
                    0,
                    0
                ],
            ),
            0
        );

        // 3. Initial nonblocking connect against bound-not-listening target -> EINPROGRESS
        g.make_sockaddr_in(ADDR_SCRATCH, port, [127, 0, 0, 1]);
        assert_eq!(
            g.call(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            DispatchOutcome::errno(carrick_abi::LINUX_EINPROGRESS)
        );

        // 4. Listener transitions to listen
        assert_eq!(g.ok(SYS_LISTEN, [listen_fd as u64, 16, 0, 0, 0, 0]), 0);

        // 5. Connect 2 reports consumed pending error -> ECONNREFUSED
        assert_eq!(
            g.call(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            DispatchOutcome::errno(carrick_abi::LINUX_ECONNREFUSED)
        );

        // 6. Connect 3 connects to now-listening target -> EINPROGRESS
        assert_eq!(
            g.call(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
            DispatchOutcome::errno(carrick_abi::LINUX_EINPROGRESS)
        );

        // 7. Readiness POLLOUT
        let pollfd_addr = DATA_SCRATCH;
        let mut pollfd = Vec::with_capacity(8);
        pollfd.extend_from_slice(&client_fd.to_ne_bytes());
        pollfd.extend_from_slice(&carrick_abi::LINUX_POLLOUT.to_ne_bytes());
        pollfd.extend_from_slice(&0i16.to_ne_bytes());
        g.mem.write_bytes(pollfd_addr, &pollfd).unwrap();
        let timeout_addr = DATA_SCRATCH + 0x40;
        g.mem.write_bytes(timeout_addr, &[0u8; 16]).unwrap();
        assert_eq!(
            g.ok(SYS_PPOLL, [pollfd_addr, 1, timeout_addr, 0, 8, 0]),
            1,
            "client should report POLLOUT"
        );
        let out = g.mem.read_bytes(pollfd_addr, 8).unwrap();
        let revents = i16::from_ne_bytes([out[6], out[7]]);
        assert_eq!(
            revents & carrick_abi::LINUX_POLLOUT,
            carrick_abi::LINUX_POLLOUT
        );

        // 8. SO_ERROR reads 0
        let optval = ADDR_SCRATCH;
        let optlen = ADDRLEN_SCRATCH;
        g.mem.write_bytes(optlen, &4u32.to_ne_bytes()).unwrap();
        assert_eq!(
            g.ok(
                SYS_GETSOCKOPT,
                [
                    client_fd as u64,
                    LINUX_SOL_SOCKET as u64,
                    LINUX_SO_ERROR as u64,
                    optval,
                    optlen,
                    0,
                ],
            ),
            0
        );
        let err_bytes = g.mem.read_bytes(optval, 4).unwrap();
        let so_err = i32::from_ne_bytes([err_bytes[0], err_bytes[1], err_bytes[2], err_bytes[3]]);
        assert_eq!(so_err, 0, "SO_ERROR after connect must be 0");

        // 9. Accept succeeds
        g.mem
            .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
            .unwrap();
        let accepted_fd = g.ok(
            SYS_ACCEPT,
            [listen_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
        ) as i32;
        assert!(accepted_fd >= 3, "accept must succeed");
    }

    mod serial_host {
        use super::*;

        #[test]
        fn inzone_tcp_disconnect_rebind_lifecycle() {
            const SYS_DUP: u64 = 23;
            let mut g = InZoneGuest::new();

            // 1. Create listener 1
            let listen1_fd = g.ok(
                SYS_SOCKET,
                [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
            ) as i32;
            g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
            assert_eq!(
                g.ok(SYS_BIND, [listen1_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );
            assert_eq!(g.ok(SYS_LISTEN, [listen1_fd as u64, 16, 0, 0, 0, 0]), 0);
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            assert_eq!(
                g.ok(
                    SYS_GETSOCKNAME,
                    [listen1_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
                ),
                0
            );
            let (listen1_port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

            // 2. Client connects to listener 1
            let client_fd = g.ok(
                SYS_SOCKET,
                [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
            ) as i32;
            g.make_sockaddr_in(ADDR_SCRATCH, listen1_port, [127, 0, 0, 1]);
            assert_eq!(
                g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Accept on server
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            let server1_fd = g.ok(
                SYS_ACCEPT,
                [listen1_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ) as i32;
            assert!(server1_fd >= 0);

            // Record client's initial ephemeral port
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            assert_eq!(
                g.ok(
                    SYS_GETSOCKNAME,
                    [client_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
                ),
                0
            );
            let (client_port_before, _) = g.read_sockaddr_in(ADDR_SCRATCH);
            assert_ne!(client_port_before, 0);

            // Create dup alias
            let dup_client_fd = g.ok(SYS_DUP, [client_fd as u64, 0, 0, 0, 0, 0]) as i32;
            assert!(dup_client_fd >= 0);

            // 3. Disconnect client via connect(AF_UNSPEC)
            let mut unspec = vec![0u8; 16];
            unspec[0..2].copy_from_slice(&(LINUX_AF_UNSPEC as u16).to_ne_bytes());
            g.mem.write_bytes(ADDR_SCRATCH, &unspec).unwrap();
            assert_eq!(
                g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // 4. Rebind client to wildcard (0.0.0.0:0)
            g.make_sockaddr_in(ADDR_SCRATCH, 0, [0, 0, 0, 0]);
            assert_eq!(
                g.ok(SYS_BIND, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Check getsockname on client: leased new port, not retained
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            assert_eq!(
                g.ok(
                    SYS_GETSOCKNAME,
                    [client_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
                ),
                0
            );
            let (client_port_after, client_ip_after) = g.read_sockaddr_in(ADDR_SCRATCH);
            assert_ne!(client_port_after, 0);
            assert_ne!(
                client_port_after, client_port_before,
                "port should not be retained"
            );
            assert_eq!(client_ip_after, [0, 0, 0, 0], "bound to wildcard");

            // Dup alias observes the new local address
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            assert_eq!(
                g.ok(
                    SYS_GETSOCKNAME,
                    [dup_client_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
                ),
                0
            );
            let (dup_port, dup_ip) = g.read_sockaddr_in(ADDR_SCRATCH);
            assert_eq!(dup_port, client_port_after, "alias port matches");
            assert_eq!(dup_ip, client_ip_after, "alias ip matches");

            // Second bind on client_fd returns EINVAL
            g.make_sockaddr_in(ADDR_SCRATCH, 0, [0, 0, 0, 0]);
            assert_eq!(
                g.call(SYS_BIND, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                DispatchOutcome::errno(LINUX_EINVAL)
            );

            // Verify old port can be rebound by another socket
            let probe_fd = g.ok(
                SYS_SOCKET,
                [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
            ) as i32;
            g.make_sockaddr_in(ADDR_SCRATCH, client_port_before, [127, 0, 0, 1]);
            assert_eq!(
                g.ok(SYS_BIND, [probe_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0,
                "previous port lease was freed"
            );
            assert_eq!(g.ok(SYS_CLOSE, [probe_fd as u64, 0, 0, 0, 0, 0]), 0);

            // 5. Subsequent listen on re-bound client_fd
            assert_eq!(g.ok(SYS_LISTEN, [client_fd as u64, 16, 0, 0, 0, 0]), 0);

            // Connect a new peer to client_fd (which is now listening on client_port_after)
            let peer_fd = g.ok(
                SYS_SOCKET,
                [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
            ) as i32;
            g.make_sockaddr_in(ADDR_SCRATCH, client_port_after, [127, 0, 0, 1]);
            assert_eq!(
                g.ok(SYS_CONNECT, [peer_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Accept on client_fd
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            let accepted2_fd = g.ok(
                SYS_ACCEPT,
                [client_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ) as i32;
            assert!(accepted2_fd >= 0);

            // Echo transfer between peer_fd and accepted2_fd
            g.mem.write_bytes(DATA_SCRATCH, b"hello-rebind").unwrap();
            assert_eq!(
                g.ok(SYS_WRITE, [peer_fd as u64, DATA_SCRATCH, 12, 0, 0, 0]),
                12
            );
            let recv_scratch = DATA_SCRATCH + 0x40;
            assert_eq!(
                g.ok(SYS_READ, [accepted2_fd as u64, recv_scratch, 12, 0, 0, 0]),
                12
            );
            let read_back = g.mem.read_bytes(recv_scratch, 12).unwrap();
            assert_eq!(read_back, b"hello-rebind");

            assert_eq!(g.ok(SYS_CLOSE, [listen1_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [server1_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [client_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [dup_client_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [peer_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [accepted2_fd as u64, 0, 0, 0, 0, 0]), 0);
        }

        #[test]
        fn inzone_tcp_disconnect_rebind_and_reconnect() {
            let mut g = InZoneGuest::new();

            // 1. Create listener 1
            let listen1_fd = g.ok(
                SYS_SOCKET,
                [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
            ) as i32;
            g.make_sockaddr_in(ADDR_SCRATCH, 0, [127, 0, 0, 1]);
            assert_eq!(
                g.ok(SYS_BIND, [listen1_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );
            assert_eq!(g.ok(SYS_LISTEN, [listen1_fd as u64, 16, 0, 0, 0, 0]), 0);
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            assert_eq!(
                g.ok(
                    SYS_GETSOCKNAME,
                    [listen1_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
                ),
                0
            );
            let (listen1_port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

            // 2. Client connects to listener 1
            let client_fd = g.ok(
                SYS_SOCKET,
                [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
            ) as i32;
            g.make_sockaddr_in(ADDR_SCRATCH, listen1_port, [127, 0, 0, 1]);
            assert_eq!(
                g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );
            let server1_fd = g.ok(
                SYS_ACCEPT,
                [listen1_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ) as i32;

            // Disconnect client
            let mut unspec = vec![0u8; 16];
            unspec[0..2].copy_from_slice(&(LINUX_AF_UNSPEC as u16).to_ne_bytes());
            g.mem.write_bytes(ADDR_SCRATCH, &unspec).unwrap();
            assert_eq!(
                g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Rebind client to wildcard
            g.make_sockaddr_in(ADDR_SCRATCH, 0, [0, 0, 0, 0]);
            assert_eq!(
                g.ok(SYS_BIND, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Reconnect client to listener 1
            g.make_sockaddr_in(ADDR_SCRATCH, listen1_port, [127, 0, 0, 1]);
            assert_eq!(
                g.ok(SYS_CONNECT, [client_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Accept second connection on listener 1
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            let server2_fd = g.ok(
                SYS_ACCEPT,
                [listen1_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ) as i32;
            assert!(server2_fd >= 0);

            // Data transfer
            g.mem.write_bytes(DATA_SCRATCH, b"reconnect-ok").unwrap();
            assert_eq!(
                g.ok(SYS_WRITE, [client_fd as u64, DATA_SCRATCH, 12, 0, 0, 0]),
                12
            );
            let recv_scratch = DATA_SCRATCH + 0x40;
            assert_eq!(
                g.ok(SYS_READ, [server2_fd as u64, recv_scratch, 12, 0, 0, 0]),
                12
            );
            let read_back = g.mem.read_bytes(recv_scratch, 12).unwrap();
            assert_eq!(read_back, b"reconnect-ok");

            assert_eq!(g.ok(SYS_CLOSE, [listen1_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [server1_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [server2_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [client_fd as u64, 0, 0, 0, 0, 0]), 0);
        }

        #[test]
        fn inzone_tcp_disconnect_rebind_accepted_stream() {
            let (mut g, client_fd, accepted_fd) = inzone_connected_pair();

            // Disconnect accepted_fd
            let mut unspec = vec![0u8; 16];
            unspec[0..2].copy_from_slice(&(LINUX_AF_UNSPEC as u16).to_ne_bytes());
            g.mem.write_bytes(ADDR_SCRATCH, &unspec).unwrap();
            assert_eq!(
                g.ok(SYS_CONNECT, [accepted_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Rebind accepted_fd
            g.make_sockaddr_in(ADDR_SCRATCH, 0, [0, 0, 0, 0]);
            assert_eq!(
                g.ok(SYS_BIND, [accepted_fd as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Listen on accepted_fd
            assert_eq!(g.ok(SYS_LISTEN, [accepted_fd as u64, 16, 0, 0, 0, 0]), 0);

            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            assert_eq!(
                g.ok(
                    SYS_GETSOCKNAME,
                    [accepted_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
                ),
                0
            );
            let (new_port, _) = g.read_sockaddr_in(ADDR_SCRATCH);

            // Connect to new_port
            let new_client = g.ok(
                SYS_SOCKET,
                [LINUX_AF_INET as u64, LINUX_SOCK_STREAM as u64, 0, 0, 0, 0],
            ) as i32;
            g.make_sockaddr_in(ADDR_SCRATCH, new_port, [127, 0, 0, 1]);
            assert_eq!(
                g.ok(SYS_CONNECT, [new_client as u64, ADDR_SCRATCH, 16, 0, 0, 0]),
                0
            );

            // Accept
            g.mem
                .write_bytes(ADDRLEN_SCRATCH, &16u32.to_ne_bytes())
                .unwrap();
            let new_server = g.ok(
                SYS_ACCEPT,
                [accepted_fd as u64, ADDR_SCRATCH, ADDRLEN_SCRATCH, 0, 0, 0],
            ) as i32;
            assert!(new_server >= 0);

            // Transfer
            g.mem.write_bytes(DATA_SCRATCH, b"accepted-rebind").unwrap();
            assert_eq!(
                g.ok(SYS_WRITE, [new_client as u64, DATA_SCRATCH, 15, 0, 0, 0]),
                15
            );
            let recv_scratch = DATA_SCRATCH + 0x40;
            assert_eq!(
                g.ok(SYS_READ, [new_server as u64, recv_scratch, 15, 0, 0, 0]),
                15
            );
            let read_back = g.mem.read_bytes(recv_scratch, 15).unwrap();
            assert_eq!(read_back, b"accepted-rebind");

            assert_eq!(g.ok(SYS_CLOSE, [client_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [accepted_fd as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [new_client as u64, 0, 0, 0, 0, 0]), 0);
            assert_eq!(g.ok(SYS_CLOSE, [new_server as u64, 0, 0, 0, 0, 0]), 0);
        }
    }
}

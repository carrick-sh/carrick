//! The minimal hypervisor-specific surface the shared threaded run-loop drives.
//! `SyscallTrap` (per-syscall) stays separate; this carries the per-thread /
//! fork / kick / futex lifecycle so single-threaded backends are unaffected.
use std::collections::{BTreeMap, HashMap};
use std::num::NonZeroU64;
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex, Weak};
use std::time::Duration;

use carrick_guest_mem::CurrentMmMemory;
pub use carrick_guest_mem::{HostVa, SharedFutexLocation};

use crate::error::{OsError, Reg, SysReg};
use crate::trap::{SyscallTrap, TrapError};

use carrick_fatal::carrick_fatal;

/// The process-local thread/vCPU **registry key**.
///
/// This is the key a guest thread is filed under in every per-process table:
/// the vCPU kick registry, the `ThreadRegistry`, the private-futex park
/// tokens, and the per-thread signal bookkeeping. It is NOT a host thread
/// identity (that axis is the mach-port `ThreadPort`) and NOT the
/// guest-visible tid (the runtime's `guest_visible_tid` derives that from this
/// key at the `gettid`//proc seam).
///
/// The field is private and there is deliberately NO general
/// `From<i32>`/`from_raw` (docs/typed-interfaces-audit.md P1.3): construction
/// goes through the named semantic constructors below, and the raw value
/// escapes only at wire/libc/probe boundaries via [`ThreadId::raw`].
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct ThreadId(i32);

impl ThreadId {
    /// The "no thread context" sentinel — numeric 0, exactly the value the raw
    /// `i32` code used (`ctx_tid` returns it when a syscall is dispatched with
    /// no thread context). Compares unequal to every real registry key.
    pub const NONE: ThreadId = ThreadId(0);

    /// The MAIN guest thread's registry key, deliberately seeded from this
    /// process's host pid. This is the identity the tree relies on:
    /// main-key == host pid == ns-base pid, which is what lets
    /// `guest_visible_tid` reconcile the main thread's key to the guest's
    /// ns-pid and lets guest-supplied tids index the registry untranslated.
    pub fn main_from_host_pid() -> Self {
        Self(std::process::id() as i32)
    }

    /// [`ThreadId::main_from_host_pid`] for a caller that already holds the
    /// host-pid VALUE (e.g. captured around a fork boundary). The argument is
    /// a HOST pid by contract — never a guest/ns pid.
    pub fn main_from_host_pid_value(host_pid: i32) -> Self {
        Self(host_pid)
    }

    /// A GUEST-SUPPLIED tid (ns domain: `tgkill`/`tkill` targets,
    /// `/proc/<tid>` lookups, `F_SETOWN_EX` ids) entering the registry-key
    /// space UNTRANSLATED.
    ///
    /// Convention: this works today because the main thread's key == host pid
    /// == ns-base pid, and worker keys are handed to the guest untranslated —
    /// so the guest hands back exactly the registry key. This constructor
    /// NAMES that crossing without changing it: no translation, no checks.
    pub fn from_guest_supplied_tid(tid: i32) -> Self {
        Self(tid)
    }

    /// A registry key ROUND-TRIPPING back from one of carrick's own raw-`i32`
    /// wire tables (the signal-core pending/xsig tables, whose publish sites
    /// exported the key with [`ThreadId::raw`]). Re-enters the value unchanged
    /// — this is NOT a general `from_raw`: only use it where the value's
    /// provenance is a prior `raw()` export of a registry key.
    pub fn from_wire_key(raw: i32) -> Self {
        Self(raw)
    }

    /// A key allocated by the thread registry's monotonic counter
    /// (`ThreadRegistry::register_child`'s `next_tid.fetch_add`). Only the
    /// registry allocation path should construct through this.
    pub fn from_registry_allocation(raw: i32) -> Self {
        Self(raw)
    }

    /// A synthetic registry key for TESTS (concurrency harnesses that
    /// fabricate worker keys like `100 + w`). Not for production code.
    pub fn synthetic_for_tests(raw: i32) -> Self {
        Self(raw)
    }

    /// The raw key value, escaping to a wire/libc/probe boundary (signal-core
    /// pending tables, USDT probes, guest tid byte writes, park tokens).
    pub fn raw(self) -> i32 {
        self.0
    }
}

impl std::fmt::Display for ThreadId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        self.0.fmt(f)
    }
}

/// Serializes as the bare `i32` key (diagnostics/event-ring payloads keep
/// their pre-newtype wire shape).
impl serde::Serialize for ThreadId {
    fn serialize<S: serde::Serializer>(&self, serializer: S) -> Result<S::Ok, S::Error> {
        self.0.serialize(serializer)
    }
}

/// Cross-thread "force this vCPU out of the guest" primitive.
/// HVF: `hv_vcpus_exit`. KVM: `pthread_kill(tid, KICK_SIGNAL)` -> `KVM_RUN` EINTR.
pub trait VcpuKick: Send + Sync + Clone {
    fn kick(&self);
}

/// Object-safe `VcpuKick` for storage in the registry (the `Clone` bound on
/// `VcpuKick` is not object-safe, so the registry stores boxed handles).
pub trait VcpuKickDyn: Send + Sync {
    fn kick(&self);
}
impl<T: VcpuKick> VcpuKickDyn for T {
    fn kick(&self) {
        VcpuKick::kick(self)
    }
}

/// One guest thread's half of the `in_guest` ↔ `quiescing` Dekker handshake:
/// "this vCPU is about to enter, or is inside, guest code".
///
/// EXACTLY ONE of these exists per guest thread. It is created with the
/// thread's runtime state and lives as long as the thread does, across every
/// blocking-wait reclaim, fork park and vCPU rebind. Typed registration
/// ([`VcpuRegistry::subscribe_register`]) publishes a clone of this same cell
/// into the registry, so the run loop's stores and a coordinator's
/// [`VcpuRegistry::any_other_in_guest`] reads always name the SAME memory —
/// there is no second cell for either side to go stale against.
///
/// The type carries the polarity that a bare `bool` lost: construction is
/// through ONE named semantic constructor, mutation is through
/// [`InGuestFlag::enter_guest`] / [`InGuestFlag::leave_guest`], and there is
/// deliberately no `Clone`/`Default` (docs/typed-interfaces-audit.md P1.3) —
/// a second flag for one thread would silently split the handshake in half.
pub struct InGuestFlag(Arc<AtomicBool>);

impl InGuestFlag {
    /// The one flag belonging to ONE guest thread, created together with that
    /// thread's runtime state. Call this exactly once per guest thread; every
    /// later (re-)registration of that thread hands `subscribe_register` this
    /// same flag.
    pub fn for_guest_thread() -> Self {
        Self(Arc::new(AtomicBool::new(false)))
    }

    /// Publish "entering guest code" before the guest-entry re-check of the
    /// coordinator's `quiescing` flag. SeqCst on both sides of the handshake
    /// guarantees at least one side observes the other.
    pub fn enter_guest(&self) {
        self.0.store(true, std::sync::atomic::Ordering::SeqCst);
    }

    /// Publish "back in host code" — a coordinator may now proceed past us.
    pub fn leave_guest(&self) {
        self.0.store(false, std::sync::atomic::Ordering::SeqCst);
    }

    /// The current handshake state (diagnostics and tests; coordination uses
    /// [`VcpuRegistry::any_other_in_guest`]).
    pub fn is_in_guest(&self) -> bool {
        self.0.load(std::sync::atomic::Ordering::SeqCst)
    }

    /// The registry's clone of this thread's cell, taken at registration.
    fn share(&self) -> Arc<AtomicBool> {
        Arc::clone(&self.0)
    }
}

/// The process-wide registry of live vCPU identities and kick handles. Held as
/// `Arc<dyn VcpuRegistry>` so the shared loop never names a concrete kicker.
///
/// A registration is ONE indivisible entry carrying BOTH facets — the
/// cross-thread kick handle and the thread's [`InGuestFlag`]. That is a
/// correctness requirement, not tidiness: the two used to be separate maps with
/// a `register` that restored only the kick handle, so every blocking-wait
/// unregister/re-register cycle silently dropped the thread's in-guest facet
/// forever and `any_other_in_guest` reported FALSE for a thread executing guest
/// code. It also gives the drain its real invariant — anything observable as
/// in-guest is, by construction, kickable.
pub trait VcpuRegistry: Send + Sync {
    /// Atomically diagnose whether every registration other than `except` has
    /// drained. This is diagnostic only; protected work requires a
    /// [`VcpuLeaseDrainGuard`] returned by [`VcpuRegistry::subscribe_lease_drain`].
    fn poll_lease_drain(&self, except: ThreadId) -> VcpuLeaseDrainPoll;
    /// Atomically wait for sibling membership to change or freeze new sibling
    /// registrations when the sibling set is already empty.
    fn subscribe_lease_drain(
        &self,
        except: ThreadId,
        callback: Arc<dyn Fn() + Send + Sync + 'static>,
    ) -> VcpuLeaseDrainEnrollment;
    /// Atomically publish or replace this thread's vCPU registration, or wait
    /// for a conflicting lease freeze to thaw.
    ///
    /// `in_guest` is the thread's one lifetime flag, not a fresh cell: the
    /// registry stores a clone of it, and the caller keeps storing through the
    /// flag it already owns.
    fn subscribe_register(
        &self,
        tid: ThreadId,
        handle: Box<dyn VcpuKickDyn>,
        in_guest: &InGuestFlag,
        callback: Arc<dyn Fn() + Send + Sync + 'static>,
    ) -> VcpuRegistrationEnrollment;
    /// Drop this thread's whole registration — it holds no live vCPU, so it can
    /// neither be kicked nor observed as in-guest until it registers again.
    fn unregister(&self, tid: ThreadId);
    fn kick(&self, tid: ThreadId);
    /// Kick `tid` only when its run loop still reports that it is entering or
    /// executing guest code. Returns whether a kick was issued.
    ///
    /// Signal-pump retries use this after the initial unconditional delivery:
    /// a vCPU in host code has already reached a pending-signal safe point and
    /// must not be kicked repeatedly for an unchanged pending bit.
    fn kick_if_in_guest(&self, tid: ThreadId) -> bool;
    /// Kick every registered vCPU (including the caller's, if registered). The
    /// process-directed signal pump uses this to nudge every in-guest thread to
    /// re-check pending at its next safe point.
    fn kick_all(&self);
    /// Kick only registrations currently entering or executing guest code.
    /// Returns whether at least one kick was issued.
    fn kick_all_in_guest(&self) -> bool;
    fn kick_all_except(&self, except: ThreadId);
    fn any_other_in_guest(&self, except: ThreadId) -> bool;
    /// Whether this exact registered vCPU is entering or executing guest code.
    fn is_in_guest(&self, tid: ThreadId) -> bool;
    fn publish_kernel_wake_debt(&self) {}
    fn retry_kernel_wake_debt(&self) -> KernelWakeRetryPoll {
        KernelWakeRetryPoll::default()
    }
    fn kernel_wake_debt_for(&self, _tid: ThreadId) -> Option<KernelWakeDebt> {
        None
    }
    fn acknowledge_kernel_wake_debt(&self, _tid: ThreadId, _debt: KernelWakeDebt) {}
    fn retire_kernel_wake_debt(&self, _tid: ThreadId) {}
    /// Bounded timeout diagnostics only: registered vCPU identities and their
    /// current in-guest handshake state, read from the SAME entries
    /// [`VcpuRegistry::any_other_in_guest`] reads, so a timeout dump cannot
    /// disagree with the predicate that produced the timeout. Ordinary
    /// coordination must use the typed predicates above rather than snapshots.
    fn debug_registered_vcpus(&self) -> Vec<(ThreadId, bool)> {
        Vec::new()
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct KernelWakeDebt {
    pub enrollment: u64,
    pub generation: u64,
}

#[derive(Clone, Copy, Debug, Default, Eq, PartialEq)]
pub struct KernelWakeRetryPoll {
    pub owed: bool,
    pub kicked: bool,
}

/// Diagnostic result for the live sibling-vCPU lease set.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum VcpuLeaseDrainPoll {
    Complete,
    Waiting(ThreadId),
}

type VcpuLeaseChangeCallback = Arc<dyn Fn() + Send + Sync + 'static>;

/// Cancellation-on-drop registration for one registry-owned change callback.
pub struct VcpuLeaseChangeSubscription {
    state: Weak<Mutex<VcpuRegistryState>>,
    listener_id: u64,
}

/// Unique witness that no sibling lease was registered when it was minted and
/// no non-owner registration can publish while it remains live.
pub struct VcpuLeaseDrainGuard {
    state: Weak<Mutex<VcpuRegistryState>>,
    owner: ThreadId,
    generation: u64,
}

/// Atomic enrollment for a sibling lease drain.
pub enum VcpuLeaseDrainEnrollment {
    Frozen(VcpuLeaseDrainGuard),
    Waiting {
        tid: ThreadId,
        subscription: VcpuLeaseChangeSubscription,
    },
    Busy {
        owner: ThreadId,
        subscription: VcpuLeaseChangeSubscription,
    },
}

/// Atomic enrollment for one exact vCPU registration.
pub enum VcpuRegistrationEnrollment {
    Registered,
    Waiting {
        owner: ThreadId,
        subscription: VcpuLeaseChangeSubscription,
    },
}

/// The platform-NEUTRAL [`VcpuRegistry`] implementation, shared by every backend.
///
/// It is ONE map of per-tid `VcpuRegistration`s — kick handle plus in-guest
/// flag, registered and dropped together — plus the SeqCst Dekker handshake the
/// fork / page-table-edit coordinators rely on. The only platform-specific
/// piece is the kick MECHANISM, which is
/// already behind [`VcpuKickDyn`] (HVF `hv_vcpus_exit`, KVM `pthread_kill`,
/// bhyve `_umtx_op`/`vm_suspend_cpu`), so the registry itself names no backend.
/// Kicks are per-handle (`kick_all` calls each handle's `kick()`); a backend that
/// batched (HVF's old bulk `hv_vcpus_exit(ids)`) is behavior-equivalent — N
/// single-id exits force the same vCPUs out, at the same infrequent quiesce
/// points — so the bulk fast path is dropped in favour of one shared registry.
///
/// A backend that needs setup at construction (e.g. KVM installing its
/// SIGRTMIN kick-signal handler) wraps this in a thin newtype whose `new()` does
/// the setup and delegates the trait. This struct is only ever driven through
/// [`VcpuRegistry`], so it intentionally has no inherent kick API.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum VcpuLeaseListenerKind {
    Membership,
    Thaw,
}

struct VcpuLeaseListener {
    kind: VcpuLeaseListenerKind,
    callback: VcpuLeaseChangeCallback,
}

struct VcpuLeaseFreeze {
    owner: ThreadId,
    generation: u64,
}

struct VcpuRegistryState {
    vcpus: HashMap<ThreadId, VcpuRegistration>,
    freeze: Option<VcpuLeaseFreeze>,
    listeners: BTreeMap<u64, VcpuLeaseListener>,
    next_listener: u64,
    next_freeze_generation: u64,
    next_enrollment: u64,
    next_kernel_wake_generation: u64,
    // Logical membership outlives temporary physical lease unregistration.
    // None means acknowledged, not retired; publication during a lease gap
    // must still leave debt for this exact thread's next registration.
    kernel_wake_debts: HashMap<ThreadId, Option<u64>>,
}

impl Default for VcpuRegistryState {
    fn default() -> Self {
        Self {
            vcpus: HashMap::new(),
            freeze: None,
            listeners: BTreeMap::new(),
            next_listener: 1,
            next_freeze_generation: 1,
            next_enrollment: 1,
            next_kernel_wake_generation: 1,
            kernel_wake_debts: HashMap::new(),
        }
    }
}

#[derive(Default)]
pub struct GenericVcpuRegistry {
    state: Arc<Mutex<VcpuRegistryState>>,
}

/// One live vCPU's registration: the two facets that must exist together or
/// not at all. Splitting them into separate maps is what let the in-guest half
/// decay away across a reclaim.
struct VcpuRegistration {
    kick: Box<dyn VcpuKickDyn>,
    in_guest: Arc<AtomicBool>,
    enrollment: u64,
    kernel_wake_generation: Option<u64>,
}

impl VcpuRegistration {
    fn is_in_guest(&self) -> bool {
        self.in_guest.load(std::sync::atomic::Ordering::SeqCst)
    }
}

impl GenericVcpuRegistry {
    pub fn new() -> Self {
        Self::default()
    }

    fn lock(&self) -> std::sync::MutexGuard<'_, VcpuRegistryState> {
        self.state.lock().unwrap_or_else(|error| error.into_inner())
    }
}

impl VcpuRegistryState {
    fn add_listener(
        &mut self,
        kind: VcpuLeaseListenerKind,
        callback: VcpuLeaseChangeCallback,
    ) -> u64 {
        let listener_id = NonZeroU64::new(self.next_listener)
            .unwrap_or_else(|| {
                carrick_fatal!(
                    "hal::vcpu_lease",
                    "next vCPU lease listener identifier was zero: next_listener={}",
                    self.next_listener
                );
            })
            .get();
        self.next_listener = self.next_listener.checked_add(1).unwrap_or_else(|| {
            carrick_fatal!(
                "hal::vcpu_lease",
                "next vCPU lease listener identifier overflowed u64 counter: next_listener={}",
                self.next_listener
            );
        });
        let replaced = self
            .listeners
            .insert(listener_id, VcpuLeaseListener { kind, callback });
        if replaced.is_some() {
            carrick_fatal!(
                "hal::vcpu_lease",
                "duplicate listener identifier collided in active vCPU lease listener map: listener_id={listener_id}"
            );
        }
        listener_id
    }

    fn next_freeze_generation(&mut self) -> u64 {
        let generation = NonZeroU64::new(self.next_freeze_generation)
            .unwrap_or_else(|| {
                carrick_fatal!(
                    "hal::vcpu_freeze",
                    "next vCPU registry freeze generation was zero: next_freeze_generation={}",
                    self.next_freeze_generation
                );
            })
            .get();
        self.next_freeze_generation = self
            .next_freeze_generation
            .checked_add(1)
            .unwrap_or_else(|| {
                carrick_fatal!(
                    "hal::vcpu_freeze",
                    "next vCPU registry freeze generation overflowed u64 counter: next_freeze_generation={}",
                    self.next_freeze_generation
                );
            });
        generation
    }

    fn take_listeners(&mut self, kind: VcpuLeaseListenerKind) -> Vec<VcpuLeaseChangeCallback> {
        let listener_ids: Vec<_> = self
            .listeners
            .iter()
            .filter_map(|(listener_id, listener)| (listener.kind == kind).then_some(*listener_id))
            .collect();
        listener_ids
            .into_iter()
            .filter_map(|listener_id| self.listeners.remove(&listener_id))
            .map(|listener| listener.callback)
            .collect()
    }
}

impl Drop for VcpuLeaseChangeSubscription {
    fn drop(&mut self) {
        let Some(state) = self.state.upgrade() else {
            return;
        };
        state
            .lock()
            .unwrap_or_else(|error| error.into_inner())
            .listeners
            .remove(&self.listener_id);
    }
}

impl Drop for VcpuLeaseDrainGuard {
    fn drop(&mut self) {
        let Some(state) = self.state.upgrade() else {
            return;
        };
        let callbacks = {
            let mut state = state.lock().unwrap_or_else(|error| error.into_inner());
            match state.freeze.as_ref() {
                Some(freeze)
                    if freeze.owner == self.owner && freeze.generation == self.generation =>
                {
                    state.freeze = None;
                    state.take_listeners(VcpuLeaseListenerKind::Thaw)
                }
                Some(_) | None => {
                    carrick_fatal!(
                        "hal::vcpu_freeze",
                        "vCPU lease drain guard dropped while registry freeze was missing or owned by another thread or generation: expected_owner={:?} expected_gen={}",
                        self.owner,
                        self.generation
                    );
                }
            }
        };
        for callback in callbacks {
            callback();
        }
    }
}

fn lowest_sibling(state: &VcpuRegistryState, except: ThreadId) -> Option<ThreadId> {
    state
        .vcpus
        .keys()
        .copied()
        .filter(|tid| *tid != except)
        .min()
}

impl VcpuRegistry for GenericVcpuRegistry {
    fn poll_lease_drain(&self, except: ThreadId) -> VcpuLeaseDrainPoll {
        match lowest_sibling(&self.lock(), except) {
            Some(tid) => VcpuLeaseDrainPoll::Waiting(tid),
            None => VcpuLeaseDrainPoll::Complete,
        }
    }

    fn subscribe_lease_drain(
        &self,
        except: ThreadId,
        callback: VcpuLeaseChangeCallback,
    ) -> VcpuLeaseDrainEnrollment {
        let mut state = self.lock();
        if let Some(freeze) = state.freeze.as_ref() {
            let owner = freeze.owner;
            let listener_id = state.add_listener(VcpuLeaseListenerKind::Thaw, callback);
            return VcpuLeaseDrainEnrollment::Busy {
                owner,
                subscription: VcpuLeaseChangeSubscription {
                    state: Arc::downgrade(&self.state),
                    listener_id,
                },
            };
        }
        if let Some(tid) = lowest_sibling(&state, except) {
            let listener_id = state.add_listener(VcpuLeaseListenerKind::Membership, callback);
            return VcpuLeaseDrainEnrollment::Waiting {
                tid,
                subscription: VcpuLeaseChangeSubscription {
                    state: Arc::downgrade(&self.state),
                    listener_id,
                },
            };
        }
        let generation = state.next_freeze_generation();
        state.freeze = Some(VcpuLeaseFreeze {
            owner: except,
            generation,
        });
        VcpuLeaseDrainEnrollment::Frozen(VcpuLeaseDrainGuard {
            state: Arc::downgrade(&self.state),
            owner: except,
            generation,
        })
    }

    fn subscribe_register(
        &self,
        tid: ThreadId,
        handle: Box<dyn VcpuKickDyn>,
        in_guest: &InGuestFlag,
        callback: VcpuLeaseChangeCallback,
    ) -> VcpuRegistrationEnrollment {
        let callbacks = {
            let mut state = self.lock();
            if let Some(freeze) = state.freeze.as_ref()
                && freeze.owner != tid
            {
                let owner = freeze.owner;
                let listener_id = state.add_listener(VcpuLeaseListenerKind::Thaw, callback);
                return VcpuRegistrationEnrollment::Waiting {
                    owner,
                    subscription: VcpuLeaseChangeSubscription {
                        state: Arc::downgrade(&self.state),
                        listener_id,
                    },
                };
            }
            let inherited_kernel_wake = *state.kernel_wake_debts.entry(tid).or_default();
            let enrollment = state.next_enrollment;
            state.next_enrollment = state.next_enrollment.checked_add(1).unwrap_or_else(|| {
                carrick_fatal!("hal::kernel_wake", "vCPU enrollment generation exhausted")
            });
            let inserted = state
                .vcpus
                .insert(
                    tid,
                    VcpuRegistration {
                        kick: handle,
                        in_guest: in_guest.share(),
                        enrollment,
                        kernel_wake_generation: inherited_kernel_wake,
                    },
                )
                .is_none();
            if inserted {
                state.take_listeners(VcpuLeaseListenerKind::Membership)
            } else {
                Vec::new()
            }
        };
        for callback in callbacks {
            callback();
        }
        VcpuRegistrationEnrollment::Registered
    }

    fn unregister(&self, tid: ThreadId) {
        let callbacks = {
            let mut state = self.lock();
            if state.vcpus.remove(&tid).is_some() {
                state.take_listeners(VcpuLeaseListenerKind::Membership)
            } else {
                Vec::new()
            }
        };
        for callback in callbacks {
            callback();
        }
    }

    fn kick(&self, tid: ThreadId) {
        if let Some(entry) = self.lock().vcpus.get(&tid) {
            entry.kick.kick();
        }
    }

    fn kick_if_in_guest(&self, tid: ThreadId) -> bool {
        let registrations = self.lock();
        let Some(entry) = registrations.vcpus.get(&tid) else {
            return false;
        };
        if !entry.is_in_guest() {
            return false;
        }
        entry.kick.kick();
        true
    }

    fn kick_all(&self) {
        for entry in self.lock().vcpus.values() {
            entry.kick.kick();
        }
    }

    fn kick_all_in_guest(&self) -> bool {
        let registrations = self.lock();
        let mut kicked = false;
        for entry in registrations.vcpus.values() {
            if entry.is_in_guest() {
                entry.kick.kick();
                kicked = true;
            }
        }
        kicked
    }

    fn kick_all_except(&self, except: ThreadId) {
        for (tid, entry) in self.lock().vcpus.iter() {
            if *tid != except {
                entry.kick.kick();
            }
        }
    }

    fn any_other_in_guest(&self, except: ThreadId) -> bool {
        self.lock()
            .vcpus
            .iter()
            .any(|(tid, entry)| *tid != except && entry.is_in_guest())
    }

    fn is_in_guest(&self, tid: ThreadId) -> bool {
        self.lock()
            .vcpus
            .get(&tid)
            .is_some_and(VcpuRegistration::is_in_guest)
    }

    fn publish_kernel_wake_debt(&self) {
        let mut state = self.lock();
        let generation = state.next_kernel_wake_generation;
        state.next_kernel_wake_generation = state
            .next_kernel_wake_generation
            .checked_add(1)
            .unwrap_or_else(|| carrick_fatal!("hal::kernel_wake", "wake generation exhausted"));
        for entry in state.vcpus.values_mut() {
            entry.kernel_wake_generation = Some(generation);
        }
        for debt in state.kernel_wake_debts.values_mut() {
            *debt = Some(generation);
        }
    }

    fn retry_kernel_wake_debt(&self) -> KernelWakeRetryPoll {
        let state = self.lock();
        let mut poll = KernelWakeRetryPoll::default();
        for entry in state.vcpus.values() {
            if entry.kernel_wake_generation.is_some() && entry.is_in_guest() {
                poll.owed = true;
                entry.kick.kick();
                poll.kicked = true;
            }
        }
        poll
    }

    fn kernel_wake_debt_for(&self, tid: ThreadId) -> Option<KernelWakeDebt> {
        let state = self.lock();
        let entry = state.vcpus.get(&tid)?;
        entry
            .kernel_wake_generation
            .map(|generation| KernelWakeDebt {
                enrollment: entry.enrollment,
                generation,
            })
    }

    fn acknowledge_kernel_wake_debt(&self, tid: ThreadId, debt: KernelWakeDebt) {
        let mut state = self.lock();
        let Some(entry) = state.vcpus.get_mut(&tid) else {
            return;
        };
        if entry.enrollment == debt.enrollment
            && entry.kernel_wake_generation == Some(debt.generation)
        {
            entry.kernel_wake_generation = None;
            if let Some(pending) = state.kernel_wake_debts.get_mut(&tid)
                && *pending == Some(debt.generation)
            {
                *pending = None;
            }
        }
    }

    fn retire_kernel_wake_debt(&self, tid: ThreadId) {
        let mut state = self.lock();
        state.kernel_wake_debts.remove(&tid);
        if let Some(entry) = state.vcpus.get_mut(&tid) {
            entry.kernel_wake_generation = None;
        }
    }

    fn debug_registered_vcpus(&self) -> Vec<(ThreadId, bool)> {
        let mut snapshot: Vec<_> = self
            .lock()
            .vcpus
            .iter()
            .map(|(tid, entry)| (*tid, entry.is_in_guest()))
            .collect();
        snapshot.sort_by_key(|(tid, _)| tid.raw());
        snapshot
    }
}

#[cfg(test)]
mod generic_registry_tests {
    use super::*;
    use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};

    fn t(raw: i32) -> ThreadId {
        ThreadId::synthetic_for_tests(raw)
    }

    struct CountingHandle(Arc<AtomicU64>);
    impl VcpuKickDyn for CountingHandle {
        fn kick(&self) {
            self.0.fetch_add(1, Ordering::SeqCst);
        }
    }

    fn noop() -> Box<dyn VcpuKickDyn> {
        Box::new(CountingHandle(Arc::new(AtomicU64::new(0))))
    }

    fn register_for_test(
        registry: &GenericVcpuRegistry,
        tid: ThreadId,
        handle: Box<dyn VcpuKickDyn>,
        in_guest: &InGuestFlag,
    ) {
        assert!(matches!(
            registry.subscribe_register(tid, handle, in_guest, Arc::new(|| {})),
            VcpuRegistrationEnrollment::Registered
        ));
    }

    #[test]
    fn lease_drain_is_identity_aware_and_freezes_registration() {
        let registry = GenericVcpuRegistry::new();
        let owner = t(10);
        let sibling = t(20);
        let owner_flag = InGuestFlag::for_guest_thread();
        let sibling_flag = InGuestFlag::for_guest_thread();
        assert!(matches!(
            registry.subscribe_register(owner, noop(), &owner_flag, Arc::new(|| {})),
            VcpuRegistrationEnrollment::Registered
        ));
        assert_eq!(
            registry.poll_lease_drain(owner),
            VcpuLeaseDrainPoll::Complete
        );
        let guard = match registry.subscribe_lease_drain(owner, Arc::new(|| {})) {
            VcpuLeaseDrainEnrollment::Frozen(guard) => guard,
            _ => panic!("sole owner must freeze"),
        };
        assert!(matches!(
            registry.subscribe_register(sibling, noop(), &sibling_flag, Arc::new(|| {})),
            VcpuRegistrationEnrollment::Waiting { owner: waiting, .. } if waiting == owner
        ));
        assert_eq!(
            registry.poll_lease_drain(owner),
            VcpuLeaseDrainPoll::Complete
        );
        drop(guard);
        assert!(matches!(
            registry.subscribe_register(sibling, noop(), &sibling_flag, Arc::new(|| {})),
            VcpuRegistrationEnrollment::Registered
        ));
        assert_eq!(
            registry.poll_lease_drain(owner),
            VcpuLeaseDrainPoll::Waiting(sibling)
        );
    }

    #[test]
    fn lease_drain_absent_owner_still_waits_on_only_registration() {
        let registry = GenericVcpuRegistry::new();
        let absent_owner = t(10);
        let sibling = t(20);
        let sibling_flag = InGuestFlag::for_guest_thread();
        register_for_test(&registry, sibling, noop(), &sibling_flag);

        assert_eq!(
            registry.poll_lease_drain(absent_owner),
            VcpuLeaseDrainPoll::Waiting(sibling)
        );
        assert!(matches!(
            registry.subscribe_lease_drain(absent_owner, Arc::new(|| {})),
            VcpuLeaseDrainEnrollment::Waiting { tid, .. } if tid == sibling
        ));
    }

    #[test]
    fn lease_drain_returns_lowest_sibling_identity() {
        let registry = GenericVcpuRegistry::new();
        let owner = t(10);
        let owner_flag = InGuestFlag::for_guest_thread();
        let high_flag = InGuestFlag::for_guest_thread();
        let low_flag = InGuestFlag::for_guest_thread();
        register_for_test(&registry, owner, noop(), &owner_flag);
        register_for_test(&registry, t(30), noop(), &high_flag);
        register_for_test(&registry, t(20), noop(), &low_flag);

        assert_eq!(
            registry.poll_lease_drain(owner),
            VcpuLeaseDrainPoll::Waiting(t(20))
        );
        assert!(matches!(
            registry.subscribe_lease_drain(owner, Arc::new(|| {})),
            VcpuLeaseDrainEnrollment::Waiting { tid, .. } if tid == t(20)
        ));
    }

    #[test]
    fn lease_drain_same_owner_reentry_is_busy() {
        let registry = GenericVcpuRegistry::new();
        let owner = t(10);
        let guard = match registry.subscribe_lease_drain(owner, Arc::new(|| {})) {
            VcpuLeaseDrainEnrollment::Frozen(guard) => guard,
            _ => panic!("empty registry must freeze"),
        };

        assert!(matches!(
            registry.subscribe_lease_drain(owner, Arc::new(|| {})),
            VcpuLeaseDrainEnrollment::Busy { owner: busy, .. } if busy == owner
        ));
        drop(guard);
    }

    #[test]
    fn lease_guard_drop_wakes_busy_drain_and_registration_waiters() {
        let registry = GenericVcpuRegistry::new();
        let owner = t(10);
        let sibling = t(20);
        let sibling_flag = InGuestFlag::for_guest_thread();
        let drain_wakes = Arc::new(AtomicUsize::new(0));
        let registration_wakes = Arc::new(AtomicUsize::new(0));
        let guard = match registry.subscribe_lease_drain(owner, Arc::new(|| {})) {
            VcpuLeaseDrainEnrollment::Frozen(guard) => guard,
            _ => panic!("empty registry must freeze"),
        };
        let drain_wakes_for_callback = Arc::clone(&drain_wakes);
        let drain_wait = registry.subscribe_lease_drain(
            t(30),
            Arc::new(move || {
                drain_wakes_for_callback.fetch_add(1, Ordering::SeqCst);
            }),
        );
        assert!(matches!(
            &drain_wait,
            VcpuLeaseDrainEnrollment::Busy { owner: busy, .. } if *busy == owner
        ));
        let registration_wakes_for_callback = Arc::clone(&registration_wakes);
        let registration_wait = registry.subscribe_register(
            sibling,
            noop(),
            &sibling_flag,
            Arc::new(move || {
                registration_wakes_for_callback.fetch_add(1, Ordering::SeqCst);
            }),
        );
        assert!(matches!(
            &registration_wait,
            VcpuRegistrationEnrollment::Waiting { owner: busy, .. } if *busy == owner
        ));

        assert_eq!(drain_wakes.load(Ordering::SeqCst), 0);
        assert_eq!(registration_wakes.load(Ordering::SeqCst), 0);
        drop(guard);
        assert_eq!(drain_wakes.load(Ordering::SeqCst), 1);
        assert_eq!(registration_wakes.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn lease_membership_mutation_wakes_waiter_after_removal() {
        let registry = GenericVcpuRegistry::new();
        let owner = t(10);
        let sibling = t(20);
        let sibling_flag = InGuestFlag::for_guest_thread();
        register_for_test(&registry, sibling, noop(), &sibling_flag);
        let wakes = Arc::new(AtomicUsize::new(0));
        let wakes_for_callback = Arc::clone(&wakes);
        let wait = registry.subscribe_lease_drain(
            owner,
            Arc::new(move || {
                wakes_for_callback.fetch_add(1, Ordering::SeqCst);
            }),
        );
        assert!(matches!(
            &wait,
            VcpuLeaseDrainEnrollment::Waiting { tid, .. } if *tid == sibling
        ));

        assert_eq!(wakes.load(Ordering::SeqCst), 0);
        registry.unregister(sibling);
        assert_eq!(wakes.load(Ordering::SeqCst), 1);
    }

    #[test]
    fn lease_registration_replacement_does_not_publish_membership_change() {
        let registry = GenericVcpuRegistry::new();
        let owner = t(10);
        let sibling = t(20);
        let first_flag = InGuestFlag::for_guest_thread();
        let replacement_flag = InGuestFlag::for_guest_thread();
        register_for_test(&registry, sibling, noop(), &first_flag);
        let wakes = Arc::new(AtomicUsize::new(0));
        let wakes_for_callback = Arc::clone(&wakes);
        let wait = registry.subscribe_lease_drain(
            owner,
            Arc::new(move || {
                wakes_for_callback.fetch_add(1, Ordering::SeqCst);
            }),
        );
        assert!(matches!(
            &wait,
            VcpuLeaseDrainEnrollment::Waiting { tid, .. } if *tid == sibling
        ));

        register_for_test(&registry, sibling, noop(), &replacement_flag);
        assert_eq!(wakes.load(Ordering::SeqCst), 0);
    }

    #[test]
    fn lease_subscription_drop_cancels_only_unclaimed_listener() {
        let registry = GenericVcpuRegistry::new();
        let owner = t(10);
        let sibling = t(20);
        let sibling_flag = InGuestFlag::for_guest_thread();
        register_for_test(&registry, sibling, noop(), &sibling_flag);
        let cancelled_wakes = Arc::new(AtomicUsize::new(0));
        let retained_wakes = Arc::new(AtomicUsize::new(0));
        let cancelled_wakes_for_callback = Arc::clone(&cancelled_wakes);
        let cancelled = registry.subscribe_lease_drain(
            owner,
            Arc::new(move || {
                cancelled_wakes_for_callback.fetch_add(1, Ordering::SeqCst);
            }),
        );
        let retained_wakes_for_callback = Arc::clone(&retained_wakes);
        let retained = registry.subscribe_lease_drain(
            owner,
            Arc::new(move || {
                retained_wakes_for_callback.fetch_add(1, Ordering::SeqCst);
            }),
        );

        drop(cancelled);
        registry.unregister(sibling);
        assert_eq!(cancelled_wakes.load(Ordering::SeqCst), 0);
        assert_eq!(retained_wakes.load(Ordering::SeqCst), 1);
        drop(retained);
    }

    #[test]
    fn register_unregister_tracks_exact_identities() {
        let r = GenericVcpuRegistry::new();
        let observer = t(99);
        let f1 = InGuestFlag::for_guest_thread();
        let f2 = InGuestFlag::for_guest_thread();
        assert_eq!(r.poll_lease_drain(observer), VcpuLeaseDrainPoll::Complete);
        register_for_test(&r, t(1), noop(), &f1);
        register_for_test(&r, t(2), noop(), &f2);
        assert_eq!(
            r.poll_lease_drain(observer),
            VcpuLeaseDrainPoll::Waiting(t(1))
        );
        r.unregister(t(1));
        assert_eq!(
            r.poll_lease_drain(observer),
            VcpuLeaseDrainPoll::Waiting(t(2))
        );
        r.unregister(t(2));
        assert_eq!(r.poll_lease_drain(observer), VcpuLeaseDrainPoll::Complete);
    }

    #[test]
    fn kick_all_except_skips_caller() {
        let r = GenericVcpuRegistry::new();
        let c1 = Arc::new(AtomicU64::new(0));
        let c2 = Arc::new(AtomicU64::new(0));
        let f1 = InGuestFlag::for_guest_thread();
        let f2 = InGuestFlag::for_guest_thread();
        register_for_test(&r, t(1), Box::new(CountingHandle(Arc::clone(&c1))), &f1);
        register_for_test(&r, t(2), Box::new(CountingHandle(Arc::clone(&c2))), &f2);
        r.kick_all_except(t(1));
        assert_eq!(c1.load(Ordering::SeqCst), 0, "caller must not be kicked");
        assert_eq!(c2.load(Ordering::SeqCst), 1, "the other vCPU is kicked");
        r.kick_all();
        assert_eq!(c1.load(Ordering::SeqCst), 1);
        assert_eq!(c2.load(Ordering::SeqCst), 2);
    }

    #[test]
    fn in_guest_flag_handshake() {
        let r = GenericVcpuRegistry::new();
        let f1 = InGuestFlag::for_guest_thread();
        let f2 = InGuestFlag::for_guest_thread();
        register_for_test(&r, t(1), noop(), &f1);
        register_for_test(&r, t(2), noop(), &f2);
        assert!(!r.any_other_in_guest(t(1)));
        f2.enter_guest();
        assert!(r.any_other_in_guest(t(1)), "tid 2 is in-guest");
        assert!(!r.any_other_in_guest(t(2)), "except self → false");
        f2.leave_guest();
        assert!(!r.any_other_in_guest(t(1)));
    }

    /// An unregistered thread holds no live vCPU: it is neither kickable nor
    /// visible as in-guest, even though it still owns its flag.
    #[test]
    fn unregistered_thread_is_invisible_to_the_drain() {
        let r = GenericVcpuRegistry::new();
        let f1 = InGuestFlag::for_guest_thread();
        let f2 = InGuestFlag::for_guest_thread();
        register_for_test(&r, t(1), noop(), &f1);
        register_for_test(&r, t(2), noop(), &f2);
        f1.enter_guest();
        assert!(r.any_other_in_guest(t(2)));
        r.unregister(t(1));
        assert!(
            !r.any_other_in_guest(t(2)),
            "a thread with no live vCPU cannot be in the guest"
        );
        assert_eq!(r.debug_registered_vcpus(), vec![(t(2), false)]);
    }

    /// RED-FIRST reproducer for the in-guest registry decay.
    ///
    /// A guest thread obtains its in-guest flag ONCE (at
    /// `ThreadRuntimeState::new`) and stores into that same `Arc` for its whole
    /// life. Every blocking wait on a kicker-refreshing backend (HVF) and every
    /// fork park unregisters the thread and then re-registers only its kick
    /// handle. If `unregister` drops the in-guest facet and re-registration does
    /// not restore it, the thread's stores land in an `Arc` the registry no
    /// longer references and `any_other_in_guest` reports FALSE for a thread
    /// that is executing guest code — the page-table-edit coordinator then
    /// edits stage-1 descriptors under a live vCPU.
    #[test]
    fn reregistration_keeps_the_in_guest_facet() {
        let r = GenericVcpuRegistry::new();
        let blocker = t(1);
        let coordinator = t(2);
        // Each thread's ONE lifetime flag, as `ThreadRuntimeState::new` makes it.
        let blocker_in_guest = InGuestFlag::for_guest_thread();
        let coordinator_in_guest = InGuestFlag::for_guest_thread();
        register_for_test(&r, blocker, noop(), &blocker_in_guest);
        register_for_test(&r, coordinator, noop(), &coordinator_in_guest);

        // The thread blocks: a kicker-refreshing backend unregisters it while
        // it has no live vCPU.
        r.unregister(blocker);
        // It wakes, rebinds a vCPU and re-registers — exactly what
        // `ThreadRuntimeState::subscribe_register_vcpu` does, with the same
        // flag.
        register_for_test(&r, blocker, noop(), &blocker_in_guest);

        // It re-enters the guest through the flag it has held since birth.
        blocker_in_guest.enter_guest();
        assert!(
            r.any_other_in_guest(coordinator),
            "a re-registered thread that entered the guest must be visible to \
             the page-table-edit coordinator's drain"
        );
        assert_eq!(
            r.debug_registered_vcpus(),
            vec![(blocker, true), (coordinator, false)],
            "the timeout diagnostic must read the same authority as the predicate"
        );
    }

    #[test]
    fn kernel_wake_published_during_lease_gap_survives_rebind() {
        for scale in [1, 8, 32, 128] {
            let r = GenericVcpuRegistry::new();
            let a = t(1);
            let flag = InGuestFlag::for_guest_thread();
            register_for_test(&r, a, noop(), &flag);
            for _ in 0..scale {
                r.unregister(a);
                r.publish_kernel_wake_debt();
                register_for_test(&r, a, noop(), &flag);
                let debt = r
                    .kernel_wake_debt_for(a)
                    .expect("a live thread must retain wakes published without a physical lease");
                r.acknowledge_kernel_wake_debt(a, debt);
                assert_eq!(r.kernel_wake_debt_for(a), None);
                assert_eq!(
                    r.lock().kernel_wake_debts.len(),
                    1,
                    "lease cycling retains one record per logical thread"
                );
            }
            r.unregister(a);
            r.retire_kernel_wake_debt(a);
            assert!(
                r.lock().kernel_wake_debts.is_empty(),
                "logical retirement must release its wake record"
            );
            r.publish_kernel_wake_debt();
            register_for_test(&r, a, noop(), &flag);
            assert_eq!(
                r.kernel_wake_debt_for(a),
                None,
                "retired identities must not collect future wake debt"
            );
        }
    }

    #[test]
    fn kernel_wake_debt_survives_exact_tid_rebind_only() {
        let r = GenericVcpuRegistry::new();
        let a = t(1);
        let b = t(2);
        let a_flag = InGuestFlag::for_guest_thread();
        let b_flag = InGuestFlag::for_guest_thread();
        register_for_test(&r, a, noop(), &a_flag);
        r.publish_kernel_wake_debt();
        let old = r.kernel_wake_debt_for(a).expect("A owes the publication");

        r.unregister(a);
        register_for_test(&r, b, noop(), &b_flag);
        assert_eq!(
            r.kernel_wake_debt_for(b),
            None,
            "unrelated B must not inherit A's debt"
        );
        register_for_test(&r, a, noop(), &a_flag);
        let rebound = r
            .kernel_wake_debt_for(a)
            .expect("A's temporary lease gap preserves debt");
        assert_ne!(rebound.enrollment, old.enrollment);
        assert_eq!(rebound.generation, old.generation);

        r.acknowledge_kernel_wake_debt(a, old);
        assert_eq!(
            r.kernel_wake_debt_for(a),
            Some(rebound),
            "stale enrollment cannot acknowledge rebound A"
        );
        r.acknowledge_kernel_wake_debt(a, rebound);
        assert_eq!(r.kernel_wake_debt_for(a), None);
    }

    #[test]
    fn retiring_a_thread_discards_its_dormant_kernel_wake_debt() {
        let r = GenericVcpuRegistry::new();
        let a = t(1);
        let flag = InGuestFlag::for_guest_thread();
        register_for_test(&r, a, noop(), &flag);
        r.publish_kernel_wake_debt();
        r.unregister(a);
        r.retire_kernel_wake_debt(a);
        register_for_test(&r, a, noop(), &flag);
        assert_eq!(r.kernel_wake_debt_for(a), None);
    }

    #[test]
    fn kernel_wake_retry_kicks_only_live_debt_in_guest() {
        let r = GenericVcpuRegistry::new();
        let tid = t(1);
        let kicks = Arc::new(AtomicU64::new(0));
        let flag = InGuestFlag::for_guest_thread();
        register_for_test(&r, tid, Box::new(CountingHandle(Arc::clone(&kicks))), &flag);
        r.publish_kernel_wake_debt();
        assert_eq!(r.retry_kernel_wake_debt(), KernelWakeRetryPoll::default());
        flag.enter_guest();
        assert_eq!(
            r.retry_kernel_wake_debt(),
            KernelWakeRetryPoll {
                owed: true,
                kicked: true
            }
        );
        assert_eq!(kicks.load(Ordering::SeqCst), 1);
        flag.leave_guest();
        assert_eq!(r.retry_kernel_wake_debt(), KernelWakeRetryPoll::default());
        assert!(
            r.kernel_wake_debt_for(tid).is_some(),
            "host residency disarms polling without acknowledging debt"
        );
    }

    #[test]
    fn sibling_ack_cannot_clear_an_in_guest_participants_debt() {
        let r = GenericVcpuRegistry::new();
        let a = t(1);
        let b = t(2);
        let a_flag = InGuestFlag::for_guest_thread();
        let b_flag = InGuestFlag::for_guest_thread();
        register_for_test(&r, a, noop(), &a_flag);
        register_for_test(&r, b, noop(), &b_flag);
        r.publish_kernel_wake_debt();
        let a_debt = r.kernel_wake_debt_for(a).unwrap();
        let b_debt = r.kernel_wake_debt_for(b).unwrap();
        a_flag.enter_guest();
        r.acknowledge_kernel_wake_debt(b, b_debt);
        assert_eq!(r.kernel_wake_debt_for(a), Some(a_debt));
        assert!(r.retry_kernel_wake_debt().owed);
    }
}

/// Outcome of a stage-1 COW write-fault resolution attempt.
///
/// `Resolved.translation` is the live post-resolution stage-1 output for the
/// fault VA (`None` when the resolver cannot name it). The refault livelock
/// detector keys on it: a recurring identical `(FAR, ESR)` whose resolved
/// translation ALSO repeats proves the resolver made no progress, while a
/// fork loop legitimately re-COWs the same VA to a fresh frame each
/// iteration — fork re-arms the parent's span and the wait loop rewrites the
/// same stack slot, so `(FAR, ESR)` alone is not evidence of a livelock.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CowFaultResolution {
    /// Not a COW-resolvable fault; ordinary fault delivery proceeds.
    NotCow,
    /// The mm now owns a writable frame for the fault; retry the instruction.
    Resolved { translation: Option<u64> },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FutexOutcome {
    Woken,
    TimedOut,
    Interrupted,
}

/// The private + shared futex backend. HVF: parking-lot `FutexTable` (private) +
/// `os_sync_wait_on_address` (shared). KVM: real host `SYS_futex` for both.
pub trait PlatformFutex: Send + Sync {
    fn private_wait(
        &self,
        addr: u64,
        val: u32,
        tid: ThreadId,
        timeout: Option<Duration>,
        interrupted: &dyn Fn() -> bool,
    ) -> FutexOutcome;
    fn private_wake(&self, addr: u64, n: u32) -> u32;
    /// Wait on a `MAP_SHARED` guest futex.
    ///
    /// `tid` is load-bearing: the waiter parks under that thread's park token so
    /// a THREAD-directed signal (`tgkill`) can wake exactly this waiter. The
    /// previous cross-process implementation could not be targeted that way and
    /// had to poll its interrupt predicate on a 20 ms slice instead.
    fn shared_wait(
        &self,
        location: SharedFutexLocation,
        val: u32,
        tid: ThreadId,
        timeout: Option<Duration>,
        interrupted: &dyn Fn() -> bool,
        wait_enrolled: &dyn Fn(),
    ) -> i64;
    fn shared_wake(&self, location: SharedFutexLocation, waiter_key: usize, n: u32) -> i64;
    fn shared_requeue(
        &self,
        _from: SharedFutexLocation,
        _from_key: usize,
        _to: SharedFutexLocation,
        _to_key: usize,
        _wake: u32,
        _requeue: u32,
    ) -> (u32, u32) {
        (0, 0)
    }
    fn requeue(&self, from: u64, to: u64, wake: u32, requeue: u32) -> (u32, u32);
    /// Wake every private-futex waiter so it re-checks its interrupt predicate
    /// (a process-directed signal became pending, or a fork/exec quiesce was
    /// requested). Does not consume the futex word; a spurious wake just costs a
    /// re-check.
    fn notify_signal_pending(&self);
    /// Wake the private-futex waiter parked for `tid` (a thread-directed signal).
    fn notify_signal_pending_for(&self, tid: ThreadId);
}

/// One standard-format XSAVE component range reported by CPUID leaf 0xD.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct X86XstateComponent {
    pub offset: u32,
    pub size: u32,
}

impl X86XstateComponent {
    pub const fn new(offset: u32, size: u32) -> Self {
        Self { offset, size }
    }

    pub fn end(self) -> Option<usize> {
        usize::try_from(self.offset)
            .ok()?
            .checked_add(usize::try_from(self.size).ok()?)
    }
}

/// Cached x86 user-xstate geometry used by the signal-frame codec. Component 9
/// (PKRU) is deliberately absent for the native lane: its guest value is a
/// Carrick virtual scalar and must never reach hardware XRSTOR.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct X86XstateCapabilities {
    pub supported_features: u64,
    pub standard_size: u32,
    pub mxcsr_mask: u32,
    pub components: [X86XstateComponent; 64],
}

impl X86XstateCapabilities {
    /// Compatibility geometry for x86 VMM backends whose existing batch seam
    /// carries the legacy area and AVX YMM_Hi component.
    pub const fn legacy_avx() -> Self {
        let mut components = [X86XstateComponent { offset: 0, size: 0 }; 64];
        components[2] = X86XstateComponent::new(576, 256);
        Self {
            supported_features: 0x7,
            standard_size: 832,
            mxcsr_mask: 0x0000_ffbf,
            components,
        }
    }

    pub fn component(self, number: u32) -> Option<X86XstateComponent> {
        let index = usize::try_from(number).ok()?;
        let component = *self.components.get(index)?;
        (component.size != 0).then_some(component)
    }

    /// Exact standard-format extent required by a supported feature subset.
    pub fn standard_size_for(self, features: u64) -> Option<usize> {
        if features & !self.supported_features != 0 || features & 0x3 != 0x3 {
            return None;
        }
        let mut end = carrick_abi::X8664_XSAVE_MIN_LEN;
        for number in 2..64u32 {
            if features & (1u64 << number) == 0 {
                continue;
            }
            end = end.max(self.component(number)?.end()?);
        }
        (end <= carrick_abi::X8664_XSAVE_AREA_MAX_LEN).then_some(end)
    }
}

/// Complete standard-format x86 signal state passed through one architecture-
/// specific batch seam. The byte vector begins with the 512-byte legacy area
/// and includes the 64-byte standard XSAVE header and every advertised
/// component at its CPUID leaf 0xD offset. Linux magic words and Carrick's PKRU
/// trailer are frame metadata and are not part of this image.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct X86SignalXstate {
    pub bytes: Vec<u8>,
    pub xfeatures: u64,
    pub virtual_pkru: u32,
    pub virtual_x87_fcs: u16,
    pub virtual_x87_fds: u16,
}

/// Get/set the registers + FP/SIMD state the shared sigframe builders need.
///
/// This is a sigframe/trap-loop adapter, not a claim that every guest ISA has
/// every [`Reg`] / [`SysReg`] variant. Narrower native engine traits translate
/// into this shape at the shared boundary.
pub trait RegAccess {
    fn get_reg(&self, r: Reg) -> Result<u64, OsError>;
    fn set_reg(&mut self, r: Reg, v: u64) -> Result<(), OsError>;
    fn get_sys_reg(&self, r: SysReg) -> Result<u64, OsError>;
    fn set_sys_reg(&mut self, r: SysReg, v: u64) -> Result<(), OsError>;
    fn get_vreg(&self, n: u32) -> Result<u128, OsError>;
    fn set_vreg(&mut self, n: u32, v: u128) -> Result<(), OsError>;
    /// The upper 128 bits of YMM\[n\] (the AVX `YMM_Hi` XSAVE component). Used by
    /// the x86 signal frame to preserve a thread's AVX upper halves across a
    /// signal+sigreturn — the FXSAVE area `get_vreg` reads holds only the low
    /// 128 bits (XMM). DEFAULT 0: a backend without AVX state (aarch64's 128-bit
    /// V-regs are fully covered by `get_vreg`) has no upper half to report.
    fn get_ymm_hi(&self, _n: u32) -> Result<u128, OsError> {
        Ok(0)
    }
    /// Set the upper 128 bits of YMM\[n\]. DEFAULT no-op (no AVX state).
    fn set_ymm_hi(&mut self, _n: u32, _v: u128) -> Result<(), OsError> {
        Ok(())
    }
    fn get_fpcr(&self) -> Result<u64, OsError>;
    fn set_fpcr(&mut self, v: u64) -> Result<(), OsError>;
    fn get_fpsr(&self) -> Result<u64, OsError>;
    fn set_fpsr(&mut self, v: u64) -> Result<(), OsError>;

    /// Capabilities for the x86 batch signal-state seam. Non-x86 callers never
    /// invoke this default; legacy x86 VMMs retain their AVX-era geometry.
    fn x86_xstate_capabilities(&self) -> Result<X86XstateCapabilities, OsError> {
        Ok(X86XstateCapabilities::legacy_avx())
    }

    /// Export all authoritative guest xstate in standard format. Native x86
    /// overrides this with a direct snapshot copy using cached CPUID geometry.
    fn save_x86_signal_xstate(&mut self) -> Result<X86SignalXstate, OsError> {
        let (mxcsr, xmm, ymm_hi) = self.save_fpsimd_frame()?;
        let caps = self.x86_xstate_capabilities()?;
        let size = usize::try_from(caps.standard_size).map_err(|_| OsError::from_raw(libc::EIO))?;
        if !(832..=carrick_abi::X8664_XSAVE_AREA_MAX_LEN).contains(&size) {
            return Err(OsError::from_raw(libc::EIO));
        }
        let mut bytes = vec![0u8; size];
        bytes[0..2].copy_from_slice(&0x037fu16.to_le_bytes());
        bytes[24..28].copy_from_slice(&mxcsr.to_le_bytes());
        bytes[28..32].copy_from_slice(&caps.mxcsr_mask.to_le_bytes());
        for (index, word) in xmm.iter().enumerate() {
            let offset = 160 + index * 4;
            bytes[offset..offset + 4].copy_from_slice(&word.to_le_bytes());
        }
        bytes[512..520].copy_from_slice(&0x7u64.to_le_bytes());
        bytes[576..832].copy_from_slice(&ymm_hi);
        Ok(X86SignalXstate {
            bytes,
            xfeatures: 0x7,
            virtual_pkru: 0,
            virtual_x87_fcs: carrick_abi::LINUX_X8664_USER_CS,
            virtual_x87_fds: carrick_abi::LINUX_X8664_USER_DS,
        })
    }

    /// Import a fully validated standard-format image. Native x86 overrides
    /// this to commit one temporary complete snapshot plus virtual PKRU.
    fn restore_x86_signal_xstate(&mut self, state: &X86SignalXstate) -> Result<(), OsError> {
        if state.bytes.len() < carrick_abi::X8664_XSAVE_MIN_LEN {
            return Err(OsError::from_raw(libc::EINVAL));
        }
        let mut mxcsr_bytes = [0u8; 4];
        mxcsr_bytes.copy_from_slice(&state.bytes[24..28]);
        let mxcsr = u32::from_le_bytes(mxcsr_bytes);
        let mut xmm = [0u32; 64];
        for (index, word) in xmm.iter_mut().enumerate() {
            let offset = 160 + index * 4;
            let mut bytes = [0u8; 4];
            bytes.copy_from_slice(&state.bytes[offset..offset + 4]);
            *word = u32::from_le_bytes(bytes);
        }
        let mut ymm_hi = [0u8; 256];
        if state.xfeatures & (1 << 2) != 0 {
            let end = 832usize;
            if state.bytes.len() < end {
                return Err(OsError::from_raw(libc::EINVAL));
            }
            ymm_hi.copy_from_slice(&state.bytes[576..end]);
        }
        self.restore_fpsimd_frame(mxcsr, &xmm, &ymm_hi)
    }

    /// Save the legacy x86 FP/SIMD subset. Kept for existing VMM adapters; new
    /// signal codecs use [`RegAccess::save_x86_signal_xstate`].
    fn save_fpsimd_frame(&mut self) -> Result<(u32, [u32; 64], [u8; 256]), OsError> {
        let mxcsr = self.get_fpcr()? as u32;
        let mut xmm = [0u32; 64];
        let mut ymm_hi = [0u8; 256];
        for n in 0..16u32 {
            let v = self.get_vreg(n)?.to_le_bytes();
            let b = (n * 4) as usize;
            for j in 0..4 {
                xmm[b + j] =
                    u32::from_le_bytes([v[j * 4], v[j * 4 + 1], v[j * 4 + 2], v[j * 4 + 3]]);
            }
            let off = n as usize * 16;
            ymm_hi[off..off + 16].copy_from_slice(&self.get_ymm_hi(n)?.to_le_bytes());
        }
        Ok((mxcsr, xmm, ymm_hi))
    }

    /// Restore the FP/SIMD state from an x86 signal frame (inverse of
    /// [`RegAccess::save_fpsimd_frame`]). DEFAULT loops the per-register setters;
    /// the x86 engine overrides with ONE `KVM_GET_XSAVE` + ONE `KVM_SET_XSAVE`,
    /// replacing ~80 per-register ioctls per signal RETURN.
    fn restore_fpsimd_frame(
        &mut self,
        mxcsr: u32,
        xmm: &[u32; 64],
        ymm_hi: &[u8; 256],
    ) -> Result<(), OsError> {
        self.set_fpcr(u64::from(mxcsr))?;
        for n in 0..16u32 {
            let b = (n * 4) as usize;
            let mut raw = [0u8; 16];
            for j in 0..4 {
                raw[j * 4..j * 4 + 4].copy_from_slice(&xmm[b + j].to_le_bytes());
            }
            self.set_vreg(n, u128::from_le_bytes(raw))?;
            let off = n as usize * 16;
            let mut hi = [0u8; 16];
            hi.copy_from_slice(&ymm_hi[off..off + 16]);
            self.set_ymm_hi(n, u128::from_le_bytes(hi))?;
        }
        Ok(())
    }
}

/// Read the aarch64 Linux syscall-argument frame — `x0..x5` (the 6 args) + `x8`
/// (the syscall number) — from a vCPU via a register getter.
///
/// Both aarch64 backends (HVF, KVM) extract the IDENTICAL frame on every `svc`
/// trap; this single-sources the register set so it lives in ONE place, a step
/// toward the `Aarch64EngineCore` symmetry with `carrick_x86` (F7). Takes a
/// `get` closure rather than `&impl RegAccess` because HVF reads inside its inner
/// engine (which is not itself the `RegAccess` impl). Each backend maps the
/// [`OsError`] to its own `TrapError` at the call site.
pub fn read_aarch64_syscall_frame(
    mut get: impl FnMut(Reg) -> Result<u64, OsError>,
) -> Result<carrick_guest_mem::Aarch64SyscallFrame, OsError> {
    Ok(carrick_guest_mem::Aarch64SyscallFrame {
        x0: get(Reg::X(0))?,
        x1: get(Reg::X(1))?,
        x2: get(Reg::X(2))?,
        x3: get(Reg::X(3))?,
        x4: get(Reg::X(4))?,
        x5: get(Reg::X(5))?,
        x8: get(Reg::X(8))?,
    })
}

/// Select the PSTATE to save into an aarch64 signal frame.
///
/// The two aarch64 backends agree on the rule: the KICK path (a host signal
/// interrupted the guest mid-EL0, so `interrupted_pc` is set) saves the LIVE EL0
/// PSTATE; the SYSCALL/eret path (`interrupted_pc == None`) saves `SPSR_EL1`,
/// where the `svc` latched the EL0 PSTATE. Single-sourced here (F7).
///
/// `live_pstate` lets a caller that ALREADY read the live PSTATE (HVF reads it
/// for its EL-discrimination) reuse it instead of re-reading; `None` reads it
/// fresh (KVM).
pub fn aarch64_signal_pstate_source(
    interrupted_pc: Option<u64>,
    live_pstate: Option<u64>,
    get: impl Fn(Reg) -> Result<u64, OsError>,
) -> Result<u64, OsError> {
    if interrupted_pc.is_some() {
        match live_pstate {
            Some(p) => Ok(p),
            None => get(Reg::Pstate),
        }
    } else {
        get(Reg::SpsrEl1)
    }
}

/// The bound the shared threaded loop is generic over. A backend is its own
/// trap vehicle + register access + current guest memory + per-thread/fork lifecycle.
/// `CurrentMmMemory` is a supertrait so the shared loop can `write_bytes` to the
/// caller's current MM (tid stamps, clone parent/child-tid writes) through the engine.
/// ISA-neutral entry register deltas for a freshly-created guest execution
/// context — a `clone(CLONE_THREAD)` sibling thread or a `fork(2)` child.
///
/// Each backend maps these named fields onto its ISA registers when seeding a
/// vCPU snapshot, so adding an architecture is "map three named values onto my
/// register file," not "reimplement entry seeding." `None` means "inherit the
/// parent's value" (a fork child inherits stack+tls via COW; a clone sibling
/// supplies fresh ones).
///
/// | field          | aarch64       | x86_64      |
/// |----------------|---------------|-------------|
/// | `return_value` | `X0`          | `RAX`       |
/// | `stack`        | `SP_EL0`      | `RSP`       |
/// | `tls`          | `TPIDR_EL0`   | `FS.base`   |
///
/// The resume PC is intentionally NOT here — it is backend-derived (aarch64
/// `ELR_EL1`; x86_64 the `SYSRETQ` after the doorbell), not caller-supplied.
#[derive(Clone, Copy, Debug, Default)]
pub struct GuestEntryRegs {
    pub return_value: u64,
    pub stack: Option<u64>,
    pub tls: Option<u64>,
}

/// Single 4 KiB leaf disposition for fork projection.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ForkLeafDisposition {
    Preserve,
    Zero,
    Omit,
}

/// A 4 KiB-aligned semantic range covering live or omitted semantic leaves.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ForkProjectionRange {
    pub va: u64,
    pub len: u64,
    pub disposition: ForkLeafDisposition,
}

/// Type-bound fork projection plan ensuring MM sharing mode and projection ranges
/// cannot disagree.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ForkProjectionPlan {
    Shared {
        parent_mm: u64,
        ranges: std::sync::Arc<[ForkProjectionRange]>,
    },
    Copied {
        parent_mm: u64,
        child_mm: u64,
        ranges: std::sync::Arc<[ForkProjectionRange]>,
    },
}

impl ForkProjectionPlan {
    pub fn is_shared(&self) -> bool {
        matches!(self, Self::Shared { .. })
    }

    pub fn ranges(&self) -> &std::sync::Arc<[ForkProjectionRange]> {
        match self {
            Self::Shared { ranges, .. } | Self::Copied { ranges, .. } => ranges,
        }
    }

    pub fn parent_mm(&self) -> u64 {
        match self {
            Self::Shared { parent_mm, .. } | Self::Copied { parent_mm, .. } => *parent_mm,
        }
    }

    pub fn child_mm(&self) -> u64 {
        match self {
            Self::Shared { parent_mm, .. } => *parent_mm,
            Self::Copied { child_mm, .. } => *child_mm,
        }
    }
}

/// Look up the fork projection disposition for a single 4 KiB page VA.
/// Returns None if the VA is not covered by any semantic VMA (i.e. absent/unmapped).
pub fn lookup_fork_projection(
    ranges: &[ForkProjectionRange],
    page_va: u64,
) -> Option<ForkLeafDisposition> {
    let idx = ranges.partition_point(|r| r.va <= page_va);
    if idx > 0 {
        let r = &ranges[idx - 1];
        if r.va.checked_add(r.len).is_some_and(|end| page_va < end) {
            return Some(r.disposition);
        }
    }
    None
}

/// Error returned when fork projection validation fails.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ForkProjectionError {
    ZeroLength,
    /// A range whose `va` or `len` is not 4 KiB aligned. Carries the exact
    /// offending pair: the rejection is otherwise indistinguishable from any
    /// other unaligned VMA in the address space, and the guest only sees
    /// `fork(2) = EAGAIN`.
    Unaligned {
        va: u64,
        len: u64,
    },
    Overflow,
    OverlappingOrUnsorted,
    IncompleteCoverage,
}

impl std::fmt::Display for ForkProjectionError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::ZeroLength => write!(f, "zero length projection range"),
            Self::Unaligned { va, len } => write!(
                f,
                "unaligned projection range va={va:#x} len={len:#x} \
                 (va&0xfff={:#x}, len&0xfff={:#x})",
                va & 0xFFF,
                len & 0xFFF
            ),
            Self::Overflow => write!(f, "projection range overflow"),
            Self::OverlappingOrUnsorted => write!(f, "overlapping or unsorted projection ranges"),
            Self::IncompleteCoverage => write!(f, "projection does not exactly cover live VMAs"),
        }
    }
}

/// Validate a total fork projection against the exact live semantic VMA ranges.
/// Holes between live VMAs remain absent; each live VMA must have one exact,
/// typed projection range, so missing coverage can never default to Preserve.
pub fn validate_total_fork_projection(
    ranges: &[ForkProjectionRange],
    live_vmas: &[(u64, u64)],
) -> Result<(), ForkProjectionError> {
    validate_fork_projection(ranges)?;
    if ranges.len() != live_vmas.len() {
        return Err(ForkProjectionError::IncompleteCoverage);
    }
    for (range, &(start, end)) in ranges.iter().zip(live_vmas) {
        let len = end
            .checked_sub(start)
            .filter(|len| *len != 0)
            .ok_or(ForkProjectionError::ZeroLength)?;
        if range.va != start || range.len != len {
            return Err(ForkProjectionError::IncompleteCoverage);
        }
    }
    Ok(())
}

impl std::error::Error for ForkProjectionError {}

/// Validate that a fork projection range slice is sorted, non-overlapping,
/// 4 KiB aligned, and has nonzero lengths.
pub fn validate_fork_projection(ranges: &[ForkProjectionRange]) -> Result<(), ForkProjectionError> {
    let mut prev_end = 0u64;
    for (i, r) in ranges.iter().enumerate() {
        if r.len == 0 {
            return Err(ForkProjectionError::ZeroLength);
        }
        if r.va & 0xFFF != 0 || r.len & 0xFFF != 0 {
            return Err(ForkProjectionError::Unaligned {
                va: r.va,
                len: r.len,
            });
        }
        let end =
            r.va.checked_add(r.len)
                .ok_or(ForkProjectionError::Overflow)?;
        if i > 0 && r.va < prev_end {
            return Err(ForkProjectionError::OverlappingOrUnsorted);
        }
        prev_end = end;
    }
    Ok(())
}

/// Complete AArch64 input for materializing a logical process inside one
/// persistent backend VM. The root-slot fields describe the current HVPatch
/// execution adapter; other backends retain the default unsupported method.
#[derive(Debug)]
pub struct ProcessForkRequest {
    pub entry: GuestEntryRegs,
    pub child_ttbr0: u64,
    pub root_slot_base: u64,
    pub root_slot_size: u64,
    pub plan: ForkProjectionPlan,
    pub child_tid: ThreadId,
    pub forking_tid: ThreadId,
    pub table_arena_source: Option<Box<dyn carrick_mem::page_table::TableArenaSource>>,
}

impl ProcessForkRequest {
    pub fn shares_mm(&self) -> bool {
        self.plan.is_shared()
    }

    pub fn projection_plan(&self) -> &std::sync::Arc<[ForkProjectionRange]> {
        self.plan.ranges()
    }
}

/// Minimal architecture-neutral register set recorded when a guest thread
/// enters a host-backed blocking wait. This is deliberately small enough for
/// the always-on event ring and crash bundles: instruction, stack, and return
/// linkage are sufficient to symbolize the park site without saving a core.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct GuestWaitRegisters {
    pub pc: u64,
    pub sp: u64,
    /// AArch64 X30. Architectures without a link register report zero.
    pub lr: u64,
}

/// Task-owned AArch64 syscall continuation transported independently of the
/// destination executor's mailbox slot, pointer, generation, and SP_EL1.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Aarch64SyscallContinuationV1 {
    pub sequence: u64,
    pub state: u32,
    pub trap_kind: u32,
    pub response_action: u32,
    pub flags: u32,
    pub native_nr: u64,
    pub args: [u64; 6],
    pub x8: u64,
    pub resume_pc: u64,
    pub spsr: u64,
    pub fp: u64,
    pub lr: u64,
    pub sp: u64,
    pub esr: u64,
    pub return_value: u64,
    pub resume_x16: u64,
    pub resume_x17: u64,
}

/// Version-one migratable AArch64 task state owned by a Kernel thread.
///
/// Executor-local `SP_EL1` and the syscall-mailbox binding are deliberately
/// absent. The remaining EL1 control registers are task-visible state: a
/// persistent executor snapshots them before detaching the task, restores its
/// own neutral controls while idle, and overlays the task values on reload.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Aarch64TaskCpuStateV1 {
    /// X0..X30.
    pub gprs: [u64; 31],
    /// Exact EL0 resume instruction pointer.
    pub pc: u64,
    /// Exact EL0 processor state paired with [`Self::pc`].
    pub pstate: u64,
    /// Raw vCPU PC at the scheduler boundary (EL1 while a syscall is pending).
    pub trap_pc: u64,
    /// Raw vCPU PSTATE paired with [`Self::trap_pc`].
    pub trap_pstate: u64,
    pub sp_el0: u64,
    /// Trap-time EL0 return address retained while a syscall is pending.
    pub elr_el1: u64,
    /// Trap-time EL0 PSTATE paired with [`Self::elr_el1`].
    pub spsr_el1: u64,
    pub ttbr0: u64,
    pub ttbr1: u64,
    pub tcr: u64,
    /// Task-visible EL1 control state. Persistent executors restore their own
    /// neutral copy only while idle, then overlay these exact values on load.
    pub sctlr_el1: u64,
    pub mair_el1: u64,
    pub vbar_el1: u64,
    pub cpacr_el1: u64,
    pub cntkctl_el1: u64,
    pub tpidr_el1: u64,
    pub actlr_el1: u64,
    pub tpidr_el0: u64,
    pub tpidrro_el0: u64,
    pub contextidr_el1: u64,
    /// V0..V31.
    pub vregs: [u128; 32],
    pub fpsr: u32,
    pub fpcr: u32,
    pub pending_resume_pc: Option<u64>,
    pub last_syscall_nr: Option<u64>,
    pub last_syscall_orig_x0: u64,
    pub last_fault_esr: u64,
    pub last_exit_class: u64,
    pub is_forked_child: bool,
    pub syscall_continuation: Option<Aarch64SyscallContinuationV1>,
    /// Exact Kernel mm generation that authorized the task translation state.
    pub mm_generation: u64,
    /// Exact ASID allocation generation paired with the task's TTBR values.
    pub asid_generation: u64,
}

/// Full x87/SSE/AVX XSAVE size for the V1 x86 task snapshot (`XCR0 = 0b111`).
pub const X86_TASK_XSAVE_LEN: usize = 832;

/// Exact backend-resume payload size carried by the V1 x86 task snapshot.
///
/// Task 2 maps the existing pending-resume/syscall fields into this fixed V1
/// payload. Fixing the size here makes truncation or an unversioned extension
/// fail before state can enter the Kernel object graph.
pub const X86_TASK_RESUME_PAYLOAD_LEN: usize = 64;
pub const X86_TASK_RESUME_MAGIC: u64 = 0x4352_4b58_3836_5631;

/// Version-one migratable x86_64 task state owned by a Kernel thread.
///
/// Variable-sized backend inputs are converted into fixed arrays at the only
/// constructor. The private fields prevent callers from bypassing that size
/// validation after construction.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct X86TaskCpuStateV1 {
    gprs: [u64; 16],
    rip: u64,
    rflags: u64,
    rsp: u64,
    cr0: u64,
    cr3: u64,
    cr4: u64,
    efer: u64,
    fs_base: u64,
    gs_base: u64,
    mm_generation: u64,
    asid_generation: u64,
    xsave: Box<[u8; X86_TASK_XSAVE_LEN]>,
    resume_payload: Box<[u8; X86_TASK_RESUME_PAYLOAD_LEN]>,
}

impl X86TaskCpuStateV1 {
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        gprs: [u64; 16],
        rip: u64,
        rflags: u64,
        rsp: u64,
        cr0: u64,
        cr3: u64,
        cr4: u64,
        efer: u64,
        fs_base: u64,
        gs_base: u64,
        mm_generation: u64,
        asid_generation: u64,
        xsave: Vec<u8>,
        resume_payload: Vec<u8>,
    ) -> Result<Self, TrapError> {
        if mm_generation == 0 || asid_generation == 0 {
            return Err(TrapError::Hypervisor(
                "x86 task-state V1 requires exact nonzero MM/ASID generations".to_owned(),
            ));
        }
        let xsave: Box<[u8; X86_TASK_XSAVE_LEN]> = xsave.try_into().map_err(|payload: Vec<u8>| {
            TrapError::Hypervisor(format!(
                "x86 task-state V1 XSAVE length mismatch: expected {X86_TASK_XSAVE_LEN}, got {}",
                payload.len()
            ))
        })?;
        let resume_payload: Box<[u8; X86_TASK_RESUME_PAYLOAD_LEN]> =
            resume_payload.try_into().map_err(|payload: Vec<u8>| {
                TrapError::Hypervisor(format!(
                    "x86 task-state V1 resume payload length mismatch: expected \
                 {X86_TASK_RESUME_PAYLOAD_LEN}, got {}",
                    payload.len()
                ))
            })?;
        let magic = u64::from_le_bytes(
            resume_payload[56..64]
                .try_into()
                .map_err(|_| TrapError::Hypervisor("x86 resume magic is truncated".to_owned()))?,
        );
        if magic != X86_TASK_RESUME_MAGIC {
            return Err(TrapError::Hypervisor(format!(
                "x86 task-state V1 resume payload magic mismatch: expected \
                 {X86_TASK_RESUME_MAGIC:#x}, got {magic:#x}"
            )));
        }
        let flags = u64::from_le_bytes(
            resume_payload[0..8]
                .try_into()
                .map_err(|_| TrapError::Hypervisor("x86 resume flags are truncated".to_owned()))?,
        );
        if flags & !0xf != 0 || resume_payload[48..56] != [0; 8] {
            return Err(TrapError::Hypervisor(
                "x86 task-state V1 resume payload contains unsupported flags or reserved bytes"
                    .to_owned(),
            ));
        }
        let read_u64 = |offset: usize| {
            let mut bytes = [0_u8; 8];
            bytes.copy_from_slice(&resume_payload[offset..offset + 8]);
            u64::from_le_bytes(bytes)
        };
        if (flags & 1 == 0 && read_u64(8) != 0)
            || (flags & 2 == 0 && read_u64(24) != 0)
            || (flags & 4 == 0 && (read_u64(32) != 0 || read_u64(40) != 0))
        {
            return Err(TrapError::Hypervisor(
                "x86 task-state V1 resume payload contains data without authority flags".to_owned(),
            ));
        }
        Ok(Self {
            gprs,
            rip,
            rflags,
            rsp,
            cr0,
            cr3,
            cr4,
            efer,
            fs_base,
            gs_base,
            mm_generation,
            asid_generation,
            xsave,
            resume_payload,
        })
    }

    pub const fn gprs(&self) -> &[u64; 16] {
        &self.gprs
    }

    pub const fn rip(&self) -> u64 {
        self.rip
    }

    pub const fn rflags(&self) -> u64 {
        self.rflags
    }

    pub const fn rsp(&self) -> u64 {
        self.rsp
    }

    pub const fn cr3(&self) -> u64 {
        self.cr3
    }

    pub const fn cr0(&self) -> u64 {
        self.cr0
    }

    pub const fn cr4(&self) -> u64 {
        self.cr4
    }

    pub const fn efer(&self) -> u64 {
        self.efer
    }

    pub const fn fs_base(&self) -> u64 {
        self.fs_base
    }

    pub const fn gs_base(&self) -> u64 {
        self.gs_base
    }

    pub const fn mm_generation(&self) -> u64 {
        self.mm_generation
    }

    pub const fn asid_generation(&self) -> u64 {
        self.asid_generation
    }

    pub const fn xsave(&self) -> &[u8; X86_TASK_XSAVE_LEN] {
        &self.xsave
    }

    pub const fn resume_payload(&self) -> &[u8; X86_TASK_RESUME_PAYLOAD_LEN] {
        &self.resume_payload
    }
}

/// Architecture- and version-typed task CPU state accepted by the Kernel.
///
/// There is intentionally no raw-byte variant or same-ABI byte constructor.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum GuestCpuState {
    Aarch64V1(std::sync::Arc<Aarch64TaskCpuStateV1>),
    X86_64V1(std::sync::Arc<X86TaskCpuStateV1>),
}

impl GuestCpuState {
    pub fn from_aarch64_v1(state: Aarch64TaskCpuStateV1) -> Self {
        Self::Aarch64V1(std::sync::Arc::new(state))
    }

    pub fn from_x86_64_v1(state: X86TaskCpuStateV1) -> Result<Self, TrapError> {
        // `X86TaskCpuStateV1` has no unchecked constructor and keeps both
        // variable-sized payloads private, so construction itself is the
        // validation boundary.
        Ok(Self::X86_64V1(std::sync::Arc::new(state)))
    }

    pub const fn guest_abi(&self) -> carrick_abi::LinuxGuestAbi {
        match self {
            Self::Aarch64V1(_) => carrick_abi::LinuxGuestAbi::Aarch64,
            Self::X86_64V1(_) => carrick_abi::LinuxGuestAbi::X86_64,
        }
    }

    pub const fn version(&self) -> u16 {
        match self {
            Self::Aarch64V1(_) | Self::X86_64V1(_) => 1,
        }
    }

    /// Exact MM/ASID generations embedded in this architectural image.
    pub fn task_identity(&self) -> (u64, u64) {
        match self {
            Self::Aarch64V1(state) => (state.mm_generation, state.asid_generation),
            Self::X86_64V1(state) => (state.mm_generation(), state.asid_generation()),
        }
    }
}

/// Complete AArch64 EL0 architectural state captured at a crash-generation
/// safe point.  This is intentionally separate from the best-effort wait
/// diagnostic above: a core publisher must fail closed if any field is absent.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Aarch64CoreRegisters {
    pub gprs: [u64; 31],
    pub sp_el0: u64,
    /// Exact EL0 instruction pointer at the safe point. A vCPU force-exited
    /// directly from EL0 uses live PC; one parked in a syscall trap uses ELR.
    pub resume_pc: u64,
    /// EL0 processor state paired with `resume_pc` (live PSTATE or saved SPSR).
    pub resume_pstate: u64,
    /// Raw live vCPU state retained for diagnosis and authority auditing.
    pub pc: u64,
    pub pstate: u64,
    pub elr_el1: u64,
    pub spsr_el1: u64,
    pub tpidr_el0: u64,
    pub vregs: [u128; 32],
    pub fpsr: u32,
    pub fpcr: u32,
}

/// Runtime authority used by a backend when a private stage-1 write fault (or
/// a kernel copy-to-user into the same page) must publish one new physical
/// frame. The backend owns physical allocation/mapping; the runtime owns the
/// authenticated kernel frame inventory transaction.
pub trait FrameCowQuiesce {}

impl<T> FrameCowQuiesce for T {}

pub trait FrameCowAuthority: Send + Sync {
    /// Exact-MM pristine anonymous state, including task-only fork publication.
    fn deferred_anonymous_state(&self) -> Option<Arc<carrick_guest_mem::DeferredAnonymousState>> {
        None
    }

    fn quiesce(&self)
    -> Result<Box<dyn FrameCowQuiesce>, Box<dyn std::error::Error + Send + Sync>>;

    fn reserve(
        &self,
        frame_candidates: usize,
        mapping_candidates: usize,
        event_count: usize,
    ) -> Result<crate::FrameInventoryReservation, Box<dyn std::error::Error + Send + Sync>>;

    fn apply(
        &self,
        commit: crate::FrameInventoryCommit<()>,
    ) -> Result<(), Box<dyn std::error::Error + Send + Sync>>;

    /// Apply the irreversible kernel inventory publication and return the
    /// provenance-authenticated exact post-commit inventory state. Foreign
    /// COW uses this boundary so no fallible live snapshot is reacquired after
    /// the commit has become externally visible.
    fn apply_with_receipt(
        &self,
        _commit: crate::FrameInventoryCommit<()>,
    ) -> Result<crate::FrameInventoryApplyReceipt, Box<dyn std::error::Error + Send + Sync>> {
        Err(Box::new(std::io::Error::new(
            std::io::ErrorKind::Unsupported,
            "frame COW authority does not issue apply receipts",
        )))
    }

    /// Atomically apply one foreign-COW inventory commit and mint an opaque
    /// runtime-private proof binding its exact semantic COW span, mapping,
    /// physical extent, and host-owner generation. The backend may carry this
    /// proof but cannot construct the private payload accepted by the runtime
    /// facade.
    #[allow(clippy::too_many_arguments)]
    fn apply_foreign_cow(
        &self,
        _commit: crate::FrameInventoryCommit<()>,
        _semantic_start: carrick_guest_mem::GuestVa,
        _semantic_len: std::num::NonZeroUsize,
        _mapping: crate::MappingId,
        _frame: crate::FrameId,
        _gpa: carrick_guest_mem::Gpa,
        _length: crate::FrameLength,
    ) -> Result<
        (
            crate::FrameInventoryApplyReceipt,
            crate::ForeignCowKernelProof,
            crate::ForeignOwnerGeneration,
        ),
        Box<dyn std::error::Error + Send + Sync>,
    > {
        Err(Box::new(std::io::Error::new(
            std::io::ErrorKind::Unsupported,
            "frame COW authority does not issue foreign-COW proofs",
        )))
    }

    /// Mint the runtime-private proof for an IDENTITY foreign write: a write
    /// into a page that is already private to the target mm (nothing to copy,
    /// no inventory mutation). The authority verifies the exact (mapping,
    /// frame, physical extent) tuple is live at the snapshot revision the
    /// caller captured, and binds the CURRENT host-owner generation into the
    /// proof. The backend carries the proof opaquely, exactly as with
    /// [`Self::apply_foreign_cow`].
    #[allow(clippy::too_many_arguments)]
    fn attest_foreign_identity_write(
        &self,
        _semantic_start: carrick_guest_mem::GuestVa,
        _semantic_len: std::num::NonZeroUsize,
        _inventory_revision: u64,
        _mapping: crate::MappingId,
        _frame: crate::FrameId,
        _gpa: carrick_guest_mem::Gpa,
        _length: crate::FrameLength,
    ) -> Result<
        (crate::ForeignCowKernelProof, crate::ForeignOwnerGeneration),
        Box<dyn std::error::Error + Send + Sync>,
    > {
        Err(Box::new(std::io::Error::new(
            std::io::ErrorKind::Unsupported,
            "frame COW authority does not attest identity writes",
        )))
    }

    /// Authenticate that the just-published physical mapping is visible in
    /// the bound mm's kernel-owned graph before the backend advertises a COW
    /// commit or disarms the permission fault.
    fn mapping_is_live(
        &self,
        mapping: crate::MappingId,
        frame: crate::FrameId,
        gpa: carrick_guest_mem::Gpa,
        length: crate::FrameLength,
    ) -> Result<bool, Box<dyn std::error::Error + Send + Sync>>;

    /// How many live mappings the authority currently holds for `frame`,
    /// across EVERY mm — `None` if the authority does not know the frame.
    ///
    /// `RetireFrame` is rejected unless the frame's mapping count reaches
    /// zero, and that count is VM-wide. A backend deciding retirement from a
    /// per-mm population is therefore asking a different question than the one
    /// the authority answers: the two agree while exactly one Linux process
    /// exists and diverge the instant a second mm maps the same frame.
    fn frame_mapping_count(
        &self,
        frame: crate::FrameId,
    ) -> Result<Option<usize>, Box<dyn std::error::Error + Send + Sync>>;

    /// Batch query mapping exact-liveness for candidate extents and mapping counts
    /// for candidate frames under a single authority synchronization.
    #[allow(clippy::type_complexity)]
    fn retirement_batch_query(
        &self,
        candidate_extents: &[(
            crate::MappingId,
            crate::FrameId,
            carrick_guest_mem::Gpa,
            crate::FrameLength,
        )],
        candidate_frames: &[crate::FrameId],
    ) -> Result<(Vec<bool>, Vec<Option<usize>>), Box<dyn std::error::Error + Send + Sync>> {
        let mut extent_liveness = Vec::with_capacity(candidate_extents.len());
        for &(mapping, frame, gpa, length) in candidate_extents {
            extent_liveness.push(self.mapping_is_live(mapping, frame, gpa, length)?);
        }
        let mut frame_counts = Vec::with_capacity(candidate_frames.len());
        for &frame in candidate_frames {
            frame_counts.push(self.frame_mapping_count(frame)?);
        }
        Ok((extent_liveness, frame_counts))
    }
}

/// One pinned incarnation from the carrier's existing host-owner directory.
/// The kernel COW proof issuer retains this across its inventory commit and
/// rechecks that the same incarnation is still current before signing it.
pub trait FrameCowOwnerLease: Send + Sync {
    fn generation(&self) -> crate::ForeignOwnerGeneration;
    fn is_current(&self) -> bool;
}

/// Read-only endpoint to the carrier's canonical host-owner directory. The
/// engine binds this independently of any foreign-MM transport, so a transport
/// cannot select the owner generation that the kernel proof issuer signs.
pub trait FrameCowOwnerInventory: Send + Sync {
    fn retain_current(
        &self,
        gpa: carrick_guest_mem::Gpa,
        length: crate::FrameLength,
    ) -> Result<Box<dyn FrameCowOwnerLease>, Box<dyn std::error::Error + Send + Sync>>;
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct FrameCowIdentity {
    pub linux_pid: i32,
    pub linux_tid: i32,
    pub mm: u64,
    pub asid: u16,
}

/// Exact kernel-graph identity of the address space an in-place `execve`
/// replaces. Unlike a carrier-directory registration, this also exists for
/// the bootstrap task that entered the persistent executor pool directly.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct ExecPredecessorIdentity {
    pub task_serial: u64,
    pub thread_serial: u64,
    pub linux_pid: i32,
    pub linux_tid: i32,
    pub mm: u64,
    pub asid: u16,
}

/// Opaque Kernel-issued authority for activating one exact HVPatch child.
/// The embedded COW authority owns the exact runtime kicker/tid binding; safe
/// consumers can inspect identity but cannot replace any component.
pub struct HvpatchChildKernelToken {
    seal: Arc<HvpatchChildTokenSeal>,
    task_serial: u64,
    thread_serial: u64,
    execution_generation: u64,
    cow_identity: FrameCowIdentity,
    authority_identity: NonZeroU64,
    cow_authority: Arc<dyn FrameCowAuthority>,
}

#[derive(Debug)]
pub struct HvpatchChildTokenIssuer {
    seal: Arc<HvpatchChildTokenSeal>,
}

#[derive(Debug)]
pub struct HvpatchChildTokenVerifier {
    seal: Arc<HvpatchChildTokenSeal>,
}

#[derive(Debug)]
struct HvpatchChildTokenSeal;

pub struct HvpatchVerifiedChildKernelBinding {
    task_serial: u64,
    thread_serial: u64,
    execution_generation: u64,
    cow_identity: FrameCowIdentity,
    authority_identity: NonZeroU64,
    cow_authority: Arc<dyn FrameCowAuthority>,
}

impl HvpatchChildTokenIssuer {
    pub fn new_pair() -> (Arc<Self>, Arc<HvpatchChildTokenVerifier>) {
        let seal = Arc::new(HvpatchChildTokenSeal);
        (
            Arc::new(Self {
                seal: Arc::clone(&seal),
            }),
            Arc::new(HvpatchChildTokenVerifier { seal }),
        )
    }

    pub fn issue(
        &self,
        task_serial: u64,
        thread_serial: u64,
        execution_generation: u64,
        cow_identity: FrameCowIdentity,
        authority_identity: NonZeroU64,
        cow_authority: Arc<dyn FrameCowAuthority>,
    ) -> HvpatchChildKernelToken {
        HvpatchChildKernelToken {
            seal: Arc::clone(&self.seal),
            task_serial,
            thread_serial,
            execution_generation,
            cow_identity,
            authority_identity,
            cow_authority,
        }
    }
}

impl HvpatchChildTokenVerifier {
    pub fn verify_and_open(
        &self,
        token: HvpatchChildKernelToken,
    ) -> Option<HvpatchVerifiedChildKernelBinding> {
        if !Arc::ptr_eq(&token.seal, &self.seal) {
            return None;
        }
        Some(HvpatchVerifiedChildKernelBinding {
            task_serial: token.task_serial,
            thread_serial: token.thread_serial,
            execution_generation: token.execution_generation,
            cow_identity: token.cow_identity,
            authority_identity: token.authority_identity,
            cow_authority: token.cow_authority,
        })
    }
}

impl HvpatchVerifiedChildKernelBinding {
    pub const fn task_serial(&self) -> u64 {
        self.task_serial
    }

    pub const fn thread_serial(&self) -> u64 {
        self.thread_serial
    }

    pub const fn execution_generation(&self) -> u64 {
        self.execution_generation
    }

    pub const fn cow_identity(&self) -> FrameCowIdentity {
        self.cow_identity
    }

    pub const fn authority_identity(&self) -> NonZeroU64 {
        self.authority_identity
    }

    pub fn into_cow_authority(self) -> Arc<dyn FrameCowAuthority> {
        self.cow_authority
    }
}

pub trait ThreadedEngine: SyscallTrap + RegAccess + CurrentMmMemory + Send {
    /// Optional backend-owned sink for the carrier-global descriptor ceiling.
    /// Unsupported execution lanes leave the optimization disabled.
    fn fd_ceiling_publisher(&self) -> Option<Arc<dyn crate::FdCeilingPublisher>> {
        None
    }

    /// Exact carrier endpoint for retaining foreign-MM access state. Only the
    /// HVPatch root bootstrap consumes this; syscall handlers never receive it.
    fn foreign_mm_endpoint(&self) -> Option<crate::ForeignMmEndpoint> {
        None
    }

    /// Independent read-only view of the carrier's existing host-owner
    /// directory. HVPatch binds it into the kernel COW proof issuer; foreign-MM
    /// transports never provide or replace this endpoint.
    fn frame_cow_owner_inventory(&self) -> Option<Arc<dyn FrameCowOwnerInventory>> {
        None
    }

    /// Fresh stage-1 software-image allocations performed by this engine's
    /// most recent `build_process_spec`. `0` when the child's image reused a
    /// recycled buffer; backends without in-process fork report `0`. The
    /// runtime charges it to the execution work scope as
    /// `page_table_image_allocations`.
    fn last_fork_stage1_image_allocations(&self) -> u64 {
        0
    }

    /// Fresh host anonymous mappings created by this engine's most recent
    /// `build_process_spec` for the child's per-mm backing. `0` when every
    /// backing came from a carrier pool. Charged to the execution work scope
    /// as `host_mapping_allocations`.
    fn last_fork_host_mapping_allocations(&self) -> u64 {
        0
    }

    /// Mapping and alias rows this engine visited to compute the most recent
    /// fork's COW projection (`0` when the cached projection was reused).
    /// Charged to the execution work scope as `fork_projection_rows_visited`.
    fn last_fork_projection_rows_visited(&self) -> u64 {
        0
    }

    /// Fail-closed backend-owned executor boundary audit. Transitional M:N
    /// workers call this only while the task is fully saved and owns no live
    /// executor/vCPU authority.
    fn audit_executor_boundary(&mut self) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "threaded backend does not implement executor boundary audit".to_owned(),
        ))
    }

    /// Bind the exact Kernel MM and ASID allocation generations that authorize
    /// scheduler snapshots produced by this engine.
    fn bind_task_snapshot_identity(&mut self, _mm_generation: u64, _asid_generation: u64) {}

    /// Bind the exact kernel-graph identity whose address space the next
    /// destructive `execve` will replace. The runtime publishes this only
    /// after its execution lease is retired and immediately before replacement.
    fn bind_exec_predecessor_identity(
        &mut self,
        _identity: ExecPredecessorIdentity,
    ) -> Result<(), TrapError> {
        Ok(())
    }

    /// Consume the exact, engine-local duration accumulated by backend run
    /// calls since the previous receipt. The value is never addressed through
    /// a process-global host-thread slot and therefore cannot alias after host
    /// thread churn.
    fn take_guest_run_receipt_ns(&mut self) -> u64;

    /// Capture the freshly materialized exec image without parking or
    /// destroying the destination executor's live vCPU.
    fn snapshot_guest_state_for_publication(&mut self) -> Result<GuestCpuState, TrapError>;

    /// Consume task-owned syscall continuation state when the task becomes
    /// terminal before the trapped syscall can publish a return. Persistent
    /// executors must reach their idle boundary without carrying the dead
    /// task's completion vehicle into the next logical task.
    fn discard_terminal_syscall_continuation(&mut self) -> Result<(), TrapError>;

    fn bind_frame_cow(
        &mut self,
        _authority: std::sync::Arc<dyn FrameCowAuthority>,
        _identity: FrameCowIdentity,
    ) {
    }

    /// Refresh fork-private backend state after the child frame inventory and
    /// exact MM/COW authority are live, but before the child enters guest code.
    fn refresh_fork_process_state(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    /// Resolve a synchronous stage-1 write-permission fault.
    /// [`CowFaultResolution::Resolved`] means the exact mm now owns a writable
    /// frame for the fault and the instruction should be retried;
    /// [`CowFaultResolution::NotCow`] leaves ordinary fault delivery unchanged.
    fn resolve_frame_cow_fault(
        &mut self,
        _syndrome: u64,
        _far: u64,
    ) -> Result<CowFaultResolution, TrapError> {
        Ok(CowFaultResolution::NotCow)
    }

    /// Arm the exact child-map transaction before any backend/topology lock is
    /// acquired. HVPatch transfers this non-cloneable reservation through its
    /// process specification; other engines retain the no-op default.
    fn begin_process_inventory(
        &mut self,
        reservation: crate::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        drop(reservation);
        Err(TrapError::Hypervisor(
            "backend does not expose process frame inventory".to_owned(),
        ))
    }

    /// Release a backend child-inventory operation slot after a fork attempt
    /// fails before materialization consumes it.
    fn cancel_process_inventory(&mut self) -> bool {
        false
    }

    /// Complete child materialization returns the staged batch through this
    /// seam. VM/vCPU replay never populates it.
    fn take_process_inventory(&mut self) -> Option<crate::FrameInventoryCommit<()>> {
        None
    }

    fn begin_retirement_inventory(
        &mut self,
        reservation: crate::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        drop(reservation);
        Err(TrapError::Hypervisor(
            "backend does not expose retirement frame inventory".to_owned(),
        ))
    }

    fn take_retirement_inventory(&mut self) -> Option<crate::FrameInventoryCommit<()>> {
        None
    }

    fn apply_exec_inventory(
        &mut self,
        _replacement_mm: u64,
        _apply: &mut dyn FnMut(
            crate::FrameInventoryCommit<()>,
        ) -> Result<crate::FrameInventoryApplyReceipt, TrapError>,
    ) -> Result<bool, TrapError> {
        Ok(false)
    }

    fn activate_exec_inventory(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    /// Install an arena source providing additional 2 MiB root slots when the
    /// primary stage-1 arena is exhausted.
    fn install_stage1_table_arena_source(
        &mut self,
        _source: Box<dyn carrick_mem::page_table::TableArenaSource>,
    ) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "threaded backend has no stage-1 manager to install arena source".to_owned(),
        ))
    }
    /// The guest CPU ISA this engine runs. Fixed per process (the guest ISA
    /// equals the host ISA), so it is an associated type — monomorphized per
    /// ISA, no syscall-hot-path vtable. Aarch64 today; x86_64 in Phase 2.
    type Arch: crate::guest_arch::GuestArch;
    type KickHandle: VcpuKick + 'static;
    type SiblingSpec: Send;
    type ProcessSpec: Send;

    /// Best-effort guest register snapshot taken before blocking-wait reclaim
    /// destroys or releases the live vCPU. Backends opt in; absence degrades
    /// diagnostics only and never changes guest behavior.
    fn diagnostic_wait_registers(&self) -> Option<GuestWaitRegisters> {
        None
    }

    /// Exact core-dump register authority.  A backend that cannot provide the
    /// complete shape returns an error/absence and no core may be published.
    fn aarch64_core_registers(&self) -> Result<Option<Aarch64CoreRegisters>, TrapError> {
        Ok(None)
    }

    /// Prepare a coherent backend memory view for live core capture. Backends
    /// whose ordinary guest-memory view is always current keep the no-op;
    /// HVPatch uses this at the all-thread safe point to load its software
    /// stage-1 observer from the live hardware table backing without editing it.
    fn prepare_core_snapshot(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    /// Read bytes from a VMA already authenticated as readable by the coherent
    /// core snapshot. The default preserves ordinary checked guest-memory
    /// semantics; AArch64 HVPatch bypasses only its syscall-path PROT_NONE
    /// reservation gate so a live `brk` prefix can be captured from backing.
    fn read_core_bytes(
        &self,
        address: u64,
        length: usize,
    ) -> Result<Vec<u8>, carrick_guest_mem::MemoryError> {
        self.read_bytes(address, length)
    }

    /// Best-effort fault-time walk of the live stage-1 backing. The returned
    /// scalar is the exact TTBR root+ASID observed at the fault; descriptors are
    /// L0..L3 for `far`. Backends without host-editable guest page tables keep
    /// the default absence.
    fn diagnostic_fault_page_tables(&self, _far: u64) -> Option<(u64, [u64; 4])> {
        None
    }

    /// Under MM mutation authority, decide whether an EL0 fault at `far` is
    /// STALE: the live stage-1 leaf already permits `access`, so a sibling
    /// thread committed the page between this thread's fault and its arrival
    /// here (or its TLB entry is stale). `Ok(true)` means the backend flushed
    /// its stage-1 translations and the faulting instruction must be retried;
    /// `Ok(false)` leaves ordinary signal delivery unchanged. Backends without
    /// host-readable guest page tables keep the default and always deliver.
    fn resolve_stale_stage1_fault(
        &mut self,
        _far: u64,
        _access: carrick_mem::page_table::LeafAccess,
    ) -> Result<bool, TrapError> {
        Ok(false)
    }

    /// Select a backend lifecycle in which guest exec/fork operations retain
    /// one host VM and replace only per-process address-space state. Backends
    /// without shared-VM process support keep the default no-op; callers still
    /// gate process creation on their explicit backend policy.
    fn set_persistent_vm_lifecycle(&mut self, _enabled: bool) {}

    /// Bind this engine to one in-process guest's AArch64 ASID. The default is
    /// a no-op for backends that retain the one-host-process-per-guest-process
    /// model. Hvpatch overrides this and keeps the ASID across exec replacement.
    fn configure_process_asid(&mut self, _asid: u16) -> Result<(), TrapError> {
        Ok(())
    }

    fn prepare_exec_address_space(
        &mut self,
        _root_slot_base: u64,
        _root_slot_size: u64,
        _asid: u16,
    ) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "backend does not accept an exact HVPatch exec address-space lease".to_owned(),
        ))
    }

    /// Declare whether the exec predecessor mm is still owned by a LIVE
    /// sharer (a vfork / `CLONE_VM` relative). Shared predecessors retire
    /// NOTHING at exec: the replacement gets a fresh ledger and the old
    /// root slot, tables and extents stay whole for the sharer. The
    /// authority is `MmResources` lease sharing, computed fresh per exec —
    /// the backend flag existed but was NEVER SET in production, so every
    /// vfork-shared exec retired the shared mm and the surviving child's
    /// stage-1 walk read zeroed tables (vforkexecthread: barrier fetch
    /// fault at LINUX_EL1_LOAD_BARRIER_BASE, all four descriptors 0x0).
    fn mark_exec_predecessor_shared(&mut self, _shared: bool) {}

    fn complete_task_load_barrier(&mut self) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "backend does not expose the required task-load DSB/ISB barrier".to_owned(),
        ))
    }

    /// True only for a backend that represents Linux fork as another vCPU plus
    /// another stage-1 address space inside the current host VM.
    fn supports_in_process_fork(&self) -> bool {
        false
    }

    /// Retire an in-process guest address space after its last vCPU reports a
    /// terminal exit. Backends with per-process stage-1/stage-2 state override
    /// this to flush translations and unmap owned ranges before lifecycle code
    /// makes the ASID/bank reusable.
    fn retire_in_process_address_space(&mut self) -> Result<(), TrapError> {
        self.process_exit_cleanup()?;
        self.destroy_vcpu_on_thread_exit();
        Ok(())
    }

    /// Retire only the loaded logical task's stage-2/mapping authority while
    /// preserving the persistent worker vCPU. ASID TLBI is a later owner-worker
    /// command after save/detach.
    fn retire_task_address_space(&mut self) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "backend does not support task-only address-space retirement".to_owned(),
        ))
    }

    fn build_process_spec(
        &mut self,
        _request: ProcessForkRequest,
    ) -> Result<Self::ProcessSpec, TrapError> {
        Err(TrapError::Hypervisor(
            "backend does not support in-process fork".to_owned(),
        ))
    }

    fn materialize_process(_spec: Self::ProcessSpec) -> Result<Self, TrapError>
    where
        Self: Sized,
    {
        Err(TrapError::Hypervisor(
            "backend does not support in-process fork".to_owned(),
        ))
    }

    /// The child is materialized and every remaining fork publication failure
    /// is fail-closed. Forget the parent's saved pre-arm state.
    fn commit_process_fork(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    /// Restore parent stage-1 and COW-arm metadata after a recoverable child
    /// spawn/materialization failure.
    fn rollback_process_fork(&mut self) -> Result<(), TrapError> {
        Ok(())
    }

    fn kick_handle(&self) -> Self::KickHandle;
    fn wait_for_vcpu_slot();
    /// Live concurrent-vCPU budget N for the admission scheduler (the M:N pool).
    /// `usize::MAX` (the default) means "no carrick-side cap" — HVF (its own
    /// `vcpu_gate` stays in Phase 1) and KVM; bhyve returns `hw.vmm.maxcpu`.
    fn vcpu_budget() -> usize {
        usize::MAX
    }
    /// Whether this backend RECLAIMS a guest thread's vCPU slot when the thread
    /// blocks (the M:N reclaim-on-block). `false` (default) keeps Phase-1
    /// lifetime-binding — HVF/KVM until Phase 3. bhyve returns `true`.
    fn reclaims(&self) -> bool {
        false
    }
    /// Whether this backend's reclaim DESTROYS the vCPU (so its kick handle goes
    /// dead and the runtime must unregister it from the VcpuRegistry before the
    /// block and re-register on wake). `true` for HVF (destroy/recreate; raw
    /// hv_vcpu_destroy does not drop applevisor's liveness Weak, so a stale handle
    /// would lie `is_valid`); `false` for bhyve (pool-swap keeps the vCPU alive).
    fn reclaim_refreshes_kicker(&self) -> bool {
        false
    }
    /// Save THIS thread's full guest CPU state (GPRs + RSP/RFLAGS + FS/GS base +
    /// FP/AVX) before releasing its vCPU slot at a block point. Only ever called by
    /// the owning host thread, only when [`reclaims`](Self::reclaims). Opaque,
    /// backend-serialized bytes round-tripped to [`rebind_to_slot`](Self::rebind_to_slot).
    /// `&mut self`: HVF DESTROYS its vCPU inside this call (snapshot then
    /// hv_vcpu_destroy); bhyve/KVM read registers and ignore the extra mutability.
    fn save_guest_state(&mut self) -> Result<GuestCpuState, TrapError> {
        Err(TrapError::Hypervisor(
            "backend does not support complete typed guest-state snapshots".to_owned(),
        ))
    }
    /// Save a freshly materialized task before it has executed one guest
    /// instruction so production can transfer it to a persistent executor.
    /// This is deliberately distinct from blocking-wait reclaim: an initial
    /// task has no outstanding syscall/mailbox continuation to preserve.
    fn save_initial_runner_state(&mut self) -> Result<GuestCpuState, TrapError> {
        Err(TrapError::Hypervisor(
            "backend does not support idle initial-runner state transfer".to_owned(),
        ))
    }
    fn rebind_initial_runner_state(
        &mut self,
        _slot: crate::SlotId,
        _state: &GuestCpuState,
    ) -> Result<(), TrapError> {
        Err(TrapError::Hypervisor(
            "backend does not support idle initial-runner restore".to_owned(),
        ))
    }
    /// Save state for a process-shared futex wait. Backends that can release
    /// stronger host resources while parked may override this separately from
    /// the generic private-futex reclaim path.
    fn save_shared_wait_state(&mut self) -> Result<GuestCpuState, TrapError> {
        self.save_guest_state()
    }
    /// Re-bind this engine to `slot`'s vCPU and restore `state` into it — called by
    /// the owning thread when it re-acquires a (possibly different) slot after a
    /// block. Only when [`reclaims`](Self::reclaims).
    fn rebind_to_slot(
        &mut self,
        slot: crate::SlotId,
        state: &GuestCpuState,
    ) -> Result<(), TrapError> {
        let _ = (slot, state);
        Err(TrapError::Hypervisor(
            "backend does not support complete typed guest-state restore".to_owned(),
        ))
    }
    /// Restore state saved by [`Self::save_shared_wait_state`].
    fn rebind_shared_wait_state(
        &mut self,
        slot: crate::SlotId,
        state: &GuestCpuState,
    ) -> Result<(), TrapError> {
        self.rebind_to_slot(slot, state)
    }
    /// MT whole-VM residency lease — VM-only release, called by the LAST
    /// parker of a multi-threaded process AFTER its own vCPU was already
    /// destroyed by [`Self::save_guest_state`] (so the runtime registry's
    /// "parked" mark truthfully means "vCPU destroyed" for every marked
    /// thread, and this call finds zero live vCPUs). Returns `Ok(true)` iff
    /// the backend released whole-VM state that a claim-true waker must
    /// rebuild via [`Self::rebind_shared_wait_state_mt`]; `Ok(false)` (the
    /// default) means the backend has no whole-VM state to release
    /// (pool-swap backends). On `Err` or `Ok(false)` the caller MUST NOT set
    /// the registry's vm-released flag — the park stays a vCPU-only park (a
    /// failed teardown must never poison an innocent sibling's wake with a
    /// rebuild against a live VM).
    fn release_vm_after_reclaim_park(&mut self) -> Result<bool, TrapError> {
        Ok(false)
    }
    /// Restore state saved by [`Self::save_shared_wait_state`] when the parked
    /// process was MULTI-THREADED (the whole-VM residency lease): the FIRST
    /// waker rebuilds the per-process VM state on behalf of every still-parked
    /// sibling, so a backend whose shared-wait park tears the whole VM down
    /// must replay the UNION of every thread's dynamic mappings — not just
    /// this (waking) thread's per-thread list (HVF overrides this via its
    /// process-global alias registry). Defaults to the single-threaded
    /// restore: pool-swap backends (KVM x86, bhyve) never tear down
    /// per-process VM state on a shared-wait park, so there is nothing extra
    /// to rebuild.
    fn rebind_shared_wait_state_mt(
        &mut self,
        slot: crate::SlotId,
        state: &GuestCpuState,
    ) -> Result<(), TrapError> {
        self.rebind_shared_wait_state(slot, state)
    }
    fn build_sibling_spec(&self, entry: GuestEntryRegs) -> Result<Self::SiblingSpec, TrapError>;
    fn materialize_sibling(spec: Self::SiblingSpec) -> Result<Self, TrapError>
    where
        Self: Sized;
    /// The guest PC of a freshly materialized sibling vCPU (trace diagnostics).
    fn program_counter(&self) -> Result<u64, TrapError>;
    /// Set the guest user stack pointer (`SP_EL0`) on a vfork child that was
    /// given an explicit `child_stack` by `clone`.
    fn set_guest_sp_el0(&self, sp: u64) -> Result<(), TrapError>;
    /// Stamp the running guest thread's guest-visible tid into the vCPU (the
    /// EL1 `gettid` fast path). No-op unless the syscall shim is enabled.
    fn set_guest_thread_id(&self, tid: u64) -> Result<(), TrapError>;
    /// Backend hook before dispatching a guest syscall. Direct shared-memory
    /// backends need nothing; a backend that emulates file-backed `MAP_SHARED`
    /// with copied guest RAM can use this to publish guest stores before the
    /// syscall observes the backing file.
    fn needs_shared_file_alias_sync(&self) -> bool {
        false
    }
    fn sync_shared_file_aliases(&mut self) -> Result<(), TrapError> {
        Ok(())
    }
    fn destroy_vcpu_on_thread_exit(&mut self) {}
    /// Construct a fresh vCPU-kick registry for one logical process.
    fn fresh_fork_kicker(&self) -> Arc<dyn VcpuRegistry>;
}

/// Object-safe startup control for a backend's process-directed signal pump.
///
/// HVPatch keeps guest process identity and lifecycle inside Carrick's kernel;
/// guest `fork(2)` therefore has no host-fork window to coordinate. The shared
/// loop retains only the one operation it actually needs: idempotently starting
/// the backend pump against the live vCPU registry and futex implementation.
pub trait SignalPumpControl: Send + Sync {
    /// Start the process-directed signal pump (idempotent) against the given
    /// registry + futex, if one is not already running.
    fn start_signal_pump(&self, registry: &Arc<dyn VcpuRegistry>, futex: &Arc<dyn PlatformFutex>);
    fn publish_kernel_wake(
        &self,
        registry: &Arc<dyn VcpuRegistry>,
        futex: &Arc<dyn PlatformFutex>,
    ) {
        registry.publish_kernel_wake_debt();
        self.start_signal_pump(registry, futex);
    }
}

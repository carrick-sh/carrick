//! The runtime↔engine trap contract.
//!
//! `SyscallTrap` is the single trait the runtime loop drives: run the vCPU
//! until a syscall trap, complete/inject/restore around guest syscalls and
//! signals, and fork/execve the guest address space. It references no
//! hypervisor-specific types in its signatures, so it lives here in
//! `carrick-hal` and is implemented per-backend (`HvfTrapEngine` on macOS,
//! `KvmTrapEngine` on Linux, and the runtime's `SplitView` test adapter).
//! `set_memory_model` and `map_host_alias` carry portable defaults so non-HVF
//! backends inherit sane behavior.

use std::os::fd::{AsRawFd, OwnedFd, RawFd};

use carrick_abi::{CanonicalNr, LinuxSiginfo, NativeNr};
use carrick_fatal::carrick_fatal;
use carrick_guest_mem::{Gpa, GuestVa};
use carrick_mem::memory::AddressSpace;
use serde::Serialize;
use thiserror::Error;

use crate::error::OsError;

/// An ISA-neutral decoded syscall: the Linux syscall number plus its six
/// argument registers, already extracted from the per-ISA register frame by the
/// backend's [`crate::GuestArch::decode_syscall`]. `SyscallTrap::next_syscall`
/// returns this (not a raw aarch64 frame) so the runtime loop is ISA-agnostic —
/// the runtime maps it onto its own `SyscallRequest`. The backend keeps reading
/// the raw registers into its `GuestArch::Frame` as before; only the decode
/// moved into the backend (Phase 1, Task 3 of the x86_64 guest-ISA seam).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RawSyscall {
    /// Stack pointer captured by the trap transport for this exact request.
    /// Backends that do not capture it leave it absent for a lazy register read.
    pub current_guest_sp: Option<u64>,
    /// The CANONICAL (asm-generic/aarch64) syscall number the dispatcher
    /// switches on. Typed [`CanonicalNr`] so it cannot be swapped with
    /// [`native_number`](Self::native_number) at a constructor.
    pub number: CanonicalNr,
    pub args: [u64; 6],
    /// The guest Linux UAPI struct-layout family for this syscall, stamped by
    /// the concrete backend's `GuestArch` at decode time. Carried as DATA (not
    /// inferred at the loop boundary) because `SyscallTrap::next_syscall` is
    /// type-erased over the ISA — a runtime loop generic over `R: SyscallTrap`
    /// (the no-threads / combined Linux loops) has no `Arch` to consult, so the
    /// abi must travel with the decoded syscall. `SyscallRequest::from_raw`
    /// reads it, so a call site cannot forget the guest ABI and mis-marshal
    /// epoll/stat/sigset layouts on the x86 path.
    pub guest_abi: carrick_abi::LinuxGuestAbi,
    /// The guest's *architecture-native* syscall number — what the guest
    /// actually put in its syscall register (`x8` on aarch64, `rax` on x86_64),
    /// BEFORE carrick normalizes it to the canonical aarch64 number in
    /// [`number`](Self::number). For aarch64 guests this equals `number`; for
    /// x86_64 guests it is the x86_64 UAPI number (`write == 1`, not the
    /// canonical `64`), and survives fork/vfork/poll/select desugaring.
    ///
    /// Carried because seccomp(2) filters compare `seccomp_data.nr` against the
    /// guest ISA's native numbering: an x86_64 Docker/libseccomp profile gates
    /// on `arch == AUDIT_ARCH_X86_64` then switches on x86_64 numbers, so the
    /// dispatcher must hand the filter the native number, not the canonical one.
    pub native_number: NativeNr,
}

/// A register/V-reg access through [`crate::RegAccess`] failed mid-sigframe
/// build/restore. The shared builder reports it as a hypervisor error so it can
/// use `?` on `RegAccess` calls (which return [`OsError`]) directly.
impl From<OsError> for TrapError {
    fn from(e: OsError) -> Self {
        TrapError::Hypervisor(format!("sigframe register access: {e}"))
    }
}

/// The replacement commit is mandatory; the retirement half mirrors the
/// `begin_exec_inventory` reservation and is absent for a retained old mm.
pub type ExecInventoryCommits = (
    Option<crate::FrameInventoryCommit<()>>,
    Option<crate::FrameInventoryCommit<()>>,
);

/// Arguments describing a signal to be injected into a guest vCPU.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SignalInjection {
    pub signum: i32,
    pub handler: u64,
    pub sa_restorer: u64,
    pub pending_syscall_retval: Option<i64>,
    pub interrupted_pc: Option<u64>,
    pub altstack: Option<(u64, u64)>,
    pub saved_sigmask: u64,
    pub fault_siginfo: Option<(i32, u64)>,
    pub queued_siginfo: Option<LinuxSiginfo>,
    pub restart_syscall: bool,
}

/// The trap-engine contract the runtime loop drives: run the vCPU until a
/// syscall trap, complete/inject/restore around guest syscalls and signals,
/// and fork/execve the guest address space. Implemented by `HvfTrapEngine`
/// (macOS), `KvmTrapEngine` (Linux), and the runtime's `SplitView` adapter.
pub trait SyscallTrap {
    /// Number of exact sparse stage-2 backing extents currently owned by this
    /// engine. Non-HVPatch engines keep the zero default and never enter the
    /// inventory transaction hooks below.
    fn frame_inventory_extent_count(&self) -> usize {
        0
    }

    /// Publish the mappings installed before the runtime Kernel existed. The
    /// caller allocates every candidate and all event storage first.
    fn inventory_initial_mappings(
        &mut self,
        reservation: crate::FrameInventoryReservation,
    ) -> Result<crate::FrameInventoryCommit<()>, TrapError> {
        drop(reservation);
        Err(TrapError::Hypervisor(
            "backend does not expose initial frame inventory".to_owned(),
        ))
    }

    /// Arm an operation-local reservation for one dynamic stage-2 alias. The
    /// backend consumes it inside `map_host_alias` and exposes the complete
    /// batch only after that method has returned and released backend locks.
    fn begin_alias_inventory(
        &mut self,
        reservation: crate::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        drop(reservation);
        Err(TrapError::Hypervisor(
            "backend does not expose alias frame inventory".to_owned(),
        ))
    }

    fn take_alias_inventory(&mut self) -> Option<crate::FrameInventoryCommit<()>> {
        None
    }

    /// Roll back the staging armed by [`Self::begin_alias_inventory`] after the
    /// alias install FAILED, so the transaction the runtime abandons leaves no
    /// residue in the backend.
    ///
    /// Stage-1, stage-2 and frame-inventory publication are one transaction.
    /// The backend already unwinds its own stage-1/stage-2 work on every alias
    /// failure path (host mapping and global-frame IPA leases are RAII), but the
    /// armed reservation — or, when stage-1 fails after stage-2 succeeded, the
    /// staged commit — outlives that unwind and would make the NEXT guest `mmap`
    /// fail with "overlapping HVPatch alias inventory transaction". Returns
    /// whether staging was actually discarded; backends with no HVPatch
    /// inventory never arm any and answer `false`.
    fn abandon_alias_inventory(&mut self) -> bool {
        false
    }

    /// Exact old/new sparse extent counts for a destructive exec replacement.
    fn frame_inventory_exec_extent_counts(&self, _new_image: &AddressSpace) -> (usize, usize) {
        (0, 0)
    }

    /// Diagnostic seam: make the next real `begin_exec_inventory` operation
    /// fail. Backends without HVPatch inventory ignore the request.
    fn inject_next_begin_exec_inventory_failure(&mut self) {}

    /// Arm independently applicable old-mm retirement and replacement-mm map
    /// transactions. Keeping them separate prevents an exec batch from being
    /// applied to the wrong `MmId`.
    ///
    /// `retired` is `None` when the exec retires nothing from the old mm
    /// because another live task still owns it — a vfork/`CLONE_VM` child's
    /// execve. That is absence, not an empty transaction: `FrameEventCapacity`
    /// is non-zero by construction and the authority rejects a zero-event
    /// commit, so a retirement that would carry no events must not be reserved.
    fn begin_exec_inventory(
        &mut self,
        retired: Option<crate::FrameInventoryReservation>,
        replacement: crate::FrameInventoryReservation,
    ) -> Result<(), TrapError> {
        drop((retired, replacement));
        Err(TrapError::Hypervisor(
            "backend does not expose exec frame inventory".to_owned(),
        ))
    }

    /// The replacement commit is mandatory; the retirement half mirrors the
    /// `begin_exec_inventory` reservation and is absent for a retained old mm.
    fn take_exec_inventory(&mut self) -> Option<ExecInventoryCommits> {
        None
    }
    /// Run the vCPU until it traps. `Ok(Some(raw))` is a guest syscall, already
    /// decoded to an ISA-neutral [`RawSyscall`] by the backend's
    /// [`crate::GuestArch::decode_syscall`]; `Ok(None)` means the vCPU was forced
    /// out of the guest by a cross-thread kick (`hv_vcpus_exit` / KVM
    /// signal-kick) with no syscall pending — the loop should run signal
    /// delivery and resume. `Err` is a real fault.
    fn next_syscall(&mut self) -> Result<Option<RawSyscall>, TrapError>;
    /// The guest PC the vCPU is currently parked at. Used as the resume address
    /// when injecting a signal on a non-syscall (kick) exit, where `ELR_EL1`
    /// does not hold a meaningful return address.
    fn current_pc(&self) -> Result<u64, TrapError>;
    fn complete_syscall(&mut self, return_value: i64) -> Result<(), TrapError>;
    /// `execve(2)` — tear down the current guest address space and
    /// re-initialise this engine with `new_image`. Does NOT advance past a
    /// syscall (execve has no successful return); the next `next_syscall`
    /// resumes at the new image's entry point.
    fn execve_into(&mut self, new_image: &AddressSpace) -> Result<(), TrapError>;
    fn is_forked_child(&self) -> bool {
        false
    }
    /// Called immediately before a forked child process `_exit`s (which skips
    /// every `Drop`). Backends whose VM is NOT released by fd-close must tear it
    /// down here. KVM/HVF: no-op — the VM is fd-lifetime-bound, so closing the
    /// inherited descriptor (or letting the kernel reap it at `_exit`) frees it.
    /// bhyve: the VM is a NAME-bound `/dev/vmm/<name>` node that persists until
    /// `vm_destroy`, so a forked child that `_exit`s without this would LEAK its
    /// node — the bhyve engine overrides this to `vm_destroy` the child VM.
    fn process_exit_cleanup(&mut self) -> Result<(), TrapError> {
        Ok(())
    }
    /// Construct a signal frame on the guest stack and update the vCPU's PC to
    /// `handler`. The guest returns via the sa_restorer trampoline; the
    /// pre-signal register state is preserved in the frame and recovered by
    /// `restore_from_sigframe` on `rt_sigreturn`.
    ///
    /// See [`SignalInjection`] and the macOS `HvfTrapEngine` impl for the full
    /// per-field contract.
    fn inject_signal(&mut self, signal: SignalInjection) -> Result<(), TrapError>;
    /// The Linux syscall number of the most recently dispatched `svc`, used to
    /// decide whether an interrupted syscall is in the SA_RESTART-restartable
    /// set. `None` before the first syscall / on traps with no vCPU.
    fn last_syscall_nr(&self) -> Option<u64> {
        None
    }
    /// Restore vCPU state from the `CarrickSigframe` at SP_EL0. Called when the
    /// guest invokes `rt_sigreturn(2)`. Does NOT advance PC past the syscall the
    /// way `complete_syscall` does — the restored PC IS the next PC.
    fn restore_from_sigframe(&mut self) -> Result<u64, TrapError>;
    /// Toggle the vCPU's memory-ordering model (`prctl(PR_SET_MEM_MODEL, …)`).
    /// `tso == true` enables hardware x86_64 Total Store Ordering on this vCPU
    /// (`ACTLR_EL1.EnTSO`), required for Rosetta-translated guests; `false`
    /// restores AArch64's default weakly-ordered model. The default
    /// implementation is a no-op (non-HVF / test traps have no vCPU register).
    fn set_memory_model(&mut self, tso: bool) -> Result<(), TrapError> {
        let _ = tso;
        Ok(())
    }
    /// Back a dynamic mmap (`DispatchOutcome::MapHostAlias`): map host memory
    /// at `ipa` and build the VA→IPA stage-1 path for `[va, va+len)`.
    ///
    /// `backing` names the host memory that must sit behind the alias — see
    /// [`HostAliasBacking`]. A file backing transfers an owned dup that the
    /// implementation closes (by dropping it) on every success, error, and
    /// unwind path. Until backends can prove that `Err` means no mutation
    /// occurred, the generic runtime fail-stops on every claimed installation
    /// failure; it does not attempt a recoverable cleanup and resume. If a host
    /// `MAP_FIXED` has already replaced a prior owner, process teardown is the
    /// ownership backstop.
    ///
    /// The dispatcher only emits `DispatchOutcome::MapHostAlias` for engines that
    /// can back an alias, so reaching this default is a carrick coverage bug —
    /// an engine received an outcome it cannot service — never a recoverable
    /// runtime condition. Fail LOUD at the call site (with the offending
    /// va/ipa/len) instead of returning a soft error that would propagate far
    /// away and surface as a generic "unsupported platform" at process exit,
    /// masking the real cause. An engine that wants this outcome MUST override
    /// the hook (HVF and KVM do).
    fn map_host_alias(
        &mut self,
        va: GuestVa,
        ipa: Gpa,
        len: u64,
        payload: &[u8],
        backing: HostAliasBacking,
    ) -> Result<(), TrapError> {
        let _ = payload;
        // Dropping the backing closes a file dup.
        drop(backing);
        let (va, ipa) = (va.raw(), ipa.raw());
        // A genuine, immediate abort (SIGABRT) — the codebase's deterministic
        // failure mechanism (see the panic-backstop note in the workspace
        // Cargo.toml). NOT a `panic!`/`unimplemented!` (both are workspace-denied
        // clippy lints) and NOT a soft `Err`: returning one would propagate far
        // away and surface as a generic "unsupported platform" at process exit,
        // masking the real cause. Aborting here names the offending va/ipa/len at
        // the exact call site.
        carrick_fatal!(
            "hal::trap",
            "SyscallTrap::map_host_alias reached trait default: unserviced MapHostAlias outcome for va={va:#x} ipa={ipa:#x} len={len:#x}"
        );
    }
}

/// Whether a dynamic host-alias backing is visible across guest `fork`.
///
/// This is the dispatcher's authoritative `MAP_SHARED`/`MAP_PRIVATE`
/// classification of the guest mapping, carried as a named domain rather than
/// a bare `bool` so a backend cannot swap it with `prot_none` or a writability
/// bit. For a file backing it also selects the HOST mapping kind: `Shared` is a
/// host `MAP_SHARED` of the file (guest stores reach the page cache), `Private`
/// is a host `MAP_PRIVATE` (Linux per-page COW: a clean page keeps tracking the
/// file, a dirtied page detaches). A backend that cannot honour `Private` for a
/// file MUST refuse rather than silently map the file shared.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum HostAliasSharing {
    /// `MAP_PRIVATE`: copy-on-write, per guest process.
    Private,
    /// `MAP_SHARED`: one backing visible to every sharer (and across fork).
    Shared,
}

impl HostAliasSharing {
    pub fn is_shared(self) -> bool {
        matches!(self, Self::Shared)
    }
}

/// Owned host fd transferred with a [`HostAliasBacking::File`].
///
/// Keeping ownership in the non-cloneable backing closes the dispatch/runtime
/// gap: dropping an unconsumed outcome closes the dup as well as aborting its
/// alias transaction. Consumers move the [`OwnedFd`] out exactly once.
pub struct HostAliasOwnedFd(OwnedFd);

impl HostAliasOwnedFd {
    /// Take ownership of a successful `dup(2)`/open result.
    pub fn new(fd: OwnedFd) -> Self {
        Self(fd)
    }

    pub fn as_raw_fd(&self) -> RawFd {
        self.0.as_raw_fd()
    }

    pub fn into_owned_fd(self) -> OwnedFd {
        self.0
    }
}

impl From<OwnedFd> for HostAliasOwnedFd {
    fn from(fd: OwnedFd) -> Self {
        Self(fd)
    }
}

impl std::fmt::Debug for HostAliasOwnedFd {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_tuple("HostAliasOwnedFd")
            .field(&self.as_raw_fd())
            .finish()
    }
}

impl PartialEq for HostAliasOwnedFd {
    fn eq(&self, other: &Self) -> bool {
        self.as_raw_fd() == other.as_raw_fd()
    }
}

impl Eq for HostAliasOwnedFd {}

impl Serialize for HostAliasOwnedFd {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_i32(self.as_raw_fd())
    }
}

/// The host memory a dynamic alias (`DispatchOutcome::MapHostAlias`) is backed
/// by. One typed value replaces the former `file: Option<(fd, off, prot)>` +
/// `shared: bool` pair, whose two-field encoding let a backend map every file
/// alias `MAP_SHARED` regardless of the guest's `MAP_PRIVATE`.
#[derive(Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum HostAliasBacking {
    /// Fresh anonymous host memory (zeroed), optionally seeded from the
    /// outcome's `payload` at offset 0. `Shared` anonymous backing stays
    /// coherent across guest `fork`; `Private` is COW per process.
    Anonymous { sharing: HostAliasSharing },
    /// A live host file mapping: the memory at `ipa` is
    /// `mmap(host_prot, MAP_<sharing>, fd, offset)`. `host_prot` is the guest's
    /// requested prot translated to `PROT_*` — it MUST match the fd's access
    /// mode for a `Shared` mapping (a `PROT_WRITE` MAP_SHARED of a read-only fd
    /// is EACCES). The fd is a dup the backend owns and closes after mapping.
    /// The outcome's `payload` is ignored: the page cache is the content.
    File {
        fd: HostAliasOwnedFd,
        offset: libc::off_t,
        host_prot: libc::c_int,
        sharing: HostAliasSharing,
    },
}

impl HostAliasBacking {
    pub fn sharing(&self) -> HostAliasSharing {
        match self {
            Self::Anonymous { sharing } | Self::File { sharing, .. } => *sharing,
        }
    }

    pub fn is_shared(&self) -> bool {
        self.sharing().is_shared()
    }

    pub fn is_file(&self) -> bool {
        matches!(self, Self::File { .. })
    }
}

#[derive(Debug, Error)]
pub enum TrapError {
    #[error("syscall trapping is not available on this platform")]
    UnsupportedPlatform,
    #[error("hypervisor operation failed: {0}")]
    Hypervisor(String),
    /// The signal frame could not be written to the guest's user stack. Linux
    /// `force_sigsegv()`s: the whole guest thread-group dies by SIGSEGV (exit
    /// 139). Signal-delivery callers map this to a term_signal=SIGSEGV
    /// termination instead of propagating a fatal carrick error.
    #[error("signal frame could not be delivered to the guest stack")]
    SignalDeliveryFault,
    #[error("guest mapping size {0} does not fit this host")]
    MappingTooLarge(u64),
    #[error("guest mapping at 0x{guest_start:x} with size {mapped_size} overflows")]
    MappingOverflow { guest_start: u64, mapped_size: u64 },
    #[error("hypervisor exited for an unexpected reason: {reason}")]
    UnexpectedExit { reason: String },
    #[error(
        "guest exception is not an AArch64 SVC trap: syndrome=0x{syndrome:x}, virtual_address=0x{virtual_address:x}, physical_address=0x{physical_address:x}"
    )]
    UnexpectedException {
        syndrome: u64,
        virtual_address: u64,
        physical_address: u64,
    },
    /// The host ran out of VM/vCPU capacity and stayed exhausted past the
    /// bounded admission wait (HVF's ~127-VM hard ceiling / the ~120-permit
    /// soft budget). Creation paths surface it as a bounded, loud error instead
    /// of parking forever.
    #[error("host VM/vCPU capacity exhausted: {what}")]
    HostResourceExhausted { what: String },
    #[error(
        "guest-memory map(host=0x{host_addr:x}, guest=0x{guest_start:x}, size={size}) failed in child: 0x{code:x}"
    )]
    ChildMapFailed {
        host_addr: u64,
        guest_start: u64,
        size: usize,
        code: u32,
    },
    /// An EL0 sync exception other than `svc #0` reached the EL1 vector
    /// trampoline (e.g. instruction abort at PC=0, data abort, undef). Surfaces
    /// the original syndrome/ELR/FAR so the runtime can map it to a Linux signal.
    ///
    /// This variant is **aarch64-internal**: the aarch64 engines (HVF, KVM
    /// aarch64) raise it carrying raw `ESR_EL1`, and the runtime loop *lowers* it
    /// to the ISA-neutral [`TrapError::GuestFault`] at the loop boundary (it
    /// resolves the raw ESR to the `(signum, si_code, fault_addr)` triple,
    /// covering both abort and debug classes). x86 backends never raise it; they
    /// emit `GuestFault` directly.
    #[error(
        "EL0 fault not handled by trap path: esr=0x{syndrome:x} elr=0x{elr:x} far=0x{far:x} x16=0x{x16:x} x17=0x{x17:x} x29=0x{x29:x} x30=0x{x30:x} sp=0x{sp:x}"
    )]
    EL0Fault {
        syndrome: u64,
        elr: u64,
        far: u64,
        x16: u64,
        x17: u64,
        x29: u64,
        x30: u64,
        sp: u64,
        from_el0_direct: bool,
    },
    #[error("stage-1 COW fault: esr=0x{syndrome:x} far=0x{far:x}")]
    Stage1CowFault {
        syndrome: u64,
        far: u64,
        elr: u64,
        spsr: u64,
    },
    /// carrick's guest took a SYNCHRONOUS exception while the CPU was at EL1.
    /// The guest itself only ever runs at EL0, and carrick's EL1 trampoline is
    /// just `hvc`/`eret`/shim code — so this is always carrick state corruption
    /// (a guest resume that left PSTATE at EL1, e.g. a signal handler entered
    /// with SPSR_EL1=EL1h whose PXN instruction fetch then aborts). The
    /// current-EL synchronous vector slots trap it via `hvc #3` so it FAILS LOUD
    /// here, instead of the guest spinning forever on a bare-`eret` that
    /// re-enters the faulting instruction at 100 % CPU. The raw EL1 fault
    /// registers (ESR/ELR/FAR/SPSR) pin the cause for post-mortem.
    #[error(
        "guest executed at EL1 (carrick state corruption): esr_el1=0x{esr_el1:x} elr_el1=0x{elr_el1:x} far_el1=0x{far_el1:x} spsr_el1=0x{spsr_el1:x}"
    )]
    GuestAtEl1 {
        esr_el1: u64,
        elr_el1: u64,
        far_el1: u64,
        spsr_el1: u64,
    },
    /// An ISA-neutral synchronous guest fault, carrying the **already-resolved**
    /// Linux signal triple (NOT a raw architectural syndrome). The runtime's
    /// fault arm delivers `signum`/`si_code` to the guest with `si_addr =
    /// fault_addr`.
    ///
    /// - aarch64 lowers [`TrapError::EL0Fault`] to this at the loop boundary
    ///   (resolving `ESR_EL1` → SIGSEGV/SIGBUS/SIGTRAP + `si_code`, and
    ///   `fault_addr` from `FAR_EL1`/`ELR_EL1`).
    /// - x86 backends emit it directly, filling `fault_addr` from **CR2** for the
    ///   SIGSEGV `si_addr`.
    #[error("guest fault: signum={signum} si_code={si_code} fault_addr=0x{fault_addr:x}")]
    GuestFault {
        signum: i32,
        si_code: i32,
        fault_addr: u64,
    },
}

impl TrapError {
    /// Build a [`TrapError::EL0Fault`] from the fault info + the EL0 GP-register
    /// snapshot captured at an aarch64 guest fault. The two aarch64 backends read
    /// these off their own vCPU API (HVF applevisor `Reg`/`SysReg`, KVM
    /// `carrick_hal::Reg`) then call this — single-sourcing the 9-field `EL0Fault`
    /// variant shape so a new fault field is added in ONE place, not in every
    /// backend's struct literal. (F7: the shared aarch64 fault-construction seam,
    /// the `Aarch64EngineCore` symmetry to `carrick_x86`.)
    #[allow(clippy::too_many_arguments)]
    pub fn el0_fault(
        syndrome: u64,
        elr: u64,
        far: u64,
        x16: u64,
        x17: u64,
        x29: u64,
        x30: u64,
        sp: u64,
        from_el0_direct: bool,
    ) -> Self {
        TrapError::EL0Fault {
            syndrome,
            elr,
            far,
            x16,
            x17,
            x29,
            x30,
            sp,
            from_el0_direct,
        }
    }
}

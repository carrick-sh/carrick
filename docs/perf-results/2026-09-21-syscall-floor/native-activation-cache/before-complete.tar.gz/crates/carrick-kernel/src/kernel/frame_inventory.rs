//! Runtime authority for the pointer-free HAL frame inventory.
//!
//! Mapping generations are per-`MappingId` lifecycle versions. Preparation
//! starts at generation 1; publication retains that generation; each protect
//! or unmap advances it by exactly one. Frame retirement must share the final
//! unmap generation in the same transaction. IDs and generations never restart.

use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::num::NonZeroU64;
use std::time::Instant;

use carrick_fatal::carrick_fatal;
use carrick_guest_mem::Gpa;
use carrick_hal::{
    FrameEventCapacity, FrameId, FrameInventoryApplyReceipt, FrameInventoryBatch,
    FrameInventoryBatchError, FrameInventoryCommit, FrameInventoryEvent, FrameInventoryProvenance,
    FrameInventoryReservation, FrameInventoryRetirementReceipt, FrameLength, KernelTransactionId,
    MappingGeneration, MappingId, MemPerms,
};
use parking_lot::Mutex;

use super::{MmId, ObjectIdError, ObjectIdRegistry};

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrameRow {
    pub frame: FrameId,
    pub length: FrameLength,
    pub mappings: Vec<MappingId>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct MappingRow {
    pub mapping: MappingId,
    pub frame: FrameId,
    pub mm: MmId,
    pub generation: MappingGeneration,
    pub gpa: Gpa,
    pub length: FrameLength,
    pub permissions: MemPerms,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct FrameInventorySnapshot {
    pub revision: u64,
    pub frames: Vec<FrameRow>,
    pub mappings: Vec<MappingRow>,
}

#[derive(Debug, Default)]
pub struct FrameInventoryAuthority {
    state: Mutex<InventoryState>,
    entropy: Mutex<ProvenanceEntropyBatch>,
}

/// Eight independent OS-generated tokens; consumed slots are cleared and
/// cached bytes are discarded if the authority is inherited by a host fork.
#[derive(Default)]
struct ProvenanceEntropyBatch {
    tokens: [[u8; 32]; 8],
    remaining: usize,
    owner_pid: u32,
}

impl std::fmt::Debug for ProvenanceEntropyBatch {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ProvenanceEntropyBatch")
            .field("remaining", &self.remaining)
            .finish_non_exhaustive()
    }
}

impl ProvenanceEntropyBatch {
    fn next(
        &mut self,
        pid: u32,
        mut fill: impl FnMut(&mut [u8]) -> Result<(), FrameInventoryReserveError>,
    ) -> Result<[u8; 32], FrameInventoryReserveError> {
        if self.owner_pid != pid {
            self.tokens.fill([0; 32]);
            self.remaining = 0;
            self.owner_pid = pid;
        }
        if self.remaining == 0 {
            if let Err(error) = fill(self.tokens.as_flattened_mut()) {
                // An entropy source may fail after a partial write. None of
                // those bytes may become a later transaction's provenance.
                self.tokens.fill([0; 32]);
                return Err(error);
            }
            self.remaining = self.tokens.len();
        }
        let index = self.tokens.len() - self.remaining;
        self.remaining -= 1;
        Ok(std::mem::take(&mut self.tokens[index]))
    }
}

#[derive(Debug, Default, Eq, PartialEq)]
struct InventoryState {
    revision: u64,
    reservations: BTreeMap<KernelTransactionId, ReservationRecord>,
    frames: BTreeMap<FrameId, FrameEntry>,
    mappings: BTreeMap<MappingId, MappingEntry>,
    /// Live mapping count per address space, maintained alongside `mappings`.
    ///
    /// `apply_inner` has to report whether the committing mm still owns any
    /// mapping AT the revision it just produced. Answering that by scanning
    /// every mapping in the carrier made each commit O(all address spaces),
    /// so a process group's memory traffic was quadratic in its own size; the
    /// scan showed up as `Iterator::all` under
    /// `FrameInventoryAuthority::apply_inner` at 8.3% of carrier CPU in the
    /// 2026-08-30 fork/exit sweep. `mappings` is mutated in exactly one place,
    /// so this stays exact by construction.
    mm_mapping_counts: BTreeMap<MmId, usize>,
}

#[derive(Debug, Eq, PartialEq)]
struct ReservationRecord {
    provenance: FrameInventoryProvenance,
    frames: Vec<FrameId>,
    mappings: Vec<MappingId>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct FrameEntry {
    length: FrameLength,
    mapping_count: usize,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
struct MappingEntry {
    frame: FrameId,
    mm: MmId,
    generation: MappingGeneration,
    gpa: Gpa,
    length: FrameLength,
    permissions: MemPerms,
    state: MappingState,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum MappingState {
    Prepared(KernelTransactionId),
    Published,
}

/// Transaction-local copy-on-write view. Only touched mappings and frames are
/// cloned, so applying one alias remains O(events + aliases of touched frames)
/// rather than O(the process-wide inventory).
/// Drop one live mapping from an address space's count, removing the row when
/// it reaches zero so `mm_mapping_counts` never accumulates dead address
/// spaces. Saturating rather than panicking: an undercount would be a
/// bookkeeping bug, and the `debug_assert` in `apply_inner` is what catches it.
/// Test-only: recompute the per-mm mapping counts from the authoritative
/// mapping table. Production reads the maintained counter; this is what proves
/// the two agree.
#[cfg(test)]
fn recomputed_mm_mapping_counts(state: &InventoryState) -> BTreeMap<MmId, usize> {
    let mut counts = BTreeMap::new();
    for mapping in state.mappings.values() {
        *counts.entry(mapping.mm).or_insert(0) += 1;
    }
    counts
}

fn decrement_mm_mapping_count(counts: &mut BTreeMap<MmId, usize>, mm: MmId) {
    if let Some(count) = counts.get_mut(&mm) {
        *count = count.saturating_sub(1);
        if *count == 0 {
            counts.remove(&mm);
        }
    }
}

struct InventoryOverlay<'a> {
    base: &'a InventoryState,
    frames: BTreeMap<FrameId, Option<FrameEntry>>,
    mappings: BTreeMap<MappingId, Option<MappingEntry>>,
    last_unmapped: BTreeMap<FrameId, MappingGeneration>,
}

struct InventoryChanges {
    frames: BTreeMap<FrameId, Option<FrameEntry>>,
    mappings: BTreeMap<MappingId, Option<MappingEntry>>,
}

impl<'a> InventoryOverlay<'a> {
    fn new(base: &'a InventoryState) -> Self {
        Self {
            base,
            frames: BTreeMap::new(),
            mappings: BTreeMap::new(),
            last_unmapped: BTreeMap::new(),
        }
    }

    fn mapping(&self, mapping: MappingId) -> Option<&MappingEntry> {
        match self.mappings.get(&mapping) {
            Some(Some(entry)) => Some(entry),
            Some(None) => None,
            None => self.base.mappings.get(&mapping),
        }
    }

    fn mapping_mut(&mut self, mapping: MappingId) -> Option<&mut MappingEntry> {
        if !self.mappings.contains_key(&mapping) {
            let entry = *self.base.mappings.get(&mapping)?;
            self.mappings.insert(mapping, Some(entry));
        }
        self.mappings.get_mut(&mapping)?.as_mut()
    }

    fn insert_mapping(&mut self, mapping: MappingId, entry: MappingEntry) {
        self.mappings.insert(mapping, Some(entry));
    }

    fn unmap_mapping(&mut self, mapping: MappingId, frame: FrameId, generation: MappingGeneration) {
        self.mappings.insert(mapping, None);
        self.last_unmapped.insert(frame, generation);
    }

    fn frame(&self, frame: FrameId) -> Option<&FrameEntry> {
        match self.frames.get(&frame) {
            Some(Some(entry)) => Some(entry),
            Some(None) => None,
            None => self.base.frames.get(&frame),
        }
    }

    fn frame_mut(&mut self, frame: FrameId) -> Option<&mut FrameEntry> {
        if !self.frames.contains_key(&frame) {
            let entry = *self.base.frames.get(&frame)?;
            self.frames.insert(frame, Some(entry));
        }
        self.frames.get_mut(&frame)?.as_mut()
    }

    fn insert_frame(&mut self, frame: FrameId, entry: FrameEntry) {
        self.frames.insert(frame, Some(entry));
    }

    fn retire_frame(&mut self, frame: FrameId) {
        self.frames.insert(frame, None);
    }

    fn into_changes(self) -> InventoryChanges {
        InventoryChanges {
            frames: self.frames,
            mappings: self.mappings,
        }
    }
}

impl FrameInventoryAuthority {
    pub fn new() -> Self {
        Self::default()
    }

    /// Allocate and register the only candidate IDs this transaction may
    /// publish. A forged HAL batch therefore cannot become authoritative.
    pub fn reserve(
        &self,
        ids: &ObjectIdRegistry,
        frame_candidates: usize,
        mapping_candidates: usize,
        event_capacity: FrameEventCapacity,
    ) -> Result<FrameInventoryReservation, FrameInventoryReserveError> {
        let (reservation, record) = prepare_reservation(
            ids,
            frame_candidates,
            mapping_candidates,
            event_capacity,
            &self.entropy,
        )?;
        let transaction = reservation.transaction();
        if self
            .state
            .lock()
            .reservations
            .insert(transaction, record)
            .is_some()
        {
            return Err(FrameInventoryReserveError::DuplicateTransaction);
        }
        Ok(reservation)
    }

    /// Release provenance after backend work fails before publication.
    /// Candidate IDs remain burned in the monotonic registry.
    pub fn abandon(&self, transaction: KernelTransactionId) -> bool {
        self.state
            .lock()
            .reservations
            .remove(&transaction)
            .is_some()
    }

    /// Apply one backend commit atomically after backend locks are released.
    pub fn apply<T>(
        &self,
        mm: MmId,
        commit: FrameInventoryCommit<T>,
    ) -> Result<(T, u64), FrameInventoryError> {
        let (outcome, revision, _) = self.apply_inner(mm, commit, None)?;
        Ok((outcome, revision))
    }

    /// Apply and issue an opaque provenance-authenticated receipt in the same
    /// Kernel owner operation. The backend retains the commit challenge and
    /// cannot fabricate this receipt from a dropped/unapplied commit.
    pub fn apply_with_receipt<T>(
        &self,
        mm: MmId,
        commit: FrameInventoryCommit<T>,
    ) -> Result<(T, FrameInventoryApplyReceipt), FrameInventoryError> {
        let transaction = commit.batch().transaction();
        let provenance = self
            .state
            .lock()
            .reservations
            .get(&transaction)
            .map(|reservation| reservation.provenance)
            .ok_or(FrameInventoryError::UnreservedTransaction(transaction))?;
        let mut mappings = Vec::new();
        for event in commit.batch().events() {
            if let FrameInventoryEvent::PrepareMapping { mapping, frame, .. } = *event
                && !mappings.contains(&(mapping, frame))
            {
                mappings.push((mapping, frame));
            }
        }
        let mm_id = mm;
        let (outcome, revision, _) = self.apply_inner(mm_id, commit, None)?;
        let mm = NonZeroU64::new(mm.raw()).unwrap_or_else(|| {
            carrick_fatal!(
                "kernel::frame_inventory",
                "zero mm ID encountered in apply_with_receipt"
            );
        });
        Ok((
            outcome,
            FrameInventoryApplyReceipt::from_kernel_authority(
                provenance,
                transaction,
                mm,
                revision,
                mappings,
            ),
        ))
    }

    /// Undo an apply that initialized an address space whose owning kernel
    /// object never became visible. Mapping IDs are monotonic and the receipt
    /// names the exact `(mapping, frame, mm)` set, so this removes no sibling
    /// publication even if other address spaces advanced the global revision.
    pub fn rollback_unpublished_apply(
        &self,
        receipt: &FrameInventoryApplyReceipt,
    ) -> Result<(), FrameInventoryError> {
        let mm = MmId::from_raw_u64(receipt.mm().get())
            .ok_or(FrameInventoryError::RollbackReceiptMmInvalid)?;
        let mut state = self.state.lock();
        let next_revision = state
            .revision
            .checked_add(1)
            .ok_or(FrameInventoryError::RevisionExhausted)?;
        let mut unique = BTreeSet::new();
        for &(mapping, frame) in receipt.mapping_set() {
            if !unique.insert(mapping) {
                return Err(FrameInventoryError::RollbackReceiptDuplicate(mapping));
            }
            let entry = state
                .mappings
                .get(&mapping)
                .ok_or(FrameInventoryError::RollbackReceiptMismatch(mapping))?;
            if entry.state != MappingState::Published || entry.mm != mm || entry.frame != frame {
                return Err(FrameInventoryError::RollbackReceiptMismatch(mapping));
            }
            let frame_entry = state
                .frames
                .get(&frame)
                .ok_or(FrameInventoryError::RollbackReceiptMismatch(mapping))?;
            if frame_entry.mapping_count == 0 {
                return Err(FrameInventoryError::MappingCountUnderflow(frame));
            }
        }

        for &(mapping, frame) in receipt.mapping_set() {
            let removed = state
                .mappings
                .remove(&mapping)
                .ok_or(FrameInventoryError::RollbackReceiptMismatch(mapping))?;
            decrement_mm_mapping_count(&mut state.mm_mapping_counts, removed.mm);
            let retire_frame = {
                let frame_entry = state
                    .frames
                    .get_mut(&frame)
                    .ok_or(FrameInventoryError::RollbackReceiptMismatch(mapping))?;
                frame_entry.mapping_count = frame_entry
                    .mapping_count
                    .checked_sub(1)
                    .ok_or(FrameInventoryError::MappingCountUnderflow(frame))?;
                frame_entry.mapping_count == 0
            };
            if retire_frame {
                state.frames.remove(&frame);
            }
        }
        state.revision = next_revision;
        Ok(())
    }

    pub fn apply_retirement_with_receipt<T>(
        &self,
        mm: MmId,
        commit: FrameInventoryCommit<T>,
    ) -> Result<(T, FrameInventoryRetirementReceipt), FrameInventoryError> {
        let transaction = commit.batch().transaction();
        let state = self.state.lock();
        let provenance = state
            .reservations
            .get(&transaction)
            .map(|reservation| reservation.provenance)
            .ok_or(FrameInventoryError::UnreservedTransaction(transaction))?;
        let mut mappings = Vec::new();
        for event in commit.batch().events() {
            if let FrameInventoryEvent::UnmapMapping { mapping, .. } = *event {
                let frame = state
                    .mappings
                    .get(&mapping)
                    .map(|entry| entry.frame)
                    .ok_or(FrameInventoryError::NonliveMapping(mapping))?;
                if !mappings.contains(&(mapping, frame)) {
                    mappings.push((mapping, frame));
                }
            }
        }
        drop(state);
        let mm_id = mm;
        let (outcome, revision, mm_empty_at_revision) = self.apply_inner(mm_id, commit, None)?;
        let mm = NonZeroU64::new(mm.raw()).unwrap_or_else(|| {
            carrick_fatal!(
                "kernel::frame_inventory",
                "zero mm ID encountered in apply_retirement_with_receipt"
            );
        });
        let receipt = FrameInventoryApplyReceipt::from_kernel_authority(
            provenance,
            transaction,
            mm,
            revision,
            mappings,
        );
        Ok((
            outcome,
            FrameInventoryRetirementReceipt::from_kernel_authority(receipt, mm_empty_at_revision),
        ))
    }

    fn apply_inner<T>(
        &self,
        mm: MmId,
        commit: FrameInventoryCommit<T>,
        fail_before_event: Option<usize>,
    ) -> Result<(T, u64, bool), FrameInventoryError> {
        let transaction = commit.batch().transaction();
        let mut state = self.state.lock();
        let reserved_provenance = state
            .reservations
            .get(&transaction)
            .map(|reservation| reservation.provenance)
            .ok_or(FrameInventoryError::UnreservedTransaction(transaction))?;
        if !commit.provenance_matches(reserved_provenance) {
            return Err(FrameInventoryError::UnauthenticatedCommit(transaction));
        }
        let reservation = state
            .reservations
            .remove(&transaction)
            .ok_or(FrameInventoryError::UnreservedTransaction(transaction))?;
        let (outcome, batch) = commit.into_parts();
        if batch.events().is_empty() {
            return Err(FrameInventoryError::EmptyBatch);
        }
        let next_revision = state
            .revision
            .checked_add(1)
            .ok_or(FrameInventoryError::RevisionExhausted)?;
        let mut candidate = InventoryOverlay::new(&state);
        for (index, event) in batch.events().iter().copied().enumerate() {
            if fail_before_event == Some(index) {
                return Err(FrameInventoryError::InjectedFailure(index));
            }
            apply_event(&mut candidate, &reservation, mm, transaction, event)?;
        }
        if fail_before_event == Some(batch.events().len()) {
            return Err(FrameInventoryError::InjectedFailure(batch.events().len()));
        }
        if candidate.mappings.values().flatten().any(|mapping| {
            matches!(mapping.state, MappingState::Prepared(owner) if owner == transaction)
        }) {
            return Err(FrameInventoryError::UnpublishedMapping);
        }
        let changes = candidate.into_changes();
        for (frame, entry) in changes.frames {
            match entry {
                Some(entry) => {
                    state.frames.insert(frame, entry);
                }
                None => {
                    state.frames.remove(&frame);
                }
            }
        }
        for (mapping, entry) in changes.mappings {
            match entry {
                Some(entry) => {
                    let mm_after = entry.mm;
                    if let Some(previous) = state.mappings.insert(mapping, entry) {
                        decrement_mm_mapping_count(&mut state.mm_mapping_counts, previous.mm);
                    }
                    *state.mm_mapping_counts.entry(mm_after).or_insert(0) += 1;
                }
                None => {
                    if let Some(previous) = state.mappings.remove(&mapping) {
                        decrement_mm_mapping_count(&mut state.mm_mapping_counts, previous.mm);
                    }
                }
            }
        }
        state.revision = next_revision;
        // Decided HERE, under the lock that produced `next_revision`, because
        // this is a claim about that exact revision. Reading it after the lock
        // drops makes it a claim about a later revision that a concurrent
        // commit may already have moved.
        // NOT a `debug_assert`: re-deriving this by scanning every mapping
        // reintroduces exactly the O(all address spaces) cost the counter
        // removes, and the conformance lane runs debug builds -- the assert
        // measured 20.7% of carrier CPU, worse than the scan it replaced.
        // `mm_mapping_counts` is verified against the mapping table by
        // `per_mm_mapping_counts_track_the_mapping_table` instead.
        let mm_empty_at_revision = state.mm_mapping_counts.get(&mm).copied().unwrap_or(0) == 0;
        Ok((outcome, next_revision, mm_empty_at_revision))
    }

    pub fn snapshot(&self) -> FrameInventorySnapshot {
        snapshot_state(&self.state.lock(), None)
    }

    pub fn snapshot_for_mm(&self, mm: MmId) -> FrameInventorySnapshot {
        snapshot_state(&self.state.lock(), Some(mm))
    }

    /// O(1) point query: does `mapping` exist, PUBLISHED, in `mm`, bound to
    /// exactly this (frame, gpa, length)? The COW-fault authority asks this
    /// once per resolved fault; answering it with `snapshot_for_mm` allocated
    /// row vectors for the WHOLE inventory under the global mutex, which made
    /// each fork-storm COW fault O(live inventory) — fork cost climbed
    /// linearly with live-process count (1.1 ms at 100 live -> 35 ms at
    /// 1000; LTP futex_cmp_requeue01's 1000-waiter phase starved on it).
    pub fn mapping_is_live_exact(
        &self,
        mm: MmId,
        mapping: MappingId,
        frame: FrameId,
        gpa: Gpa,
        length: FrameLength,
    ) -> bool {
        let state = self.state.lock();
        state.mappings.get(&mapping).is_some_and(|entry| {
            entry.state == MappingState::Published
                && entry.mm == mm
                && entry.frame == frame
                && entry.gpa == gpa
                && entry.length == length
        })
    }

    /// Exact point query tied to the same global inventory revision carried by
    /// a kernel-issued foreign-COW proof. Any intervening inventory publication
    /// makes the proof stale even if the mapping row itself is unchanged.
    pub fn mapping_is_live_exact_at_revision(
        &self,
        mm: MmId,
        revision: u64,
        mapping: MappingId,
        frame: FrameId,
        gpa: Gpa,
        length: FrameLength,
    ) -> bool {
        let state = self.state.lock();
        state.revision == revision
            && state.mappings.get(&mapping).is_some_and(|entry| {
                entry.state == MappingState::Published
                    && entry.mm == mm
                    && entry.frame == frame
                    && entry.gpa == gpa
                    && entry.length == length
            })
    }

    /// Live mappings naming `frame`, across every mm; `None` once the frame
    /// is retired or was never inserted.
    ///
    /// This is the population `RetireFrame` enforces, so a backend planning a
    /// retirement must gate on THIS number rather than on its own per-mm
    /// bookkeeping.
    /// Diagnostic for a refused publication: the reserved, not-yet-applied
    /// transaction (if any) holding `frame` as a candidate. A `PrepareMapping`
    /// naming a frame the authority does not know can only be legitimate if
    /// that frame is a candidate of THIS batch's reservation; a hit here on a
    /// DIFFERENT transaction means a sibling staged the frame in the backend
    /// (where a shared-file frame is visible to reusers from staging time)
    /// but has not published it yet — the publication-order race. Linear in
    /// the live reservation count, which is small; failure-path only.
    pub fn pending_reservation_for_frame(&self, frame: FrameId) -> Option<KernelTransactionId> {
        let state = self.state.lock();
        state
            .reservations
            .iter()
            .find(|(_, record)| record.frames.binary_search(&frame).is_ok())
            .map(|(transaction, _)| *transaction)
    }

    pub fn frame_mapping_count(&self, frame: FrameId) -> Option<usize> {
        let state = self.state.lock();
        state.frames.get(&frame).map(|entry| entry.mapping_count)
    }

    /// Query extent liveness for a batch of candidate extents and reference
    /// counts for a batch of frames under a single inventory mutex acquisition.
    pub fn retirement_batch_query(
        &self,
        mm: MmId,
        extents: &[(MappingId, FrameId, Gpa, FrameLength)],
        frames: &[FrameId],
    ) -> (Vec<bool>, Vec<Option<usize>>) {
        let state = self.state.lock();
        let extent_liveness = extents
            .iter()
            .map(|&(target_map, frame, gpa, length)| {
                state.mappings.get(&target_map).is_some_and(|entry| {
                    entry.state == MappingState::Published
                        && entry.mm == mm
                        && entry.frame == frame
                        && entry.gpa == gpa
                        && entry.length == length
                })
            })
            .collect();
        let frame_counts = frames
            .iter()
            .map(|&frame| state.frames.get(&frame).map(|entry| entry.mapping_count))
            .collect();
        (extent_liveness, frame_counts)
    }

    pub(crate) fn snapshot_until(&self, deadline: Instant) -> Option<FrameInventorySnapshot> {
        self.state
            .try_lock_until(deadline)
            .map(|state| snapshot_state(&state, None))
    }

    pub fn snapshot_for_mm_until(
        &self,
        mm: MmId,
        deadline: Instant,
    ) -> Option<FrameInventorySnapshot> {
        self.state
            .try_lock_until(deadline)
            .map(|state| snapshot_state(&state, Some(mm)))
    }

    pub(crate) fn revision_until(&self, deadline: Instant) -> Option<u64> {
        self.state
            .try_lock_until(deadline)
            .map(|state| state.revision)
    }

    #[cfg(test)]
    fn apply_with_failpoint<T>(
        &self,
        mm: MmId,
        commit: FrameInventoryCommit<T>,
        fail_before_event: usize,
    ) -> Result<(T, u64), FrameInventoryError> {
        let (outcome, revision, _) = self.apply_inner(mm, commit, Some(fail_before_event))?;
        Ok((outcome, revision))
    }
}

fn apply_event(
    state: &mut InventoryOverlay<'_>,
    reservation: &ReservationRecord,
    mm: MmId,
    transaction: KernelTransactionId,
    event: FrameInventoryEvent,
) -> Result<(), FrameInventoryError> {
    if event.transaction() != transaction {
        return Err(FrameInventoryError::TransactionMismatch);
    }
    match event {
        FrameInventoryEvent::PrepareMapping {
            frame,
            mapping,
            generation,
            gpa,
            length,
            permissions,
            ..
        } => {
            tracing::trace!(
                ?mm,
                ?transaction,
                ?mapping,
                ?frame,
                ?gpa,
                ?length,
                "frame inventory prepare"
            );
            if reservation.mappings.binary_search(&mapping).is_err() {
                return Err(FrameInventoryError::UnreservedMapping(mapping));
            }
            if gpa.0.checked_add(length.raw()).is_none() {
                return Err(FrameInventoryError::ExtentOverflow { gpa, length });
            }
            if generation.raw() != 1 {
                return Err(FrameInventoryError::GenerationMismatch {
                    mapping,
                    expected: 1,
                    actual: generation.raw(),
                });
            }
            if let Some(existing) = state.mapping(mapping) {
                return Err(if existing.mm != mm {
                    FrameInventoryError::CrossMmMappingReuse {
                        mapping,
                        owner: existing.mm,
                        attempted: mm,
                    }
                } else {
                    FrameInventoryError::DuplicateMapping(mapping)
                });
            }
            if state.frame(frame).is_none() {
                if reservation.frames.binary_search(&frame).is_err() {
                    return Err(FrameInventoryError::UnreservedFrame(frame));
                }
                state.insert_frame(
                    frame,
                    FrameEntry {
                        length,
                        mapping_count: 0,
                    },
                );
            }
            let frame_entry = state
                .frame_mut(frame)
                .ok_or(FrameInventoryError::RetiredFrame(frame))?;
            // A FrameId names the complete physical backing. Exact per-mm
            // mappings may cover smaller subranges after a 16 KiB COW/munmap
            // split; they must never claim more bytes than that backing.
            if length.raw() > frame_entry.length.raw() {
                return Err(FrameInventoryError::FrameLengthMismatch {
                    frame,
                    expected: frame_entry.length,
                    actual: length,
                });
            }
            frame_entry.mapping_count = frame_entry
                .mapping_count
                .checked_add(1)
                .ok_or(FrameInventoryError::MappingCountExhausted(frame))?;
            state.insert_mapping(
                mapping,
                MappingEntry {
                    frame,
                    mm,
                    generation,
                    gpa,
                    length,
                    permissions,
                    state: MappingState::Prepared(transaction),
                },
            );
        }
        FrameInventoryEvent::PublishMapping {
            mapping,
            generation,
            ..
        } => {
            let entry = state
                .mapping_mut(mapping)
                .ok_or(FrameInventoryError::NonliveMapping(mapping))?;
            if entry.mm != mm {
                return Err(FrameInventoryError::CrossMmMappingReuse {
                    mapping,
                    owner: entry.mm,
                    attempted: mm,
                });
            }
            if entry.generation != generation {
                return Err(generation_error(mapping, entry.generation, generation));
            }
            if entry.state != MappingState::Prepared(transaction) {
                return Err(FrameInventoryError::InvalidOrdering(mapping));
            }
            entry.state = MappingState::Published;
        }
        FrameInventoryEvent::ProtectMapping {
            mapping,
            generation,
            permissions,
            ..
        } => {
            let entry = live_mapping_mut(state, mm, mapping)?;
            require_next_generation(mapping, entry.generation, generation)?;
            entry.generation = generation;
            entry.permissions = permissions;
        }
        FrameInventoryEvent::UnmapMapping {
            mapping,
            generation,
            ..
        } => {
            tracing::trace!(
                ?mm,
                ?transaction,
                ?mapping,
                ?generation,
                "frame inventory unmap"
            );
            let frame_id = {
                let entry = live_mapping_mut(state, mm, mapping)?;
                require_next_generation(mapping, entry.generation, generation)?;
                entry.frame
            };
            let frame = state
                .frame_mut(frame_id)
                .ok_or(FrameInventoryError::RetiredFrame(frame_id))?;
            frame.mapping_count = frame
                .mapping_count
                .checked_sub(1)
                .ok_or(FrameInventoryError::MappingCountUnderflow(frame_id))?;
            state.unmap_mapping(mapping, frame_id, generation);
        }
        FrameInventoryEvent::RetireFrame {
            frame, generation, ..
        } => {
            let entry = state
                .frame(frame)
                .ok_or(FrameInventoryError::RetiredFrame(frame))?;
            if entry.mapping_count != 0 {
                return Err(FrameInventoryError::FrameStillMapped(frame));
            }
            let expected = state
                .last_unmapped
                .get(&frame)
                .copied()
                .ok_or(FrameInventoryError::RetireWithoutUnmap(frame))?;
            if generation != expected {
                return Err(FrameInventoryError::FrameGenerationMismatch {
                    frame,
                    expected: expected.raw(),
                    actual: generation.raw(),
                });
            }
            state.retire_frame(frame);
        }
    }
    Ok(())
}

fn live_mapping_mut<'a>(
    state: &'a mut InventoryOverlay<'_>,
    mm: MmId,
    mapping: MappingId,
) -> Result<&'a mut MappingEntry, FrameInventoryError> {
    let entry = state
        .mapping_mut(mapping)
        .ok_or(FrameInventoryError::NonliveMapping(mapping))?;
    if entry.mm != mm {
        return Err(FrameInventoryError::CrossMmMappingReuse {
            mapping,
            owner: entry.mm,
            attempted: mm,
        });
    }
    if entry.state != MappingState::Published {
        return Err(FrameInventoryError::MappingNotPublished(mapping));
    }
    Ok(entry)
}

fn require_next_generation(
    mapping: MappingId,
    current: MappingGeneration,
    actual: MappingGeneration,
) -> Result<(), FrameInventoryError> {
    let expected = next_generation(current)?;
    if expected != actual {
        return Err(generation_error(mapping, expected, actual));
    }
    Ok(())
}

fn next_generation(
    generation: MappingGeneration,
) -> Result<MappingGeneration, FrameInventoryError> {
    let raw = generation
        .raw()
        .checked_add(1)
        .and_then(NonZeroU64::new)
        .ok_or(FrameInventoryError::GenerationExhausted)?;
    Ok(MappingGeneration::from_backend_counter(raw))
}

fn generation_error(
    mapping: MappingId,
    expected: MappingGeneration,
    actual: MappingGeneration,
) -> FrameInventoryError {
    FrameInventoryError::GenerationMismatch {
        mapping,
        expected: expected.raw(),
        actual: actual.raw(),
    }
}

fn snapshot_state(state: &InventoryState, mm_filter: Option<MmId>) -> FrameInventorySnapshot {
    let mut frames = Vec::with_capacity(state.frames.len());
    let mut frame_indexes = HashMap::with_capacity(state.frames.len());
    for (index, (frame, entry)) in state.frames.iter().enumerate() {
        frame_indexes.insert(*frame, index);
        frames.push(FrameRow {
            frame: *frame,
            length: entry.length,
            mappings: Vec::new(),
        });
    }
    let mut mappings = Vec::with_capacity(state.mappings.len());
    for (mapping, entry) in &state.mappings {
        if entry.state != MappingState::Published || mm_filter.is_some_and(|mm| entry.mm != mm) {
            continue;
        }
        let row = MappingRow {
            mapping: *mapping,
            frame: entry.frame,
            mm: entry.mm,
            generation: entry.generation,
            gpa: entry.gpa,
            length: entry.length,
            permissions: entry.permissions,
        };
        if let Some(index) = frame_indexes.get(&entry.frame).copied() {
            frames[index].mappings.push(*mapping);
        }
        mappings.push(row);
    }
    if mm_filter.is_some() {
        frames.retain(|frame| !frame.mappings.is_empty());
    }
    FrameInventorySnapshot {
        revision: state.revision,
        frames,
        mappings,
    }
}

fn prepare_reservation(
    ids: &ObjectIdRegistry,
    frame_candidates: usize,
    mapping_candidates: usize,
    event_capacity: FrameEventCapacity,
    entropy: &Mutex<ProvenanceEntropyBatch>,
) -> Result<(FrameInventoryReservation, ReservationRecord), FrameInventoryReserveError> {
    if frame_candidates > event_capacity.get() || mapping_candidates > event_capacity.get() {
        return Err(FrameInventoryReserveError::CandidateCountExceedsEvents);
    }
    let mut frames = Vec::new();
    frames
        .try_reserve_exact(frame_candidates)
        .map_err(|_| FrameInventoryReserveError::AllocationFailed)?;
    let mut mappings = Vec::new();
    mappings
        .try_reserve_exact(mapping_candidates)
        .map_err(|_| FrameInventoryReserveError::AllocationFailed)?;
    let mut recorded_frames = Vec::new();
    recorded_frames
        .try_reserve_exact(frame_candidates)
        .map_err(|_| FrameInventoryReserveError::AllocationFailed)?;
    let mut recorded_mappings = Vec::new();
    recorded_mappings
        .try_reserve_exact(mapping_candidates)
        .map_err(|_| FrameInventoryReserveError::AllocationFailed)?;
    let transaction = ids.transaction_id()?;
    let provenance_bytes = entropy.lock().next(std::process::id(), |bytes| {
        getrandom::fill(bytes).map_err(|_| FrameInventoryReserveError::EntropyUnavailable)
    })?;
    let provenance = FrameInventoryProvenance::from_kernel_entropy(provenance_bytes);
    let batch = FrameInventoryBatch::prepare(transaction, event_capacity)?;
    for _ in 0..frame_candidates {
        let frame = ids.frame_id()?;
        frames.push(frame);
        recorded_frames.push(frame);
    }
    for _ in 0..mapping_candidates {
        let mapping = ids.mapping_id()?;
        mappings.push(mapping);
        recorded_mappings.push(mapping);
    }
    let record = ReservationRecord {
        provenance,
        frames: recorded_frames,
        mappings: recorded_mappings,
    };
    Ok((
        FrameInventoryReservation::from_kernel_candidates(provenance, batch, frames, mappings),
        record,
    ))
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, thiserror::Error)]
pub enum FrameInventoryReserveError {
    #[error("candidate count exceeds the bounded event capacity")]
    CandidateCountExceedsEvents,
    #[error("frame inventory candidate storage allocation failed")]
    AllocationFailed,
    #[error("frame inventory transaction candidate was already registered")]
    DuplicateTransaction,
    #[error("frame inventory reservation entropy is unavailable")]
    EntropyUnavailable,
    #[error(transparent)]
    ObjectId(#[from] ObjectIdError),
    #[error(transparent)]
    Batch(#[from] FrameInventoryBatchError),
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, thiserror::Error)]
pub enum FrameInventoryError {
    #[error("frame inventory batch is empty")]
    EmptyBatch,
    #[error("frame inventory transaction {0:?} was not reserved by this authority")]
    UnreservedTransaction(KernelTransactionId),
    #[error("frame inventory transaction {0:?} has invalid provenance")]
    UnauthenticatedCommit(KernelTransactionId),
    #[error("frame {0:?} was not reserved by this authority")]
    UnreservedFrame(FrameId),
    #[error("mapping {0:?} was not reserved by this authority")]
    UnreservedMapping(MappingId),
    #[error("frame inventory event transaction does not match its batch")]
    TransactionMismatch,
    #[error("mapping {0:?} is duplicated")]
    DuplicateMapping(MappingId),
    #[error("mapping {mapping:?} belongs to mm {owner:?}, not {attempted:?}")]
    CrossMmMappingReuse {
        mapping: MappingId,
        owner: MmId,
        attempted: MmId,
    },
    #[error("mapping {0:?} is not live")]
    NonliveMapping(MappingId),
    /// The mapping EXISTS but is still `Prepared` — its publishing transaction
    /// has not committed. Distinct from [`Self::NonliveMapping`], which means no
    /// such mapping at all. They were one error for a long time, which made a
    /// FATAL abort say only "is not live" and leave the reader unable to tell a
    /// double-retire (absent) from a mid-transaction one (prepared).
    #[error("mapping {0:?} exists but is not published")]
    MappingNotPublished(MappingId),
    #[error("mapping {0:?} event is out of lifecycle order")]
    InvalidOrdering(MappingId),
    #[error("mapping {mapping:?} generation {actual} does not match expected {expected}")]
    GenerationMismatch {
        mapping: MappingId,
        expected: u64,
        actual: u64,
    },
    #[error("frame {frame:?} generation {actual} does not match expected {expected}")]
    FrameGenerationMismatch {
        frame: FrameId,
        expected: u64,
        actual: u64,
    },
    #[error("mapping extent at {gpa:?} with length {length:?} overflows the GPA domain")]
    ExtentOverflow { gpa: Gpa, length: FrameLength },
    #[error("frame {frame:?} length {actual:?} does not match {expected:?}")]
    FrameLengthMismatch {
        frame: FrameId,
        expected: FrameLength,
        actual: FrameLength,
    },
    #[error("frame {0:?} is retired or unknown")]
    RetiredFrame(FrameId),
    #[error("frame {0:?} still has live mappings")]
    FrameStillMapped(FrameId),
    #[error("frame {0:?} retirement is not paired with its last unmap")]
    RetireWithoutUnmap(FrameId),
    #[error("batch leaves a prepared mapping unpublished")]
    UnpublishedMapping,
    #[error("mapping generation space exhausted")]
    GenerationExhausted,
    #[error("frame {0:?} mapping count exhausted")]
    MappingCountExhausted(FrameId),
    #[error("frame {0:?} mapping count underflowed")]
    MappingCountUnderflow(FrameId),
    #[error("frame inventory revision space exhausted")]
    RevisionExhausted,
    #[error("unpublished frame inventory rollback receipt has an invalid mm")]
    RollbackReceiptMmInvalid,
    #[error("unpublished frame inventory rollback receipt duplicates mapping {0:?}")]
    RollbackReceiptDuplicate(MappingId),
    #[error("unpublished frame inventory rollback receipt does not match mapping {0:?}")]
    RollbackReceiptMismatch(MappingId),
    #[error("test failpoint before event {0}")]
    InjectedFailure(usize),
}

impl FrameInventoryError {
    /// The frame a refusal is about, when it is about one.
    pub fn frame(&self) -> Option<FrameId> {
        match self {
            Self::UnreservedFrame(frame)
            | Self::RetiredFrame(frame)
            | Self::FrameStillMapped(frame)
            | Self::RetireWithoutUnmap(frame)
            | Self::MappingCountExhausted(frame)
            | Self::MappingCountUnderflow(frame)
            | Self::FrameGenerationMismatch { frame, .. }
            | Self::FrameLengthMismatch { frame, .. } => Some(*frame),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn provenance_entropy_batch_refills_once_per_eight_tokens() {
        let mut batch = ProvenanceEntropyBatch::default();
        let mut fills = 0;
        let mut seen = BTreeSet::new();
        for _ in 0..17 {
            let token = batch
                .next(1, |bytes| {
                    fills += 1;
                    for (i, chunk) in bytes.chunks_mut(32).enumerate() {
                        chunk.fill((fills * 8 + i) as u8);
                    }
                    Ok(())
                })
                .expect("entropy fixture");
            assert!(seen.insert(token), "tokens are consumed only once");
        }
        assert_eq!(fills, 3, "17 tokens need exactly three OS batches");
        assert_eq!(batch.remaining, 7);
        assert_eq!(batch.tokens[0], [0; 32], "consumed slot is cleared");
    }

    #[test]
    fn provenance_entropy_batch_discards_inherited_and_failed_bytes() {
        let mut batch = ProvenanceEntropyBatch::default();
        assert_eq!(
            batch
                .next(10, |bytes| {
                    bytes.fill(1);
                    Ok(())
                })
                .unwrap(),
            [1; 32]
        );
        let failed = batch.next(11, |bytes| {
            bytes[..16].fill(2);
            Err(FrameInventoryReserveError::EntropyUnavailable)
        });
        assert_eq!(failed, Err(FrameInventoryReserveError::EntropyUnavailable));
        assert_eq!(batch.remaining, 0);
        assert!(batch.tokens.iter().all(|token| *token == [0; 32]));
        assert_eq!(
            batch
                .next(11, |bytes| {
                    bytes.fill(3);
                    Ok(())
                })
                .unwrap(),
            [3; 32]
        );
        assert_eq!(batch.remaining, 7);
        assert_eq!(batch.owner_pid, 11);
        assert_eq!(batch.tokens[0], [0; 32]);
    }

    fn nz(raw: u64) -> NonZeroU64 {
        NonZeroU64::new(raw).expect("nonzero fixture value")
    }

    fn generation(raw: u64) -> MappingGeneration {
        MappingGeneration::from_backend_counter(nz(raw))
    }

    fn length(raw: u64) -> FrameLength {
        FrameLength::from_mapping_extent(nz(raw))
    }

    fn perms(write: bool) -> MemPerms {
        MemPerms {
            read: true,
            write,
            exec: false,
        }
    }

    struct Fixture {
        ids: ObjectIdRegistry,
        authority: FrameInventoryAuthority,
        mm1: MmId,
        mm2: MmId,
    }

    impl Fixture {
        fn new() -> Self {
            let ids = ObjectIdRegistry::new();
            let mm1 = ids.mm_id().expect("first mm");
            let mm2 = ids.mm_id().expect("second mm");
            Self {
                ids,
                authority: FrameInventoryAuthority::new(),
                mm1,
                mm2,
            }
        }

        fn batch(
            &self,
            events: usize,
            build: impl FnOnce(KernelTransactionId, &mut FrameInventoryReservation),
        ) -> FrameInventoryCommit<()> {
            let capacity = FrameEventCapacity::for_event_count(events).expect("capacity");
            let mut reservation = self
                .authority
                .reserve(&self.ids, events, events, capacity)
                .expect("reservation");
            let transaction = reservation.transaction();
            build(transaction, &mut reservation);
            reservation.commit(())
        }
    }

    fn prepare_publish(
        reservation: &mut FrameInventoryReservation,
        transaction: KernelTransactionId,
        frame: FrameId,
        mapping: MappingId,
        gpa: u64,
        len: u64,
    ) {
        reservation
            .push(FrameInventoryEvent::PrepareMapping {
                transaction,
                frame,
                mapping,
                generation: generation(1),
                gpa: Gpa(gpa),
                length: length(len),
                permissions: perms(true),
            })
            .expect("prepare");
        reservation
            .push(FrameInventoryEvent::PublishMapping {
                transaction,
                mapping,
                generation: generation(1),
            })
            .expect("publish");
    }

    #[test]
    fn retirement_emptiness_is_decided_under_the_applying_lock() {
        // `mm_empty_at_revision` is a claim ABOUT the revision the retirement
        // produced, so it has to be evaluated at that revision. Computing it
        // after `apply_inner` releases the state lock made it a claim about
        // whatever revision happened to be current a moment later: any
        // concurrent commit — a sibling process during fork teardown, which is
        // the normal case — bumped `state.revision`, the `state.revision ==
        // revision` conjunct went false, and an mm that really was empty
        // reported non-empty and aborted the carrier. Measured on `forkcow` at
        // roughly one run in four.
        //
        // The window is a few instructions wide, so a timing test would only
        // ever false-pass. Pin the shape instead: nothing after `apply_inner`
        // may re-read the state.
        let body = include_str!("frame_inventory.rs")
            .split("pub fn apply_retirement_with_receipt")
            .nth(1)
            .expect("retirement entry point");
        let tail = body
            .split("apply_inner(")
            .nth(1)
            .expect("the retirement applies through apply_inner");
        let tail = tail.split("fn apply_inner").next().unwrap_or(tail);
        assert!(
            !tail.contains("self.state.lock()"),
            "apply_retirement_with_receipt must not re-read inventory state after \
             apply_inner: the emptiness verdict belongs to the revision the apply \
             produced, not to whatever revision is current afterwards"
        );
    }

    #[test]
    fn kernel_apply_receipt_is_opaque_mm_and_mapping_frame_exact() {
        let fixture = Fixture::new();
        let mut expected = None;
        let batch = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().unwrap();
            let mapping = reservation.claim_mapping().unwrap();
            expected = Some((mapping, frame));
            prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
        });
        let challenge = batch.receipt_challenge();
        let (_, receipt) = fixture
            .authority
            .apply_with_receipt(fixture.mm1, batch)
            .unwrap();
        let (mapping, frame) = expected.unwrap();
        assert!(receipt.authorizes(mapping, frame));
        assert!(!receipt.authorizes(fixture.ids.mapping_id().unwrap(), frame));
        assert!(challenge.authenticate_apply(&receipt, nz(fixture.mm1.raw())));

        let retirement = fixture.batch(2, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::UnmapMapping {
                    transaction,
                    mapping,
                    generation: generation(2),
                })
                .unwrap();
            reservation
                .push(FrameInventoryEvent::RetireFrame {
                    transaction,
                    frame,
                    generation: generation(2),
                })
                .unwrap();
        });
        let retirement_challenge = retirement.receipt_challenge();
        let (_, retirement_receipt) = fixture
            .authority
            .apply_retirement_with_receipt(fixture.mm1, retirement)
            .unwrap();
        assert!(retirement_receipt.authorizes(mapping, frame));
        assert!(retirement_receipt.mm_empty_at_revision());
        assert!(
            retirement_challenge
                .authenticate_retirement(&retirement_receipt, nz(fixture.mm1.raw()))
        );
    }

    #[test]
    fn unpublished_apply_receipt_rolls_back_only_its_exact_mm_mappings() {
        let fixture = Fixture::new();
        let mut first_pair = None;
        let first = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().unwrap();
            let mapping = reservation.claim_mapping().unwrap();
            first_pair = Some((mapping, frame));
            prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
        });
        let (_, first_receipt) = fixture
            .authority
            .apply_with_receipt(fixture.mm1, first)
            .unwrap();

        let mut sibling_pair = None;
        let sibling = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().unwrap();
            let mapping = reservation.claim_mapping().unwrap();
            sibling_pair = Some((mapping, frame));
            prepare_publish(reservation, transaction, frame, mapping, 0x8000, 0x4000);
        });
        fixture.authority.apply(fixture.mm2, sibling).unwrap();

        fixture
            .authority
            .rollback_unpublished_apply(&first_receipt)
            .expect("rollback exact unpublished apply");
        let (first_mapping, first_frame) = first_pair.unwrap();
        assert!(!fixture.authority.mapping_is_live_exact(
            fixture.mm1,
            first_mapping,
            first_frame,
            Gpa(0x4000),
            length(0x4000),
        ));
        let (sibling_mapping, sibling_frame) = sibling_pair.unwrap();
        assert!(fixture.authority.mapping_is_live_exact(
            fixture.mm2,
            sibling_mapping,
            sibling_frame,
            Gpa(0x8000),
            length(0x4000),
        ));
    }

    #[test]
    fn sparse_40_gib_extent_stays_one_k1_frame_and_mapping() {
        let fixture = Fixture::new();
        const SPARSE_BANK_LEN: u64 = 40 * 1024 * 1024 * 1024;
        let batch = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("extent frame");
            let mapping = reservation.claim_mapping().expect("extent mapping");
            prepare_publish(
                reservation,
                transaction,
                frame,
                mapping,
                0x4000,
                SPARSE_BANK_LEN,
            );
        });
        fixture
            .authority
            .apply(fixture.mm1, batch)
            .expect("apply sparse extent");

        let snapshot = fixture.authority.snapshot();
        assert_eq!(snapshot.frames.len(), 1);
        assert_eq!(snapshot.mappings.len(), 1);
        assert_eq!(snapshot.frames[0].length.raw(), SPARSE_BANK_LEN);
        assert_eq!(snapshot.mappings[0].length.raw(), SPARSE_BANK_LEN);
    }

    #[test]
    fn high_alias_frame_keeps_constant_size_apply_state() {
        let fixture = Fixture::new();
        const ALIASES: usize = 1_024;
        assert_eq!(std::mem::size_of::<FrameEntry>(), 16);
        let mut first_mapping = None;
        let publish = fixture.batch(ALIASES * 2, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("shared frame");
            for index in 0..ALIASES {
                let mapping = reservation.claim_mapping().expect("alias mapping");
                first_mapping.get_or_insert(mapping);
                prepare_publish(
                    reservation,
                    transaction,
                    frame,
                    mapping,
                    0x4000 + u64::try_from(index).expect("bounded index") * 0x4000,
                    0x4000,
                );
            }
        });
        fixture
            .authority
            .apply(fixture.mm1, publish)
            .expect("publish aliases");
        assert_eq!(
            fixture.authority.snapshot().frames[0].mappings.len(),
            ALIASES
        );

        let mapping = first_mapping.expect("first alias");
        let protect = fixture.batch(1, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::ProtectMapping {
                    transaction,
                    mapping,
                    generation: generation(2),
                    permissions: perms(false),
                })
                .expect("protect one alias");
        });
        fixture
            .authority
            .apply(fixture.mm1, protect)
            .expect("constant-size protect");
        assert_eq!(
            fixture.authority.snapshot().frames[0].mappings.len(),
            ALIASES
        );
    }

    #[test]
    fn shared_frame_aliases_and_copied_frames_have_exact_sorted_joins() {
        let fixture = Fixture::new();
        let batch = fixture.batch(6, |transaction, reservation| {
            let shared = reservation.claim_frame().expect("shared frame");
            let copied = reservation.claim_frame().expect("copied frame");
            let high = reservation.claim_mapping().expect("mapping");
            let low = reservation.claim_mapping().expect("mapping");
            let copy = reservation.claim_mapping().expect("mapping");
            prepare_publish(reservation, transaction, shared, high, 0x8000, 0x4000);
            prepare_publish(reservation, transaction, shared, low, 0x4000, 0x4000);
            prepare_publish(reservation, transaction, copied, copy, 0xc000, 0x4000);
        });
        fixture.authority.apply(fixture.mm1, batch).expect("apply");

        let snapshot = fixture.authority.snapshot();
        assert_eq!(snapshot.revision, 1);
        assert_eq!(snapshot.frames.len(), 2);
        assert_eq!(snapshot.mappings.len(), 3);
        assert!(
            snapshot
                .frames
                .windows(2)
                .all(|rows| rows[0].frame < rows[1].frame)
        );
        assert!(
            snapshot
                .mappings
                .windows(2)
                .all(|rows| rows[0].mapping < rows[1].mapping)
        );
        for frame in &snapshot.frames {
            for mapping in &frame.mappings {
                assert_eq!(
                    snapshot
                        .mappings
                        .iter()
                        .find(|row| row.mapping == *mapping)
                        .map(|row| row.frame),
                    Some(frame.frame)
                );
            }
        }
        assert_eq!(fixture.authority.snapshot_for_mm(fixture.mm1), snapshot);
        assert!(
            fixture
                .authority
                .snapshot_for_mm(fixture.mm2)
                .mappings
                .is_empty()
        );
    }

    /// The maintained per-mm mapping counter must agree with the mapping table
    /// it summarizes, across publish, unmap and cross-mm sharing.
    ///
    /// `apply_inner` reports whether the committing mm still owns a mapping AT
    /// the revision it just produced. Deriving that by scanning every mapping
    /// in the carrier made each commit O(all live address spaces), so a
    /// process group's memory traffic was quadratic in its own size (8.3% of
    /// carrier CPU in the 2026-08-30 fork/exit sweep). The counter replaces
    /// that scan, and this is what keeps the two honest — a `debug_assert`
    /// cannot, because it re-runs the scan in exactly the debug builds the
    /// conformance lane uses.
    #[test]
    fn per_mm_mapping_counts_track_the_mapping_table() {
        let fixture = Fixture::new();
        let assert_counts_agree = |stage: &str| {
            let state = fixture.authority.state.lock();
            assert_eq!(
                state.mm_mapping_counts,
                recomputed_mm_mapping_counts(&state),
                "per-mm mapping counts diverged from the mapping table after {stage}"
            );
            assert!(
                state.mm_mapping_counts.values().all(|count| *count > 0),
                "an address space with no mappings must not retain a count row after {stage}"
            );
        };
        assert_counts_agree("construction");

        let mut first_mapping = None;
        let first = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("frame");
            let mapping = reservation.claim_mapping().expect("mapping");
            first_mapping = Some(mapping);
            prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
        });
        fixture
            .authority
            .apply(fixture.mm1, first)
            .expect("publish into mm1");
        assert_counts_agree("publish into mm1");

        let second = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("frame");
            let mapping = reservation.claim_mapping().expect("mapping");
            prepare_publish(reservation, transaction, frame, mapping, 0x8000, 0x4000);
        });
        fixture
            .authority
            .apply(fixture.mm2, second)
            .expect("publish into mm2");
        assert_counts_agree("publish into mm2");

        let first_mapping = first_mapping.expect("first mapping");
        let unmap = fixture.batch(1, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::UnmapMapping {
                    transaction,
                    mapping: first_mapping,
                    generation: generation(2),
                })
                .expect("unmap mm1's only mapping");
        });
        fixture
            .authority
            .apply(fixture.mm1, unmap)
            .expect("unmap from mm1");
        assert_counts_agree("unmap mm1's only mapping");
        assert!(
            !fixture
                .authority
                .state
                .lock()
                .mm_mapping_counts
                .contains_key(&fixture.mm1),
            "an emptied address space must drop out of the counter entirely"
        );
    }

    #[test]
    fn one_frame_can_join_aliases_from_distinct_mms() {
        let fixture = Fixture::new();
        let mut shared = None;
        let first = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("frame");
            let mapping = reservation.claim_mapping().expect("mapping");
            shared = Some((frame, mapping));
            prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
        });
        fixture
            .authority
            .apply(fixture.mm1, first)
            .expect("first alias");
        let (frame, first_mapping) = shared.expect("shared frame ID");
        let mut second_mapping = None;
        let second = fixture.batch(2, |transaction, reservation| {
            let mapping = reservation.claim_mapping().expect("mapping");
            second_mapping = Some(mapping);
            prepare_publish(reservation, transaction, frame, mapping, 0x8000, 0x4000);
        });
        fixture
            .authority
            .apply(fixture.mm2, second)
            .expect("second alias");

        assert_eq!(fixture.authority.snapshot().frames[0].mappings.len(), 2);
        assert_eq!(
            fixture.authority.snapshot_for_mm(fixture.mm1).frames[0]
                .mappings
                .len(),
            1
        );
        assert_eq!(
            fixture.authority.snapshot_for_mm(fixture.mm2).frames[0]
                .mappings
                .len(),
            1
        );

        let unmap_first = fixture.batch(1, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::UnmapMapping {
                    transaction,
                    mapping: first_mapping,
                    generation: generation(2),
                })
                .expect("unmap first alias");
        });
        fixture
            .authority
            .apply(fixture.mm1, unmap_first)
            .expect("remove first alias");
        assert!(
            fixture
                .authority
                .snapshot_for_mm(fixture.mm1)
                .frames
                .is_empty()
        );
        assert_eq!(fixture.authority.snapshot().frames[0].mappings.len(), 1);

        let second_mapping = second_mapping.expect("second mapping");
        let retire = fixture.batch(2, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::UnmapMapping {
                    transaction,
                    mapping: second_mapping,
                    generation: generation(2),
                })
                .expect("unmap second alias");
            reservation
                .push(FrameInventoryEvent::RetireFrame {
                    transaction,
                    frame,
                    generation: generation(2),
                })
                .expect("retire shared frame");
        });
        fixture
            .authority
            .apply(fixture.mm2, retire)
            .expect("retire last cross-mm alias");
        assert!(fixture.authority.snapshot().frames.is_empty());
        assert!(fixture.authority.snapshot().mappings.is_empty());
    }

    #[test]
    fn protect_then_atomic_unmap_retire_advances_generation_and_reclaims_rows() {
        let fixture = Fixture::new();
        let (frame, mapping) = {
            let mut values = None;
            let batch = fixture.batch(2, |transaction, reservation| {
                let frame = reservation.claim_frame().expect("frame");
                let mapping = reservation.claim_mapping().expect("mapping");
                values = Some((frame, mapping));
                prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
            });
            fixture
                .authority
                .apply(fixture.mm1, batch)
                .expect("publish");
            values.expect("IDs")
        };
        let protect = fixture.batch(1, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::ProtectMapping {
                    transaction,
                    mapping,
                    generation: generation(2),
                    permissions: perms(false),
                })
                .expect("protect");
        });
        fixture
            .authority
            .apply(fixture.mm1, protect)
            .expect("protect apply");
        assert!(!fixture.authority.snapshot().mappings[0].permissions.write);

        let retire = fixture.batch(2, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::UnmapMapping {
                    transaction,
                    mapping,
                    generation: generation(3),
                })
                .expect("unmap");
            reservation
                .push(FrameInventoryEvent::RetireFrame {
                    transaction,
                    frame,
                    generation: generation(3),
                })
                .expect("retire");
        });
        fixture
            .authority
            .apply(fixture.mm1, retire)
            .expect("unmap and retire apply");
        assert_eq!(fixture.authority.snapshot().revision, 3);
        assert!(fixture.authority.snapshot().frames.is_empty());
        assert!(fixture.authority.snapshot().mappings.is_empty());
    }

    #[test]
    fn rejects_duplicate_transaction_generation_length_order_and_cross_mm_reuse() {
        let fixture = Fixture::new();
        let mut ids = None;
        let original = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("frame");
            let mapping = reservation.claim_mapping().expect("mapping");
            ids = Some((frame, mapping));
            prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
        });
        let transaction = original.batch().transaction();
        let duplicate = FrameInventoryReservation::from_kernel_candidates(
            FrameInventoryProvenance::from_kernel_entropy([0x55; 32]),
            FrameInventoryBatch::prepare(
                transaction,
                FrameEventCapacity::for_event_count(1).expect("capacity"),
            )
            .expect("forged batch"),
            Vec::new(),
            Vec::new(),
        )
        .commit(());
        fixture
            .authority
            .apply(fixture.mm1, original)
            .expect("first");
        assert!(matches!(
            fixture.authority.apply(fixture.mm1, duplicate),
            Err(FrameInventoryError::UnreservedTransaction(_))
        ));
        let (frame, mapping) = ids.expect("IDs");

        let stale = fixture.batch(1, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::ProtectMapping {
                    transaction,
                    mapping,
                    generation: generation(3),
                    permissions: perms(false),
                })
                .expect("event");
        });
        assert!(matches!(
            fixture.authority.apply(fixture.mm1, stale),
            Err(FrameInventoryError::GenerationMismatch { .. })
        ));
        let cross_mm = fixture.batch(1, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::ProtectMapping {
                    transaction,
                    mapping,
                    generation: generation(2),
                    permissions: perms(false),
                })
                .expect("event");
        });
        assert!(matches!(
            fixture.authority.apply(fixture.mm2, cross_mm),
            Err(FrameInventoryError::CrossMmMappingReuse { .. })
        ));
        let alias_wrong_length = fixture.batch(2, |transaction, reservation| {
            let alias = reservation.claim_mapping().expect("alias");
            prepare_publish(reservation, transaction, frame, alias, 0x8000, 0x8000);
        });
        assert!(matches!(
            fixture.authority.apply(fixture.mm1, alias_wrong_length),
            Err(FrameInventoryError::FrameLengthMismatch { .. })
        ));
        let unmap_unknown = fixture.batch(1, |transaction, reservation| {
            let unknown = reservation.claim_mapping().expect("unknown");
            reservation
                .push(FrameInventoryEvent::UnmapMapping {
                    transaction,
                    mapping: unknown,
                    generation: generation(1),
                })
                .expect("event");
        });
        assert!(matches!(
            fixture.authority.apply(fixture.mm1, unmap_unknown),
            Err(FrameInventoryError::NonliveMapping(_))
        ));
    }

    #[test]
    fn invalid_lifecycle_ordering_and_duplicate_mapping_roll_back_exactly() {
        let fixture = Fixture::new();
        let mut ids = None;
        let initial = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("frame");
            let mapping = reservation.claim_mapping().expect("mapping");
            ids = Some((frame, mapping));
            prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
        });
        fixture
            .authority
            .apply(fixture.mm1, initial)
            .expect("initial mapping");
        let (frame, mapping) = ids.expect("IDs");
        let before = fixture.authority.snapshot();

        let duplicate = fixture.batch(2, |transaction, reservation| {
            prepare_publish(reservation, transaction, frame, mapping, 0x8000, 0x4000);
        });
        assert_eq!(
            fixture.authority.apply(fixture.mm1, duplicate),
            Err(FrameInventoryError::UnreservedMapping(mapping))
        );
        assert_eq!(fixture.authority.snapshot(), before);

        let publish_again = fixture.batch(1, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::PublishMapping {
                    transaction,
                    mapping,
                    generation: generation(1),
                })
                .expect("publish event");
        });
        assert_eq!(
            fixture.authority.apply(fixture.mm1, publish_again),
            Err(FrameInventoryError::InvalidOrdering(mapping))
        );
        assert_eq!(fixture.authority.snapshot(), before);

        let retire_live = fixture.batch(1, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::RetireFrame {
                    transaction,
                    frame,
                    generation: generation(2),
                })
                .expect("retire event");
        });
        assert_eq!(
            fixture.authority.apply(fixture.mm1, retire_live),
            Err(FrameInventoryError::FrameStillMapped(frame))
        );
        assert_eq!(fixture.authority.snapshot(), before);
    }

    #[test]
    fn unused_candidate_ids_burn_in_the_runtime_registry() {
        let fixture = Fixture::new();
        let capacity = FrameEventCapacity::for_event_count(2).expect("capacity");
        let mut abandoned = fixture
            .authority
            .reserve(&fixture.ids, 2, 2, capacity)
            .expect("reservation");
        let transaction = abandoned.transaction();
        let claimed_frame = abandoned.claim_frame().expect("frame");
        let claimed_mapping = abandoned.claim_mapping().expect("mapping");
        drop(abandoned);
        assert!(fixture.authority.abandon(transaction));

        let mut replacement = fixture
            .authority
            .reserve(&fixture.ids, 1, 1, capacity)
            .expect("replacement");
        assert!(replacement.claim_frame().expect("new frame").raw() > claimed_frame.raw());
        assert!(replacement.claim_mapping().expect("new mapping").raw() > claimed_mapping.raw());
    }

    #[test]
    fn rejects_an_unreserved_new_frame_even_with_a_reserved_mapping() {
        let fixture = Fixture::new();
        let forged = fixture.ids.frame_id().expect("forged frame");
        let batch = fixture.batch(2, |transaction, reservation| {
            let mapping = reservation.claim_mapping().expect("mapping");
            prepare_publish(reservation, transaction, forged, mapping, 0x4000, 0x4000);
        });
        assert_eq!(
            fixture.authority.apply(fixture.mm1, batch),
            Err(FrameInventoryError::UnreservedFrame(forged))
        );
        assert!(fixture.authority.snapshot().frames.is_empty());
    }

    #[test]
    fn guessed_ids_cannot_forge_a_reserved_transaction_capability() {
        let fixture = Fixture::new();
        let capacity = FrameEventCapacity::for_event_count(2).expect("capacity");
        let mut legitimate = fixture
            .authority
            .reserve(&fixture.ids, 1, 1, capacity)
            .expect("legitimate reservation");
        let transaction = legitimate.transaction();
        let frame = legitimate.claim_frame().expect("frame");
        let mapping = legitimate.claim_mapping().expect("mapping");
        prepare_publish(&mut legitimate, transaction, frame, mapping, 0x4000, 0x4000);

        let mut forged_batch =
            FrameInventoryBatch::prepare(transaction, capacity).expect("forged batch");
        forged_batch
            .push(FrameInventoryEvent::PrepareMapping {
                transaction,
                frame,
                mapping,
                generation: generation(1),
                gpa: Gpa(0x4000),
                length: length(0x4000),
                permissions: perms(true),
            })
            .expect("forged prepare");
        forged_batch
            .push(FrameInventoryEvent::PublishMapping {
                transaction,
                mapping,
                generation: generation(1),
            })
            .expect("forged publish");
        let forged = FrameInventoryReservation::from_kernel_candidates(
            FrameInventoryProvenance::from_kernel_entropy([0x99; 32]),
            forged_batch,
            vec![frame],
            vec![mapping],
        )
        .commit(());
        assert_eq!(
            fixture.authority.apply(fixture.mm1, forged),
            Err(FrameInventoryError::UnauthenticatedCommit(transaction))
        );
        fixture
            .authority
            .apply(fixture.mm1, legitimate.commit(()))
            .expect("real capability remains valid");
        assert_eq!(fixture.authority.snapshot().mappings.len(), 1);
    }

    #[test]
    fn duplicate_mapping_inside_one_reserved_batch_is_rejected_atomically() {
        let fixture = Fixture::new();
        let mut duplicate = None;
        let batch = fixture.batch(3, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("frame");
            let mapping = reservation.claim_mapping().expect("mapping");
            duplicate = Some(mapping);
            prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
            reservation
                .push(FrameInventoryEvent::PrepareMapping {
                    transaction,
                    frame,
                    mapping,
                    generation: generation(1),
                    gpa: Gpa(0x8000),
                    length: length(0x4000),
                    permissions: perms(true),
                })
                .expect("duplicate prepare");
        });
        let mapping = duplicate.expect("mapping ID");
        assert_eq!(
            fixture.authority.apply(fixture.mm1, batch),
            Err(FrameInventoryError::DuplicateMapping(mapping))
        );
        assert!(fixture.authority.snapshot().mappings.is_empty());
    }

    #[test]
    fn published_mapping_can_split_into_exact_subranges_of_the_same_frame() {
        let fixture = Fixture::new();
        let mut original = None;
        let publish = fixture.batch(2, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("frame");
            let mapping = reservation.claim_mapping().expect("mapping");
            original = Some((frame, mapping));
            prepare_publish(reservation, transaction, frame, mapping, 0x10000, 0x10000);
        });
        fixture
            .authority
            .apply(fixture.mm1, publish)
            .expect("publish original");
        let (frame, mapping) = original.expect("original IDs");

        let split = fixture.batch(5, |transaction, reservation| {
            reservation
                .push(FrameInventoryEvent::UnmapMapping {
                    transaction,
                    mapping,
                    generation: generation(2),
                })
                .expect("unmap original");
            for (gpa, len) in [(0x10000, 0x4000), (0x18000, 0x8000)] {
                let fragment = reservation.claim_mapping().expect("fragment mapping");
                prepare_publish(reservation, transaction, frame, fragment, gpa, len);
            }
        });
        fixture
            .authority
            .apply(fixture.mm1, split)
            .expect("apply split");

        let snapshot = fixture.authority.snapshot_for_mm(fixture.mm1);
        assert_eq!(snapshot.frames.len(), 1);
        assert_eq!(snapshot.frames[0].frame, frame);
        assert_eq!(snapshot.frames[0].length.raw(), 0x10000);
        assert_eq!(snapshot.mappings.len(), 2);
        assert_eq!(
            snapshot
                .mappings
                .iter()
                .map(|mapping| (mapping.gpa.0, mapping.length.raw()))
                .collect::<Vec<_>>(),
            vec![(0x10000, 0x4000), (0x18000, 0x8000)]
        );
    }

    #[test]
    fn completed_mapping_churn_reclaims_rows_and_provenance() {
        let fixture = Fixture::new();
        for index in 0..128_u64 {
            let mut ids = None;
            let publish = fixture.batch(2, |transaction, reservation| {
                let frame = reservation.claim_frame().expect("frame");
                let mapping = reservation.claim_mapping().expect("mapping");
                ids = Some((frame, mapping));
                prepare_publish(
                    reservation,
                    transaction,
                    frame,
                    mapping,
                    0x4000 + index * 0x4000,
                    0x4000,
                );
            });
            fixture
                .authority
                .apply(fixture.mm1, publish)
                .expect("publish");
            let (frame, mapping) = ids.expect("IDs");
            let retire = fixture.batch(2, |transaction, reservation| {
                reservation
                    .push(FrameInventoryEvent::UnmapMapping {
                        transaction,
                        mapping,
                        generation: generation(2),
                    })
                    .expect("unmap");
                reservation
                    .push(FrameInventoryEvent::RetireFrame {
                        transaction,
                        frame,
                        generation: generation(2),
                    })
                    .expect("retire");
            });
            fixture
                .authority
                .apply(fixture.mm1, retire)
                .expect("retire");
        }
        let snapshot = fixture.authority.snapshot();
        assert_eq!(snapshot.revision, 256);
        assert!(snapshot.frames.is_empty());
        assert!(snapshot.mappings.is_empty());
        let state = fixture.authority.state.lock();
        assert!(state.reservations.is_empty());
        assert!(state.frames.is_empty());
        assert!(state.mappings.is_empty());
    }

    #[test]
    fn every_event_failpoint_rolls_back_the_whole_batch() {
        for failpoint in 0..=3 {
            let fixture = Fixture::new();
            let batch = fixture.batch(3, |transaction, reservation| {
                let frame = reservation.claim_frame().expect("frame");
                let mapping = reservation.claim_mapping().expect("mapping");
                prepare_publish(reservation, transaction, frame, mapping, 0x4000, 0x4000);
                reservation
                    .push(FrameInventoryEvent::ProtectMapping {
                        transaction,
                        mapping,
                        generation: generation(2),
                        permissions: perms(false),
                    })
                    .expect("protect");
            });
            let before = fixture.authority.snapshot();
            assert_eq!(
                fixture
                    .authority
                    .apply_with_failpoint(fixture.mm1, batch, failpoint),
                Err(FrameInventoryError::InjectedFailure(failpoint))
            );
            assert_eq!(fixture.authority.snapshot(), before);
            assert!(fixture.authority.state.lock().reservations.is_empty());
        }
    }

    #[test]
    fn unpublished_prepare_rolls_back_without_revision_or_join_changes() {
        let fixture = Fixture::new();
        let batch = fixture.batch(1, |transaction, reservation| {
            let frame = reservation.claim_frame().expect("frame");
            let mapping = reservation.claim_mapping().expect("mapping");
            reservation
                .push(FrameInventoryEvent::PrepareMapping {
                    transaction,
                    frame,
                    mapping,
                    generation: generation(1),
                    gpa: Gpa(0x4000),
                    length: length(0x4000),
                    permissions: perms(true),
                })
                .expect("prepare");
        });
        assert_eq!(
            fixture.authority.apply(fixture.mm1, batch),
            Err(FrameInventoryError::UnpublishedMapping)
        );
        assert_eq!(
            fixture.authority.snapshot(),
            FrameInventorySnapshot {
                revision: 0,
                frames: Vec::new(),
                mappings: Vec::new(),
            }
        );
        assert!(fixture.authority.state.lock().reservations.is_empty());
    }

    #[test]
    fn retirement_batch_query_matches_point_queries_across_shared_and_private_frames() {
        let fixture = Fixture::new();
        let mm3 = fixture.ids.mm_id().expect("vfork child mm");

        let mut shared_frame = None;
        let mut private_frame = None;
        let mut mm1_shared_mapping = None;
        let mut mm1_private_mapping = None;

        // 1. Process mm1 sets up shared and private frames.
        let batch1 = fixture.batch(4, |transaction, reservation| {
            let shared = reservation.claim_frame().expect("shared frame");
            let private = reservation.claim_frame().expect("private frame");
            let m_shared = reservation.claim_mapping().expect("m_shared");
            let m_private = reservation.claim_mapping().expect("m_private");

            shared_frame = Some(shared);
            private_frame = Some(private);
            mm1_shared_mapping = Some(m_shared);
            mm1_private_mapping = Some(m_private);

            prepare_publish(reservation, transaction, shared, m_shared, 0x1000, 0x4000);
            prepare_publish(reservation, transaction, private, m_private, 0x2000, 0x4000);
        });
        fixture
            .authority
            .apply(fixture.mm1, batch1)
            .expect("apply mm1");

        let shared_frame = shared_frame.unwrap();
        let private_frame = private_frame.unwrap();
        let mm1_shared_mapping = mm1_shared_mapping.unwrap();
        let mm1_private_mapping = mm1_private_mapping.unwrap();

        // 2. Forked sibling mm2 maps the shared frame and its own private sibling frame.
        let mut sibling_frame = None;
        let mut mm2_shared_mapping = None;
        let mut mm2_sibling_mapping = None;
        let batch2 = fixture.batch(4, |transaction, reservation| {
            let sibling = reservation.claim_frame().expect("sibling frame");
            let m_shared = reservation.claim_mapping().expect("m_shared 2");
            let m_sibling = reservation.claim_mapping().expect("m_sibling");

            sibling_frame = Some(sibling);
            mm2_shared_mapping = Some(m_shared);
            mm2_sibling_mapping = Some(m_sibling);

            prepare_publish(
                reservation,
                transaction,
                shared_frame,
                m_shared,
                0x1000,
                0x4000,
            );
            prepare_publish(reservation, transaction, sibling, m_sibling, 0x3000, 0x4000);
        });
        fixture
            .authority
            .apply(fixture.mm2, batch2)
            .expect("apply mm2");

        let sibling_frame = sibling_frame.unwrap();
        let mm2_shared_mapping = mm2_shared_mapping.unwrap();
        let mm2_sibling_mapping = mm2_sibling_mapping.unwrap();

        // 3. vfork child mm3 maps the shared frame and its own private vfork frame.
        let mut vfork_frame = None;
        let mut mm3_shared_mapping = None;
        let mut mm3_vfork_mapping = None;
        let batch3 = fixture.batch(4, |transaction, reservation| {
            let vfork = reservation.claim_frame().expect("vfork frame");
            let m_shared = reservation.claim_mapping().expect("m_shared 3");
            let m_vfork = reservation.claim_mapping().expect("m_vfork");

            vfork_frame = Some(vfork);
            mm3_shared_mapping = Some(m_shared);
            mm3_vfork_mapping = Some(m_vfork);

            prepare_publish(
                reservation,
                transaction,
                shared_frame,
                m_shared,
                0x1000,
                0x4000,
            );
            prepare_publish(reservation, transaction, vfork, m_vfork, 0x4000, 0x4000);
        });
        fixture.authority.apply(mm3, batch3).expect("apply mm3");

        let vfork_frame = vfork_frame.unwrap();
        let mm3_shared_mapping = mm3_shared_mapping.unwrap();
        let _mm3_vfork_mapping = mm3_vfork_mapping.unwrap();

        // An unknown/unmapped frame claimed from a reservation that is never applied.
        let unknown_frame = {
            let capacity = FrameEventCapacity::for_event_count(1).expect("capacity");
            let mut res = fixture
                .authority
                .reserve(&fixture.ids, 1, 1, capacity)
                .expect("res");
            let frame = res.claim_frame().expect("unapplied frame");
            fixture.authority.abandon(res.transaction());
            frame
        };

        // Construct candidate extents to test against mm1
        let candidate_extents = vec![
            // Valid private extent for mm1
            (
                mm1_private_mapping,
                private_frame,
                Gpa(0x2000),
                length(0x4000),
            ),
            // Valid shared extent for mm1
            (
                mm1_shared_mapping,
                shared_frame,
                Gpa(0x1000),
                length(0x4000),
            ),
            // Sibling mm2's extent of the shared frame (not live in mm1)
            (
                mm2_shared_mapping,
                shared_frame,
                Gpa(0x1000),
                length(0x4000),
            ),
            // vfork child mm3's extent of the shared frame (not live in mm1)
            (
                mm3_shared_mapping,
                shared_frame,
                Gpa(0x1000),
                length(0x4000),
            ),
            // Sibling mm2's private extent (not live in mm1)
            (
                mm2_sibling_mapping,
                sibling_frame,
                Gpa(0x3000),
                length(0x4000),
            ),
            // Mismatched frame
            (
                mm1_private_mapping,
                shared_frame,
                Gpa(0x2000),
                length(0x4000),
            ),
            // Mismatched GPA
            (
                mm1_private_mapping,
                private_frame,
                Gpa(0x9000),
                length(0x4000),
            ),
            // Mismatched length
            (
                mm1_private_mapping,
                private_frame,
                Gpa(0x2000),
                length(0x8000),
            ),
        ];

        let candidate_frames = vec![
            shared_frame,
            private_frame,
            sibling_frame,
            vfork_frame,
            unknown_frame,
        ];

        let (batch_liveness, batch_counts) = fixture.authority.retirement_batch_query(
            fixture.mm1,
            &candidate_extents,
            &candidate_frames,
        );

        // Prove exact equivalence against point queries
        for (i, &(cand_map, frame, gpa, length)) in candidate_extents.iter().enumerate() {
            let point_live =
                fixture
                    .authority
                    .mapping_is_live_exact(fixture.mm1, cand_map, frame, gpa, length);
            assert_eq!(
                batch_liveness[i], point_live,
                "extent #{i} mismatch between batch and point query"
            );
        }
        for (j, &frame) in candidate_frames.iter().enumerate() {
            let point_count = fixture.authority.frame_mapping_count(frame);
            assert_eq!(
                batch_counts[j], point_count,
                "frame #{j} mismatch between batch and point query"
            );
        }

        // Exact expected values
        assert_eq!(
            batch_liveness,
            vec![true, true, false, false, false, false, false, false]
        );
        assert_eq!(batch_counts, vec![Some(3), Some(1), Some(1), Some(1), None]);
    }
}

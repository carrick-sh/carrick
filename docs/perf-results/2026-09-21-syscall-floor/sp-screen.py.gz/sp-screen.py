from pathlib import Path
import hashlib,json,os,re,statistics,subprocess,time
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'target/lease-cost/sp-screen'; OUT.mkdir(exist_ok=False)
IMAGE='localhost:5050/ltp@sha256:bc75ded40c5827f2ec9e1891edc23b988beae3f428f5be2c8fd7e3ee52fee80b'
PROBE=ROOT/'conformance-probes/target/aarch64-unknown-linux-musl/release/perf_inotify09_scale'
ARMS={'base':ROOT/'target/lease-cost/carrick-base','candidate':ROOT/'target/lease-cost/carrick-sp'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={str(p):sha(p) for p in [PROBE,*ARMS.values()]}
(OUT/'inputs.json').write_text(json.dumps(expected,indent=2))
records=[]
for index,arm in enumerate(['base','candidate','candidate','base']*2):
 for name,h in expected.items():assert sha(Path(name))==h
 run_id=f'syscall-sp-screen-{index}-{arm}'
 argv=[str(ARMS[arm]),'run','--max-traps','18446744073709551615','--fs','host','-v',f'{PROBE}:/probe:ro',IMAGE,'/bin/sh','-c','/probe watch-only']
 env=os.environ.copy();env['CARRICK_RUN_ID']=run_id
 start=time.monotonic()
 p=subprocess.run(argv,env=env,stdin=subprocess.DEVNULL,capture_output=True,text=True)
 elapsed=time.monotonic()-start
 (OUT/f'{index}-{arm}.out').write_text(p.stdout);(OUT/f'{index}-{arm}.err').write_text(p.stderr)
 values={}
 for line in p.stdout.splitlines():
  m=re.fullmatch(r'phase=(\w+) scale=(\d+) samples=21 p50_ns_per_iter=(\d+) complete=1',line)
  if m: values[f'{m[1]}:{m[2]}']=int(m[3])
 record={'index':index,'arm':arm,'argv':argv,'run_id':run_id,'returncode':p.returncode,'elapsed_s':elapsed,'values':values}
 with (OUT/'runs.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 assert p.returncode==0,(run_id,p.returncode,p.stderr)
 assert len(values)==15,(run_id,values)
 records.append(record)
 print(f'{index} {arm}: '+str({k:v for k,v in values.items() if k.endswith(':65536')}),flush=True)
ratios={}
for key in records[0]['values']:
 blocks=[]
 for off in [0,4]:
  a=statistics.mean([records[off]['values'][key],records[off+3]['values'][key]])
  b=statistics.mean([records[off+1]['values'][key],records[off+2]['values'][key]])
  blocks.append(b/a)
 ratios[key]={'block_ratios':blocks,'geomean_candidate_over_base':statistics.geometric_mean(blocks)}
for name,h in expected.items():assert sha(Path(name))==h
(OUT/'ratios.json').write_text(json.dumps(ratios,indent=2))
print(json.dumps({k:v for k,v in ratios.items() if k.endswith(':65536')},indent=2),flush=True)

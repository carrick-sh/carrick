https://github.com/carrick-sh/carrick/issues/1715

State when read: open.

x86: node image exceeds the CPL0 carrier initial memory budget on KVM

**What fails:** `node:22-slim` with `--entrypoint /usr/local/bin/node` fails before boot on x86_64 carrick (KVM): `trap engine failed: hypervisor operation failed: initial image exceeds carrier memory budget`, from `Cpl0Carrier::initial_extent_bytes_for`. Found by #1711.

**Acceptance:** find the budget and why node's image (about 100 MB binary) exceeds it on x86 but not ARM. The initial image should map lazily like ARM's rather than reserving the whole extent; never just raise a constant. Witness on KVM: `node -e "console.log(1)"` boots past the carrier.

Part of #1711.
